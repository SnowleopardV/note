## JavaScript规范

### 一、命名

#### 1. 全局常量名全部大写并单词间用下划线分隔
```javascript
const YMM_DOMAIN = '//www.ymm56.com/'
```
#### 2. 对象的属性、函数名、变量名使用小驼峰式
```javascript
const guideObj = {
  guideFunction() {

  },
  guideProperty: 1
}
```
#### 3. 文件夹、文件的命名与命名空间应能代表代码功能，可读性强
#### 4. React组件文件名首字母统一大写，其余js文件首字母统一小写

### 二、代码格式

#### 1. 缩进为2个ASCII空格
```javascript
if (index) {
  console.log(1)
}
```
#### 2. 关键词、条件括弧后面使用空格；运算操作符号两侧使用空格；语句分割符","后面使用空格
```javascript
let num = 0, index = 1
if (true) {
  num += 1
}
```
#### 3. 左大括号"{"居行尾; 右大括号"}"单独占一行, 居行首
```javascript
const fn = () => {

}
```
#### 4. 句末不使用分号结尾
##### 错误
```javascript
let a = 1;
```
##### 正确
```javascript
let a = 1
```
#### 5. 单行过长应在适当位置予以换行,增强可读性
```javascript
if (
  (true || true) ||
  (false && false) &&
  (true || false)
)
```
#### 6. if、while、for、do、case语句的执行体总是用"{"和"}"括起来，即使在其结构体内只有一条语句
#### 7. 语法意义相互独立的代码将用空行分隔

### 三、 注意事项
#### 1. 数组避免额外的逗号（[1, 2, 3, ]）
##### 错误
```javascript
const a = [1, 2, 3,]
```
##### 正确
```javascript
const a = [1, 2, 3]
```
#### 2. 数据自己能把控的， 使用严格的条件判断符。用===代替==，用!==代替!=
#### 3. Number、String、Boolean、Object、Array的对象不使用new声明
#### 4. 字符串拼接应使用数组保存字符串片段，使用时调用join方法。避免使用+或+=的方式拼接较长的字符串，每个字符串都会使用一个小的内存片段，过多的内存片段会影响性能
##### 错误
```javascript
const a = 'a' + 'b' + 'c' + 'd' + 'f'
```
##### 正确
```javascript
const a = ['a', 'b', 'c', 'd', 'f'].join('')
```

### 四、React组件规范
```javascript
import React, { Component, PropTypes } from 'react'

import XXXX from '../XXXX/XXXX'
import XXXX from '../../../XXXX/XXXX'

export default class Guide extends Component {
  constructor(props) {
    super(props)
  }

  componentWillMount() {}

  componentDidMount() {}

  componentWillReceiveProps() {}


  shouldComponentUpdate() {}

  componentWillUpdate() {}

  componentDidUpdate() {}

  componentWillUnmount() {}

  // 响应事件的方法
  handleClick = () => {}

  // 其他方法
  translateDate = () => {}

  // 渲染dom的方法
  renderTopBanner = () => {}

  render() {}
}

Guide.propTypes = {}

Guide.defaultProps = {}
```
### 五、代码注释
#### 1.Javascript支持三种不同类型的注释：行内注释、单行注释和多行注释<br />
#### 2.行内注释和单行注释时，使用一个空格分开文本和斜杠<br />
#### 3.多行注释包括注释描述，注释参数等<br />
#### 4.推荐使用vscode,并安装Document this这个插件

##### 正确
```javascript
 // 单行注释demo
 const companyName = '运满满'
 const cityName = '南京' // 行内注释demo
 /**
   * 根据用户id和姓名获取用户信息
   * @author ymm developer
   * @param {any} userId 用户Id
   * @param {any} name 用户姓名  
 */
 getUserInfoByUserIdAndName = (userId, name) => {}
```
##### 错误
```javascript
 //注释demo
 //  注释demo
```