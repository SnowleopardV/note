import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, Theme, MBText, Whitespace } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
type listType = {
  label: string;
  value: string;
};
// 单选选择 模态框
interface Props {
  visible?: boolean;
  noData?: string;
  title: string;
  list: listType[];
  onConfirm?: (item: listType, index: number) => void;
  onCancel?: () => void;
}
export default class SelectModal extends React.Component<Props, any> {
  static defaultProps = {
    list: [],
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      index: 0,
    };
  }
  handleConfirm = () => {
    const { onConfirm, list } = this.props;
    const { index } = this.state;
    onConfirm && onConfirm(list[index], index);
  };
  handleCancel = () => {
    const { onCancel } = this.props;
    onCancel && onCancel();
  };
  handleChange = (index: number) => {
    this.setState({ index: index });
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: autoFix(80), width: autoFix(80), justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  get listDate() {
    const { list } = this.props;
    return (
      list?.map((item: listType) => {
        return {
          ...item,
          content(selected: boolean) {
            return (
              <Flex direction="row" justify="center" align="center">
                <MBText bold={selected} size={selected ? 'md' : 'sm'} color={selected ? 'primary' : '#333333'} numberOfLines={1}>
                  {item.label}
                </MBText>
              </Flex>
            );
          },
        };
      }) || []
    );
  }
  render() {
    const { visible, noData, title } = this.props;
    const { index } = this.state;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight={this.rightElement()}
          title={title}
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          {this.listDate.length ? (
            <Flex direction="row" justify="center" align="center">
              <Flex.Item key="time">
                <View style={{ flexDirection: 'column' }}>
                  <Selector type={1} value={index} rowTitle="content" list={this.listDate} scaleFont={true} onChange={this.handleChange} />
                </View>
              </Flex.Item>
            </Flex>
          ) : (
            <MBText style={{ marginVertical: 50 }} color="#999999">
              {noData ? noData : '暂无数据'}
            </MBText>
          )}
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({});
