import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { MBText, Whitespace } from '@ymm/rn-elements';
import AddressList from '~/components/AddressList';
import InputItem from '~/components/common/InputItem';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

/**
 * 装卸货地址组件
 */

export interface StateAddressModel {
  districtCode: 0; // 区code
  districtName: ''; // 区名称
  provinceCode: 0; // 省code
  provinceName: ''; // 省名称
  cityCode: 0; // 市code
  cityName: ''; // 市名称
  address: ''; // 地址
  addressLongitude: '0'; // 经度
  addressLatitude: '0'; // 纬度
  addressMapType: 2; // 地图类型：1-百度 2-高德
}

interface AddressRequiredConfigModel {
  loadAddressConfig?: boolean;
  unloadAddressConfig?: boolean;
}

interface LoadUnloadAddressProps {
  editable?: boolean;
  dispatchType?: number;
  addressValue?: string;
  addressType?: number; // 0 装货，1 卸货
  addressConfig?: boolean;
  isRulesTips?: boolean;
  isAddressChanged?: boolean;
  searchLoading?: boolean;
  addressList: StateAddressModel[];
  onChange: (data: any) => void;
  onFoucs: (data: any) => void;
  onBlur: (data: any) => void;
  onSelect: (data: any) => void;
}

const extraElement = (text: string) => {
  return (
    <View style={{ paddingRight: autoFix(28) }}>
      <MBText size="xs" color="#F54242" align="right">
        {text}
      </MBText>
      <Whitespace vertical={12} />
    </View>
  );
};

const LoadUnloadAddress: React.FunctionComponent<LoadUnloadAddressProps> = (props) => {
  const {
    editable = true,
    dispatchType,
    addressValue,
    addressType,
    addressConfig,
    addressList,
    isRulesTips,
    isAddressChanged,
    searchLoading,
    onChange,
    onFoucs,
    onBlur,
    onSelect,
  } = props;

  return (
    <View style={addressType ? styles.unloadAddressWrapper : styles.loadAddressWrapper}>
      <InputItem
        required
        bottomLine
        editable={editable}
        requiredStyle={!editable ? styles.inputDisabledStyle : {}}
        titleStyle={!editable ? [styles.inputDisabledStyle, styles.inputTitleStyle] : styles.inputTitleStyle}
        inputStyle={!editable ? styles.inputDisabledStyle : {}}
        title={addressType ? '卸货地址' : '装货地址'}
        placeholder="请输入"
        maxLength={100}
        value={addressValue}
        onChangeText={(value) => onChange({ value, addressType, dispatchType })}
        textAlign="right"
        extra={isRulesTips && !addressValue && extraElement(addressType ? '卸货地址未选择' : '装货地址未选择')}
        onFocus={() => onFoucs({ addressType, dispatchType })}
        onBlur={() => onBlur({ addressType })}
        onSubmitEditing={() => {}}
      />
      {/* {addressList.length && isAddressChanged && addressValue ? (
        <View style={styles.addressAssociate}>
          <AddressList
            inputText={addressValue}
            addressList={addressList}
            onSelect={(item) => onSelect({ item, addressType, dispatchType })}
          />
        </View>
      ) : addressConfig && !searchLoading && isAddressChanged && addressValue ? (
        <View style={styles.addressAssociate}>
          <Whitespace vertical={14} />
          <MBText align="center" color="#ccc">
            无搜索结果
          </MBText>
        </View>
      ) : null} */}
    </View>
  );
};

const styles = StyleSheet.create({
  loadAddressWrapper: {
    position: 'relative',
    backgroundColor: '#fff',
    zIndex: 99,
  },

  unloadAddressWrapper: {
    position: 'relative',
    backgroundColor: '#fff',
    zIndex: 98,
  },

  addressAssociate: {
    position: 'absolute',
    left: autoFix(145),
    top: autoFix(86),
    width: autoFix(540),
    minHeight: autoFix(132),
    maxHeight: autoFix(532),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 5, height: 5 },
    shadowRadius: autoFix(20),
    elevation: 20,
    borderRadius: autoFix(8),
  },

  inputDisabledStyle: {
    color: '#ccc',
  },

  inputTitleStyle: {
    paddingRight: autoFix(8),
  },
});

export default LoadUnloadAddress;
