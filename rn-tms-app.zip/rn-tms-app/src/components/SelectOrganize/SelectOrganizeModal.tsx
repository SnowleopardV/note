import { Flex, Modal, Selector, Whitespace } from '@ymm/rn-elements';
import React, { PureComponent } from 'react';
import { StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native';

// 选择弹窗
export interface Props {
  onChange?: (item: any) => void;
  visible: boolean;
  list: Array<any>;
}
export default class SelectOrganizeModal extends PureComponent<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      index: 0,
      item: null,
    };
  }
  componentWillReceiveProps(next: any) {
    if (next.visible && next.list?.length) {
      this.setState({ index: 0, item: next.list[0] });
    }
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { item } = this.state;
    onChange && onChange(item);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange(null);
  };
  handleChange = (val: any, item: any) => {
    this.setState({ index: val, item: item });
  };
  render() {
    const { visible, list } = this.props;
    const { index } = this.state;
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight="确定"
          title="请选择运单所属组织"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row" justify="center" align="center">
            <Flex.Item key="time">
              <View style={{ flexDirection: 'column' }}>
                <Selector type={1} value={index} rowTitle="orgName" list={list} onChange={this.handleChange} />
              </View>
            </Flex.Item>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
