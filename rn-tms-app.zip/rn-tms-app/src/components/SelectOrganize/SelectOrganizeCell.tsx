import { CellGroup, Whitespace } from '@ymm/rn-elements';
import React, { PureComponent } from 'react';
import { View } from 'react-native';
import Cell from '~/components/common/Cell';
import SelectOrganizeModal from './SelectOrganizeModal';
import { inject, observer } from 'mobx-react';
import server from '~/server';
// 表单显示用
export interface Props {
  placeholder?: string;
  store?: any;
  readonly?: boolean; // 只读 文字置灰 调度页面置灰不用选择， 运单页需要选择
  from?: number;
}

@inject('store')
@observer
export default class SelectOrganizeCell extends PureComponent<Props, any> {
  static defaultProps = {
    placeholder: '请选择运单所属组织',
    readonly: true,
  };
  constructor(props: any) {
    super(props);
    this.state = {
      showModel: false,
      list: [],
    };
  }
  componentDidMount() {
    const { readonly } = this.props;
    if (!readonly) {
      this.api_orgList();
    }
  }
  /** 组织列表 */
  api_orgList() {
    server({ url: '/saas-tms-trans/yzgApp/org/create/order/list', data: {} }).then((res: any) => {
      console.log('=================组织列表=================');
      console.log(res);
      if (res?.data) {
        this.setState({ list: res.data });
        if (res.data.length === 1) {
          // 如果列表只有一条数据，默认选择这条，点击不显示弹窗
          this.props.store.saveStateData({ orgId: res.data[0].orgId, orgName: res.data[0].orgName });
        }
      }
    });
  }
  handleShow = () => {
    this.setState({ showModel: true });
  };
  handleCancel = (val: any) => {
    this.setState({ showModel: false });
    if (val) {
      // 将选择中的组件保存下
      this.props.store.saveStateData({ orgId: val.orgId, orgName: val.orgName });
    }
  };
  render() {
    const { placeholder, store, from, readonly } = this.props;
    const { showModel, list } = this.state;
    let orgName = null;
    if (readonly) {
      orgName = store['formData_' + from].orgName; // 调度
    } else {
      orgName = store?.stateData?.orgName; // 运单
    }

    return (
      (!!orgName || list.length > 1) && (
        <View>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell
              title="组织"
              align="right"
              readonly={readonly || list.length < 2}
              value={orgName}
              placeholder={placeholder}
              numberOfLines={1}
              onPress={this.handleShow}
            />
          </CellGroup>
          <SelectOrganizeModal visible={showModel} onChange={this.handleCancel} list={list} />
        </View>
      )
    );
  }
}
