import * as React from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import images from '~public/static/images';

interface Props {
  text: string;
}

export default class TipsText extends React.Component<Props, any> {
  constructor(props: Props) {
    super(props);
  }
  render() {
    const { text } = this.props;
    return (
      <View style={styles.tipsBox}>
        <Image style={{ height: autoFix(30), width: autoFix(30), marginRight: autoFix(6) }} source={images.icon_warning_yellow} />
        <View style={{ flex: 1 }}>
          <MBText style={[styles.text]}>{text}</MBText>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  tipsBox: {
    paddingHorizontal: autoFix(30),
    paddingVertical: autoFix(12),
    flexDirection: 'row',
    backgroundColor: '#FFFBE6',
  },
  text: {
    color: '#FFBB44',
    padding: 0,
    fontSize: autoFix(26),
  },
});
