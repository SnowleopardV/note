import * as React from 'react';
import { MBText, RNElementsUtil, Modal, Whitespace } from '@ymm/rn-elements';
import { Dimensions, Image, ScrollView, View } from 'react-native';
import images from '~public/static/images';
import commonData from '~/pages/commonData';
import { MBBridge } from '@ymm/rn-lib';
const { height: winHeight } = Dimensions.get('window');
export interface Props {
  navigation: any;
  allFailure?: boolean; // 是否发货都失败了
}
export default class OpenDispatchResultModal extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      visible: false,
      list: commonData.cargoRespList,
      id: commonData.gotoId.id,
      type: commonData.gotoId.type,
      number: '', // 编号
    };
  }
  /**
   * 满帮找车发货结果弹窗，
   */
  openModal(number?: string) {
    this.setState(
      {
        list: commonData.cargoRespList,
        id: commonData.gotoId.id,
        type: commonData.gotoId.type,
        number: number,
      },
      () => {
        console.log('满帮找车发货结果弹窗');
        if (commonData.cargoRespList) {
          this.setState({ visible: true });
          commonData.gotoId = { id: null, type: null };
          commonData.cargoRespList = null;
        }
      }
    );
  }
  handleConfirm = () => {
    this.setState({ visible: false });
    const { id, type, number } = this.state;
    if (!this.props.allFailure) {
      // 如果全部发货失败 不跳转
      this.props?.navigation?.navigate(
        'CarBoard',
        type == 'task' ? { taskNo: number, id: id, type: 2 } : { orderNo: number, id: id, type: 1 }
      );
    }
  };
  handleCancel = () => {
    this.setState({ visible: false });
  };
  render() {
    const { visible, list } = this.state;
    const modalHeigh: number = winHeight ? winHeight * 0.5 : RNElementsUtil.autoFix(600);
    return (
      <Modal
        modalType="View"
        animationType="slide"
        title="满帮找车发货结果"
        position="center"
        visible={visible}
        headerLine={false}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        // onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
        cancelText={this.props.allFailure ? false : '知道了'}
        confirmText={this.props.allFailure ? '知道了' : '去查看'}
      >
        <ScrollView style={{ maxHeight: modalHeigh, width: RNElementsUtil.autoFix(520) }}>
          {list?.map((item: any) => {
            const data = [];
            item.dispatcherName && data.push(<MBText numberOfLines={1}>{item.dispatcherName}</MBText>);
            item.dispatcherPhone && data.push(<MBText>/{item.dispatcherPhone}</MBText>);
            data.push(<MBText>{`（剩${item.remainDispatchNumber || 0}次）`}</MBText>);
            return (
              <View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, flexWrap: 'wrap' }}>{data}</View>
                  {item.successFlag ? (
                    <Image style={{ height: 12, width: 16, marginTop: 5 }} source={images.icon_hook_mark} />
                  ) : (
                    <Image style={{ height: 16, width: 16, marginTop: 3 }} source={images.icon_cross_mark} />
                  )}
                </View>
                {!!item.failErrorMsg && (
                  <View style={{ width: '100%' }}>
                    <MBText color="#999999" size="xs">
                      {item.failErrorMsg}
                    </MBText>
                  </View>
                )}
              </View>
            );
          })}
          <Whitespace vertical={20} />
        </ScrollView>
      </Modal>
    );
  }
}
