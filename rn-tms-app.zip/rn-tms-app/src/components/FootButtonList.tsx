import { MBText, Modal, RNElementsUtil, Splitline, Whitespace } from '@ymm/rn-elements';
import { HandleOnceUtil, MBToast } from '@ymm/rn-lib';
import * as React from 'react';
import { View, StyleSheet, TouchableOpacity, Image, TouchableWithoutFeedback } from 'react-native';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

// 列表 详情底部按钮区域
interface Props {
  onConfirm?: any;
  buttonList: any[];
  maxShowNum: number;
  keyText?: string;
  isClosedBeiDouTrace?: boolean;
  isFromWaybillDetail?: boolean;
}
interface State {
  visible: boolean;
}
export default class FootButtonList extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      visible: false,
    };
  }
  get footBtnList() {
    const { buttonList, maxShowNum } = this.props;
    return buttonList.slice(0, buttonList.length + 1 > maxShowNum ? maxShowNum : maxShowNum);
  }

  handleConfirm = (item: any) => {
    const { onConfirm } = this.props;
    onConfirm && onConfirm(item);
  };
  showBtnModal = () => {
    this.setState({ visible: true });
  };
  onCancel = () => {
    this.setState({ visible: false });
  };
  selectItem(item: any) {
    this.setState({ visible: false }, () => this.handleConfirm(item));
  }

  modalElement() {
    const { visible } = this.state;
    const { buttonList, maxShowNum } = this.props;
    const list = buttonList.slice(maxShowNum);
    return (
      <Modal animationType="slide" position="bottom" visible={visible} onMaskClose={this.onCancel} onRequestClose={this.onCancel}>
        {list.map((item: any, index: number) => {
          return (
            <View key={index} style={{ width: '100%' }}>
              <TouchableOpacity style={styles.selectItem} onPress={() => this.selectItem(item)}>
                <MBText color={item.disabled ? '#ccc' : ''}>{item.name}</MBText>
              </TouchableOpacity>
              <Splitline color="#F7F7F7" />
            </View>
          );
        })}
        <View style={{ backgroundColor: '#F7F7F7', width: 400, height: 10 }}></View>
        <TouchableOpacity style={[styles.selectItem, { width: '100%' }]} onPress={this.onCancel.bind(this)}>
          <MBText>取消</MBText>
        </TouchableOpacity>
        <Whitespace vertical={20} />
      </Modal>
    );
  }
  render() {
    const { buttonList, maxShowNum, keyText, isClosedBeiDouTrace, isFromWaybillDetail } = this.props;
    return (
      <View style={styles.listBox}>
        {this.footBtnList?.map((btn: any) => (
          <TouchableOpacity
            key={keyText ? keyText + btn.code : btn.code}
            activeOpacity={0.3}
            onPress={() => HandleOnceUtil.callOnceInInterval(() => this.handleConfirm(btn), 1000)}
          >
            <View style={styles.btn}>
              {btn.badge && (
                <View style={styles.badgeBox}>
                  <MBText style={styles.badgeText} color="#FFFFFF">
                    {btn.badge}
                  </MBText>
                </View>
              )}

              {btn.code === 'TRACE' && !isClosedBeiDouTrace && isFromWaybillDetail ? (
                <View style={styles.btnTooltip}>
                  <MBText style={styles.btnTooltipText} color="#FFFFFF">
                    查看精准北斗定位
                  </MBText>
                  <View style={styles.toolTipTriangle}></View>
                </View>
              ) : null}
              <MBText style={styles.btnTxt}>{btn.name}</MBText>
            </View>
          </TouchableOpacity>
        ))}

        {buttonList.length > maxShowNum && (
          <TouchableOpacity
            key="moreBtn"
            activeOpacity={0.3}
            onPress={() => HandleOnceUtil.callOnceInInterval(() => this.showBtnModal(), 1000)}
          >
            <View style={styles.moreBtn}>
              <Image
                fadeDuration={0}
                resizeMode="stretch"
                style={{ width: RNElementsUtil.autoFix(25), height: RNElementsUtil.autoFix(6) }}
                source={images.icon_more}
              />
            </View>
          </TouchableOpacity>
        )}
        {buttonList.length > maxShowNum && this.modalElement()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  listBox: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  btn: {
    paddingVertical: RNElementsUtil.autoFix(10),
    paddingHorizontal: RNElementsUtil.autoFix(26),
    borderRadius: RNElementsUtil.autoFix(50),
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: RNElementsUtil.autoFix(12),
    position: 'relative',
  },
  btnTxt: {
    fontSize: RNElementsUtil.autoFix(24),
    fontWeight: 'bold',
    color: '#4885FF',
  },
  moreBtn: {
    borderRadius: 1000,
    borderColor: '#4885FF',
    borderWidth: 1,
    height: RNElementsUtil.autoFix(55),
    width: RNElementsUtil.autoFix(55),
    marginLeft: RNElementsUtil.autoFix(12),
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectItem: {
    width: '100%',
    height: RNElementsUtil.autoFix(100),
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeBox: {
    position: 'absolute',
    top: -RNElementsUtil.autoFix(30),
    left: RNElementsUtil.autoFix(16),
    backgroundColor: '#f31432',
    borderTopLeftRadius: RNElementsUtil.autoFix(20),
    borderTopRightRadius: RNElementsUtil.autoFix(20),
    borderBottomRightRadius: RNElementsUtil.autoFix(20),
    borderBottomLeftRadius: 0,
    width: RNElementsUtil.autoFix(100),
    height: RNElementsUtil.autoFix(40),
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    fontSize: RNElementsUtil.autoFix(20),
  },

  btnTooltip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#000000',
    borderRadius: RNElementsUtil.autoFix(10),
    position: 'absolute',
    top: RNElementsUtil.autoFix(-90),
    left: RNElementsUtil.autoFix(-43),
    width: RNElementsUtil.autoFix(260),
    height: RNElementsUtil.autoFix(60),
    paddingHorizontal: RNElementsUtil.autoFix(28),
    opacity: 0.7,
    zIndex: 100,
  },

  toolTipTriangle: {
    position: 'absolute',
    bottom: RNElementsUtil.autoFix(-8),
    right: RNElementsUtil.autoFix(122),
    borderStyle: 'solid',
    borderBottomColor: '#000000',
    borderBottomWidth: RNElementsUtil.autoFix(16),
    borderLeftWidth: RNElementsUtil.autoFix(16),
    borderLeftColor: 'transparent',
    transform: [{ rotate: '45deg' }],
  },

  btnTooltipText: {
    fontSize: RNElementsUtil.autoFix(24),
    color: '#fff',
  },
});
