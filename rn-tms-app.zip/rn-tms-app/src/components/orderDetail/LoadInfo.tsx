import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { MBText, Splitline, RNElementsUtil } from '@ymm/rn-elements';
import Cell from '../common/Cell';
import Popup from './Popup';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import LevelTag from '../LevelTag';

// 装卸信息
export default class LoadInfo extends React.Component {
  constructor(props: any) {
    super(props);
    this.state = {
      visible: false,
    };
  }

  handleOpen = () => {
    this.setState({
      visible: true,
    });
  };

  handleClose = () => {
    this.setState({
      visible: false,
    });
  };

  renderItem = (item, index, length = 1, type = 'load') => {
    let label = '';
    if (type === 'load') {
      label = length > 1 ? `装${index + 1}` : '装';
    } else {
      label = length > 1 ? `卸${index + 1}` : '卸';
    }
    return (
      <View key={index} style={styles.item}>
        {!!item.estimateTimeDesc && (
          <View style={styles.timeLine}>
            <Image style={{ width: autoFix(36), height: autoFix(36) }} source={{ uri: images.icon_time }} />
            <MBText style={styles.time}>{item.estimateTimeDesc}</MBText>
          </View>
        )}
        <View style={styles.address}>
          <View style={[styles.loadType, type === 'unload' && { backgroundColor: '#333' }]}>
            <MBText style={styles.label}>{label}</MBText>
          </View>
          <View style={styles.addressText}>
            {/* <MBText style={styles.mainText}>{item.areaAddress || '--'}</MBText> */}
            <MBText style={styles.subText}>{item.address || '--'}</MBText>
          </View>
        </View>
        {item.companyName ? (
          <View style={styles.contacText}>
            <MBText style={[styles.subText]}>{item.companyName}</MBText>
          </View>
        ) : null}
        {item.contactName || item.contactPhone ? (
          <View style={styles.contacText}>
            {!!item.contactName && <MBText style={[styles.subText, styles.contactName]}>{item.contactName}</MBText>}
            <MBText style={styles.subText}>{item.contactPhone}</MBText>
          </View>
        ) : null}
      </View>
    );
  };

  render() {
    const { loads, unLoads, custName, orderFeature } = this.props;
    const show = loads.length || unLoads.length;
    const { visible } = this.state;

    // 最多显示1条
    const max = 1;
    const showMore = loads.length > max || unLoads.length > max;
    return (
      !!show && (
        <View style={styles.container}>
          <Cell
            name="address"
            title="装卸信息"
            align="right"
            value={showMore ? '更多装卸地址' : ''}
            isLink={showMore}
            contentStyle={showMore ? styles.contentStyle : styles.noValSty}
            titleStyle={styles.titleStyle}
            valueStyle={styles.valueStyle}
            onPress={showMore && this.handleOpen}
          />
          <View style={styles.content}>
            {!!custName && (
              <View style={[styles.flexRow, styles.flexing]}>
                <Image style={{ height: autoFix(36), width: autoFix(36) }} source={{ uri: images.icon_peopleGary }} />
                <MBText style={styles.custName}>{custName || '--'}</MBText>
                {!!orderFeature && !!orderFeature['f.a'] && <LevelTag text={orderFeature['f.a']} isFull />}
              </View>
            )}
            {loads.slice(0, max).map((item, index) => this.renderItem(item, index, loads.length))}
            <Splitline color="#e8e8e8" style={styles.splitline} />
            {unLoads.slice(0, max).map((item, index) => this.renderItem(item, index, unLoads.length, 'unload'))}
          </View>
          <Popup title="装卸信息" visible={visible} onClose={this.handleClose}>
            {loads.map((item, index) => this.renderItem(item, index, loads.length))}
            <Splitline color="#e8e8e8" style={styles.splitline} />
            {unLoads.map((item, index) => this.renderItem(item, index, unLoads.length, 'unload'))}
          </Popup>
        </View>
      )
    );
  }
}

LoadInfo.defaultProps = {
  loads: [],
  unLoads: [],
  custName: '',
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: autoFix(4),
    marginBottom: autoFix(20),
    marginHorizontal: autoFix(18),
    paddingTop: autoFix(12),
  },
  content: {
    paddingLeft: autoFix(28),
  },
  flexing: {
    flex: 1,
  },
  item: {
    paddingBottom: autoFix(26),
    paddingRight: autoFix(20),
  },
  contentStyle: {
    paddingVertical: autoFix(16),
  },
  noValSty: {
    paddingVertical: autoFix(35),
  },
  titleStyle: {
    fontSize: autoFix(24),
    color: '#999',
  },
  valueStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'normal',
    marginRight: autoFix(10),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: autoFix(20),
  },
  timeLine: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: autoFix(20),
  },
  time: {
    fontSize: autoFix(24),
    color: '#666',
    marginLeft: autoFix(28),
  },
  address: {
    flexDirection: 'row',
  },
  loadType: {
    width: autoFix(36),
    height: autoFix(36),
    borderRadius: autoFix(6),
    backgroundColor: '#4885FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: autoFix(24),
  },
  label: {
    fontSize: autoFix(22),
    color: '#fff',
  },
  addressText: {
    flex: 1,
    justifyContent: 'center',
  },
  mainText: {
    fontSize: autoFix(24),
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
  },
  subText: {
    fontSize: autoFix(24),
    includeFontPadding: false,
    // marginTop: RNElementsUtil.autoFix(10),
  },
  splitline: {
    marginBottom: autoFix(30),
  },
  custName: {
    marginLeft: autoFix(24),
    fontSize: autoFix(24),
    color: '#333',
    flexShrink: 1,
  },

  contacText: {
    flexDirection: 'row',
    paddingLeft: autoFix(60),
    marginTop: autoFix(6),
  },

  contactName: {
    marginRight: autoFix(6),
  },
});
