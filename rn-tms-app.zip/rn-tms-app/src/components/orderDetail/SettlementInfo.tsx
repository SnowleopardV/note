import React from 'react';
import { StyleSheet } from 'react-native';
import { CellGroup } from '@ymm/rn-elements';
import Cell from '../common/Cell';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

// 结算方式
export default class SettlementInfo extends React.Component {
  constructor(props: any) {
    super(props);
  }

  render() {
    const { info } = this.props;
    const show = info.length;
    return (
      !!show && (
        <CellGroup withBottomLine={false} style={styles.groupStyle}>
          <Cell
            name="settlement"
            title="结算方式"
            isLink={false}
            contentStyle={styles.contentStyle}
            titleStyle={styles.titleStyle}
            valueStyle={styles.valueStyle}
          />
          {info.map((item, index) => (
            <Cell
              key={index}
              name={index}
              title={item.settleTypeDesc}
              align="right"
              value={item.amountDesc}
              bottomLine
              isLink={false}
              contentStyle={styles.contentStyle}
              titleStyle={styles.subTitleStyle}
              valueStyle={styles.valueStyle}
            />
          ))}
        </CellGroup>
      )
    );
  }
}

SettlementInfo.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: autoFix(20),
    paddingTop: autoFix(20),
  },
  contentStyle: {
    paddingVertical: autoFix(28),
  },
  titleStyle: {
    fontSize: autoFix(24),
    color: '#999',
  },
  subTitleStyle: {
    fontSize: autoFix(24),
  },
  valueStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'bold',
    marginRight: 0,
  },
});
