import React from 'react';
import { StyleSheet } from 'react-native';
import { CellGroup } from '@ymm/rn-elements';
import Cell from '../common/Cell';
import CellDepositDetail from '~/pages/task-manage/components/ReturnDeposit/CellDepositDetail';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

// 费用信息
export default class FeeInfo extends React.Component {
  constructor(props: any) {
    super(props);
  }

  render() {
    const { info, dispatcherMode, depositDetail } = this.props;
    const show = info.length;
    return (
      !!show && (
        <CellGroup withBottomLine={false} style={styles.groupStyle}>
          <Cell
            name="fee"
            title={dispatcherMode == '1' ? '成本费用' : '费用信息'}
            isLink={false}
            contentStyle={styles.contentStyle}
            titleStyle={styles.titleStyle}
            valueStyle={styles.valueStyle}
          />
          {info.map((item, index) => (
            <Cell
              key={index}
              name={index}
              title={item.name}
              align="right"
              value={item.value}
              bottomLine
              isLink={false}
              contentStyle={styles.contentStyle}
              titleStyle={styles.subTitleStyle}
              valueStyle={styles.valueStyle}
            />
          ))}
          {!!depositDetail && <CellDepositDetail depositDetail={depositDetail} />}
        </CellGroup>
      )
    );
  }
}

FeeInfo.defaultProps = {
  info: {},
  dispatcherMode: '',
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: autoFix(20),
    paddingTop: autoFix(20),
  },
  contentStyle: {
    paddingVertical: autoFix(28),
  },
  titleStyle: {
    fontSize: autoFix(24),
    color: '#999',
  },
  subTitleStyle: {
    fontSize: autoFix(24),
  },
  valueStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'bold',
    marginRight: 0,
  },
});
