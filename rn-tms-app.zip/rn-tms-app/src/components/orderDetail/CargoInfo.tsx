import React from 'react';
import { View, StyleSheet } from 'react-native';
import { MBText, CellGroup } from '@ymm/rn-elements';
import Cell from '../common/Cell';
import Popup from './Popup';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

// 货物信息
export default class CargoInfo extends React.Component {
  constructor(props: any) {
    super(props);
    this.state = {
      visible: false,
    };
  }

  handleOpen = () => {
    this.setState({
      visible: true,
    });
  };

  handleClose = () => {
    this.setState({
      visible: false,
    });
  };

  render() {
    let { info } = this.props;
    const show = info.length;
    const { visible } = this.state;
    // 前台最多展示3条
    const max = 3;
    return (
      !!show && (
        <View>
          <CellGroup withBottomLine={false} style={styles.groupStyle}>
            <Cell
              name="cargo"
              title="货物信息"
              align="right"
              value={info.length > max ? '更多货物' : ''}
              isLink={info.length > max}
              contentStyle={info.length > max ? styles.contentStyle : styles.noValSty}
              titleStyle={styles.titleStyle}
              valueStyle={styles.moreStyle}
              onPress={info.length > max && this.handleOpen}
            />
            {info.slice(0, max).map((item, index) => (
              <Cell
                key={index}
                name={index}
                title={info.length > 1 ? `货物${index + 1}` : '货物'}
                align="right"
                value={item.cargoInfoForDisplay}
                isLink={false}
                contentStyle={styles.contentStyle}
                titleStyle={styles.subTitleStyle}
                valueStyle={styles.valueStyle}
              />
            ))}
          </CellGroup>
          <Popup title="货物信息" visible={visible} contentStyle={{ paddingHorizontal: 10 }} onClose={this.handleClose}>
            {info.map((item, index) => (
              <Cell
                key={index}
                name={index}
                title={`货物${index + 1}`}
                align="right"
                value={item.cargoInfoForDisplay}
                isLink={false}
                contentStyle={styles.contentStyle}
                titleStyle={styles.subTitleStyle}
                valueStyle={styles.valueStyle}
              />
            ))}
          </Popup>
        </View>
      )
    );
  }
}

CargoInfo.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: autoFix(20),
    paddingVertical: autoFix(12),
  },
  contentStyle: {
    paddingVertical: autoFix(16),
  },
  noValSty: {
    paddingVertical: autoFix(35),
  },
  titleStyle: {
    fontSize: autoFix(24),
    color: '#999',
  },
  subTitleStyle: {
    fontSize: autoFix(24),
  },
  moreStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'normal',
    marginRight: autoFix(10),
  },
  valueStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'bold',
    marginRight: 0,
  },
});
