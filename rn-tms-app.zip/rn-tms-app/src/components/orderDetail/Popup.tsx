import { StyleSheet, ScrollView, TouchableWithoutFeedback, SafeAreaView, View, TouchableOpacity } from 'react-native';
import React from 'react';
import { Modal, MBText } from '@ymm/rn-elements';

export default class Popup extends React.Component {
  constructor(props: any) {
    super(props);
  }

  handleClose = () => {
    this.props?.onClose();
  };

  renderHeaderRight() {
    return (
      <TouchableOpacity onPress={() => this.handleClose()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText style={styles.close}>关闭</MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { title, visible, contentStyle } = this.props;
    return (
      <SafeAreaView style={styles.flexing}>
        <Modal
          headerRight={this.renderHeaderRight()}
          title={title}
          position="bottom"
          visible={visible}
          autoAjdustPosition={true}
          headerLine={false}
          contentStyle={{ ...contentStyle }}
          onMaskClose={this.handleClose}
          onRequestClose={this.handleClose}
        >
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {this.props.children}
          </ScrollView>
        </Modal>
      </SafeAreaView>
    );
  }
}

Popup.defaultProps = {
  title: '',
  visible: false,
  contentStyle: {},
  onClose: () => {},
};

const styles = StyleSheet.create({
  flexing: {
    flex: 1,
    flexDirection: 'column',
  },
  close: {
    color: '#4885FF',
  },
  content: {
    width: '100%',
    maxHeight: 600,
    paddingTop: 6,
    paddingBottom: 20,
  },
});
