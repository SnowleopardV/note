import React from 'react';
import { View, StyleSheet, TouchableOpacity, Clipboard, Image } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import LevelTag from '../LevelTag';

// 状态栏
export default class StatusBar extends React.Component {
  constructor(props: any) {
    super(props);
  }

  copy = async (value) => {
    Clipboard.setString(value);
    const str = await Clipboard.getString();
    NativeBridge.toast(`复制成功${str}`);
  };

  renderCopy = (item) => {
    return (
      <TouchableOpacity activeOpacity={0.3} onPress={() => this.copy(item)}>
        <View style={styles.copy}>
          <Image style={{ width: 14, height: 16 }} source={images.icon_copy} />
        </View>
      </TouchableOpacity>
    );
  };
  get carTypeLength() {
    const { carLengthName, carTypeName } = this.props;
    const carTypeLengthList = [];
    !!carTypeName && carTypeLengthList.push(carTypeName);
    !!carLengthName && carTypeLengthList.push(carLengthName);
    return carTypeLengthList.join(' / ');
  }
  render() {
    const { info } = this.props;
    return (
      <View style={styles.StatusBar}>
        <MBText style={styles.status}>{info.status}</MBText>
        {!!info.orgName ? (
          <View style={styles.flexRow}>
            <MBText style={styles.orderNum} numberOfLines={1}>
              组织：{info.orgName}
            </MBText>
          </View>
        ) : null}

        {!!info.transOrderNo || this.carTypeLength ? (
          <View style={[styles.flexRow, styles.transOrderNoCarTypeLengthWrapper]}>
            <View style={styles.transOrderNoWrapper}>
              <MBText style={styles.orderNum}>{`运单号: ${info.transOrderNo}`}</MBText>
              {!!info.orderFeature && !!info.orderFeature['f.b'] && <LevelTag text={info.orderFeature['f.b']} isFull={false} />}
              {this.renderCopy(info.transOrderNo)}
            </View>

            {this.carTypeLength ? <MBText style={styles.carTypeLength}>需求：{this.carTypeLength}</MBText> : null}
          </View>
        ) : null}

        {!!info.taskNo ? (
          <View style={styles.flexRow}>
            <MBText style={styles.orderNum}>{`${info.taskType === '1' ? '提货单号' : '任务号'}: ${info.taskNo}`}</MBText>
            {this.renderCopy(info.taskNo)}
          </View>
        ) : null}

        {info.mybOrderId ? (
          <View style={styles.flexRow}>
            <MBText style={styles.orderNum}>平台单号: {info.mybOrderId}</MBText>
            {info.mybCorpIcon ? <Image style={{ width: autoFix(125), height: autoFix(30) }} source={{ uri: info.mybCorpIcon }} /> : null}
            {info.showMybCancel ? <MBText style={styles.isCancel}>已取消</MBText> : null}
            {this.renderCopy(info.mybOrderId)}
          </View>
        ) : null}
      </View>
    );
  }
}

StatusBar.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  StatusBar: {
    paddingTop: autoFix(20),
    paddingBottom: autoFix(24),
    paddingHorizontal: autoFix(36),
    backgroundColor: 'transparent',
  },
  status: {
    fontSize: autoFix(50),
    // fontFamily: 'PingFangSC-Medium, PingFang SC',
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: autoFix(14),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: autoFix(14),
  },
  orderNum: {
    fontSize: autoFix(20),
    color: '#fff',
    marginRight: autoFix(6),
    flexShrink: 1,
  },
  copy: {
    marginLeft: autoFix(6),
  },
  isCancel: {
    paddingHorizontal: autoFix(5),
    borderWidth: autoFix(1),
    fontSize: autoFix(20),
    borderRadius: autoFix(8),
    borderBottomLeftRadius: 0,
    color: '#fff',
    borderColor: '#fff',
    marginHorizontal: autoFix(6),
    opacity: 0.7,
  },

  carTypeLength: {
    marginRight: autoFix(28),
    fontSize: autoFix(22),
    color: '#fff',
    textAlign: 'right',
  },

  transOrderNoCarTypeLengthWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  transOrderNoWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});
