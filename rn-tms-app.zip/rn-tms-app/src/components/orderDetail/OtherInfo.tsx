import React from 'react';
import { StyleSheet, View } from 'react-native';
import { CellGroup, MBText } from '@ymm/rn-elements';
import dayjs from 'dayjs';
import Cell from '../common/Cell';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

// 其他信息
export default class OtherInfo extends React.Component {
  constructor(props: any) {
    super(props);
  }

  render() {
    const { info } = this.props;
    const show = info.otherList.length;
    let dispatcherNamestr = '';
    //增加调度员信息展示
    info.dispatcherListInfo.map((item, index) => {
      if (index === 0) {
        dispatcherNamestr = item.dispatcherName;
      } else {
        dispatcherNamestr = dispatcherNamestr + ',' + item.dispatcherName;
      }
    });
    return (
      !!show && (
        <CellGroup withBottomLine={false} style={styles.groupStyle}>
          <Cell
            name="other"
            title="其他信息"
            isLink={false}
            contentStyle={styles.contentStyle}
            titleStyle={styles.titleStyle}
            valueStyle={styles.valueStyle}
          />
          {dispatcherNamestr !== '' ? (
            <Cell
              name={'1111'}
              title={'调度员'}
              align="right"
              value={dispatcherNamestr}
              bottomLine
              isLink={false}
              contentStyle={styles.contentStyle}
              titleStyle={styles.subTitleStyle}
              valueStyle={styles.valueStyle}
            />
          ) : null}

          {info.otherList.map((item, index) => (
            <Cell
              key={index}
              name={index}
              title={item.name}
              align="right"
              value={item.name === '下单时间' ? dayjs(item.value).format('YYYY-MM-DD HH:mm') : item.value}
              bottomLine
              isLink={false}
              contentStyle={styles.contentStyle}
              titleStyle={styles.subTitleStyle}
              valueStyle={styles.valueStyle}
            />
          ))}
        </CellGroup>
      )
    );
  }
}

OtherInfo.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: autoFix(20),
    paddingTop: autoFix(20),
  },
  contentStyle: {
    paddingVertical: autoFix(28),
  },
  titleStyle: {
    fontSize: autoFix(24),
    color: '#999',
  },
  subTitleStyle: {
    fontSize: autoFix(24),
  },
  valueStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'bold',
    marginRight: 0,
  },
});
