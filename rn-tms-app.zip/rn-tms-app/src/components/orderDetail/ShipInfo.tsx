import React from 'react';
import { StyleSheet } from 'react-native';
import { CellGroup } from '@ymm/rn-elements';
import Cell from '../common/Cell';

// 发货信息
export default class ShipInfo extends React.Component {
  constructor(props: any) {
    super(props);
  }

  render() {
    const { info } = this.props;
    const show = info?.options.length;

    return (
      !!show && (
        <CellGroup withBottomLine={false} style={styles.groupStyle}>
          <Cell
            name="other"
            title={info.title}
            isLink={false}
            contentStyle={styles.contentStyle}
            titleStyle={styles.titleStyle}
            valueStyle={styles.valueStyle}
          />

          {info?.options.map((item, index) => (
            <Cell
              key={index}
              name={index}
              title={item.label}
              align="right"
              value={item.value}
              bottomLine
              isLink={false}
              contentStyle={styles.contentStyle}
              titleStyle={styles.subTitleStyle}
              valueStyle={styles.valueStyle}
            />
          ))}
        </CellGroup>
      )
    );
  }
}

ShipInfo.defaultProps = {
  info: {
    title: '发货信息',
    options: [],
  },
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: 10,
    paddingTop: 10,
  },
  contentStyle: {
    paddingVertical: 14,
  },
  titleStyle: {
    fontSize: 14,
    color: '#999',
  },
  subTitleStyle: {
    fontSize: 14,
  },
  valueStyle: {
    fontSize: 14,
    color: '#666',
    fontWeight: 'bold',
    marginRight: 0,
  },
});
