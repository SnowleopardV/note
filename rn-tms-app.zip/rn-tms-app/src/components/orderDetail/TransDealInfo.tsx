import React from 'react';
import { StyleSheet } from 'react-native';
import { CellGroup } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import Cell from '../common/Cell';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

// 运输协议
export default class TransDealInfo extends React.Component {
  constructor(props: any) {
    super(props);
  }

  onAction = () => {
    const { onPress } = this.props;
    !!onPress && onPress();
  };

  render() {
    const { info } = this.props;
    return (
      !!info && (
        <CellGroup withBottomLine={false} style={styles.groupStyle}>
          <Cell name="main" title="运输协议" isLink={false} contentStyle={styles.contentStyle} titleStyle={styles.titleStyle} />
          <Cell
            name="trans"
            title={info.agreementName}
            align="right"
            value={info.agreementStatusDesc}
            contentStyle={styles.contentStyle}
            titleStyle={styles.subTitleStyle}
            valueStyle={styles.valueStyle}
            onPress={this.onAction}
          />
        </CellGroup>
      )
    );
  }
}

TransDealInfo.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: autoFix(20),
    paddingTop: autoFix(20),
  },
  contentStyle: {
    paddingVertical: autoFix(28),
  },
  titleStyle: {
    fontSize: autoFix(24),
    color: '#999',
  },
  subTitleStyle: {
    fontSize: autoFix(24),
  },
  valueStyle: {
    fontSize: autoFix(24),
    color: '#666',
    fontWeight: 'normal',
    marginRight: autoFix(10),
  },
});
