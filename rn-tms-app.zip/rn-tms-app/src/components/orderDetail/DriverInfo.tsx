import React from 'react';
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

const Driver_Type = {
  '1': { name: '自有车', color: '#4885FF' },
  '2': { name: '承运商', color: '#4885FF' },
  '3': { name: '外调车', color: '#4885FF' },
  '4': { name: '满帮车', color: '#4885FF' },
};
const LOADING_IMG = 'https://image.ymm56.com/ymmfile/operation-biz/1bdc3b6b-54ff-4415-b824-316f365c94c6.gif';
// 承运商模块
export default class DriverInfo extends React.Component {
  constructor(props: any) {
    super(props);
  }

  onCall = (telephone) => {
    NativeBridge.dial({ telephone });
  };

  // 渲染找车中
  renderLookCar = (lookingCarText) => {
    return (
      <View style={[styles.container, styles.flexRow]}>
        <View style={[styles.flexRow, styles.flexing]}>
          <Image style={{ width: autoFix(60), height: autoFix(60) }} source={{ uri: LOADING_IMG }} />
          <MBText style={styles.lookingText}>{lookingCarText}</MBText>
        </View>
      </View>
    );
  };

  // 渲染司机信息
  renderDriverInfo = () => {
    const { info } = this.props;
    const driverName =
      info.dispatcherMode == 2 ? (info.driverName ? `${info.driverName}-${info.carrierName}` : info.carrierName) : info.driverName;
    return (
      <View style={[styles.flexRow, styles.flexing]}>
        <Image style={{ width: autoFix(64), height: autoFix(64) }} source={{ uri: info.driverPhoto }} />
        <View style={[styles.driverInfo, styles.flexing]}>
          <View style={[styles.flexRow, { flex: 1, paddingRight: autoFix(80) }]}>
            {driverName ? (
              <MBText style={styles.driverName} numberOfLines={1}>
                {driverName}
              </MBText>
            ) : null}
            <MBText style={[styles.driverType, { color: '#4885FF', borderColor: '#4885FF' }]}>{info.truckType}</MBText>
          </View>
          {info.carInfoForDisplay ? <MBText style={styles.truckInfo}>{info.carInfoForDisplay}</MBText> : null}
        </View>
      </View>
    );
  };

  render() {
    const { info, status, source, lookingCarText } = this.props;
    if (status === 'LOOKING_CAR') {
      if (lookingCarText) return this.renderLookCar(lookingCarText);
      return null;
    }
    if (!info) return null;
    if (source === 'list') return this.renderDriverInfo();
    return (
      <View style={[styles.container, styles.flexRow]}>
        {this.renderDriverInfo()}
        {info.driverPhone ? (
          <TouchableOpacity activeOpacity={0.3} onPress={() => this.onCall(info.driverPhone)}>
            <View style={styles.phoneCall}>
              <Image style={{ width: autoFix(56), height: autoFix(56) }} source={images.icon_telephone} />
            </View>
          </TouchableOpacity>
        ) : null}
      </View>
    );
  }
}

DriverInfo.defaultProps = {
  info: {},
  status: '',
  lookingCarText: '',
  source: 'detail', // 来源是列表还是详情
};

const styles = StyleSheet.create({
  flexing: {
    flex: 1,
  },
  container: {
    paddingVertical: autoFix(24),
    paddingHorizontal: autoFix(28),
    borderTopWidth: autoFix(1),
    borderTopColor: '#fff',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    borderRadius: 2,
    marginBottom: autoFix(20),
    marginHorizontal: autoFix(18),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverInfo: {
    marginLeft: autoFix(16),
  },
  driverName: {
    fontSize: autoFix(24),
    // maxWidth: 163,
  },
  driverType: {
    paddingHorizontal: autoFix(6),
    marginLeft: autoFix(6),
    borderWidth: autoFix(1),
    fontSize: autoFix(20),
    borderRadius: autoFix(8),
    borderBottomLeftRadius: 0,
  },
  truckInfo: {
    fontSize: autoFix(22),
    color: '#999',
  },
  phoneCall: {
    marginLeft: autoFix(10),
  },
  lookingText: {
    fontSize: autoFix(24),
    color: '#666',
    marginLeft: autoFix(25),
    flex: 1,
  },
});
