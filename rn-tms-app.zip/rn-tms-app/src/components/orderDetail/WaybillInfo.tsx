import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { MBText, CellGroup } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import Cell from '../common/Cell';
import Popup from './Popup';

// 装车清单
export default class WaybillInfo extends React.Component {
  constructor(props: any) {
    super(props);
    this.state = {
      visible: false,
    };
  }

  handleOpen = () => {
    this.setState({
      visible: true,
    });
  };

  handleClose = () => {
    this.setState({
      visible: false,
    });
  };

  jump = (id) => {
    if (Platform.OS === 'ios') {
      this.handleClose();
    }
    const url = `ymm://rn.tms/waybilldetail?id=${id}`;
    NativeBridge.setOpenUrl({ url });
  };

  render() {
    const { info } = this.props;
    const show = info.length;
    const { visible } = this.state;
    // 前台最多展示3条
    const max = 3;
    return (
      !!show && (
        <View>
          <CellGroup withBottomLine={false} style={styles.groupStyle}>
            <Cell
              name="bill"
              title="装车清单"
              align="right"
              value={info.length > max ? '更多运单' : ''}
              isLink={info.length > max}
              contentStyle={info.length > max ? styles.contentStyle : styles.noValSty}
              titleStyle={styles.titleStyle}
              valueStyle={styles.valueStyle}
              onPress={info.length > max && this.handleOpen}
            />
            {info.slice(0, max).map((item, index) => (
              <Cell
                key={index}
                name={index}
                title={info.length > 1 ? `运单${index + 1}` : '运单'}
                align="right"
                value={item.transOrderNo}
                contentStyle={styles.contentStyle}
                titleStyle={styles.subTitleStyle}
                valueStyle={styles.valueStyle}
                onPress={() => this.jump(item.id)}
              />
            ))}
          </CellGroup>
          <Popup title="装车清单" visible={visible} contentStyle={{ paddingHorizontal: 10 }} onClose={this.handleClose}>
            {info.map((item, index) => (
              <Cell
                key={index}
                name={index}
                title={info.length > 1 ? `运单${index + 1}` : '运单'}
                align="right"
                value={item.transOrderNo}
                contentStyle={styles.contentStyle}
                titleStyle={styles.subTitleStyle}
                valueStyle={styles.valueStyle}
                onPress={() => this.jump(item.id)}
              />
            ))}
          </Popup>
        </View>
      )
    );
  }
}

WaybillInfo.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  groupStyle: {
    marginBottom: 10,
    paddingVertical: 6,
  },
  contentStyle: {
    paddingVertical: 8,
  },
  noValSty: {
    paddingVertical: 17.5,
  },
  titleStyle: {
    fontSize: 14,
    color: '#999',
  },
  subTitleStyle: {
    fontSize: 14,
  },
  valueStyle: {
    fontSize: 14,
    color: '#666',
    fontWeight: 'normal',
    marginRight: 5,
  },
});
