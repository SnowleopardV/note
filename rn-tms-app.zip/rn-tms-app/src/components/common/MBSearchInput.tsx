import { View, Image, TextInput, TouchableOpacity, StyleSheet, Platform, Keyboard, EmitterSubscription, Input } from 'react-native';
import React from 'react';
import Images from '../../../public/static/images';
import InputItem from './InputItem';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

interface Props {
  hideSearchIcon?: boolean;
  autoFocus?: boolean;
  //输入框没有内容的时候，需不需要隐藏删除按钮
  hideCancelIcon?: boolean;
  initialText?: string;
  placeholder?: string;
  onChangeText?: (string) => void;
  onSearch?: (string) => void;
  onFocus?: () => void;
  onBlur?: () => void;
  parentStyle?: any;
}

interface State {
  focus: boolean;
}

class MBSearchInput extends React.Component<Props, State> {
  inputNode: Input | null;
  keyboardHideListener?: EmitterSubscription;

  constructor(props: any) {
    super(props);
    this.inputNode = null;
    this.state = {
      focus: false,
    };
    if (Platform.OS === 'android') {
      this.keyboardHideListener = Keyboard.addListener('keyboardDidHide', this.keyboardHide);
    }
  }

  componentWillUnmount(): void {
    this.keyboardHideListener?.remove();
  }

  keyboardHide = () => {
    if (this.state.focus) {
      this.blur();
    }
  };

  onBlur = () => {
    const { onBlur } = this.props;
    this.setState(
      {
        focus: false,
      },
      () => {
        onBlur && onBlur();
      }
    );
  };

  onFocus = () => {
    const { onFocus } = this.props;
    this.setState(
      {
        focus: true,
      },
      () => {
        onFocus && onFocus();
      }
    );
  };

  focus = () => {
    if (this.inputNode) {
      this.inputNode.focus();
      this.setState({
        focus: true,
      });
    }
  };

  blur = () => {
    if (this.inputNode) {
      this.inputNode.blur();
      this.setState({
        focus: false,
      });
    }
  };

  render() {
    const {
      initialText,
      placeholder,
      onChangeText,
      onSearch,
      parentStyle,
      autoFocus,
      hideCancelIcon,
      onFocus,
      onBlur,
      ...restProps
    } = this.props;

    return (
      <View style={[styles.container, parentStyle]}>
        <TouchableOpacity style={[styles.iconContainer, { marginHorizontal: 15 }]} onPress={() => this._onSearch()}>
          {this.props?.hideSearchIcon ? <View /> : <Image style={{ width: 17, height: 17 }} source={{ uri: Images.icon_input_search }} />}
        </TouchableOpacity>

        <View style={[styles.inputContainer, { left: this.props?.hideSearchIcon ? 21 : 34 }]}>
          <InputItem
            ref={(el) => {
              (this.inputNode as any) = el;
            }}
            styleItem={styles.inputItem}
            inputStyle={styles.input}
            allowFontScaling={false}
            editable={true}
            autoFocus={autoFocus || false}
            placeholder={placeholder}
            placeholderTextColor={'#ccc'}
            value={initialText}
            blurOnSubmit={true}
            returnKeyType="done"
            {...restProps}
            onSubmitEditing={(e) => {
              this._onSearch();
            }}
            onChangeText={(text: string) => {
              this._onTextChange(text);
            }}
            onFocus={this.onFocus}
            onBlur={this.onBlur}
          />
        </View>
        {hideCancelIcon || !initialText || !this.state.focus ? (
          <View />
        ) : (
          <TouchableOpacity
            style={[styles.iconContainer, { right: 0, paddingRight: 10, paddingLeft: 10 }]}
            onPress={(e) => {
              this._onClear();
            }}
          >
            <Image style={{ width: 15, height: 15 }} source={{ uri: Images.icon_input_edit_cancel }} />
          </TouchableOpacity>
        )}
      </View>
    );
  }

  _onTextChange(text: string) {
    // this.text = text;
    if (this.props.onChangeText) {
      this.props.onChangeText(text);
    }
  }

  _onSearch() {
    // let text = this.text;
    if (this.props.onSearch) {
      if (this.inputNode) {
        this.props.onSearch(this.inputNode.value);
      }
    }
  }

  _onClear() {
    if (this.inputNode) {
      this.inputNode.clear();
    }
    if (this.props.onChangeText) {
      this.props.onChangeText('');
    }
  }
}

const styles = StyleSheet.create({
  iconContainer: {
    position: 'absolute',
    height: 38,
    justifyContent: 'center',
  },
  inputItem: {
    paddingVertical: 0,
    width: '100%',
  },
  input: {
    color: '#333',
    width: '100%',
  },
  inputContainer: {
    position: 'absolute',
    left: autoFix(28),
    height: autoFix(80),
    justifyContent: 'center',
    flex: 1,
    width: '100%',
    ...Platform.select({ ios: { top: -autoFix(7) } }),
  },
  container: {
    height: autoFix(80),
    paddingLeft: autoFix(28),
    paddingRight: autoFix(28),
    backgroundColor: '#F0F0F0',
    flexDirection: 'row',
    borderRadius: autoFix(100),
    alignItems: 'center',
  },
});

export default MBSearchInput;
