import { Platform } from 'react-native';
import { action, observable, computed } from 'mobx';
import { CityPickerProps } from './propTypes';
const defaultValue = {
  province: 0,
  provinceName: '',
  city: 0,
  cityName: '',
  area: 0,
  areaName: '',
  address: '',
  longitude: '0',
  latitude: '0',
  poiName: '',
  typeCode: '',
};
/**
 * 城市选择和详细地址store
 */
export default class CityPickerStore {
  @observable value: AddressType = { ...defaultValue };

  @computed get cityDisplayText(): string {
    let value = '';
    if (this.value.city) {
      if (this.value?.provinceName === this.value?.cityName) {
        value = `${this.value?.provinceName || ''} ${this.value?.areaName || ''}`;
      } else {
        value = `${this.value?.provinceName || ''} ${this.value?.cityName || ''} ${this.value?.areaName || ''}`;
      }
    }
    return value;
  }

  @computed get addressDisplayText(): string {
    return this.value.address || '';
  }

  constructor(props: CityPickerProps) {
    this.initialize(props.value);
  }

  @action initialize(value?: AddressType): void {
    if (value) {
      this.value = value;
    }
  }

  @action changeCity(value: AddressType): void {
    this.value = value;
  }
}
