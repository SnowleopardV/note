import * as React from 'react';
import { View, Platform } from 'react-native';
import { observer } from 'mobx-react';
import { MBToast, MBBridge, URLUtils } from '@ymm/rn-lib';
import { MBText, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import * as MapBridge from '~/extends/MapBridge';
import addressConvert, { ConvertType } from '~/utils/addressConvert';
import Cell from '~/components/common/Cell';
import { CityPickerProps, CityPickerState } from './propTypes';
import Store from './store';

@observer
export default class CityPickerComponent extends React.Component<CityPickerProps, CityPickerState> {
  static defaultProps = {
    cityTitle: '所在地区',
    addressTitle: '详细地址',
    cityPlaceholder: '请选择',
    addressPlaceholder: '请输入',
    deep: 3,
    readonlyCity: false, // 只读所在地区，不能再选中
    addressRequired: true, // 详细地址默认是必填的
    onlyAddress: false,
  };
  store: Store;
  constructor(props: CityPickerProps) {
    super(props);
    this.store = new Store(props);
    this.state = {
      // city
      area: null,
    };
  }
  /**
   * 选择城市
   */
  selectCity = () => {
    MapBridge.selectPlace({ type: 0, code: this.store.value?.area || -1 }, (result: any, source: number) => {
      if (source === -1) {
        // 取消
        return;
      }
      if (result.code === this.store.value?.area) {
        // 重复区数据
        return;
      }

      const address = addressConvert(result, ConvertType.CityPicker2Server);
      // 本地store数据
      this.store.changeCity(address as AddressType);
      // 外部onChange回调
      this.props.onChange?.(address as AddressType);
      const { area } = address;
      this.setState({ area: area });
      return;
    });
    this.props.onPress?.('City');
  };
  /**
   * 选择详细地址
   */
  selectAddress = () => {
    if (!this.store.cityDisplayText) {
      MBToast.show('请先选择省市区');
      return;
    }
    const schemeUrl = URLUtils.appendParamsToUrl('ymm://rn.tms/detailaddress', {
      value:
        Platform.OS == 'android'
          ? JSON.stringify({ ...this.store.value, onlyAddress: this.props.onlyAddress })
          : encodeURI(JSON.stringify({ ...this.store.value, onlyAddress: this.props.onlyAddress })),
    }).replace('?&', '?');
    MBBridge.app.base.openSchemeForResult({ schemeUrl }).then((res) => {
      this.selectSuccess(res);
    });
    this.props.onPress?.('Address');
  };

  selectSuccess = (result: any) => {
    let data = Platform.OS === 'ios' ? JSON.parse(result?.data) : result?.data;
    if (data.back) {
      // 直接返回了
      return;
    }

    if (data?.onlyAddress) {
      // 空详情
      data = {
        ...this.store.value,
        address: data.onlyAddress.address || '',
      };
    } else if (!data.area) {
      data.area = this.state.area; // 如果详情里带出来的数据没有区号就用省市区组件的区号来代替，否则服务端会报错
    } else if (!data.cityName) {
      // 如果没有返回省市区名称 使用城市组件里选择的名称
      const value = this.store.value || {};
      Object.keys(data).forEach((key: string) => {
        if (data[key]) {
          value[key] = data[key];
        }
      });
      data = value;
    }
    const address = { ...data };
    this.store.changeCity(address);
    this.props.onChange?.(address);
    // return;
  };
  public render(): JSX.Element {
    const { cityTitle, addressTitle, cityPlaceholder, addressPlaceholder, rules, readonlyCity, addressRequired } = this.props;
    return (
      <View>
        <Cell
          key="city"
          title={cityTitle}
          placeholder={cityPlaceholder}
          value={this.store.cityDisplayText}
          bottomLine
          required
          align="right"
          onPress={this.selectCity}
          readonly={readonlyCity}
          extra={
            rules?.[0].isError && (
              <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                <MBText size="xs" color="#F54242" align="right">
                  {rules[0].message}
                </MBText>
                <Whitespace vertical={14} />
              </View>
            )
          }
        />
        <Cell
          key="address"
          title={addressTitle}
          placeholder={addressPlaceholder}
          value={this.store.addressDisplayText}
          required={addressRequired}
          align="right"
          onPress={this.selectAddress}
          extra={
            rules?.[1].isError && (
              <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                <MBText size="xs" color="#F54242" align="right">
                  {rules[1].message}
                </MBText>
                <Whitespace vertical={14} />
              </View>
            )
          }
        />
      </View>
    );
  }
}
