export type CityClickName = 'City' | 'Address';
export interface CityPickerProps {
  cityTitle?: string;
  addressTitle?: string;
  cityPlaceholder?: string;
  addressPlaceholder?: string;
  value?: AddressType;
  deep?: number;
  placeholder?: string;
  bottomLine?: boolean;
  rules?: any[];
  readonlyCity?: boolean; // 只读所在地区，不能选择
  onlyAddress?: boolean; // 手写地址
  onChange?: (value: AddressType) => void;
  onPress?: (type: CityClickName) => void;
}

export interface CityPickerState {
  area: number | string | null; // 区号
}
