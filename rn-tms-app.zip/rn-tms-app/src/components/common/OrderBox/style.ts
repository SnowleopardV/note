import { StyleSheet } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  searchBoxContainer: {
    marginHorizontal: 10,
    flexDirection: 'row',
  },
  searchBox: {
    height: autoFix(48),
    borderRadius: autoFix(24),
    backgroundColor: 'rgba(255, 255, 255, 1)',
    marginRight: autoFix(20),
    fontSize: autoFix(26),
    paddingHorizontal: autoFix(20),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchBoxSelect: {
    backgroundColor: 'rgba(72, 133, 255, 0.12)',
  },
  searchBoxSelectText: {
    color: 'rgba(72, 133, 255, 1)',
  },
  orderBox: {
    width: autoFix(30),
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  orderUp: {
    width: autoFix(0),
    height: autoFix(0),
    borderWidth: autoFix(6),
    borderColor: 'transparent',
    borderBottomColor: 'rgba(153, 153, 153, 1)',
    marginBottom: autoFix(4),
  },
  orderUpSelect: {
    borderBottomColor: '#4885FF',
  },
  orderUpTransparent: {
    borderBottomColor: 'transparent',
  },
  orderDown: {
    width: autoFix(0),
    height: autoFix(0),
    borderWidth: autoFix(6),
    borderColor: 'transparent',
    borderTopColor: 'rgba(153, 153, 153, 1)',
  },
  orderDownSelect: {
    borderTopColor: '#4885FF',
  },
  orderDownTransparent: {
    borderTopColor: 'transparent',
  },
  priceCardCellText: {
    fontSize: autoFix(26),
    color: 'rgba(153, 153, 153, 1)',
  },
});
