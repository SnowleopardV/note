import React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import styles from './style';

interface OrderItem {
  key: string; // 排序项的唯一标识
  title: string; // 排序项的标题
}
interface OrderBoxProps {
  list: Array<OrderItem>;
  handleOrderChange: (key: string, orderBy: boolean) => void; // 排序改变处理函数
  ref: React.RefObject<unknown>;
}
interface OderBoxState {
  orderByAsc: boolean; // 按true增序 或 false降序
  selectOrderType: string | null; // '1': 运费参考价;'2': 运输里程;'3':成交时间
}
/**
 * 排序组件，可点击触发重新排序事件，参考 src\pages\dispatch\freight-assistant\index.tsx运价助手页面使用，
 */
export default class OrderBox extends React.Component<OrderBoxProps, OderBoxState> {
  constructor(props: OrderBoxProps) {
    super(props);
    this.state = {
      orderByAsc: true,
      selectOrderType: null,
    };
  }
  // 取消排序状态
  cancelOrderState(): void {
    this.setState({
      orderByAsc: true,
      selectOrderType: null,
    });
  }
  // 排序规则改变事件
  orderChange = (orderType: string): void => {
    if (this.state.selectOrderType === orderType) {
      this.setState((prevState) => ({
        orderByAsc: !prevState.orderByAsc,
      }));
    } else {
      this.setState({
        selectOrderType: orderType,
        orderByAsc: true,
      });
    }
    setTimeout(() => this.props.handleOrderChange(orderType, this.state.orderByAsc), 0);
  };
  render(): React.ReactNode {
    const { selectOrderType, orderByAsc } = this.state;
    return (
      <View style={styles.searchBoxContainer}>
        {this.props.list.map((item) => (
          <TouchableOpacity key={item.key} onPress={() => this.orderChange(item.key)}>
            <View style={[styles.searchBox, selectOrderType === item.key ? styles.searchBoxSelect : {}]}>
              <MBText style={[styles.priceCardCellText, selectOrderType === item.key ? styles.searchBoxSelectText : {}]}>
                {item.title}
              </MBText>
              {selectOrderType !== item.key ? (
                <View style={styles.orderBox}>
                  <View style={[styles.orderUp]}></View>
                  <View style={[styles.orderDown]}></View>
                </View>
              ) : (
                <View style={styles.orderBox}>
                  {/* {orderByAsc ? (
                    <View style={[styles.orderUp, styles.orderUpSelect]}></View>
                  ) : (
                    <View style={[styles.orderDown, styles.orderDownSelect]}></View>
                  )} */}
                  <View style={[styles.orderUp, orderByAsc ? styles.orderUpSelect : styles.orderUpTransparent]}></View>
                  <View style={[styles.orderDown, !orderByAsc ? styles.orderDownSelect : styles.orderDownTransparent]}></View>
                </View>
              )}
            </View>
          </TouchableOpacity>
        ))}
      </View>
    );
  }
}
