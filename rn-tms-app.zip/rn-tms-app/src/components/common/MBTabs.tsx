import { StyleSheet, Text } from 'react-native';
import React from 'react';
import { Tabs } from '@ymm/rn-elements';

export default class MBTabs extends React.Component<any, any> {
  static defaultProps = {
    defaultIndex: 0,
    fixedWidth: true,
    tabs: [],
    name: 'tabs',
    onTabChange: () => null,
    renderList: () => null,
  };
  constructor(props: any) {
    super(props);
    this.state = {
      keyName: this.props.name + new Date(),
    };
  }

  handleChange = (index: number, name: string) => {
    this.props?.onTabChange(index, name);
  };

  render() {
    const { tabs, fixedWidth, defaultIndex, renderList, renderTitle, name } = this.props;
    const { keyName } = this.state;
    return (
      <Tabs
        key={(name || 'Tab') + keyName}
        defaultIndex={defaultIndex}
        activeTextStyle={styles.active}
        onChange={this.handleChange}
        fixedWidth={fixedWidth}
      >
        {tabs.map((item: any, index: number) => (
          <Tabs.TabPane key={index + keyName} position={index} title={renderTitle ? renderTitle : item.title} name={item.title}>
            {!!renderList && renderList(index)}
          </Tabs.TabPane>
        ))}
      </Tabs>
    );
  }
}

const styles = StyleSheet.create({
  flexing: {
    flex: 1,
  },
  active: {
    color: '#4885FF',
  },
});
