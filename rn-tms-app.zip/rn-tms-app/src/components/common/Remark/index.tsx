import React from 'react';
import { View, StyleProp, ViewStyle, Platform, Keyboard, EmitterSubscription } from 'react-native';
import { Flex, MBText, Input } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import styles from './styles';

const FlexItem = Flex.Item;

export interface InputProps {
  name: string; // 选项名
  required?: boolean; // 显示星号，必填
  multiline?: boolean; // 是否多行
  placeholder?: string; // placeholder
  value?: string; // 值
  title?: string; // lable
  inputStyle?: StyleProp<ViewStyle>;
  maxLength?: number | any;
  autoFocus?: boolean;
  onChangeText?: (name: string) => void;
  onBlur?: () => void;
  onFocus?: () => void;
  style?: StyleProp<ViewStyle>;
}

export interface InputItemState {
  focus: boolean;
}

class Remark extends React.Component<InputProps, InputItemState> {
  inputNode: Input | null;
  keyboardHideListener?: EmitterSubscription;
  static defaultProps: InputProps = {
    name: 'field',
    required: false,
    title: '备注',
    placeholder: '请输入备注信息',
    value: '',
    multiline: true,
    maxLength: 101,
    autoFocus: false,
  };

  constructor(props: InputProps) {
    super(props);
    this.inputNode = null;
    this.state = {
      focus: props.autoFocus || false,
    };

    if (Platform.OS === 'android') {
      this.keyboardHideListener = Keyboard.addListener('keyboardDidHide', this.keyboardHide);
    }
  }

  componentWillUnmount(): void {
    this.keyboardHideListener?.remove();
  }

  keyboardHide = () => {
    if (this.state.focus) {
      this.blur();
    }
  };

  onBlur = () => {
    const { onBlur } = this.props;
    this.setState(
      {
        focus: false,
      },
      () => {
        onBlur && onBlur();
      }
    );
  };

  onFocus = () => {
    const { onFocus } = this.props;
    this.setState(
      {
        focus: true,
      },
      () => {
        onFocus && onFocus();
      }
    );
  };

  focus = () => {
    if (this.inputNode) {
      this.inputNode.focus();
      this.setState({
        focus: true,
      });
    }
  };

  blur = () => {
    if (this.inputNode) {
      this.inputNode.blur();
      this.setState({
        focus: false,
      });
    }
  };

  onChange = (value: string) => {
    const { onChangeText, maxLength } = this.props;
    const len = maxLength - 1;

    if (value.length > len) {
      NativeBridge.toast(`已达到输入上限${len}个字符`);
      return;
    }
    onChangeText && onChangeText(value);
  };

  render() {
    const { inputStyle, title, placeholder, value, multiline, maxLength, style, required, ...restProps } = this.props;
    return (
      <View style={[styles.container, style]}>
        <Flex direction="row">
          <FlexItem style={styles.flexItemStyle}>
            <View style={styles.lable}>
              <MBText>
                {title}
                {required ? <MBText style={styles.item_required}>&nbsp;*</MBText> : null}
              </MBText>
            </View>
            <Input
              ref={(el) => {
                (this.inputNode as any) = el;
              }}
              style={[styles.input, inputStyle]}
              value={value}
              placeholder={placeholder}
              maxLength={maxLength}
              multiline={multiline}
              numberOfLines={3}
              returnKeyType="done"
              {...restProps}
              onSubmitEditing={Keyboard.dismiss}
              onChangeText={this.onChange}
              onFocus={this.onFocus}
              onBlur={this.onBlur}
              blurOnSubmit={true} // 禁止换行
            />
          </FlexItem>
        </Flex>
        <Flex align="flex-end" style={styles.tipWrapper}>
          <FlexItem>
            <MBText color="#ccc" style={styles.lengthTip}>
              {value ? value.length : 0}/{maxLength - 1}
            </MBText>
          </FlexItem>
        </Flex>
      </View>
    );
  }
}

export default Remark;
