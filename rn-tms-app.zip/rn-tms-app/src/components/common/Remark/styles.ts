import { StyleSheet } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';

export default StyleSheet.create({
  container: {
    padding: RNElementsUtil.autoFix(28),
  },

  flexItemStyle: {
    flexDirection: 'row',
  },

  input: {
    flex: 1,
    fontSize: RNElementsUtil.autoFix(28),
    color: '#666',
    textAlignVertical: 'top',
  },

  lable: {
    paddingRight: RNElementsUtil.autoFix(32),
  },

  tipWrapper: {
    paddingTop: RNElementsUtil.autoFix(10),
  },

  lengthTip: {
    fontSize: RNElementsUtil.autoFix(30),
    height: RNElementsUtil.autoFix(40),
  },

  item_required: {
    fontSize: 15,
    color: '#FF4040',
    marginLeft: 4,
  },
});
