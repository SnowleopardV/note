import React from 'react';
import ImageViewer from 'react-native-image-zoom-viewer';
import { Modal, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { IImageInfo } from './index.type';
import { RNElementsUtil } from '@ymm/rn-elements';
const { autoFix } = RNElementsUtil;
const Styles = StyleSheet.create({
  cancel: {
    width: '100%',
    textAlign: 'center',
    backgroundColor: '#000',
    color: '#fff',
    fontSize: autoFix(30),
    //position:'absolute',
    zIndex: 10,
    //paddingBottom:autoFix(40),
  },
});
export default ({
  visible,
  imageUrls,
  onCancel,
  index = 0,
}: {
  visible: boolean;
  imageUrls: IImageInfo[] | null;
  onCancel: () => void;
  index?: number;
}) => (
  <Modal visible={visible} transparent={true}>
    <ImageViewer
      enablePreload={true}
      imageUrls={imageUrls || []}
      backgroundColor="#000"
      onClick={() => {
        onCancel && onCancel();
      }}
      index={index}
    ></ImageViewer>
  </Modal>
);
