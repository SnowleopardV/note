import * as React from 'react';
import { View, Image, TouchableOpacity, StyleProp, TextStyle, ViewStyle } from 'react-native';
import { Row, Col, Flex, MBText, Splitline, RNElementsUtil } from '@ymm/rn-elements';
import { CellItemProps } from './PropTypes';
import styles from './styles';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
/**
 * 发货页货物信息、车型车长、几装几卸的显示框
 * 点击显示框唤起弹出框
 */
export default class CellItem extends React.Component<CellItemProps, any> {
  static defaultProps: CellItemProps = {
    isLink: true,
    name: 'field',
    align: 'left', // 默认文字靠左显示
    readonly: false, //
    fontSize: RNElementsUtil.autoFix(28),
    numberOfLines: 3,
    required: false,
    // rightElement: <Image style={styles.item_arrow} source={{ uri: Images.icon_arrow_gray }} />,
  };
  constructor(props: CellItemProps) {
    super(props);

    this.state = {};
  }
  onPress = () => {
    if (this.props.readonly) {
      this.props.onReadOnlyPress && this.props.onReadOnlyPress(this.props.name);
      return;
    }
    this.props.onPress && this.props.onPress(this.props.name);
  };
  /**
   * 渲染选项标题
   * @param {string} title 标题名
   */
  renderTitle(
    styles: any,
    title?: string,
    icon?: string | React.ReactNode,
    titleStyle?: StyleProp<TextStyle>,
    required?: boolean,
    readonly?: boolean
  ) {
    if (title) {
      return (
        <Row>
          {this.renderIcon(styles, icon)}
          <Col flex={0}>
            <MBText style={[styles.item_title, titleStyle, readonly ? { color: '#ccc' } : null]}>
              {title}
              {!!required && <MBText style={[styles.item_required, readonly ? { color: '#ccc' } : null]}>&nbsp;*</MBText>}
            </MBText>
          </Col>
        </Row>
      );
    }
    return null;
  }
  /**
   * 渲染选项缩略图标
   * @param {string} thumb
   */
  renderIcon(styles: any, icon?: string | React.ReactNode) {
    if (icon) {
      if (typeof icon === 'string') {
        return (
          <Flex justify="center" style={styles.item_icon_container}>
            <Image style={styles.item_icon} source={{ uri: icon }} />
          </Flex>
        );
      }
      return (
        <Flex flex={0} style={styles.item_icon_container}>
          {icon}
        </Flex>
      );
    }
    return null;
  }
  /**
   * 渲染标签
   * @param tag
   * @param tagStyle
   */
  renderTag(styles: any, tag: string | React.ReactNode, tagStyle?: StyleProp<ViewStyle>): React.ReactNode {
    if (tag) {
      if (typeof tag === 'string') {
        return (
          <View style={[styles.item_tag_container, tagStyle]}>
            <MBText style={styles.item_tag_text}>{tag}</MBText>
          </View>
        );
      }
      return tag;
    }
    return null;
  }
  renderRightElement(styles: any, isLink?: boolean, rightIcon?: React.ReactNode, rightElement?: React.ReactNode) {
    const { value, showClear } = this.props;
    if (rightIcon) {
      return <View style={styles.item_arrow_container}>{rightIcon}</View>;
    } else if (rightElement) {
      return rightElement;
    } else if ((isLink && !showClear) || (isLink && showClear && !value)) {
      return (
        <View style={styles.item_arrow_container}>
          <Image style={styles.item_arrow} source={{ uri: images.icon_arrow_gray }} />
        </View>
      );
    }
    return null;
  }
  render() {
    const {
      icon,
      title,
      value,
      tag,
      rightTag,
      placeholder,
      align,
      extra,
      readonly,
      isLink,
      rightIcon,
      rightElement,
      fontSize,
      bottomLine,
      rightTagStyle,
      titleStyle,
      valueStyle,
      tagStyle,
      style,
      numberOfLines,
      contentStyle,
      required,
      showClear,
      TipsText,
    } = this.props;
    let activeOpacity = 0.8;
    if (!isLink) {
      // 没有点击特效
      activeOpacity = 1;
    }
    return (
      <View style={[styles.item, style]}>
        <Row style={styles.item_container}>
          <View>
            <Row>
              {this.renderTitle(styles, title, icon, titleStyle, required, readonly)}
              {this.renderTag(styles, tag, tagStyle)}
            </Row>
          </View>
          <Col style={styles.item_content_wrap}>
            <TouchableOpacity activeOpacity={activeOpacity} onPress={this.onPress} style={[styles.item_content, contentStyle]}>
              <Row flex={1}>
                {!!value || !!placeholder ? (
                  <Row flex={1} justify={align === 'right' ? 'flex-end' : 'flex-start'}>
                    <MBText
                      numberOfLines={numberOfLines}
                      style={
                        value
                          ? [
                              align === 'right' ? { textAlign: 'right' } : null,
                              styles.item_text,
                              { fontSize },
                              readonly ? { color: '#ccc' } : {},
                              valueStyle,
                            ]
                          : [styles.item_hint, { fontSize }]
                      }
                    >
                      {value || placeholder}
                    </MBText>
                  </Row>
                ) : null}
                {this.renderTag(styles, rightTag, rightTagStyle)}
                {!!showClear && value && (
                  <TouchableOpacity
                    onPress={() => {
                      !!this.props?.onClearPress && this.props?.onClearPress();
                    }}
                  >
                    <Image source={{ uri: images.icon_close }} style={{ height: autoFix(32), width: autoFix(32) }}></Image>
                  </TouchableOpacity>
                )}
              </Row>
              {this.renderRightElement(styles, isLink, rightIcon, rightElement)}
            </TouchableOpacity>
          </Col>
        </Row>
        {!!TipsText && (
          <View style={{ marginBottom: autoFix(16), alignItems: 'flex-end', paddingHorizontal: autoFix(28) }}>
            <MBText size="xs" color="red">
              {TipsText}
            </MBText>
          </View>
        )}
        {extra && <View>{extra}</View>}
        {bottomLine && <Splitline />}
      </View>
    );
  }
}
