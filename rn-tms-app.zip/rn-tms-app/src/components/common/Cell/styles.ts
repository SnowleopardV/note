import { StyleSheet, Platform } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';
export default StyleSheet.create({
  item: {
    flexDirection: 'column',
    paddingLeft: RNElementsUtil.autoFix(28),
  },
  item_container: {},
  item_icon: {
    width: 16,
    height: 16,
  },

  item_title: {
    fontSize: 15,
    color: '#333',
    marginRight: 7,
  },
  item_required: {
    fontSize: 15,
    color: '#FF4040',
    marginLeft: 4,
  },
  item_icon_container: {
    marginRight: 5,
  },
  item_content_wrap: {
    paddingRight: RNElementsUtil.autoFix(28),
  },
  item_content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: RNElementsUtil.autoFix(29),
  },
  item_hint: {
    fontSize: 15,
    color: '#ccc',
    marginRight: 8,
  },
  item_text: {
    fontSize: 15,
    color: '#666',
    marginRight: 8,
    flex: 1,
  },
  item_text_container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    flex: 1,
  },
  item_tag_container: {
    ...Platform.select({
      ios: {
        paddingVertical: 2,
      },
      android: {
        paddingBottom: 1,
      },
    }),
    backgroundColor: '#f87d22',
    borderRadius: 4,
    paddingHorizontal: 4,
    // paddingVertical: 3,
  },
  item_tag_text: {
    fontSize: RNElementsUtil.autoFix(24),
    color: '#fff',
  },
  item_arrow_container: {
    justifyContent: 'flex-end',
    // marginLeft: 8,
  },
  item_arrow: {
    width: 8,
    height: 14,
  },
  item_content_tap_container: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    flex: 1,
  },
  item_content_tap_text_container: {
    justifyContent: 'center',
  },
  item_content_tag_view: {
    ...Platform.select({
      ios: {
        paddingVertical: 2,
      },
    }),
    borderRadius: 4,
    paddingLeft: 4,
    paddingRight: 4,
    backgroundColor: '#f87d22',
    marginLeft: 8,
  },
});
