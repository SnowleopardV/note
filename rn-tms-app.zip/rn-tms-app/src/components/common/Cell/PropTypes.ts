import { StyleProp, ViewStyle, TextStyle } from 'react-native';

export interface CellItemProps {
  name: string; // 选项名
  title?: string; // 货物信息
  icon?: string | React.ReactNode; // 左侧标题旁icon
  required?: boolean; // 显示星号，必填
  placeholder?: string; // 提示信息,
  value?: string | React.ReactNode; // 值
  tag?: string | React.ReactNode; // title旁标签提示
  rightTag?: string | React.ReactNode; // value旁标签提示
  align?: 'left' | 'right'; // 值靠左还是靠右显示
  extra?: React.ReactNode | string; // 下划线等其他额外填充组件
  isLink?: boolean; // 是否是链接,右侧是箭头图标
  rightIcon?: React.ReactNode; // 右侧图标
  rightElement?: React.ReactNode; // 右边控件元素
  readonly?: boolean; // 只读
  bottomLine?: boolean; // 底部分割线条
  fontSize?: number; // value或placeholder的文字大小
  numberOfLines?: number;
  showClear?: boolean; // 是否显示删除按钮
  TipsText?: string | null; // 底部提示行
  tagStyle?: StyleProp<ViewStyle>;
  rightTagStyle?: StyleProp<ViewStyle>;
  titleStyle?: StyleProp<TextStyle>;
  valueStyle?: StyleProp<TextStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  style?: StyleProp<ViewStyle>;
  onPress?: (name: string) => void;
  onReadOnlyPress?: (name: string) => void;
  onClearPress?: () => void;
}
