export interface RequestDateTime {
  startTimestamp: number;
  endTimestamp: number;
  displayValue: string; // 显示文案
  dateCode: string;
  timeInterval: number;
  hourPeriod: number;
}
