import * as React from 'react';
import { View, StyleProp, ViewStyle } from 'react-native';
import { inject, observer } from 'mobx-react';
import Cell from '~/components/common/Cell';
import ModalDateTime from './components/ModalDateTime';
import { AppointTime, DatetimeType } from './components/ModalDateTime/proptypes';
import Store from './store';
import { RequestDateTime } from './proptypes';
/**
 * 装卸货时间，时间选择控件
 */
export interface MBDateTimePickerProps {
  modalTitle?: string;
  type?: DatetimeType;
  defaultTime?: any;
  onChange?: (value: RequestDateTime) => void;
  onCancel?: () => void;
}

export interface MBDateTimePickerState {
  visible: boolean;
  list: Array<any>;
}
@observer
export default class MBDateTimePickerComponent extends React.Component<MBDateTimePickerProps, MBDateTimePickerState> {
  store: Store;
  static defaultProps = {
    modalTitle: '选择时间',
    visible: false,
  };
  constructor(props: MBDateTimePickerProps) {
    super(props);
    this.store = new Store(props.type!);
    this.state = {
      visible: false,
      list: [],
    };
  }
  UNSAFE_componentWillReceiveProps(nextProps: any, prevProps: any) {
    const { visible } = nextProps;
    if (prevProps.visible !== visible && visible) {
      this.handlePress();
    }
  }
  handlePress = (): void => {
    this.store.showModal();
  };

  handleConfirm = (values: AppointTime[]): void => {
    this.store.saveValue(values);
    this.store.hideModal();

    this.props.onChange?.(this.store.datetimeValue4Api);
  };

  handleCancel = () => {
    this.store.hideModal();
    this.props.onCancel?.();
  };
  public render(): JSX.Element | null {
    const { modalTitle, defaultTime } = this.props;
    const { datetimeList } = this.store;
    if (!!datetimeList.length) {
      return (
        <ModalDateTime
          title={modalTitle}
          list={this.store.datetimeList}
          visible={this.store.visible}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          defaultTime={defaultTime}
        />
      );
    } else {
      return null;
    }
  }
}
