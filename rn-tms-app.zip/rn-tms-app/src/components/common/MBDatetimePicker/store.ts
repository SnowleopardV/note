import { computed, observable, action } from 'mobx';
import dayjs from 'dayjs';
import { AppointTime, DatetimeType } from './components/ModalDateTime/proptypes';
import { RequestDateTime } from './proptypes';
import { generatorList } from './util/generator';
import defaultData from './defaultData';
// const mock = require('./mock.json');

class Store {
  // 时间
  @observable value: AppointTime[] = [];
  // 时间集合
  @observable datetimeList: AppointTime[] = [];

  // 时间弹窗显示
  @observable visible: boolean = false;

  type: DatetimeType = 'loadTime';
  @computed get displayValue(): string {
    if (this.value && this.value.length) {
      return this.value.map((item) => item.displayName || '').join(' ');
    }
    return '';
  }

  /**
   * 开始时间时间戳
   */
  @computed get datetimeStamp() {
    if (this.value && this.value.length) {
      const length = this.value.length;
      return this.value[length - 1]?.endTimestamp;
    }
    return 0;
  }
  /**
   * 提交给接口的数据
   */
  @computed get datetimeValue4Api(): RequestDateTime | null {
    if (this.value && this.value.length) {
      const length = this.value.length;
      return {
        startTimestamp: this.value[length - 1].startTimestamp!,
        endTimestamp: this.value[length - 1].endTimestamp!,
        displayValue: this.value.map((item) => item.displayName || '').join(' '),
        dateCode: this.value[0].selectItemKey,
        timeInterval: Number(this.value[1].selectItemKey),
        hourPeriod: Number(this.value[2].selectItemKey),
      };
    }
    return null;
  }
  now = dayjs();
  constructor(type: DatetimeType) {
    this.type = type;
    const typeData = this.filterType(type);
    if (this.type === 'loadTimeMonth' || this.type === 'unloadTimeMonth') {
      this.initMonthData(typeData);
    } else {
      setTimeout(() => {
        this.saveDateTimeList(generatorList(this.now, this.now, typeData));
      }, 0);
    }
  }
  /** 要计算前后一个月的，使用缓存，只计算当天第一次的，后面都用缓存 */
  @action initMonthData = (typeData: any) => {
    const nowDay = this.now.date();
    if (defaultData.day !== nowDay || !defaultData.datetimeList.length) {
      defaultData.day = nowDay;
      defaultData.datetimeList = generatorList(this.now, this.now, typeData);
    }
    setTimeout(() => {
      this.saveDateTimeList(defaultData.datetimeList);
    }, 0);
  };
  /**
   * 根据type区分日期范围
   * loadTime：未来7天，unloadTime：未来14天，
   * loadTimeMonth：前后一个月，unloadTimeMonth：前一个月后一个月零七天
   */
  @action filterType = (type: string) => {
    let typeData = {
      beforeDay: 0,
      afterDay: 7,
    };

    switch (type) {
      case 'loadTime':
        typeData = {
          beforeDay: 0,
          afterDay: 7,
        };
        break;
      case 'unloadTime':
        typeData = {
          beforeDay: 0,
          afterDay: 14,
        };
        break;
      case 'loadTimeMonth':
        typeData = {
          beforeDay: 30,
          afterDay: 30,
        };
        break;
      case 'unloadTimeMonth':
        typeData = {
          beforeDay: 30,
          afterDay: 37,
        };
        break;
      default:
        typeData = {
          beforeDay: 0,
          afterDay: 7,
        };
        break;
    }

    return typeData;
  };

  @action showModal = () => {
    this.visible = true;
  };

  @action hideModal = () => {
    this.visible = false;
  };

  @action saveDateTimeList = (list: AppointTime[]) => {
    this.datetimeList = list;
  };

  /**
   * 接口返回的数据
   */
  @action saveInitialValue = (value: RequestDateTime) => {
    // if (value.startTimestamp < this.now.hour(0).valueOf()) {
    //   // 时间值过期
    //   return;
    // }
    const valueLevel1 = this.datetimeList.find((item) => item.selectItemKey == value.dateCode);
    const valueLevel2 = valueLevel1?.children?.find((item) => item.selectItemKey == value.timeInterval.toString());
    const valueLevel3 = valueLevel2?.children?.find((item) => item.selectItemKey == value.hourPeriod.toString());
    this.value = [
      Object.assign({}, valueLevel1, { children: null }),
      Object.assign({}, valueLevel2, { children: null }),
      { ...valueLevel3 },
    ];
  };
  @action saveValue = (values: AppointTime[]) => {
    this.value = values;
  };

  /**
   * 请求时间数据
   * @returns
   */
  fetchPageRenderData(): Promise<any> {
    const params = {};
    return new Promise((resolve) => {
      setTimeout(() => {
        // this.saveDateTimeList(mock.moduleData);
        resolve(true);
      }, 200);
    });
    // return Api.fetchPageRenderData(params)
    //   .then((resp) => {
    //     if (resp.success) {
    //       const modules = resp.data.list || [];
    //       this.saveDateTimeList(modules);
    //     }
    //     return resp;
    //   })
    //   .catch((error) => {
    //     MBToast.show(error.errorMsg || error.message || error.reason || '请检查网络');
    //     return Promise.reject(error);
    //   });
  }
}
export default Store;
