import { StyleSheet } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';
export default StyleSheet.create({
  header: {
    height: 58,
    width: '100%',
  },
  content: {
    zIndex: -1,
    marginHorizontal: RNElementsUtil.autoFix(-34),
  },
  hidden: {
    zIndex: -1,
    height: RNElementsUtil.autoFix(736),
    width: '100%',
  },
  confirmButton: {
    borderRadius: 24,
    paddingHorizontal: RNElementsUtil.autoFix(20),
  },
  section0: {
    width: RNElementsUtil.autoFix(280),
  },
  section1: {
    flex: 1,
  },
  msg: {
    paddingVertical: RNElementsUtil.autoFix(16),
    backgroundColor: '#FFF3E7',
  },
  textMiddleLine: {
    backgroundColor: '#333',
    height: 1,
    width: 8,
  },
});
