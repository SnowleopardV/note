export interface AppointTime {
  level: number;
  selectItemKey: string;
  selectItemName: string;
  displayName: string;
  startTimestamp?: number;
  endTimestamp?: number;
  selected: 0 | 1 | number;
  children?: AppointTime[];
}
export type DatetimeType = 'loadTime' | 'unloadTime' | 'loadTimeMonth' | 'unloadTimeMonth';

// SL: 二级时间（成交率），TL：三级时间（拍卖，满运宝，安心运，普票）,SC：2段式（整车，包含最早时间，最晚时间）
export type DateTimeUIType = 'TL' | 'SL' | 'SC';

export enum DateTimeUI {
  TL = 'TL', // 三级时间
  SL = 'SL', // 二级时间
  SC = 'SC', // 2段式时间
}

export interface RequestDateTime {
  startTimestamp: number;
  endTimestamp: number;
  displayValue: string; // 显示文案
  dateCode: string;
  timeInterval: number;
  hourPeriod: number;
}
