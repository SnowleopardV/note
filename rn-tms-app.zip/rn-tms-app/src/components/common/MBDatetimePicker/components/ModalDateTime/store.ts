import { observable, computed, action } from 'mobx';
import dayjs, { Dayjs } from 'dayjs';
import { AppointTime, DatetimeType, DateTimeUIType, DateTimeUI } from './proptypes';
import { generatorValue } from '../../util/generator';
const Level1DateFormate = 'YYYYMMDD';
class Store {
  level: number = 2; // 2：2段时间，3：3段时间列
  uiType: DateTimeUIType;
  @observable type: DatetimeType = 'loadTime';
  // 一级时间，年月日
  @observable valueLevel1: AppointTime;
  // 二级时间，凌晨，上午，下午，晚上时间段,时间点 12：00-13：00
  @observable valueLevel2: AppointTime;
  // 三级时间，时间点 12：00-13：00
  @observable valueLevel3?: AppointTime;

  // 索引位置
  @observable value1Position: number = 0;
  @observable value2Position: number = 0;
  @observable value3Position: number = 0;
  // 所有时间集合
  @observable list: AppointTime[] = [];

  /**
   * 第一列渲染的值
   */
  @computed get level1List(): AppointTime[] {
    return this.list.map((item) => {
      return Object.assign({}, item, { children: null });
    });
  }
  /**
   * 第二列渲染的值
   */
  @computed get level2List(): AppointTime[] {
    if (this.list && this.list.length) {
      const level1List = this.list.find((item) => item.selectItemKey === this.valueLevel1.selectItemKey);
      if (level1List && level1List.children && level1List.children.length) {
        return level1List.children;
      }
    }
    return [];
  }

  /**
   * 第三列渲染的值
   */
  @computed get level3List(): AppointTime[] {
    if (this.list && this.list.length) {
      const level2List = this.level2List.find((item) => item.selectItemKey === this.valueLevel2.selectItemKey);
      if (level2List && level2List.children && level2List.children.length) {
        return level2List.children;
      }
    }
    return [];
  }
  /**
   * 整车的2段式时间控件，1级时间的selectItemKey 都一样，所以需要取时间戳区分
   */
  @computed get level2ListByEndTimestamp(): AppointTime[] {
    if (this.list && this.list.length) {
      const level1List = this.list.find((item) => item.endTimestamp === this.valueLevel1.endTimestamp);
      if (level1List && level1List.children && level1List.children.length) {
        return level1List.children;
      }
    }
    return [];
  }

  @computed get values(): any[] {
    if (this.level === 2) {
      return [this.valueLevel1, this.valueLevel2];
    }
    return [this.valueLevel1, this.valueLevel2, this.valueLevel3].filter((value) => !!value);
  }
  /**
   * 初始化
   * @param level
   */
  constructor(level: number) {
    const now = dayjs();
    this.level = level;
    this.uiType = 'TL';
    // 默认时间
    this.valueLevel1 = {
      level: 1,
      selectItemKey: now.format(Level1DateFormate),
      selectItemName: '今天',
      displayName: '今天',
      startTimestamp: now.clone().startOf('date').valueOf(),
      endTimestamp: now.clone().add(1, 'day').startOf('date').valueOf(),
      selected: 1,
    };
    this.valueLevel2 = this.defaultLevel2Value(now, this.level);
    if (this.level === 3) {
      this.valueLevel3 = this.defaultLevel3Value(now);
    }
  }
  @action setValues = (values: AppointTime[]) => {
    if (values && values.length) {
      if (this.uiType === DateTimeUI.SC) {
        this.setValues4SC(values);
        return;
      }
      let expireTime = true;
      const [valueLevel1, valueLevel2, valueLevel3] = values;
      if (this.list && this.list[0]) {
        const firstItem = this.list[0];
        if (valueLevel3) {
          // 异常处理
          if (firstItem?.children?.[0]?.children) {
            // 3段式
            const lastTimeStamp =
              firstItem.children[0].children[0].selectItemKey.indexOf('0') !== -1 && firstItem.children[0].children.length > 1
                ? firstItem.children[0].children[1]
                : firstItem.children[0].children[0];
            expireTime = lastTimeStamp.endTimestamp > valueLevel3.endTimestamp;
          }
        } else if (valueLevel2) {
          const lastTimeStamp = firstItem.children[0].selectItemKey.indexOf('0') !== -1 ? firstItem.children[1] : firstItem.children[0];
          expireTime = lastTimeStamp.endTimestamp > valueLevel2.endTimestamp;
        }
        if (!expireTime) {
          this.valueLevel1 = valueLevel1;
          this.valueLevel2 = valueLevel2;
          this.valueLevel3 = valueLevel3;

          this.setValuePosition();
        }
      }
    }
  };
  /**
   * sc2段式的赋值和其他的都不一样
   * 每个段的时间值是独立的，比如：中午12:00 - 下午18:00
   * @param values
   */
  @action setValues4SC = (values: AppointTime[]) => {
    const [valueLevel1, valueLevel2] = values;
    let expireTime = true;
    if (this.list && this.list[0]) {
      const firstItem = this.list[0];
      // 如果1段时间已经过期，就以默认值为主
      if (valueLevel1 && valueLevel1.displayName !== '现在') {
        if (valueLevel1.endTimestamp > firstItem.endTimestamp) {
          // 未过期时间了
          this.valueLevel1 = valueLevel1;
        }
      }

      if (valueLevel2) {
        const lastTimeStamp = firstItem.children[0];
        expireTime = lastTimeStamp.endTimestamp > valueLevel2.endTimestamp;
      }
      if (!expireTime) {
        // if (valueLevel1.displayName !== '现在') {
        //   // displayname=‘现在’，他的endTimestamp是一直在变的
        //   this.valueLevel1 = valueLevel1
        // }
        this.valueLevel2 = valueLevel2;

        this.setValuePosition();
      }
    }
  };
  /**
   * 默认二级时间
   * @param now
   */
  defaultLevel2Value(now: Dayjs, level: number) {
    return generatorValue(now, level, 1);
  }
  /**
   * 默认 3级时间
   * @param now
   */
  defaultLevel3Value(now) {
    return generatorValue(now, 3, 2);
  }

  @action setValuePosition = () => {
    const { valueLevel1, valueLevel2, valueLevel3, uiType } = this;
    // 不同的时间，itemkey不一定能作为唯一键
    const uniqueKey = uiType === 'SC' ? 'endTimestamp' : 'selectItemKey';
    const value1Position = this.list.findIndex((item) => {
      return item[uniqueKey] === valueLevel1[uniqueKey];
    });
    if (value1Position === -1) {
      return;
    }
    const value2Position = this.list[value1Position].children!.findIndex((item) => {
      return item[uniqueKey] === valueLevel2[uniqueKey];
    });
    this.value1Position = value1Position;
    if (value2Position === -1) {
      return;
    }
    this.value2Position = value2Position;
    if (valueLevel3) {
      const value3Position = this.list[value1Position].children?.[value2Position].children?.findIndex((item) => {
        return item[uniqueKey] === valueLevel3[uniqueKey];
      });
      this.value3Position = value3Position || 0;
    }
  };

  @action setList(list: AppointTime[]) {
    this.list = list;
    // 先校验有无默认需要选中的，没有的话默认选中第一个
    this.valueLevel1 = this.getDefaultSelectedValue(list);
    if (!this.valueLevel1.children) {
      // 没有子节点
      return;
    }
    // 二级时间
    this.valueLevel2 = this.getDefaultSelectedValue(this.valueLevel1.children);
    // 三级时间
    let valueLevel3: any = void 0;
    if (this.valueLevel2.children) {
      valueLevel3 = this.getDefaultSelectedValue(this.valueLevel2.children);
    }
    this.valueLevel3 = valueLevel3;

    this.setValuePosition();
  }
  /**
   * 默认选中值，优先读取selected=1，否则取数组第一个
   * @param list
   */
  getDefaultSelectedValue(list: AppointTime[]) {
    const value = list.find((item) => item.selected === 1);
    if (value) {
      return value;
    } else {
      return list[0];
    }
  }
  /**
   * 2段式时间
   * 选择日期
   * 1. level1的值赋值
   * 2. 设置二级和三级时间的第一个子节点为默认值
   */
  @action setDate = (value: AppointTime) => {
    const uniqueKey = this.uiType === 'SC' ? 'endTimestamp' : 'selectItemKey';
    this.valueLevel1 = Object.assign({}, value, { selected: 1 });
    const level1 = this.list.find((item) => item[uniqueKey] === this.valueLevel1[uniqueKey]);
    if (level1 && level1.children) {
      this.valueLevel2 = this.getDefaultSelectedValue(level1.children);
      if (this.valueLevel2 && this.valueLevel2.children) {
        this.valueLevel3 = this.getDefaultSelectedValue(this.valueLevel2.children);
      }
    }
  };
  /**
   * 2段式时间
   * 选择时间段和时间点范围
   * 比如：上11：00-12：00
   * 需要同时设置二级时间和三级时间
   */
  @action setTime = (value: AppointTime) => {
    this.valueLevel2 = Object.assign({}, value, { selected: 1 });
    if (this.valueLevel2 && this.valueLevel2.children) {
      this.valueLevel3 = this.getDefaultSelectedValue(this.valueLevel2.children);
    }
  };
  /**
   * 设置3段式时间
   * @param position 3段式滚动的索引位置
   * @param value 选中的值
   * @param type 0:日期，1:时间段，2:时间点
   */
  @action setDateTimePoint = (position: number, value: AppointTime, type: number) => {
    if (type === 0) {
      this.setDate(value);
      this.value1Position = position;
      this.value2Position = this.findIndex(this.list[position].children, this.valueLevel2);
      this.value3Position = this.findIndex(this.valueLevel2.children, this.valueLevel3);
    } else if (type === 1) {
      // 今天或明天快速切换第二列的时候，出现value值为undefined的场景，需要重置下日期列的值
      if (value) {
        this.setTime(value);
        this.value2Position = position;
        this.value3Position = this.findIndex(this.valueLevel2.children, this.valueLevel3);
      } else {
        this.setDate(this.valueLevel1);
        this.value2Position = this.findIndex(this.list[this.value1Position].children, this.valueLevel2);
        this.value3Position = this.findIndex(this.valueLevel2.children, this.valueLevel3);
      }
    } else if (type === 2) {
      this.valueLevel3 = value;
      this.value3Position = position;
    }
  };

  @action setDateTimeForColumn2 = (position: number, value: AppointTime, type: number) => {
    if (type === 0) {
      const valueLevel2 = this.valueLevel2;
      this.setDate(value);
      this.value1Position = position;
      if (this.list[position].children) {
        // let value2Position = this.list[position].children.findIndex((item) => item['endTimestamp'] === valueLevel2['endTimestamp'])
        const value2Position = this.findIndex(this.list[position].children, valueLevel2);
        // 如果当前二级值依然存在于切换后的level1的children里，就不重置二级时间的值和索引位置了
        if (value2Position !== -1) {
          this.valueLevel2 = this.list[position].children[value2Position];
          this.value2Position = value2Position;
          this.value3Position = 0;
        } else {
          // 二段时间的位置索引
          // let value2Position = this.list[position].children.findIndex((item) => item['endTimestamp'] === this.valueLevel2['endTimestamp'])
          this.value2Position = this.findIndex(this.list[position].children, this.valueLevel2);
          this.value3Position = 0;
        }
      }
    } else if (type === 1) {
      this.setTime(value);
      this.value2Position = position;
      this.value3Position = 0;
    }
  };

  findIndex(list: AppointTime[], value: AppointTime) {
    if (list && value) {
      return list.findIndex((item) => item['endTimestamp'] === value['endTimestamp']);
    }
    return -1;
  }
}
export default Store;
