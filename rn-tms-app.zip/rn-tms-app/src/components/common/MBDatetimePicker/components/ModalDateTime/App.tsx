import * as React from 'react';
import { View, ActivityIndicator, StyleProp, ViewStyle, TouchableOpacity } from 'react-native';
import { observer, inject } from 'mobx-react';
import { Modal, Flex, MBText, Whitespace } from '@ymm/rn-elements';
import Store from './store';
import { AppointTime, DatetimeType, DateTimeUIType, DateTimeUI, RequestDateTime } from './proptypes';
import Level3List from './components/Level3List';
import styles from './styles';
import dayjs from 'dayjs';
/**
 * 成交率7.0 的时间选择控件
 */
export interface DateTimePickerAppProps {
  level: number;
  values?: AppointTime[]; // valueLevel1, valueLevel2
  list: AppointTime[];
  message?: string;
  visible: boolean;
  uiType: DateTimeUIType;
  scTexts?: string[]; // 2段式顶部提示文件，['最早装货时间','最晚装货时间']
  title?: string;
  store?: Store;
  onCancel?: () => void;
  onConfirm?: (values: AppointTime[]) => void;
  ymm_hotPageName?: string;
  autoHintRequiredTipsSwitch?: boolean;
  defaultTime?: RequestDateTime;
  contentStyle?: StyleProp<ViewStyle>;
}

@inject('store')
@observer
export default class DateTimePickerApp extends React.Component<DateTimePickerAppProps, any> {
  static defaultProps = {
    list: [],
    title: '请选择',
    level: 3,
    uiType: DateTimeUI.TL,
  };
  get store() {
    return this.props.store!;
  }
  constructor(props: DateTimePickerAppProps) {
    super(props);
    this.state = {};
  }
  componentWillReceiveProps(nextProps: DateTimePickerAppProps) {
    if (nextProps.uiType !== this.props.uiType) {
      this.store.uiType = nextProps.uiType;
      this.store.level = nextProps.level;
    }
    if (nextProps.list !== this.props.list) {
      if (nextProps.list && nextProps.list.length) {
        this.store.setList(nextProps.list);
        /**
         * 性能慢的手机，会出现values有值，但是配置下发render/page接口数据未返回的情况
         * 导致values赋值不成功，这里补偿下赋值
         */
        if (nextProps.values && nextProps.values.length) {
          if (
            nextProps.level === 2 &&
            nextProps.values.length === 2 &&
            nextProps.values[1].selectItemKey !== this.store.valueLevel2.selectItemKey
          ) {
            this.store.setValues(nextProps.values);
          } else if (
            nextProps.level === 3 &&
            nextProps.values.length === 3 &&
            this.store.valueLevel3 &&
            nextProps.values[2].selectItemKey !== this.store.valueLevel3.selectItemKey
          ) {
            // 可能由2段切换到3段时间控件
            this.store.setValues(nextProps.values);
          }
        }
      }
    }
    if (nextProps.values !== this.props.values && nextProps.values) {
      this.store.setValues(nextProps.values);
    }
  }
  componentDidMount() {
    const { values, list, uiType, defaultTime } = this.props;

    this.store.uiType = uiType;
    // 将默认时间在时间列表中标记出来
    if (list && list.length) {
      const listData = JSON.parse(JSON.stringify(list));
      if (defaultTime && defaultTime.dateCode) {
        for (const item_1 of listData) {
          if (item_1.selectItemKey == defaultTime?.dateCode) {
            item_1.selected = 1;
            for (const item_2 of item_1.children) {
              if (item_2.selectItemKey == defaultTime?.timeInterval) {
                item_2.selected = 1;
                for (const item_3 of item_2.children) {
                  if (item_3.selectItemKey == defaultTime?.hourPeriod) {
                    item_3.selected = 1;
                    break;
                  }
                }
                break;
              }
            }
            break;
          }
        }
      } else {
        // 如果没有默认时间，自动到当天时间
        const nowDate = dayjs().format('YYYYMMDD');
        for (const item_1 of listData) {
          if (item_1.selectItemKey === nowDate) {
            item_1.selected = 1;
            break;
          }
        }
      }
      this.store.setList(listData);
    }
    if (values && values.length) {
      this.store.setValues(values);
    }
  }
  /**
   * 确定
   */
  onConfirm = () => {
    const { onConfirm } = this.props;
    onConfirm && onConfirm(this.store.values);
  };
  /**
   * 取消
   */
  onCancel = () => {
    const { onCancel } = this.props;
    // 重置values的值
    if (this.props.values) {
      this.store.setValues(this.props.values);
    }
    onCancel && onCancel();
  };
  onRequestClose = () => {
    this.onCancel();
  };

  /**
   * 消息提醒
   * @param message 消息内容
   */
  renderMessage(message?: string) {
    if (message) {
      return (
        <View style={styles.msg}>
          <MBText align="center" color="bright" size="xs">
            {message}
          </MBText>
        </View>
      );
    }
    return null;
  }

  renderTextRow(texts?: string[]) {
    if (texts && texts.length) {
      return (
        <Flex direction="row" style={{ paddingVertical: 5, marginTop: 15 }}>
          {texts.map((str) => {
            return (
              <Flex flex={1} justify="center" direction="row" key={str}>
                <View style={styles.textMiddleLine} />
                <MBText>{str}</MBText>
                <View style={styles.textMiddleLine} />
              </Flex>
            );
          })}
        </Flex>
      );
    }
    return null;
  }

  /**
   * 渲染时间列表
   * 3段式
   * 场景：拍卖，满运宝，普票，安心运
   * @param list
   */
  renderLevel3List(list?: AppointTime[]) {
    if (list && list.length > 0) {
      return <Level3List values={this.store.values} />;
    }
    return this.renderActivityIndicator();
  }

  /**
   * 加载中
   */
  renderActivityIndicator() {
    return (
      <Flex justify="center" style={styles.hidden}>
        <ActivityIndicator size="small" color="#666" />
      </Flex>
    );
  }
  rightElement() {
    return (
      <TouchableOpacity
        onPress={() => {
          this.onConfirm();
        }}
      >
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render(): JSX.Element {
    const { visible, title, message, list, level, scTexts, uiType, contentStyle } = this.props;
    if (list.length <= 0) {
      return <View />;
    }
    return (
      <Modal
        visible={visible}
        position="bottom"
        title={title}
        headerLeft="取消"
        onCancel={this.onCancel}
        onConfirm={this.onConfirm}
        headerRight={this.rightElement()}
        headerStyle={styles.header}
        onRequestClose={this.onRequestClose}
        onMaskClose={this.onCancel}
        contentStyle={contentStyle}
      >
        <View style={styles.content}>
          {this.renderMessage(message)}
          {this.renderTextRow(scTexts)}
          {uiType === DateTimeUI.TL && this.renderLevel3List(list)}
          <Whitespace vertical={34} />
        </View>
      </Modal>
    );
  }
}
