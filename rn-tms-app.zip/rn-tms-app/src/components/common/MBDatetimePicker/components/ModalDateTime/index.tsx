import * as React from 'react';
import { View, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { Provider } from 'mobx-react';
import App from './App';
import Store from './store';
import { AppointTime, DatetimeType, DateTimeUIType, DateTimeUI, RequestDateTime } from './proptypes';
// 320114, 110101
export interface DateTimePickerProps {
  level?: number; // 2段，3段时间展示
  visible: boolean;
  uiType: DateTimeUIType;
  scTexts?: string[]; //
  title?: string;
  values?: AppointTime[];
  list: AppointTime[];
  message?: string;
  defaultTime?: RequestDateTime;
  onCancel?: () => void;
  onConfirm?: (values: AppointTime[]) => void;
  contentStyle?: StyleProp<ViewStyle>;
}
/**
 * 3段式日期时间选择控件
 * api:https://wiki.1111.com/pages/viewpage.action?pageId=103234587
 */
export default class DateTimePickerComponent extends React.Component<DateTimePickerProps, any> {
  store: Store;
  static defaultProps = {
    level: 3,
    uiType: DateTimeUI.TL,
  };
  constructor(props: DateTimePickerProps) {
    super(props);

    this.store = new Store(props.level || 3);
  }

  render() {
    const { level = 2, ...rest } = this.props;
    return (
      <Provider store={this.store}>
        <App level={level} {...rest} />
      </Provider>
    );
  }
}
