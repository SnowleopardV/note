import * as React from 'react';
import { observer, inject } from 'mobx-react';
import { Flex, Selector } from '@ymm/rn-elements';
import Store from '../../store';
import { AppointTime } from '../../proptypes';
import styles from './styles';
export interface Level3ListProps {
  store?: Store;
  values: AppointTime[];
}

// export interface Level3ListState {}
/**
 * 3段式时间控件
 */
@inject('store')
@observer
export default class Level3List extends React.Component<Level3ListProps, any> {
  get store() {
    return this.props.store!;
  }
  constructor(props: Level3ListProps) {
    super(props);
    this.state = {};
  }

  handleChangeDateTime(position: number, value: AppointTime, type: number) {
    this.store.setDateTimePoint(position, value, type);
  }
  render() {
    const { value1Position, value2Position, value3Position } = this.store;
    return (
      <Flex direction="row" justify="center" style={styles.hidden}>
        <Flex.Item key="date">
          <Selector
            type={2}
            scaleFont={true}
            value={value1Position}
            rowTitle="selectItemName"
            list={this.store.level1List}
            onChange={(position: number, value: AppointTime) => {
              this.handleChangeDateTime(position, value, 0);
            }}
          />
        </Flex.Item>
        <Flex.Item key="section">
          <Selector
            type={2}
            scaleFont={true}
            value={value2Position}
            rowTitle="selectItemName"
            list={this.store.level2List}
            onChange={(position: number, value: AppointTime) => {
              this.handleChangeDateTime(position, value, 1);
            }}
          />
        </Flex.Item>
        <Flex.Item key="time">
          <Selector
            type={2}
            scaleFont={true}
            value={value3Position}
            rowTitle="selectItemName"
            list={this.store.level3List}
            onChange={(position: number, value: AppointTime) => {
              this.handleChangeDateTime(position, value, 2);
            }}
          />
        </Flex.Item>
      </Flex>
    );
  }
}
