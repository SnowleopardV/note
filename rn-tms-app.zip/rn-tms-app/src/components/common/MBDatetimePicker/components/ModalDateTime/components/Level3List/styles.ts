import { StyleSheet } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';
export default StyleSheet.create({
  hidden: {
    marginTop: RNElementsUtil.autoFix(34),
    zIndex: -12,
    width: '100%',
  },
});
