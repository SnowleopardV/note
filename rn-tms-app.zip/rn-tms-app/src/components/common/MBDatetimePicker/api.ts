import server from '~/server';
import { AppointTime, DatetimeType } from './components/ModalDateTime/proptypes';
interface PageRenderResponseParams {
  list: AppointTime[];
}
const Api = {
  fetchPageRenderData(params: any = {}): Promise<ResponseData<PageRenderResponseParams>> {
    return server({
      url: '/saas-tms-trans/yzgApp/render/page',
      data: { ...params },
    });
  },
};

export default Api;
