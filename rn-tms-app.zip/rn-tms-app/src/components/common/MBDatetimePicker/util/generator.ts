import { Dayjs } from 'dayjs';
import { AppointTime } from '../components/ModalDateTime/proptypes';
interface DatetimeItemConfig {
  key: string;
  timeName: string;
  displayName: string;
  start: number;
  end: number;
}
interface DateTimeMapModel {
  [key: string]: DatetimeItemConfig;
}

interface typeDataConfig {
  beforeDay: number;
  afterDay: number;
}

const dateTimeMap: DateTimeMapModel = {
  '1': {
    key: '00',
    timeName: '凌晨',
    displayName: '都可以',
    start: 0,
    end: 6,
  },
  '2': {
    key: '10',
    timeName: '上午',
    displayName: '都可以',
    start: 6,
    end: 12,
  },
  '3': {
    key: '20',
    timeName: '下午',
    displayName: '都可以',
    start: 12,
    end: 18,
  },
  '4': {
    key: '30',
    timeName: '晚上',
    displayName: '都可以',
    start: 18,
    end: 24,
  },
};

function leftZero(text: number) {
  let string = text.toString();
  if (string.toString().length == 1) {
    string = `0${string.toString()}`;
  }
  return string;
}

function formatRang(start: number, end: number) {
  const startText = leftZero(start) + ':00';
  const endText = leftZero(end) + ':00';
  return `${startText} - ${endText}`;
}
/**
 * 生成某个时间段的所有时间数据
 * @param startDate 起始时间
 * @param now 今天
 * @param beforeDay 今天向前多少天
 * @param afterDay 今天向后多少天
 */
export function generatorList(startDate: Dayjs, now: Dayjs, typeData: typeDataConfig): AppointTime[] {
  const list: AppointTime[] = [];
  // 在当前时间前插入天数
  if (typeData.beforeDay) {
    for (let i = 0; i < typeData.beforeDay; i++) {
      const date = startDate.subtract(i + 1, 'day');
      // const name = date.isSame(now, 'date') ? '今天' : date.date() - 1 === now.date() ? '明天' : date.format('MM月DD日');
      const name = date.format('MM月DD日');
      const rootItem: AppointTime = {
        level: 1,
        selectItemKey: date.format('YYYYMMDD'),
        selectItemName: name,
        displayName: name,
        selected: 0,
        children: [generatorAllDay(date)].concat(generatorTimes(date)),
      };
      list.unshift(rootItem);
    }
  }
  // 在当前时间后插入天数
  if (typeData.afterDay) {
    for (let i = 0; i < typeData.afterDay; i++) {
      const date = startDate.add(i, 'day');
      const name = date.format('MM月DD日');
      const rootItem: AppointTime = {
        level: 1,
        selectItemKey: date.format('YYYYMMDD'),
        selectItemName: name,
        displayName: name,
        selected: 0,
        children: [generatorAllDay(date)].concat(generatorTimes(date)),
      };
      list.push(rootItem);
    }
  }

  for (const i in list) {
    /**
     * 如果是今天
     * 1.修改今天全天都可以的开始时间戳
     * 2.过滤当前时间之前的时间
     */
    if (list[i].selectItemName === now.format('MM月DD日') && !typeData?.beforeDay) {
      list[i].children![0].children![0].startTimestamp = now.valueOf();
      // 过滤掉时间段，比如现在已经是下午14：00，需要过滤凌晨和上午
      for (const key in dateTimeMap) {
        if (dateTimeMap[key].end > now.hour()) {
          list[i].children!.splice(1, Number(key - 1));
          break;
        }
      }
      // 过滤掉时间点
      list[i].children![1].children = list[i].children![1].children!.filter(
        (item, index) => item.selectItemKey === '-1' || Number(item.selectItemKey) > now.hour()
      );
      break;
    }
  }
  return list;
}
/**
 * 根据某天生成都可以数据
 * @param targetDate
 * @returns
 */
export function generatorAllDay(targetDate: Dayjs): AppointTime {
  const value: AppointTime = {
    level: 2,
    startTimestamp: targetDate.hour(0).startOf('hour').valueOf(),
    endTimestamp: targetDate.hour(24).startOf('hour').valueOf(),
    selectItemKey: '0',
    selectItemName: '全天',
    displayName: '全天',
    selected: 0,
    children: [
      {
        level: 3,
        startTimestamp: targetDate.hour(0).startOf('hour').valueOf(),
        endTimestamp: targetDate.hour(24).startOf('hour').valueOf(),
        selectItemName: '都可以',
        displayName: '00:00 - 24:00',
        selectItemKey: '-1',
        selected: 0,
      },
    ],
  };
  return value;
}
/**
 * 生成时间段数据，并包含时间段下的子数据
 * 凌晨，上午，下午，晚上
 */
export function generatorTimes(targetDate: Dayjs): AppointTime[] {
  const hours: AppointTime[] = [];
  // 先基于某天生成24个小时的时间数据
  for (let i = 0; i <= 23; i++) {
    const date = targetDate.hour(i);
    const formatName = `${i + 1}:00`;
    const hour: AppointTime = {
      level: 3,
      startTimestamp: date.startOf('hours').valueOf(),
      endTimestamp: date
        .hour(i + 1)
        .startOf('hours')
        .valueOf(),
      selectItemKey: `${i + 1}`,
      selectItemName: formatName,
      displayName: formatName,
      selected: 0,
    };
    hours.push(hour);
  }
  // 凌晨，上午，下午，晚上
  const times: AppointTime[] = Object.keys(dateTimeMap).map((key, index) => {
    return {
      level: 2,
      startTimestamp: targetDate.hour(dateTimeMap[key].start).startOf('hour').valueOf(),
      endTimestamp: targetDate.hour(dateTimeMap[key].end).startOf('hour').valueOf(),
      selectItemKey: key,
      selectItemName: dateTimeMap[key].timeName,
      displayName: dateTimeMap[key].timeName,
      selected: 0,
      children: [
        {
          level: 3,
          startTimestamp: targetDate.hour(dateTimeMap[key].start).startOf('hour').valueOf(),
          endTimestamp: targetDate.hour(dateTimeMap[key].end).startOf('hour').valueOf(),
          selectItemKey: '-1',
          selectItemName: dateTimeMap[key].displayName,
          displayName: leftZero(dateTimeMap[key].start) + ':00-' + leftZero(dateTimeMap[key].end) + ':00',
          selected: 0,
        } as AppointTime,
      ].concat(hours.slice(dateTimeMap[key].start, dateTimeMap[key].end)),
    };
  });
  return times;
}
/**
 *
 * @param now 当前时间
 * @param level 2段时间或3段时间
 * @param index 第2或第3个列的索引
 */
export function generatorValue(now: Dayjs, level: number, index: number) {
  // level=2，说明只有2段时间，2级时间的level是3；
  const value: AppointTime = {
    level: level === 2 && index === 1 ? 3 : index + 1,
    selectItemKey: '20',
    selectItemName: '下午',
    displayName: '下午',
    startTimestamp: now.startOf('date').valueOf(),
    endTimestamp: now.endOf('date').valueOf(),
    selected: 1,
  };
  const hour = now.hour();
  if (index === 1) {
    // 2级时间
    for (const key in dateTimeMap) {
      const config = dateTimeMap[key];
      if (hour < config.end) {
        value.selectItemKey = `${key}99`;
        value.selectItemName = level === 2 ? `${config.timeName} ${config.displayName}` : config.timeName;
        value.displayName = level === 2 ? `${config.timeName} ${formatRang(config.start, config.end)}` : config.timeName;
        value.startTimestamp = now.hour(config.start).startOf('hour').valueOf();
        value.endTimestamp = now.hour(config.end).startOf('hour').valueOf();
        break;
      }
    }
  } else if (index === 2) {
    for (const key in dateTimeMap) {
      const config = dateTimeMap[key];
      if (hour < config.end) {
        const nextHour = hour + 1;
        // 比如上午8点：0608；下午14点：1214
        value.selectItemKey = `${leftZero(config.start)}${leftZero(nextHour)}`;
        value.selectItemName = `${leftZero(nextHour)}:00前`;
        value.displayName = `${formatRang(hour, nextHour)}`;
        value.startTimestamp = now.hour(config.start).startOf('hour').valueOf();
        value.endTimestamp = now.hour(nextHour).startOf('hour').valueOf();
        break;
      }
    }
  }
  return value;
}
