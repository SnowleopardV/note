import * as React from 'react';
import { View, StyleProp, ViewStyle } from 'react-native';
import { inject, observer } from 'mobx-react';
import Cell from '~/components/common/Cell';
import ModalDateTime from './components/ModalDateTime';
import { AppointTime, DatetimeType } from './components/ModalDateTime/proptypes';
import Store from './store';
import { RequestDateTime } from './proptypes';

/**
 * 装卸货时间，时间选择控件
 */
export interface MBDateTimePickerProps {
  withIcon?: boolean;
  title?: string;
  modalTitle?: string;
  align?: 'left' | 'right';
  placeholder?: string;
  value?: RequestDateTime;
  type?: DatetimeType;
  onChange?: (value: RequestDateTime) => void;
  style?: StyleProp<ViewStyle>;
  required?: boolean;
  extra?: React.ReactNode | string;
  contentStyle?: StyleProp<ViewStyle>;
}

export interface MBDateTimePickerState {
  visible: boolean;
}
const icon = 'https://image.ymm56.com/ymmfile/operation-biz/a0361c79-1f0e-4846-827d-4ee6a69a4cc3.png';
@observer
export default class MBDateTimePickerComponent extends React.Component<MBDateTimePickerProps, MBDateTimePickerState> {
  store: Store;
  static defaultProps = {
    withIcon: false,
    modalTitle: '选择时间',
    type: 'loadTime',
  };
  constructor(props: MBDateTimePickerProps) {
    super(props);
    this.store = new Store(props.type!);
    this.state = {
      visible: false,
    };
    if (props.value) {
      this.store.saveInitialValue(props.value);
    }
  }

  componentWillMount() {
    // this.store.fetchPageRenderData().then((resp: ResponseData<any>) => {
    //   if (resp.success) {
    //     //成功
    //   }
    // });
  }
  handlePress = (): void => {
    this.store.showModal();
  };

  handleConfirm = (values: AppointTime[]): void => {
    this.store.saveValue(values);
    this.store.hideModal();

    this.props.onChange?.(this.store.datetimeValue4Api);
  };

  handleCancel = () => {
    this.store.hideModal();
  };
  public render(): JSX.Element {
    const { withIcon, title, modalTitle, placeholder, align, required, style, extra, contentStyle } = this.props;
    return (
      <View>
        {!withIcon ? (
          <Cell
            title={title}
            placeholder={placeholder}
            align={align}
            required={required}
            value={this.store.displayValue}
            onPress={this.handlePress}
            extra={extra}
          />
        ) : (
          <Cell
            icon={icon}
            title={' '}
            placeholder={placeholder}
            align={'left'}
            value={this.store.displayValue}
            onPress={this.handlePress}
            titleStyle={{ marginRight: 6 }}
            style={style}
            extra={extra}
          />
        )}
        <ModalDateTime
          title={modalTitle}
          list={this.store.datetimeList}
          visible={this.store.visible}
          contentStyle={contentStyle}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
        />
      </View>
    );
  }
}
