const defaultData: any = {
  day: 0,
  datetimeList: [], // 当天保存的一个月的缓存
};
export default defaultData;
