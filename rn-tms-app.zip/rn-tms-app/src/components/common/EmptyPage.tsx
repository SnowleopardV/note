import React from 'react';
import { StyleSheet, View, Image } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Images from '~/../public/static/images';

const EmptyPage = (props: any) => (
  <View style={[styles.emptyPage, props.style]}>
    <Image style={[styles.imgStyle, props.imgStyle]} source={{ uri: props.errorData?.image ?? Images.icon_empty_data }} />
    <MBText style={[styles.tipText, props.tipText]} align="center">
      {props.errorData?.msg}
    </MBText>
    {props.renderElement ? props.renderElement : null}
  </View>
);

const styles = StyleSheet.create<any>({
  emptyPage: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#F7F7F7',
    paddingTop: autoFix(355),
  },

  imgStyle: {
    width: autoFix(287),
    height: autoFix(272),
  },

  tipText: {
    width: autoFix(400),
    marginTop: autoFix(33),
    fontSize: autoFix(28),
    color: '#A2ADC7',
  },
});

export default EmptyPage;
