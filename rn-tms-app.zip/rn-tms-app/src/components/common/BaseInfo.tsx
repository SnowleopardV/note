import React from 'react';
import { View, StyleSheet, Image, Platform } from 'react-native';
import { Flex, MBText, Whitespace } from '@ymm/rn-elements';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import { MBToast } from '@ymm/rn-lib';
import TagMini from '../TagMini';
import LevelTag from '../LevelTag';

export default class BaseInfo extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      timeLineHeight: 0,
    };
  }
  onLayoutAddress(el: any) {
    const height = el?.nativeEvent?.layout?.height;
    this.setState({ timeLineHeight: height + autoFix(6) });
  }
  render() {
    const { info } = this.props;
    const { timeLineHeight } = this.state;
    return (
      <View>
        <View style={styles.infoBox}>
          <View style={styles.flexRow}>
            <View style={{ flexDirection: 'row' }}>
              <MBText style={styles.orderNum}>{info.orderNo}</MBText>
              {!!info.orderCargoLevel && <LevelTag text={info.orderCargoLevel} isFull={false} />}
            </View>
            {!!info.orgName && (
              <MBText color="#999" numberOfLines={1} style={{ flex: 1, paddingLeft: 20, textAlign: 'right', fontSize: 12 }}>
                {info.orgName}
              </MBText>
            )}
            {info.dispatchStatus ? (
              <MBText style={[styles.orderStatus, info.dispatchStatus === '已取消' && { color: '#999' }]}>{info.dispatchStatus}</MBText>
            ) : null}
          </View>
          {/*插入logo*/}
          <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
            <MBText style={styles.company}>{info.custName || '--'}</MBText>
            {info.invoiceFlag === '1' && (
              <Image style={{ height: autoFix(28), width: autoFix(140), marginTop: autoFix(3) }} source={images.logo_task_mybqy} />
            )}
            {info.invoiceFlag === '2' && (
              <Image style={{ height: autoFix(28), width: autoFix(77), marginTop: autoFix(3) }} source={{ uri: images.icon_myb }} />
            )}
            {!!info.custLevel && <LevelTag text={info.custLevel} isFull />}
          </View>

          <MBText style={styles.cargoInfo} numberOfLines={2}>
            {info.cargoInfoForDisplay || '--'}
          </MBText>
          <View style={{ position: 'relative' }}>
            <View style={styles.address} onLayout={(el) => this.onLayoutAddress(el)}>
              <View style={[styles.point, styles.load]}></View>
              <MBText style={styles.addressText}>{info.loadMessage?.address || info.loadAddress || '--'}</MBText>
            </View>
            <Whitespace vertical={10} />
            <View style={styles.stepLine}>
              {!!timeLineHeight && (
                <View style={{ height: timeLineHeight }}>
                  <Image fadeDuration={0} resizeMode="repeat" style={{ height: '100%', width: autoFix(2) }} source={images.line_vertical} />
                </View>
              )}
            </View>
            <View style={styles.address}>
              <View style={[styles.point, styles.unload]}></View>
              <MBText style={styles.addressText}>{info.unloadMessage?.address || info.unloadAddress || '--'}</MBText>
            </View>
          </View>
        </View>
        {info.dispatcherName || info.expectLoadTime ? (
          <View style={styles.dispatcherTime}>
            <View style={styles.dispatcherNameExpectLoadTime}>
              {info.dispatcherName ? (
                <View style={styles.dispatcherNameWrapper}>
                  <MBText style={styles.dispatcherName}>调度员：{info.dispatcherName}</MBText>
                </View>
              ) : null}
              {info.expectLoadTime ? <MBText style={styles.expectLoadTime}>预计装货时间：{info.expectLoadTime}</MBText> : null}
            </View>
          </View>
        ) : null}

        {this.props.children}
      </View>
    );
  }
}

BaseInfo.defaultProps = {
  info: {},
};

const styles = StyleSheet.create({
  flexing: {
    flex: 1,
  },
  infoBox: {
    paddingVertical: 14,
    paddingHorizontal: 16,
  },
  flexRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  orderNum: {
    fontSize: 14,
    color: '#999',
  },
  cargoInfo: {
    fontSize: 14,
    color: '#999',
    marginBottom: 8,
  },
  orderStatus: {
    paddingLeft: 20,
    fontSize: 12,
    color: '#4885FF',
  },
  company: {
    fontSize: 16,
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  address: {
    flexDirection: 'row',
  },
  point: {
    width: autoFix(14),
    height: autoFix(14),
    borderRadius: 100,
    marginTop: autoFix(9),
    marginRight: autoFix(14),
  },
  load: {
    backgroundColor: '#4885FF',
  },
  unload: {
    backgroundColor: '#333333',
  },
  addressText: {
    fontSize: autoFix(24),
  },
  stepLine: {
    position: 'absolute',
    top: autoFix(22),
    left: autoFix(6),
    height: autoFix(16),
  },

  dispatcherTime: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 10,
    paddingLeft: 8,
    paddingRight: 13,
  },

  dispatcherNameExpectLoadTime: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginLeft: 8,
  },

  dispatcherName: {
    color: '#333333',
    fontSize: 14,
  },

  expectLoadTime: {
    color: '#999999',
    fontSize: 12,
  },

  dispatcherNameWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  dispatcherNameTag: {
    paddingHorizontal: 3,
    marginLeft: 3,
    borderWidth: 0.5,
    fontSize: 10,
    borderRadius: 4,
    borderBottomLeftRadius: 0,
    color: '#4885FF',
    borderColor: '#4885FF',
  },
});
