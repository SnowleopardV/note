import * as React from 'react';
import { TouchableOpacity, View, Image, StyleProp, TextStyle } from 'react-native';
import { YMMCommonNavBar, MBBridge } from '@ymm/rn-lib';
import { MBText } from '@ymm/rn-elements';
interface INavBarProps {
  leftElementImagUri?: string;
  title: string | JSX.Element;
  leftClick?: () => void;
  onRight?: () => void;
  titleStyle?: StyleProp<TextStyle>;
  rightElement?: string | JSX.Element;
  bgColor?: string;
}

const NavBar: React.FunctionComponent<INavBarProps> = (props) => {
  const { title, leftClick, leftElementImagUri, titleStyle, ...restProps } = props;
  const handleLeftClick = () => {
    if (leftClick) {
      leftClick();
      return;
    }
    MBBridge.app.ui.closeWindow({});
  };
  return (
    <YMMCommonNavBar
      {...restProps}
      leftElement={
        <TouchableOpacity onPress={handleLeftClick}>
          <View style={{ width: 60, height: 44, justifyContent: 'center' }}>
            <Image resizeMode={'stretch'} source={{ uri: leftElementImagUri }} style={{ width: 17, height: 20, marginLeft: 15 }} />
          </View>
        </TouchableOpacity>
      }
      titleEelement={
        <MBText size="lg" style={titleStyle}>
          {title}
        </MBText>
      }
    />
  );
};

NavBar.defaultProps = {
  leftElementImagUri: 'https://image.ymm56.com/ymmfile/operation-biz/b3e6c94d-00ed-4e4a-9990-d56e951e9ec9.png',
};

export default NavBar;
