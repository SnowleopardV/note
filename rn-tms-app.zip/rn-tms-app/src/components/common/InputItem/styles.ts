import { StyleSheet } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';

export default StyleSheet.create({
  container: {
    flexDirection: 'column',
    paddingLeft: RNElementsUtil.autoFix(28),
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: RNElementsUtil.autoFix(28),
    paddingRight: RNElementsUtil.autoFix(28),
  },
  title: {
    fontSize: 15,
    color: '#333',
  },
  input: {
    flex: 1,
    fontSize: 15,
    color: '#666',
    margin: 0,
    // marginHorizontal: RNElementsUtil.autoFix(30),
    // lineHeight: RNElementsUtil.autoFix(30),
  },
  item_required: {
    fontSize: 15,
    color: '#FF4040',
    marginLeft: 4,
  },
  item_arrow_container: {
    justifyContent: 'flex-end',
    marginLeft: 8,
  },
  item_arrow: {
    width: 8,
    height: 14,
  },
  extra_node: {
    fontSize: 15,
    color: '#666',
  },
});
