import { ViewStyle, TextStyle, StyleProp } from 'react-native';
import { InputProps } from '@ymm/rn-elements/lib/components/Input/PropTypes';

export interface InputItemProps extends InputProps {
  title?: string;
  titleIcon?: React.ReactNode;
  value?: string;
  required?: boolean; // 显示星号，必填
  defaultValue?: string;
  autoFocus?: boolean; // didmount后获取焦点
  editable?: boolean; // 是否可以编辑，默认true
  maxLength?: number;
  placeholder?: string;
  isLink?: boolean; // 是否有箭头
  rightIcon?: React.ReactNode; // 右侧图标
  rightElement?: React.ReactNode; // 右边控件元素
  extra?: React.ReactNode | string; // 下划线等其他额外填充组件
  extraNode?: React.ReactNode | string;
  bottomLine?: boolean; // 底部下划线
  textAlign?: 'left' | 'right' | 'center';
  readonly?: boolean; // 只读置灰
  onChange?: (e: any) => void;
  onChangeText?: (text: string) => void;
  onEndEditing?: () => void;
  onBlur?: () => void;
  onFocus?: () => void;
  onTitlePress?: () => void; // 左侧标题被点击
  onReadOnlyPress?: () => void; // 只读模式下被点击
  inputStyle?: StyleProp<ViewStyle> | StyleProp<TextStyle>;
  style?: StyleProp<ViewStyle>;
  titleStyle?: StyleProp<ViewStyle> | StyleProp<TextStyle>;
  styleItem?: StyleProp<ViewStyle>;
  requiredStyle?: StyleProp<ViewStyle> | StyleProp<TextStyle>;
  linkIconStyle?: StyleProp<ViewStyle>;
}

export interface InputItemState {
  focus: boolean;
}
