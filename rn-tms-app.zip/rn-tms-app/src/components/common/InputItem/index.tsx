import * as React from 'react';
import { View, Image, Keyboard, Platform, EmitterSubscription, StyleProp, ViewStyle } from 'react-native';
import { MBText, Input, Splitline } from '@ymm/rn-elements';
import { InputItemProps, InputItemState } from './PropTypes';
import styles from './styles';
import images from '~public/static/images';

export default class InputItem extends React.Component<InputItemProps, InputItemState> {
  inputNode: Input | null;
  keyboardHideListener?: EmitterSubscription;
  static defaultProps = {
    bottomLine: false,
    required: false,
    isLink: false,
    readonly: false,
    textAlign: 'left',
    multiline: true,
    numberOfLines: 1,
  };
  constructor(props: InputItemProps) {
    super(props);
    this.inputNode = null;
    this.state = {
      focus: props.autoFocus || false,
    };
    if (Platform.OS === 'android') {
      this.keyboardHideListener = Keyboard.addListener('keyboardDidHide', this.keyboardHide);
    }
  }
  componentWillUnmount(): void {
    this.keyboardHideListener?.remove();
  }
  keyboardHide = () => {
    if (this.state.focus) {
      this.blur();
    }
  };
  onBlur = () => {
    const { onBlur } = this.props;
    this.setState(
      {
        focus: false,
      },
      () => {
        onBlur && onBlur();
      }
    );
  };
  onFocus = () => {
    const { onFocus } = this.props;
    this.setState(
      {
        focus: true,
      },
      () => {
        onFocus && onFocus();
      }
    );
  };
  focus = () => {
    if (this.inputNode) {
      this.inputNode.focus();
      this.setState({
        focus: true,
      });
    }
  };
  blur = () => {
    if (this.inputNode) {
      this.inputNode.blur();
      this.setState({
        focus: false,
      });
    }
  };
  /**
   * 是否获取焦点
   */
  isFocused = () => {
    if (this.inputNode) {
      return this.inputNode.isFocused();
    }
    return false;
  };
  /**
   * todo:增加清除功能
   * 清除输入框内容
   */
  clear = () => {
    if (this.inputNode) {
      this.inputNode.clear();
    }
    this.props.onChangeText && this.props.onChangeText('');
  };
  renderExtraNode(
    styles: any,
    extraNode: React.ReactNode | string,
    isLink?: boolean,
    readonly?: boolean,
    linkIconStyle?: StyleProp<ViewStyle>
  ) {
    if (typeof extraNode === 'string') {
      return (
        <View style={{ paddingRight: 16 }}>
          <MBText style={[styles.extra_node, readonly ? { color: '#ccc' } : {}]}>{extraNode}</MBText>
        </View>
      );
    } else if (isLink) {
      return (
        <View style={[styles.item_arrow_container, linkIconStyle]}>
          <Image style={styles.item_arrow} source={{ uri: images.icon_arrow_gray }} />
        </View>
      );
    }
    return extraNode || <View style={{ paddingRight: 16 }} />;
  }
  render() {
    const {
      required,
      title,
      titleIcon,
      titleStyle,
      extra,
      extraNode,
      inputStyle,
      isLink,
      style,
      bottomLine,
      styleItem,
      requiredStyle,
      readonly,
      textAlign,
      multiline,
      numberOfLines,
      linkIconStyle,
      onTitlePress,
      onReadOnlyPress,
      ...restProps
    } = this.props;
    const valueProps: any = {};
    if ('value' in restProps) {
      valueProps.value = restProps.value ? restProps.value.toString() : '';
    } else {
      valueProps.defaultValue = restProps.defaultValue;
    }
    return (
      <View style={[styles.container, style]}>
        <View style={[styles.item, styleItem]}>
          {!!titleIcon && titleIcon}
          <View>
            <MBText style={[styles.title, readonly ? { color: '#ccc' } : {}, titleStyle]} onPress={onTitlePress}>
              {title}
              {required ? <MBText style={[styles.item_required, requiredStyle, readonly ? { color: '#ccc' } : {}]}>&nbsp;*</MBText> : null}
            </MBText>
          </View>
          {readonly ? (
            <MBText style={[styles.input, { color: '#ccc', textAlign: textAlign }, inputStyle]} onPress={onReadOnlyPress}>
              {this.props.value}
            </MBText>
          ) : (
            <Input
              ref={(el) => {
                (this.inputNode as any) = el;
              }}
              style={[styles.input, inputStyle, readonly ? { color: '#ccc' } : {}]}
              placeholderTextColor="#ccc"
              returnKeyType="done"
              textAlign={textAlign}
              multiline={multiline}
              numberOfLines={numberOfLines}
              onSubmitEditing={Keyboard.dismiss}
              blurOnSubmit={true}
              {...restProps}
              {...valueProps}
              onFocus={this.onFocus}
              onBlur={this.onBlur}
            />
          )}
          {this.renderExtraNode(styles, extraNode, isLink, readonly, linkIconStyle)}
        </View>
        {!!extra && <View>{extra}</View>}
        {bottomLine && <Splitline />}
      </View>
    );
  }
}
