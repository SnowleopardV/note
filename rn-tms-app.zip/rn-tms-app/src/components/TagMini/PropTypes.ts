import { StyleProp, ViewStyle, TextStyle, ImageStyle } from 'react-native';

export interface TagMiniProps {
  type?: string;
  color?: string;
  borderRadius?: boolean; // 是否显示三角圆角
  bgColor?: string; // 是否显示三角圆角
  children: string;
  textStyle?: StyleProp<TextStyle>;
  iconStyle?: StyleProp<ImageStyle>;
  style?: StyleProp<ViewStyle>;
}
