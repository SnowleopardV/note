import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import { StyleSheet } from 'react-native';

const Styles = (val: any) => {
  return StyleSheet.create({
    tagBox: {
      borderWidth: autoFix(1),
      marginLeft: autoFix(16),
      marginRight: autoFix(16),
      paddingHorizontal: autoFix(6),
      paddingVertical: autoFix(2),
      borderColor: !val.bgColor && val.color ? val.color : 'transparent',
      backgroundColor: val.bgColor || 'transparent',
    },
    borderRadius: {
      borderTopLeftRadius: autoFix(8),
      borderTopRightRadius: autoFix(8),
      borderBottomRightRadius: autoFix(8),
    },
    text: {
      color: val.color || '#fff',
      fontSize: val.type === 'large' ? autoFix(20) : autoFix(16),
    },
  });
};
export default Styles;
