import * as React from 'react';
import { View } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import getStyles from './styles';
import { TagMiniProps } from './PropTypes';

export default class TagMini extends React.Component<TagMiniProps, any> {
  static defaultProps = { color: '#4885FF', borderRadius: true };
  constructor(props: TagMiniProps) {
    super(props);
    this.state = {};
  }
  render() {
    const { style, textStyle, children, color, type, borderRadius, bgColor } = this.props;
    const styles = getStyles({ color, bgColor, type });
    return (
      <View style={[styles.tagBox, borderRadius ? styles.borderRadius : null, style]}>
        <MBText style={[styles.text, textStyle]}>{children}</MBText>
      </View>
    );
  }
}
