import * as React from 'react';
import { View, ScrollView, Image, StyleSheet } from 'react-native';
import { MBText, Flex, Splitline } from '@ymm/rn-elements';
import TouchableThrottle from '~/components/TouchableThrottle';
import Images from '../../public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
const FlexItem = Flex.Item;

/**
 * 地址搜索结果组件
 */

export interface StateAddressModel {
  poiName?: string;
  detailAddress?: string;
  regionAddress?: string;
  regionAddressWithSpace?: string;
  streetAddress?: string;
  longitude?: string;
  latitude?: string;
  districtCode?: number;
  districtName?: string;
  cityCode?: number;
  cityName?: string;
  provinceCode?: number;
  provinceName?: string;
}

interface IAddressListProps {
  inputText?: string;
  addressList: StateAddressModel[];
  hisAddressList: StateAddressModel[];
  onSelect: (address: any) => void;
}

const AddressList: React.FunctionComponent<IAddressListProps> = (props) => {
  const { addressList = [], inputText = '', onSelect, hisAddressList = [] } = props;
  return (
    <ScrollView style={styles.scrollBox} keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false}>
      <View>
        <View style={{ flex: 1 }}>
          {hisAddressList.length ? (
            <Flex direction="row" style={{ marginTop: autoFix(25), paddingHorizontal: autoFix(20) }}>
              <FlexItem>
                <Splitline color="#CCD2DE" />
              </FlexItem>
              <FlexItem flex={2} style={{ paddingLeft: autoFix(20) }}>
                <MBText style={{ textAlign: 'center', color: '#CCD2DE' }}>历史地址</MBText>
              </FlexItem>
              <FlexItem flex={4}>
                <Splitline color="#CCD2DE" />
              </FlexItem>
            </Flex>
          ) : null}

          {hisAddressList.map((addr: any, index: number) => {
            return (
              <TouchableThrottle
                activeOpacity={0.8}
                onPress={() => {
                  onSelect(addr);
                }}
                key={index}
              >
                <View style={styles.addrItem}>
                  <View style={styles.addrDesc}>
                    {!!addr.address ? (
                      <View style={{ flexDirection: 'row', alignItems: 'center', paddingRight: autoFix(90) }}>
                        <View style={{ flexDirection: 'row' }}>
                          <View style={styles.iconWrapper}>
                            <Image style={styles.itemIcon} source={{ uri: Images.icon_timeOrange }} />
                          </View>
                        </View>
                        <MBText style={[styles.addrDetailText, styles.colorBlack]}>{addr.address}</MBText>
                        {addr.tip && (
                          <View style={styles.addrTipTextContainer}>
                            <MBText style={styles.addrCommonText}>{addr.tip}</MBText>
                          </View>
                        )}
                      </View>
                    ) : null}
                  </View>
                </View>
              </TouchableThrottle>
            );
          })}
        </View>

        <View style={{ flex: 1 }}>
          {addressList.length ? (
            <Flex direction="row" style={{ marginTop: autoFix(25), paddingHorizontal: autoFix(20) }}>
              <FlexItem>
                <Splitline color="#CCD2DE" />
              </FlexItem>
              <FlexItem flex={2} style={{ paddingLeft: autoFix(20) }}>
                <MBText style={{ textAlign: 'center', color: '#CCD2DE' }}>地图地址</MBText>
              </FlexItem>
              <FlexItem flex={4}>
                <Splitline color="#CCD2DE" />
              </FlexItem>
            </Flex>
          ) : null}

          {addressList.map((addr: any, index: number) => {
            return (
              <TouchableThrottle
                activeOpacity={0.8}
                onPress={() => {
                  onSelect(addr);
                }}
                key={index}
              >
                <View style={styles.addrItem}>
                  <View style={styles.iconWrapper}>
                    <Image style={styles.itemIcon} source={{ uri: Images.icon_addressBlue }} />
                  </View>
                  <View style={styles.addrDesc}>
                    {!!addr.poiName ? (
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 2 }}>
                        {!!inputText && addr?.poiName?.indexOf(inputText) >= 0 ? (
                          <View style={{ flexDirection: 'row' }}>
                            <MBText style={styles.addrPoiText}>{addr?.poiName?.substring(0, addr?.poiName?.indexOf(inputText))}</MBText>
                            <MBText style={[styles.addrPoiText, { color: '#4885FF' }]}>
                              {addr?.poiName?.substring(
                                addr?.poiName?.indexOf(inputText),
                                addr?.poiName?.indexOf(inputText) + inputText.length
                              )}
                            </MBText>
                            <MBText style={styles.addrPoiText}>
                              {addr?.poiName?.substring(addr?.poiName?.indexOf(inputText) + inputText.length)}
                            </MBText>
                          </View>
                        ) : (
                          <MBText style={[styles.addrPoiText, { fontWeight: 'normal' }]}>{addr.poiName}</MBText>
                        )}
                        {addr.tip && (
                          <View style={styles.addrTipTextContainer}>
                            <MBText style={styles.addrCommonText}>{addr.tip}</MBText>
                          </View>
                        )}
                      </View>
                    ) : null}

                    {!!addr.address ? <MBText style={[styles.addrDetailText]}>{addr.address}</MBText> : null}
                  </View>
                </View>
              </TouchableThrottle>
            );
          })}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  listBox: {
    flex: 1,
    backgroundColor: '#fff',
    marginHorizontal: 10,
    borderRadius: 8,
  },
  scrollBox: {
    flex: 1,
  },
  addrItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingLeft: 14,
  },
  addrIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  addrIconImg: {
    width: 18,
    height: 23,
    marginRight: 8,
  },
  addrDesc: {
    flex: 1,
    paddingTop: 10,
    paddingBottom: 10,
    flexDirection: 'column',
  },
  addrPoiText: {
    fontSize: 16,
    color: '#333333',
  },
  addrTipTextContainer: {
    paddingLeft: 4,
    paddingRight: 4,
    paddingTop: 1,
    paddingBottom: 1,
    borderRadius: 5,
    marginLeft: 4,
    backgroundColor: '#FA871E',
    justifyContent: 'center',
    alignItems: 'center',
    height: 17,
  },
  addrCommonText: {
    fontSize: 12,
    color: 'white',
  },
  addrDetailText: {
    fontSize: 14,
    color: '#999999',
  },
  colorBlack: {
    color: '#333333',
  },
  addrDividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 10,
    paddingBottom: 10,
  },
  addrDividerLabel: {
    fontSize: 12,
    color: '#999999',
    marginLeft: 14,
    marginRight: 14,
    fontWeight: 'bold',
  },
  iconWrapper: {
    marginRight: autoFix(12),
    marginTop: autoFix(8),
  },
  itemIcon: {
    width: autoFix(32),
    height: autoFix(32),
  },
});

export default AddressList;
