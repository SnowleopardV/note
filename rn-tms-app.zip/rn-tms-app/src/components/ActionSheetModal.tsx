import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Modal, MBText, Whitespace, Splitline } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
type listType = {
  label: string;
  value: string;
};
// ActionSheetModal 模态框
interface Props {
  visible?: boolean;
  title: string;
  list: listType[];
  defaultData: string | null;
  onConfirm?: (item: listType) => void;
  onCancel?: () => void;
}
export default class ActionSheetModal extends React.Component<Props, any> {
  static defaultProps = {
    list: [],
  };
  constructor(props: Props) {
    super(props);
    this.state = {};
  }
  handleConfirm = (item: listType) => {
    const { onConfirm } = this.props;
    onConfirm && onConfirm(item);
  };
  handleCancel = () => {
    const { onCancel } = this.props;
    onCancel && onCancel();
  };
  render(): JSX.Element {
    const { visible, list, title, defaultData } = this.props;
    return (
      <View>
        <Modal
          title={title}
          position="bottom"
          visible={visible}
          headerLine={false}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <View style={{ width: '100%' }}>
            {list.map((item: listType, index: number) => {
              return (
                <TouchableOpacity style={{ width: '100%', height: autoFix(100) }} onPress={() => this.handleConfirm(item)}>
                  <MBText
                    numberOfLines={1}
                    bold={defaultData === item.value}
                    color={defaultData === item.value ? '#4885FF' : '#333'}
                    style={{ flex: 1, flexDirection: 'row', textAlign: 'center', lineHeight: autoFix(100), fontSize: autoFix(29) }}
                  >
                    {item.label}
                  </MBText>
                  {list.length - 1 > index && <Splitline color="#E8E8E8" />}
                </TouchableOpacity>
              );
            })}
          </View>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create({});
