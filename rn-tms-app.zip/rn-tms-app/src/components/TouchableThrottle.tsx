import React, { PureComponent } from 'react';
import { StyleProp, TouchableOpacity, ViewStyle } from 'react-native';

export interface TouchableProps {
  onPress: () => void;
  activeOpacity?: number;
  style?: StyleProp<ViewStyle>;
  waitSecond?: number; //单位是秒
}
/**
 * 防止多次点击事件
 */
export default class TouchableThrottle extends PureComponent<TouchableProps, any> {
  static defaultProps = {
    waitSecond: 1,
    activeOpacity: 1.0,
  };
  //是否可以点击
  clickEnabled: boolean = true;

  constructor(props) {
    super(props);
  }

  render() {
    const { activeOpacity, onPress, waitSecond = 1 } = this.props;
    return (
      <TouchableOpacity
        {...this.props}
        onPress={() => {
          if (this.clickEnabled) {
            this.clickEnabled = false;
            onPress && onPress();
            setTimeout(() => {
              this.clickEnabled = true;
            }, waitSecond * 1000);
          }
        }}
        activeOpacity={activeOpacity}
      >
        {this.props.children}
      </TouchableOpacity>
    );
  }
}
