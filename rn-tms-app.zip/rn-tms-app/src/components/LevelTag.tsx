import * as React from 'react';
import { View, ScrollView, Image, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import TagMini from './TagMini';
interface Props {
  text?: string;
  isFull: boolean;
  style?: StyleProp<ViewStyle>;
}
const typeColorMap = {
  A: '#35c75a',
  B: '#ff9f0a',
  C: '#ff375f',
  D: '#aeaeb2',
  '-1': '#FFFFFF',
};
const LevelTag = function (props: Props) {
  const text = props.text + '类';
  return (
    <View>
      <TagMini
        type="large"
        borderRadius={false}
        color={props.isFull ? '#FFFFFF' : typeColorMap[props.text?.toUpperCase() || -1]}
        bgColor={props.isFull ? typeColorMap[props.text?.toUpperCase() || -1] : null}
        style={props.style}
      >
        {text}
      </TagMini>
    </View>
  );
};
export default LevelTag;
