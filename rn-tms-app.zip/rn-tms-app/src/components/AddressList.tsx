import * as React from 'react';
import { View, ScrollView, Image, StyleSheet } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import TouchableThrottle from '~/components/TouchableThrottle';

/**
 * 地址搜索结果组件
 */

export interface StateAddressModel {
  poiName?: string;
  detailAddress?: string;
  regionAddress?: string;
  regionAddressWithSpace?: string;
  streetAddress?: string;
  longitude?: string;
  latitude?: string;
  districtCode?: number;
  districtName?: string;
  cityCode?: number;
  cityName?: string;
  provinceCode?: number;
  provinceName?: string;
}

interface IAddressListProps {
  inputText?: string;
  addressList: StateAddressModel[];
  onSelect: (address: any) => void;
}

const AddressList: React.FunctionComponent<IAddressListProps> = (props) => {
  const { addressList = [], inputText = '', onSelect } = props;
  return (
    <ScrollView style={styles.scrollBox} keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false}>
      <View style={styles.listBox}>
        {addressList.map((addr: any, index: number) => {
          let formatName = '';
          if (!!addr?.provinceName && !!addr?.cityName) {
            formatName =
              (addr.provinceName != addr.cityName ? addr.provinceName : '') +
              addr.cityName +
              (!!addr.districtName ? addr.districtName : '');
          }
          return (
            <TouchableThrottle
              activeOpacity={0.8}
              onPress={() => {
                onSelect(addr);
              }}
              key={index}
            >
              <View style={styles.addrItem}>
                <View style={styles.addrDesc}>
                  {!!addr.poiName ? (
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 2 }}>
                      {!!inputText && addr?.poiName?.indexOf(inputText) >= 0 ? (
                        <View style={{ flexDirection: 'row' }}>
                          <MBText style={styles.addrPoiText}>{addr?.poiName?.substring(0, addr?.poiName?.indexOf(inputText))}</MBText>
                          <MBText style={[styles.addrPoiText, { color: '#4885FF' }]}>
                            {addr?.poiName?.substring(
                              addr?.poiName?.indexOf(inputText),
                              addr?.poiName?.indexOf(inputText) + inputText.length
                            )}
                          </MBText>
                          <MBText style={styles.addrPoiText}>
                            {addr?.poiName?.substring(addr?.poiName?.indexOf(inputText) + inputText.length)}
                          </MBText>
                        </View>
                      ) : (
                        <MBText style={[styles.addrPoiText, { fontWeight: 'normal' }]}>{addr.poiName}</MBText>
                      )}
                      {addr.tip && (
                        <View style={styles.addrTipTextContainer}>
                          <MBText style={styles.addrCommonText}>{addr.tip}</MBText>
                        </View>
                      )}
                    </View>
                  ) : null}

                  {!!addr.address ? <MBText style={[styles.addrDetailText]}>{addr.address}</MBText> : null}
                </View>
              </View>
            </TouchableThrottle>
          );
        })}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  listBox: {
    flex: 1,
    backgroundColor: '#fff',
    marginHorizontal: 10,
    borderRadius: 8,
  },
  scrollBox: {
    flex: 1,
  },
  addrItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingLeft: 14,
  },
  addrIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  addrIconImg: {
    width: 18,
    height: 23,
    marginRight: 8,
  },
  addrDesc: {
    flex: 1,
    paddingTop: 10,
    paddingBottom: 10,
    flexDirection: 'column',
  },
  addrPoiText: {
    fontSize: 16,
    color: '#333333',
  },
  addrTipTextContainer: {
    paddingLeft: 4,
    paddingRight: 4,
    paddingTop: 1,
    paddingBottom: 1,
    borderRadius: 5,
    marginLeft: 4,
    backgroundColor: '#FA871E',
    justifyContent: 'center',
    alignItems: 'center',
    height: 17,
  },
  addrCommonText: {
    fontSize: 12,
    color: 'white',
  },
  addrDetailText: {
    fontSize: 14,
    color: '#999999',
  },
  addrDividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 10,
    paddingBottom: 10,
  },
  addrDividerLabel: {
    fontSize: 12,
    color: '#999999',
    marginLeft: 14,
    marginRight: 14,
    fontWeight: 'bold',
  },
});

export default AddressList;
