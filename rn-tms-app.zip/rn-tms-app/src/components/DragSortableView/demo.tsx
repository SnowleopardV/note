import { LayProvider, MBText, SortableList } from '@ymm/rn-elements';
import React from 'react';
import { Dimensions, Image, ScrollView, StyleSheet, View } from 'react-native';
import NavBar from '~/components/common/NavBar';
import images from '../../../public/static/images';
import DragSortableView from '~/components/DragSortableView/DragSortableView';
const { width } = Dimensions.get('window');
/** 定义分享字段文案 */
export default class demo extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      scrollEnabled: true,
      isEnterEdit: false,
      selectedList: [
        { id: 1, name: '客户名称1', belonging: '运单' },
        { id: 2, name: '客户名称2', belonging: '运单' },
        { id: 3, name: '客户名称3', belonging: '运单' },
        { id: 4, name: '客户名称4', belonging: '运单' },
        { id: 5, name: '客户名称4', belonging: '运单' },
        { id: 6, name: '客户名称4', belonging: '运单' },
        { id: 7, name: '客户名称4', belonging: '运单' },
        { id: 8, name: '阿迪斯', belonging: '运单' },
        { id: -1, name: '未选择' },
        { id: 9, name: '客户名称4', belonging: '运单' },
        { id: 10, name: '火影', belonging: '运单' },
        { id: 11, name: '名人堂', belonging: '运单' },
        { id: 12, name: '客户名称4', belonging: '运单' },
        { id: 13, name: '客户名称4', belonging: '运单' },
        { id: 14, name: '客户名称4', belonging: '运单' },
      ],
    };
  }

  rightElement() {
    return <MBText color="primary">确定</MBText>;
  }
  renderRow = (row: any, index: number) => {
    return (
      <View key={index} style={{ width: width, backgroundColor: row.id === -1 ? '#F6F7F9' : '#fff' }}>
        {row.id !== -1 ? (
          <View style={[styles.item]}>
            <MBText style={{ width: 80 }}>{row.id}</MBText>
            <MBText style={{ width: 100 }}>{row?.belonging}</MBText>
            <MBText style={{ flex: 1 }}>{row?.name}</MBText>
            <Image source={images.icon_readjust} style={{ width: 25, height: 17 }} />
          </View>
        ) : (
          <View style={[styles.item]}>
            <MBText color="#84848A">未选择</MBText>
          </View>
        )}
      </View>
    );
  };
  render() {
    const { scrollEnabled, selectedList } = this.state;
    return (
      <LayProvider theme="skyblue" style={{ flex: 1, backgroundColor: '#F6F7F9' }}>
        <NavBar title="分享字段设置" leftClick={() => this.props.navigation?.goBack()} rightElement={this.rightElement()} />
        <ScrollView style={{ flex: 1 }} scrollEnabled={scrollEnabled}>
          <View>
            <View style={[styles.title, styles.paddingH]}>
              <MBText style={{ width: 80 }}>序号</MBText>
              <MBText style={{ width: 100 }}>归属</MBText>
              <MBText style={{ flex: 1 }}>字段名称</MBText>
              <MBText>调整</MBText>
            </View>
            <View style={[styles.paddingH, { paddingVertical: 15 }]}>
              <MBText color="#84848A">已选择</MBText>
            </View>
            <DragSortableView
              key="seleded"
              dataSource={selectedList}
              parentWidth={width}
              childrenWidth={width}
              childrenHeight={50}
              onDragStart={(startIndex: number, endIndex: number) => {
                if (!this.state.isEnterEdit) {
                  this.setState({
                    isEnterEdit: true,
                    scrollEnabled: false,
                  });
                } else {
                  this.setState({ scrollEnabled: false });
                }
              }}
              onDragEnd={(startIndex: number) => {
                this.setState({ scrollEnabled: true });
              }}
              onDataChange={(data: any) => {
                if (data.length == selectedList.length) {
                  let num = 0;
                  const list = data.map((item: any) => {
                    if (item.id === -1) {
                      num = 0;
                    } else {
                      ++num;
                      item.id = num;
                    }
                    return item;
                  });
                  this.setState({ selectedList: list });
                }
              }}
              onClickItem={(data: any, item: any, index: number) => {
                // click delete
                if (this.state.isEnterEdit) {
                  const newData = [...data];
                  newData.splice(index, 1);
                  this.setState({
                    data: newData,
                  });
                }
              }}
              keyExtractor={(item: any, index: number) => item.txt} // FlatList作用一样，优化
              renderItem={(item: any, index: number) => {
                return this.renderRow(item, index);
              }}
            />
          </View>
        </ScrollView>
      </LayProvider>
    );
  }
}

const styles = StyleSheet.create({
  paddingH: {
    paddingHorizontal: 20,
  },
  title: {
    marginTop: 15,
    height: 50,
    lineHeight: 50,
    backgroundColor: '#FFF',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  item: {
    height: 50,
    lineHeight: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#F6F7F9',
    borderBottomWidth: 1,
    marginLeft: 20,
    paddingRight: 20,
  },
});
