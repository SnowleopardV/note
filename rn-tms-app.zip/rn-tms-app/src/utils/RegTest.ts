const RegTest = {
  /**
   * 正整数
   * @param str
   */
  positiveInteger: function (str) {
    const reg = /^(([1-9][0-9]*))$/;
    return reg.test(str);
  },

  /**
   * 0-100且小数点后最多二位数字
   * @param str
   */
  zeroHundredTwoPrecision: function (str) {
    const reg = /^(\d{1,2}(\.\d{0,2})?|100(\.0{0,2})?)$/;
    return reg.test(str);
  },

  /**
   * 0-100且小数点后最多五位数字
   * @param str
   */
  zeroHundredFivePrecision: function (str) {
    const reg = /^(\d{1,2}(\.\d{0,5})?|100(\.0{0,5})?)$/;
    return reg.test(str);
  },

  /**
   * 小数点后最多二位数字
   * @param str
   */
  twoPrecision: function (str) {
    const reg = /^(([0-9][0-9]*)|(([0]\.\d{0,2}|[0-9][0-9]*\.\d{0,2})))$/;
    return reg.test(str);
  },

  /**
   * 小数点后最多n位数字
   * @param str
   */
    numPrecision: function (str: string | number,  n: number) {
      const regStr = `/^(([0-9][0-9]*)|([0]\\.\\d{0,${n}}|[0-9][0-9]*\\.\\d{0,${n}}))$/`;
      return eval(regStr).test(str);
    },

  /**
   * 非负整数
   * @param str
   */
  unNegativeInteger: function (str) {
    const reg = /^[0-9]*$/;
    return reg.test(str);
  },

  /**
   * 表情
   * @param str
   */
  emoji: function (str) {
    const reg = /[^\u0020-\u007E\u00A0-\u00BE\u2E80-\uA4CF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\u0080-\u009F\u2000-\u201f\u2026\u2022\u20ac\r\n]/g;
    return reg.test(str);
  },

  /**
   * 非0且000/0.00
   * @param str
   */
  isDigit: function (str) {
    const reg = /^([1-9]\d*|0)(\.\d*[1-9])?$/;
    return reg.test(str);
  },
};

export default RegTest;
