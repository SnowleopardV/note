/**
 * @parmas arr: 需要去重的数组
 * @val key: 数组对象的key
 * 根据数组对象的某个字段去重
 * */
function unique(arr: any, key: string) {
  const res = new Map();
  return arr.filter((item: any) => !res.has(item[key]) && res.set(item[key], 1));
}

export { unique };
