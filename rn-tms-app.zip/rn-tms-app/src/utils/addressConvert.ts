export enum ConvertType {
  CityPicker2Server = 'citypicker2server', //citypicker2server(省市区弹窗数据格式转为服务端所需字段)
}

export default function convertAddress(data: any, type: ConvertType) {
  const typeCode = data?.typeCode || '';
  switch (type) {
    case ConvertType.CityPicker2Server:
      return {
        province: Number(data?.deep == 2 ? data?.parentCode : data?.grandId),
        provinceName: data?.deep == 2 ? data?.parentName : data?.formatName ? data?.formatName?.split(' ')[0] : '',
        city: Number(data?.deep == 2 ? data?.code : data?.parentCode),
        cityName: data?.deep == 2 ? data?.name : data?.parentName,
        area: Number(data?.code),
        areaName: data?.deep == 2 ? '' : data?.name,
        address: '',
        poiName: '',
        latitude: data?.lat,
        longitude: data?.lon,
        typeCode,
      };
    default:
      return null;
  }
}
