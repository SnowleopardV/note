import { create, all } from 'mathjs';

const config = {};
const math = create(all, config);

function comp(_func, args) {
  let t = math.chain(math.bignumber(args[0]));
  for (let i = 1; i < args.length; i++) {
    t = t[_func](math.bignumber(args[i]));
  }
  // 防止超过6位使用科学计数法
  return parseFloat(t.done());
}

export const xyzMath = {
  // 加
  add(...theArgs) {
    return comp('add', theArgs);
  },

  // 减
  subtract(...theArgs) {
    return comp('subtract', theArgs);
  },

  // 乘
  multiply(...theArgs) {
    return comp('multiply', theArgs);
  },

  // 除
  divide(...theArgs) {
    return comp('divide', theArgs);
  },

  // 四舍五入+保留n位有效数字
  round(...theArgs) {
    return comp('round', theArgs);
  },
};
