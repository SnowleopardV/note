import { Platform } from 'react-native';
import { MBBridge, MBToast, App } from '@ymm/rn-lib';
/**
 * 请求，只有post
 * @param params
 * @returns
 */
interface BaseRequestParams {
  url: string;
  data?: any; // post参数
  method?: 'POST';
  headers?: any;
}
interface OptionalParams {
  showLoading?: boolean; // loading
  toastError?: boolean; // 异常提醒
}
export type ServerSecondLevelData = boolean | string | number | ServerReallyData;
export interface ServerReallyData {
  [x: string]: any;
}
export interface BaseReturnData {
  code: string;
  msg: string;
  success: boolean;
  data: ServerSecondLevelData;
}
let timerHttp: any = null;
export default async function http(params: BaseRequestParams, _optional?: OptionalParams): Promise<void | BaseReturnData> {
  if (!params.url) {
    MBToast.show('请求缺少url入参');
    return Promise.reject(new TypeError('请求缺少url入参'));
  }
  const optional = Object.assign({ showLoading: true, toastError: true }, _optional || {});
  if (optional.showLoading) {
    clearTimeout(timerHttp);
    timerHttp = setTimeout(() => {
      MBBridge.ui.showLoading({});
    }, 100); // 延迟100ms 再显示loading
  }

  const res = await MBBridge.app.base.appInfo({});

  // http://yapi.1111.com/#/project/1649/interface/api/109538
  // serverType 0:dev 1:QA 3: release
  if (res.data.appId !== 'com.tms.merchant' && res.data.appId !== 'com.tms8.merchant') {
    if (res.data.serverType === 0) params.url = 'https://dev-api.tms8.com' + params.url;
    else if (res.data.serverType === 1) params.url = 'https://qa-api.tms8.com' + params.url;
    else if (res.data.serverType === 3) params.url = 'https://api.tms8.com' + params.url;
  }

  params.headers = {
    url_name: 'tms',
    // 'gateway-swimlane': 'appop',
  };

  //todo ios base.tmsRequest
  return MBBridge.app.base
    .request(params)
    .then((response: any) => {
      // ios多包了一层。。
      if (Platform.OS === 'ios') {
        if (response.code === 0) {
          response = response.data;
        } else {
          // 错误信息 reason字段
          return Promise.reject(response);
        }
      }

      // 异常code处理
      // TODO 租户域code:number类型10000，等待下次强制升级前后端一起处理
      if (
        (!response.success || response.data?.success === false) &&
        response.code !== 10000 &&
        response.code !== '90000' &&
        response.code !== '710012' &&
        response.code !== '710013'
      ) {
        // MBToast.show(response.reason || response.msg || JSON.stringify(response));
        console.log('错误接口：', params.url);
        return Promise.reject(response);
      }
      return response;
    })
    .catch((er) => {
      // android：-111033， ios:410, 鉴权失败，弹出去登录弹窗时不toast提醒
      if (optional.toastError && (er.code !== -111033 || er.code !== 410)) {
        MBToast.show(er.message || er.msg || er.reason || JSON.stringify(er));
      }

      // code：'310010', 登录失效，请重新登录
      if (res.data.appId !== 'com.tms.merchant' && res.data.appId !== 'com.tms8.merchant') {
        // ymm
        if (er.code === '310010') {
          if (Platform.OS === 'android') {
            MBBridge.app.base.openSchema({ url: 'ymm://user/login' });
          } else {
            App.sendEvent('NotificationDidLogout', {});
          }
        }
      } else {
        // tms
        if (Platform.OS === 'android') {
          if (er.code === '310010') {
            MBBridge.app.base.openSchema({ url: 'ymm://tms/logout' });
          }
          if (er.code === '600009') {
            MBBridge.app.base.openSchema({ url: 'ymm://tms/expired?msg='.concat(er.msg) });
          }
        }
      }

      return Promise.reject(er);
    })
    .finally(() => {
      if (optional.showLoading) {
        clearTimeout(timerHttp);
        MBBridge.ui.hideLoading({});
      }
    });
}
