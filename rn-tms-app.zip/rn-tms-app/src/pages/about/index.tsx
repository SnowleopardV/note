import React from 'react';
import { SafeAreaView, View, StyleSheet } from 'react-native';
import { CellGroup, Whitespace } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Cell from '~/components/common/Cell';
import NavBar from '~/components/common/NavBar';
import { RouterPageName } from './Router/register';
import { MBBridge } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';

export interface AboutIndexProps {
  navigation: any;
}

const AboutIndex = function (props: AboutIndexProps): JSX.Element {
  const { navigation } = props;

  const onNavigation = (routerName: string) => {
    navigation.navigate(RouterPageName[routerName]);
  };
  const goPages = (url: string) => {
    NativeBridge.openWebViewPage(url);
  };
  return (
    <View style={styles.container}>
      <NavBar title="关于我们" />
      <SafeAreaView style={styles.flexStyle}>
        <CellGroup withBottomLine style={styles.cellWrapper}>
          <Cell
            name="introduce"
            title="公司介绍"
            align="right"
            isLink
            contentStyle={styles.contentStyle}
            onPress={() => onNavigation('CompanyIntroduce')}
          />
          <Cell
            name="user"
            title="服务协议"
            align="right"
            isLink
            contentStyle={styles.contentStyle}
            onPress={() => goPages('https://static.tms8.com/rn/agreement/vue.html#/mw-tview/index?key=632357E096')}
          />
          <Cell
            name="privacy"
            title="隐私政策"
            align="right"
            isLink
            contentStyle={styles.contentStyle}
            onPress={() => goPages('https://static.tms8.com/rn/agreement/vue.html#/mw-tview/index?key=88b1818C4c')}
          />
        </CellGroup>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  cellWrapper: {
    margin: 10,
  },
  contentStyle: {
    height: 54,
  },
});

export default AboutIndex;
