import React from 'react';
import { SafeAreaView, View, StyleSheet, ScrollView } from 'react-native';
import { MBText, Splitline, Whitespace } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NavBar from '~/components/common/NavBar';

export interface UserProps {
  navigation?: any;
  screenProps?: any;
}

const User = function (props: UserProps): JSX.Element {
  const { navigation, screenProps } = props;

  const onLeftClick = () => {
    if (screenProps.routername) {
      MBBridge.app.ui.closeWindow({});
      return;
    }
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <NavBar title="服务协议" leftClick={onLeftClick} />
      <ScrollView keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
        <SafeAreaView>
          <View style={styles.content}>
            <MBText style={styles.pageTitle}>运掌柜用户服务协议</MBText>
            <Splitline />
            <Whitespace vertical={20} />
            <MBText style={styles.text}>
              <MBText style={styles.strongText}>&emsp;&emsp;欢迎您注册运掌柜账号并使用运掌柜的服务！</MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;为使用运掌柜平台及运掌柜的服务，您应当认真阅读并遵守本《运掌柜用户服务协议》（“
              <MBText style={styles.strongText}>本协议</MBText>
              ”）以及运掌柜平台发布的各项协议、规则、条款以及其他内容与文件。本协议是上海运掌柜电子科技有限公司（简称“
              <MBText style={styles.strongText}>运掌柜</MBText>
              ”）作为运掌柜平台（定义见下文）的运营者和服务提供者，与您（“<MBText style={styles.strongText}>您</MBText>”或“
              <MBText style={styles.strongText}>用户</MBText>”）就您注册、使用运掌柜平台所订立的有效合约。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;您点击或勾选运掌柜平台相关页面上的“同意”键或者以其他方式确认同意/接受本协议（如在相关页面上点击后续操作或已实际享有本协议项下的权益或已实际接受运掌柜的服务或已实际执行本协议项下的部分约定等（“确认”）），即表示您与运掌柜已达成协议并同意接受本协议全部约定内容的约束。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;在确认本协议之前，请您务必审慎、仔细阅读并充分理解本协议的全部内容（特别是免除或者限制责任的内容、开通或使用某项服务的内容、收费的内容以及以粗体及/或下划线标注的内容）。如果您不同意本协议的任何内容，或者无法准确理解本协议任何条款的含义，请不要进行确认及后续操作。本协议构成您注册、使用运掌柜平台之先决条件，您的使用行为将视为同意接受本协议各项条款的约束。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;运掌柜有权随时变更本协议并在运掌柜平台上予以公告，如您不同意相关变更，必须停止使用运掌柜平台。本协议内容包括协议正文及所有运掌柜已经发布的各类规则。所有规则为本协议不可分割的一部分，与本协议正文具有同等法律效力。一旦您继续使用运掌柜平台，则表示您已接受并自愿遵守经修订后的条款。
              </MBText>
            </MBText>

            <MBText style={styles.h2Title}>一、定义</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.1 运掌柜平台：</MBText>
              指运掌柜运营的为用户提供订单管理、调度分配、行车管理、GPS车辆定位系统、车辆管理、人员管理、数据报表管理等服务的物流运输管理系统，包括但不限于“运掌柜”PC、APP、微信公众号、小程序等软件/网站/网页/程序。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.2 用户：</MBText>使用任一运掌柜平台所提供的服务的自然人、法人或其他组织。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.3 用户信息：</MBText>
              指您提交给运掌柜/运掌柜平台的及通过运掌柜/运掌柜平台发布的及/或运掌柜通过您授权的第三方获取的用户相关信息，包括但不限于您提交、发布的您的基本信息、营业执照、用户指定的代表及/或联系人的姓名与联系方式、授权委托书、道路运输经营许可证、车辆行驶证、驾驶证、开户许可证、银行账户信息、用户的法定代表人/负责人/经营者/代表姓名、身份证号及身份证载明的其他信息等；姓名、电话号码、身份证号及身份证载明的其他信息、车辆信息、货源信息等,以及您为申请、使用运掌柜的合作方所提供的服务/商品而提交的其他用户相关信息。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.4 个人信息：</MBText>《运掌柜隐私政策》下“个人信息”的定义和范围适用本协议。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.5 账号：</MBText>
              指您按运掌柜平台提供的方式设置或取得的供您登录及使用运掌柜平台服务的编码，该编码可能是您的手机号码/邮箱地址，也可以是根据运掌柜平台规则编辑或设置的其他数字或文字。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.6 身份验证：</MBText>
              指您按运掌柜平台提供的方式设置或取得的供您登录及使用运掌柜平台服务的编码，该编码可能是您的手机号码/邮箱地址，也可以是根据运掌柜平台规则编辑或设置的其他数字或文字。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.7 验证信息凭证：</MBText>
              指验证信息的一切载体，包括但不限于载有、证明、体现、反映验证信息的各类文件、资料、凭据、凭证、证件、证照、图片、照片、视频等。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp; <MBText style={styles.strongText}>1.8 会员：</MBText>
              用户在其支付会员服务费后，即可成为运掌柜平台特定级别/类别的会员，享有相应的会员权益，并有权使用运掌柜平台及/或其合作方所提供的相应的会员服务，具体以运掌柜平台公布的内容与规则为准。
            </MBText>

            <MBText style={styles.h2Title}>二、用户资格</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;2.1 您向运掌柜申请使用运掌柜平台服务应当首先注册成为运掌柜平台的用户，成为用户应具备以下条件：
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;（1）
              若您为企业、其他法人组织或个体工商户，您必须是经过相关法律法规合法注册且有效存续，具有完全的民事行为能力和民事权利能力，具备就您所从事的经营活动及/或其他活动依法承担民事责任的能力，且具有良好的信誉。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（2）
              若您为自然人，您必须年满十八周岁，并具有完全的民事行为能力和民事权利能力。若您不具备前述民事行为能力，则您及您的监护人应依照法律规定承担因此而导致的一切后果。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（3）您一直按照所有对您适用的法律法规的规定开展经营活动及/或其他活动，不存在违法违规的行为及/或情形。
            </MBText>

            <MBText style={styles.h2Title}>三、用户的账号、密码及验证信息</MBText>
            <MBText style={styles.text}>&emsp;&emsp;3.1 您一旦在运掌柜平台成功注册为用户，将得到一个账号和密码。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.2
              您应自行设置账号的密码，并予以妥善保管，不得以任何形式擅自转让或授权他人使用您的账号和密码，否则您应当承担由此产生的全部责任，运掌柜保留拒绝提供相应服务、冻结或收回注册账号或终止本服务协议的权利，并可要求您对运掌柜所承受的损失予以赔偿。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.3
              在您注册运掌柜平台用户或开通、使用、接受运掌柜平台的服务及/或用户/会员资格的过程中，您应按运掌柜平台的要求提供真实、准确、完整且有效的个人信息。运掌柜及运掌柜的合作方有权根据本协议及其他运掌柜平台的规则要求您提供验证信息及验证信息凭证，并对您的验证信息和验证信息凭证的真实性、准确性及/或一致性进行验证，您应积极配合，否则运掌柜有权限制或停止向您提供部分或全部运掌柜平台服务。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.4
              若因国家法律法规、部门规章、监管机构的要求或运掌柜平台经营需要，运掌柜需要您补充提供任何验证信息及验证信息凭证时，如您不能及时提供，运掌柜有权立即暂停或终止向您提供部分或全部运掌柜平台服务。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;3.5
                您应保证您所填写及提供的用户信息、用户信息凭证、验证信息、验证信息凭证、联系电话、联系地址、电子邮件地址等资料、凭证、信息的真实性、准确性、完整性及有效性，同时也有义务在相关资料、凭证、信息发生变更时及时通知运掌柜进行更新。您了解并同意，您有义务持续确保您提供的相关资料、凭证、信息的真实性、完整性及有效性。若您提供任何错误、不实、不准确、过时或不完整资料、凭证、信息，或运掌柜有合理理由怀疑该资料、凭证、信息为错误、不实、不准确、过时或不完整的，运掌柜有权立即暂停或终止对您提供服务，或限制您运掌柜账号的部分或全部功能，运掌柜对此不承担任何责任，您将承担因此而产生的全部直接或间接损失，同时，您还应当赔偿运掌柜及/或任何其他第三方因此遭受的全部损失。
              </MBText>
            </MBText>

            <MBText style={styles.text}>&emsp;&emsp;3.6 您应妥善保管下列信息、资料和硬件设备：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）账号及其密码；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）银行卡及其密码、CVV码、有效期等卡片信息；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）手机等您用于登陆账号及/或使用运掌柜平台的硬件设备及SIM卡信息；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）您授权/指定的代表的人脸信息、指纹信息等生物识别信息。</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;您应妥善保管上述资料、信息和硬件设备，并确保您的手机等移动终端设备在安全、无病毒、未被入侵、未被监控、未被非法控制的环境下运行和使用。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;若您泄露了上述信息中的任意一项或遗失了上述硬件设备，或您遭受他人攻击、诈骗等损害，由此导致的风险和损失应由您自行承担。
              </MBText>
            </MBText>
            <MBText style={styles.text}>&emsp;&emsp;3.7 发生下列任一情形时，您应及时联系运掌柜的客服部门，以减少可能发生的损失：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）您不慎遗失或泄露了本协议第3.6条所列信息的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）您遗失了您的手机等移动终端或SIM卡的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）您在开设银行账户时预留了他人的手机号码的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）第三人冒用或盗用您的验证信息、验证信息凭证或账户信息的；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（5） 其他任何未经您本人合法授权，却在使用您的账号、本服务或您的银行账户的情况及/或您的账户有其他安全漏洞的情况。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;如发生上述情形，请及时拨打运掌柜客服电话。若您未及时通知运掌柜而导致损失形成或扩大的，您应自行承担因此遭受的损失。您理解运掌柜对您的任何请求会要求您提供必要、充分的说明与证据并进行必要的验证，且运掌柜采取行动需要合理时间，运掌柜不确保应您请求而采取的行动能够避免或阻止侵害后果的形成或扩大，运掌柜对您发生上述情形而遭受的损失不承担责任。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;3.8
                您在此不可撤销地同意并授权：（1）在您需通过运掌柜平台支付任何款项时，由运掌柜及/或运掌柜合作的银行及/或第三方支付机构（合称“支付机构”）根据您发出的指令代您扣划银行卡（需绑定）账户、微信账户、支付宝账户或第三方支付机构为您开立的钱包账户（包括但不限于由运掌柜合作的第三方支付机构为您开立并在运掌柜平台相关页面进行显示的钱包账户）等其他账户中的款项，并代为将所扣划的款项用于向您的交易相对方进行结算；（2）若由支付机构代为扣划的，根据支付机构要求，您需在支付机构开立支付账户的，您在此不可撤销的授权并同意，运掌柜将您的相关信息提供给该支付机构，由其为您开立支付账户；（3）在您需通过运掌柜平台收取任何款项时，由运掌柜合作的银行或支付机构代您收取该等款项，且在您需提取/使用该等款项并履行了银行、支付机构要求的必要的手续（包括但不限于按支付机构的要求绑定银行卡并完善相关信息）后，由运掌柜合作的银行或支付机构向您结算或为您扣划该等款项；（4）运掌柜及运掌柜平台有权根据您通过银行或支付机构的服务支付、收取及/或提现的款项金额实时记录、留存及/或通过运掌柜平台及运掌柜平台的相关页面(如运掌柜平台“余额”页面、运掌柜平台“钱包”页面)向您显示您的交易信息及在支付机构留存的款项金额变动信息，但您确认并同意，运掌柜平台及运掌柜平台均不向您提供任何支付服务，上述所有与支付、金额等相关的信息最终由提供支付服务的支付机构向您负责，运掌柜不就该等信息的真实性、准确性、完整性与有效性负责。就绑定银行卡，您应确保合法地享有使用所绑定银行卡及该银行卡内资金的权利，未侵犯任何第三方的合法权益，否则因此造成运掌柜及/或第三方损失的，您应负责赔偿并承担全部法律责任。
              </MBText>
            </MBText>

            <MBText style={styles.h2Title}>四、账户的操作</MBText>
            <MBText style={styles.text}>若您为企业或其他法人组织的，您需要：</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;4.1 在申请注册运掌柜平台用户之前，您应自行指定账号操作人。账号操作人持有您的平台账户及密码。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;4.2
                您应理解，运掌柜就您与您的账号使用人/操作人之间的关系不具有任何核查的义务，您应自行妥善保管账号密码，任何使用您的账号密码登录使用运掌柜服务的行为均视同您的行为，由此产生的风险、责任与法律后果由您承担。如因您与您的账号使用人/操作人之间的纠纷或争议导致给运掌柜或其他任何第三方造成侵权或损失的，您与您的账号使用人/操作人应当承担连带赔偿责任，运掌柜因此而遭受了损失的，运掌柜有权向您直接追偿。
              </MBText>
            </MBText>

            <MBText style={styles.h2Title}>五、用户权利与义务</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;5.1 您应根据本协议及运掌柜平台发布的其他相关协议、规则，使用运掌柜平台提供的物流运输管理系统功能与服务（统称“
              <MBText style={styles.strongText}>运掌柜平台服务</MBText>”或“<MBText style={styles.strongText}>本服务</MBText>”）。
              <MBText style={[styles.strongText, styles.bottomLine]}>
                但对于运掌柜平台提供的会员服务等付费服务，运掌柜有权根据服务类型及服务阶段确定不同的资费标准和收费方式，运掌柜可能会给予您一定免费体验付费服务的次数或期限，但运掌柜有权根据运营需要或您的使用情况随时终止您的免费体验，免费体验终止后您须按运掌柜平台页面显示的资费标准、收费方式、购买方式等资费政策信息购买付费服务后方能继续使用。
              </MBText>
            </MBText>
            <MBText style={styles.text}>&emsp;&emsp;5.2 您使用运掌柜平台服务的，必须自行准备如下设备和承担如下开支：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）上网设备，包括但不限于电脑、手机或者其他上网终端及其他必备的上网装置；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）上网开支，包括并不限于网络接入费、上网设备租用费、手机流量费等。</MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;5.3
                您在运掌柜平台提供及发布的信息应当合法、真实、有效、完整，否则，您应就由此造成的损失承担赔偿责任，且运掌柜有权停止向您提供任何服务。若您发布的任何信息不符合本协议约定的，运掌柜有权视情况要求您进行改正、完善、删除或采取其他措施。因您发布的任何信息给运掌柜或其他任何第三方造成侵权或损失的，您应当承担赔偿等责任，运掌柜因此而遭受了损失的，运掌柜有权向您追偿。
              </MBText>
            </MBText>
            <MBText style={styles.text}>&emsp;&emsp;5.4 您不得使用以下方式登录运掌柜平台或破坏运掌柜平台所提供的服务：</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（1）以任何机器人软件、蜘蛛软件、爬虫软件、刷屏软件或其它自动方式访问或登录运掌柜平台；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（2） 通过任何方式对运掌柜平台结构造成或可能造成不合理或不合比例的重大负荷的行为；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（3） 通过任何方式干扰或试图干扰运掌柜平台的正常工作或运掌柜平台上进行的任何活动。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;5.5
              您存在向第三方付款及/或收款的需求时，若您接受了运掌柜及/或运掌柜的合作方提供的代付及/或代收服务，即代表您授权运掌柜及/或运掌柜的合作方先向您收取及/或支付该等费用/款项，再由运掌柜及/或运掌柜的合作方将该等费用/款项向您的收款方支付及/或向您的付款方收取。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;5.6
              您知晓并同意运掌柜合作、指定或认可的第三方征信机构有权基于提供信用或风控服务的需要，向合法保存有您的信息的机构（包括但不限于运掌柜）采集相应信息，用于验证您的信息的真实性及风险判断使用，并将上述分析结果提供给运掌柜。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={styles.strongText}>
                &emsp;&emsp;5.7
                您理解并同意：为向您提供更为细致、贴心的服务，在经过您的事先确认后，运掌柜/运掌柜或运掌柜授权、认可的第三方商家、广告商可能通过您注册时填写的手机号码或者电子邮箱向您发送您可能感兴趣的商品服务的广告宣传信息、促销优惠等商业性信息；如果您不愿意接收此类信息，则您有权通过运掌柜/运掌柜提供的相应的退订方式进行退订。您理解并同意，对上述的相关广告信息，您应审慎判断其真实性和可靠性，除法律法规明确规定外，您应对依该广告信息进行的交易负责。
              </MBText>
            </MBText>
            <MBText style={styles.h2Title}>六、用户行为规范</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;6.1 您同意并保证，作为运掌柜平台的用户，您应严格履行如下约定：</MBText>
            <MBText style={styles.text}>（1）您应本着“遵纪守法”的原则严格遵守所在国家或地区的法律法规及相关规定；</MBText>
            <MBText style={[styles.text]}>
              （2）您应本着“审慎交易”的原则了解并遵守本协议项下及运掌柜平台的所有规则以及社会公共利益、公共道德；
            </MBText>
            <MBText style={[styles.text]}>
              （3）您应本着“诚实信用”的原则使用运掌柜平台服务，不得通过虚构事实、伪造证据、与他人串通等手段，侵害运掌柜及其他第三方的权益；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;6.2 您同意并保证，作为运掌柜平台的用户，您应严格遵守以下义务：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）不得传输、发表及/或传播含有下列内容的信息：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;a. 反对宪法所确定的基本原则；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;b. 煽动抗拒、反对或破坏宪法和法律、行政法规实施；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;c. 危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;d. 损害国家荣誉和利益的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;e. 煽动民族仇恨、民族歧视，破坏民族团结的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;f. 破坏国家宗教政策，宣扬邪教和封建迷信的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;g. 散布谣言，扰乱社会秩序，破坏社会稳定的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;h. 散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;i. 侮辱或者诽谤他人，侵害他人合法权益的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;j. 含有法律、行政法规及/或其他国家有关规定禁止的其他内容的。</MBText>

            <MBText style={[styles.text]}>&emsp;&emsp;（2）从中国大陆向境外传输资料信息时必须符合中国有关法律法规；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）不得利用运掌柜平台从事洗钱、窃取商业秘密、窃取个人信息等违法犯罪活动；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）不得干扰运掌柜平台的正常运转，不得侵入运掌柜平台及国家计算机信息系统；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（5）
              不得传输、发表及/或传播任何违法犯罪的、骚扰性的、中伤他人的、辱骂性的、诽谤性的、恐吓性的、歧视性的、伤害性的、庸俗的、不文明的、虚假的及其他违反公序良俗的信息资料；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（6）不得传输、发表及/或传播损害国家社会公共利益和涉及国家安全的信息资料或言论；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（7）不得教唆他人从事本条所禁止的行为；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（8）不得在运掌柜平台任何页面（包括但不限于评论、社区）发布任何形式的营销广告，或类似的营销信息、垃圾信息；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（9）
              您账户内的任何优惠信息（包括但不限于积分、优惠券及其他形式优惠或折扣等）您仅在使用运掌柜平台相关服务时享有使用权，严禁利用上述优惠信息进行其他经营性行为；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（10）
              您不得利用任何非法手段获取其他用户个人信息，不得将其他用户信息用于任何营利或非营利目的，不得泄露其他用户或权利人的个人隐私，否则运掌柜有权采取本协议规定的合理措施制止您的上述行为，情节严重的，将提交公安机关进行刑事立案；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（11）
              您不得发布任何侵犯他人著作权、商标权等知识产权或其他合法权利的内容；如果运掌柜或其他用户或权利人发现您发布的信息涉嫌侵犯他人知识产权或其他合法权益的，运掌柜有权立即删除您发布的信息，或者采取其他必要措施予以制止；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（12）
              您应不时关注并遵守运掌柜平台不时公布或修改的各类规则规定。运掌柜保有删除各类不符合法律政策或不真实的信息内容而无须通知您的权利；
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;6.3 您不得
              <MBText style={[styles.bottomLine]}>
                利用运掌柜平台的论坛社区、跟帖评论服务发布、传播法律法规和国家有关规
                定禁止的信息（包括但不限于本协议第6.2条禁止的信息）；您应当不时关注并遵守运掌柜平台上公布的论坛社区、跟帖评论相关的规则。
              </MBText>
            </MBText>

            <MBText style={styles.text}>
              &emsp;&emsp;6.4
              若您未遵守本协议的任何约定、用户行为规范、运掌柜平台公布的其他规则、规范及/或您在运掌柜平台签署的其他协议、文件的，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                运掌柜有权做出独立判断并立即采取停止传输、消除信息、限制/取消您的权限、版块、暂停、封禁或关闭您的账号、冻结您平台账户内余额、关闭相应交易、暂停、限制您使用的服务、保存有关记录、向国家有关机关报告等措施。
              </MBText>
              您须对自己在网上的言论和行为承担法律责任，如您的行为导致任何法律后果的发生，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                您应以自己的名义独立承担相应的法律责任，如给运掌柜造成任何损失的，则您应立即足额赔偿运掌柜的全部直接与间接损失。
              </MBText>
            </MBText>

            <MBText style={styles.h2Title}>七、平台服务费用及其他费用</MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;7.1
                当您申请获得运掌柜平台会员资格及/或使用需付费的运掌柜平台服务时，运掌柜有权向您收取相关会员服务费及其他平台服务费用（合称“平台服务费用”）。各项平台服务费用详见您使用运掌柜平台服务时，运掌柜平台上所列之收费说明及收费标准。运掌柜保留单方面制定及调整平台服务费用收费标准的权利。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;7.2
                您在使用运掌柜平台服务过程中可能需要向第三方（如银行、支付机构或提供技术服务的第三方等）支付一定的第三方服务费用（“第三方服务费用”），具体费用名称及收费标准详见运掌柜平台的提示及收费标准。您需按运掌柜平台的操作引导进行支付，您同意将根据上述收费标准自行或委托运掌柜或其合作方代为向第三方支付该等服务费。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;7.3
                若您不同意支付上述平台服务费用及/或第三方服务费用的，则您将无法使用运掌柜平台所有付费功能/服务。您若需要获取、使用相关功能/服务的，请先提前了解清楚关于该服务的收费标准、方式等信息。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;7.4
                你确认，您使用运掌柜平台服务系为开展商业运营为目的，您认可平台服务所具有的经济价值并已充分理解本协议中有关平台服务费用及其他费用的收费约定（“收费约定”），且您已基于独立、理性的商业判断而选择同意接受本协议项下的收费约定。您在此不可撤销地确认并同意，本协议中的收费约定代替运掌柜在线上及/或线下曾向您作出及/或出具的有关免费、不收费及/或其他与收费约定存在冲突的所有书面以及口头的宣传文件、承诺、函件、文件等（如有）。
              </MBText>
            </MBText>

            <MBText style={styles.h2Title}>八、终止服务的特别约定</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;8.1 如果您有下列情形发生，运掌柜有权终止您使用运掌柜平台：</MBText>
            <MBText style={[styles.text]}>（1） 您违反相关法律法规，具有非法目的或利用本协议项下的安排实施侵害他人合法权益的行为；</MBText>
            <MBText style={[styles.text]}>
              （2）
              您提供虚假注册信息，或存在通过虚构事实、伪造证据、发布虚假信息、与第三方串通等手段，侵害运掌柜及/或其他第三方权益的情形的；
            </MBText>
            <MBText style={[styles.text]}>
              （3）
              您严重违反本协议及运掌柜平台公布的其他规则，运掌柜有权依据本协议收回、注销用户账号，此情形下，本协议于账号收回、注销之日终止；
            </MBText>
            <MBText style={[styles.text]}>
              （4） 在满足运掌柜平台公示的账号注销条件时，您通过网站自助服务或运掌柜的客服注销运掌柜的用户账号，本协议于账号注销之日终止；
            </MBText>
            <MBText style={[styles.text]}>
              （5）
              运掌柜有权根据自身商业安排经过合理的提前通知终止运掌柜平台的所有服务，本协议于运掌柜平台全部服务依法定程序及方式终止之日终止。
            </MBText>

            <MBText style={styles.text}>
              &emsp;&emsp;8.2 本协议的终止不影响本协议终止前各方的相关权利和义务，包括但不限于守约方依据本协议向违约方追究相应的违约责任。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;8.3
              本协议终止后，对于您在本协议存续期间产生的交易订单，您可与交易相对方协商是否继续履行，并向运掌柜平台提交您与交易相对方就此达成的双方签字和/或盖章的书面协议。否则，运掌柜可通知交易相对方并根据交易相对方的意愿决定是否关闭该等交易订单；如交易相对方要求继续履行的，则您应当就该等交易订单继续履行本协议及交易订单的约定，并承担因此产生的任何损失或增加的任何费用。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;8.4
              您理解并同意，在您注销前您已认真阅读、认可《运掌柜隐私政策》及《运掌柜账户注销须知》，并已了解、同意相关用户注销流程及注销后的权利义务安排；运掌柜将按照《运掌柜隐私政策》及《运掌柜账户注销须知》的规定处理您的个人信息。
            </MBText>

            <MBText style={styles.h2Title}>九、运掌柜的其他权利及义务</MBText>
            <MBText style={styles.text}>&emsp;&emsp;9.1 运掌柜设立业务咨询和投诉电话，负责解答您在履行本协议过程中遇到的各种疑问。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.2
              您了解并同意，运掌柜有权应国家有权机关（包括但不限于监管部门、司法机关等）的要求，向其提供您在运掌柜平台的个人信息和交易记录等必要信息。如您涉嫌侵犯他人合法权益，则运掌柜有权在初步判断涉嫌侵权行为可能存在的情况下，向权利人提供您必要的个人信息。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.3
              您同意，运掌柜有权使用您的注册信息、用户名、密码等信息，登陆进入您的注册账户，进行证据保全，包括但不限于公证、见证、协助司法机关进行调查取证等。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.4
              您授权运掌柜有权留存您在使用本服务过程中提供、发布、形成的相关数据信息并提供给关联公司或政府部门、合作机构，以供后续向您持续性地提供相应服务（包括但不限于将本信息用于向您推广、提供其他更加优质的产品或服务）。您同意运掌柜使用、复制、修订、编辑、发布、展示、翻译、分发您的上述数据信息，并以已知或日后开发的形式、媒体或技术上将上述数据信息纳入其他作品内。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.5 由于运掌柜平台定位等功能需要，用户在安装、使用运掌柜平台时，运掌柜有权获取用户所在的位置信息。
            </MBText>
            <MBText style={[styles.text, styles.bottomLine]}>
              &emsp;&emsp;9.6
              您有义务持续确保您在运掌柜平台所填写及提供的手机号、用户信息、用户信息凭证、验证信息、验证信息凭证等资料、凭证、信息的真实性、准确性、完整性、对应一致性及有效性。若您注册账号的手机号所认证的身份证号、姓名并非手机通信运营商实名认证一致的身份证号、姓名（“实名身份信息”），则您应立即将认证的身份证号和姓名修改为实名身份信息，否则运掌柜有权限制或停止向您提供部分或全部运掌柜平台服务或限制您运掌柜账户的部分或全部功能，运掌柜对此不承担任何责任，您将承担因此而产生的全部直接或间接损失，同时，您还应当赔偿运掌柜及/或任何其他第三方因此遭受的全部损失。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.7
              为使您更安全、便捷、全面地使用本服务，运掌柜有权向您发送与本服务有关的信息，如果您不愿意接收此类信息，则您有权通过运掌柜/运掌柜提供的相应的退订方式进行退订。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.8
              为更好地为您提供本服务，运掌柜将不时进行运掌柜平台的维护和升级。您同意，届时运掌柜仅须提前在运掌柜平台发布公告即可，系统维护及升级过程中产生的业务中断或不稳定状态，不视为违约。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;9.9
              为更好地为您提供本服务，运掌柜有可能修改本协议项下业务的相关规则。您同意，届时运掌柜仅须提前在运掌柜平台发布公告即可，您自愿接受本协议及运掌柜不时发布的新规则的约束。
            </MBText>

            <MBText style={styles.h2Title}>十、免责条款</MBText>

            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;10.1
                运掌柜仅提供本服务，并不参与具体的商品或服务交易，您使用本服务时，因商品或服务交易本身以及您与任何第三方所产生的任何纠纷或责任，应由您自行解决并承担全部责任
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;10.2 本服务是在现有技术水平下提供的，运掌柜将尽力为您提供服务，但无法保证该服务完全符合您的预期。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;10.3运掌柜平台是一个信息（包括但不限于车源信息、货源信息）交换平台，信息由各用户提供，运掌柜要求各信息提供者对所提供信息内容的真实性、合法性、准确性、有效性负责，运掌柜仅就信息内容本身尽形式审查义务，但运掌柜对信息内容的真实性、准确性、合法性、有效性不提供任何保证，亦不承担任何责任，对此您应谨慎判断。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;10.4
                运掌柜仅就司机注册身份及运输车辆的运输资质进行形式审查，但运掌柜对其运输资质的真实性、合法性、准确性、有效性不承担任何责任。货主应当自行查验司机及相关运输车辆的运输资质，并承担所有由于运输资质造成的风险。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;10.5
                司机应当自行承担所有因道路限行、交通管理规定、交通管制措施引起的行政责任（包括但不限于行政处罚）以及由此造成的任何直接、间接损失（包括但不限于给货主造成的损失），运掌柜不承担相关责任。
              </MBText>
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;10.6 不可抗力</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;由于不可抗力或意外事件而影响运掌柜提供正常的服务和技术支持时，运掌柜不承担任何责任。“不可抗力”是指不能预见、不能克服且无法避免的客观事件，如战争、自然灾害、政府规范修订、黑客攻击等；“意外事件”指诸如光缆出现故障的影响或损坏；通信线路或服务器发生超出运掌柜防范与预见能力的故障等类似事件。对以下情形导致的本服务中断或受阻，不视为运掌柜违约，运掌柜不承担责任：
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）电信设备出现故障、公共网络故障；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）运掌柜平台受到计算机病毒、木马或其他恶意程序、黑客攻击的破坏；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）电信部门及/或其他运掌柜平台运营所依赖的有关部门、机构出现调整或故障；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）国家相关主管部门颁布、变更法令、政策；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（5）您或运掌柜的电脑软件、系统、硬件和通信线路出现故障；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（6）国家相关主管部门颁布、变更法令、政策；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（7）其他不可抗力因素。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;10.7 您在使用本服务的过程中，运掌柜不对下列风险担责：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）您操作不当；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）您通过非运掌柜授权的方式使用本服务；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）来自他人匿名或冒名的含有威胁、诽谤、令人反感或非法内容的信息；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）遭受他人误导、欺骗或其他导致任何心理、生理上的伤害以及经济上的损失；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（5）其他因网络信息或您行为引起的风险。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;10.8
              运掌柜平台所提供的定位功能，是采用运营商的基站位置信息，由于通信信号等多种因素，运掌柜不保证用户使用的连贯性以及位置精准性。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;10.9 您在使用本服务的过程中，运掌柜在法律规定的范围内可处理违法违规内容，但其不构成运掌柜的义务或承诺。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;10.10
              为了改善用户体验、修复漏洞、保障安全性等考虑，运掌柜有权对软件进行更新，您应该将相关软件更新至最新版本，否则运掌柜将不保证您能正常使用相关软件。如果您从未经运掌柜授权的第三方获取软件，运掌柜无法保证该软件能够正常使用，由此造成的相关损失，运掌柜不予负责。
            </MBText>

            <MBText style={styles.h2Title}>十一、隐私保护</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;11.1
              运掌柜重视对您个人信息的保护，您的个人信息依《运掌柜隐私政策》受到保护与规范，详情请参阅《运掌柜隐私政策》。《运掌柜隐私政策》构成本协议不可分割的组成部分，共同适用于您所使用的运掌柜平台服务。
            </MBText>

            <MBText style={styles.h2Title}>十二、知识产权保护</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;12.1
              运掌柜在本服务中提供的内容（包括但不限于网页、文字、图片、音频、视频、图表等）的知识产权归运掌柜及其关联公司所有。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;12.2 除另有特别声明外，运掌柜提供本服务时所依托软件的著作权、专利权及其他知识产权均归运掌柜及其关联公司所有。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;12.3
              运掌柜在本服务中所使用的“运掌柜货主”、“运掌柜货主”、“运掌柜司机”、“运掌柜司机”和“运掌柜”、“运掌柜”等商业标识，其著作权、商标权归运掌柜及运掌柜及其关联公司所有。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;12.4
              上述知识产权均受到法律保护，未经运掌柜或相关权利人书面许可，您承诺不应且不应允许或协助任何人以任何形式（包括但不限于通过任何机器人、蜘蛛、截屏等程序或设备）进行使用、出租、出借、分发、展示、复制、修改、链接、转载、汇编、发表、出版、抓取、监视、引用或创造相关衍生作品。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;12.5
              您理解并同意，您在使用运掌柜提供的服务时上传、提交、存储或发布的内容（包括但不限于文字、图片、视频、音频、动画等）的知识产权归属您或您已获合法授权，您的上传、提交、存储或发布行为不会侵犯他人的知识产权或其他合法权益。如果任何第三方提出关于知识产权的异议，运掌柜有权根据实际情况删除相关的内容，且有权追究您法律责任，给运掌柜或任何第三方造成损失的，用户应负责全额赔偿。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={styles.strongText}>
                &emsp;&emsp;12.6
                您同意将您在使用运掌柜提供的服务时上传、提交或发布的内容授予运掌柜永久的、免费的、不可撤销的、非独家的使用许可以及完整的再许可权利；运掌柜有权使用、复制、修改、改编、出版、翻译、据以创作衍生作品、传播、表演和展示该内容的整体或部分，及/或将该内容用于任何运掌柜相关的软件或服务上。您进一步同意，运掌柜有权以运掌柜的名义独立或委托第三方针对侵犯以上权利的行为采取任何必要的法律行动，包括但不限于民事诉讼、行政投诉、平台投诉等，并获得依据中华人民共和国法律可获得的所有救济。
              </MBText>
            </MBText>
            <MBText style={styles.h2Title}>十三、其他</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.1
              您同意，运掌柜有权根据您的风险程度及自身业务运营情况需要随时中止或终止向您提供本服务，或调整本协议项下业务有关的规则。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.2
              您确认，一旦您违反本协议及/或运掌柜其他平台规则、规范，运掌柜有权根据相应规则对您违约发布的信息进行删除、屏蔽处理，有权依据本协议的约定终止对您的服务，查封您的账户，并有权通知合作机构，暂停对您提供有关服务。运掌柜可将对您上述违约行为处理措施信息以及其他经国家行政或司法机关生效法律文书确认的违法信息在运掌柜平台上予以公示。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.3
              您同意，用户账户的暂停、中断或终止不代表责任的终止，您仍应对使用运掌柜服务期间的行为承担可能的违约或损害赔偿责任，同时运掌柜仍可保有用户的相关信息。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.4
              因您违反本协议及/或运掌柜其他平台规则、规范约定造成运掌柜损失的，您应赔偿相应的损失（包括但不限于直接经济损失、商誉损失及对外支付的赔偿金、和解款、律师费、诉讼费等间接经济损失）。如您的行为使运掌柜遭受第三人主张权利，运掌柜可在对第三人承担金钱给付等义务后就全部损失向您追偿。如因您的行为使得第三人遭受损失或您怠于履行调处决定，运掌柜出于社会公共利益保护或其他善意第三方保护目的，可在符合法律规定的前提下，自您的账户中划扣相应款项进行支付。
            </MBText>

            <MBText style={styles.text}>
              <MBText style={styles.strongText}>&emsp;&emsp;13.5 本协议自您按本协议文首列明的方式确认接受本协议之日起生效。</MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.6
              您同意，本协议的签订、效力、履行、终止及其解释适用中华人民共和国（为本协议之目的，不包括香港特别行政区、澳门特别行政区及台湾地区）的法律。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;13.7
                因运掌柜与您就本协议的签订、履行或解释发生争议，双方应努力友好协商解决。如协商不成，运掌柜和您均同意由上海运掌柜电子科技有限公司住所地有管辖权的法院通过诉讼解决。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.8
              本协议内容包括协议正文、《运掌柜隐私政策》及所有运掌柜已经发布的或将来可能发布的运掌柜平台服务使用规则。所有规则为本协议不可分割的一部分，与本协议正文具有相同法律效力。由于互联网高速发展，您与运掌柜签署的本协议列明的条款并不能完整罗列并覆盖您与运掌柜之间的所有权利与义务，现有的约定也不能保证完全符合未来发展的需求。因此，运掌柜通过运掌柜平台发布的声明及政策、规则均为本协议的补充协议，与本协议不可分割且具有同等法律效力。如您使用或继续使用运掌柜平台服务，视为您同意上述补充协议。
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;13.9
                根据国家法律法规变化及运营需要，运掌柜有权对本协议条款及其他平台规则、规范不时地进行修改，并通过在运掌柜平台移动客户端或PC端上发出公告、站内信等合理、醒目的方式向您进行提前通知，上述修改更新内容将在相关更新说明中指定的日期开始实施，通常情况下不短于发布之日后七个自然日。您应当及时查阅并了解相关更新修改内容，如您不同意相关更新修改内容，可停止使用相关更新修改内容所涉及的服务，此情形下，变更事项对您不产生效力；如您在上述更新修改内容实施后继续使用所涉及的服务，将视为您已同意各项更新修改内容。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;13.10
                就您在运掌柜平台上确认、同意的协议、规则、政策、文档等（统称“协议文件”），您同意运掌柜将协议文件置于电子签约平台以数据电文形式在线签署并储存，并将您的个人信息（姓名、身份证号、手机号、银行卡号、电子邮箱地址及其他身份认证信息）报送给电子签约平台用于电子签名认证并生成数字证书，您特此委托电子签约平台托管并调用您的数字证书代您签署协议文件。您认可由运掌柜将协议文件的内容发送到电子签约平台生成签约文本。协议文件使用的电子签约平台为可合法有效提供电子签约服务的平台。您同意运掌柜向电子签约平台调取协议文件、您的签约信息、您的身份认证信息及与证明协议文件有效性、您的电子签名有效性相关的其他信息。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.11
              如果本协议中任何一条被视为废止、无效或因任何理由不可执行，该条应视为可分的且并不影响任何其余条款的有效性和可执行性。
            </MBText>
            <MBText style={styles.text}>&emsp;&emsp;13.12 本协议未尽事宜，您需遵守运掌柜平台实时公布的规则。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.13
              运掌柜有权通过您提供的联系方式向您发出通知，其中以电子的方式发出的书面通知，包括但不限于在运掌柜平台公告，向您提供的联系电话发送手机短信，向您提供的电子邮件地址发送电子邮件，向您发送系统消息以及站内信信息，运掌柜可任意选择其中一种方式对您发出通知，在发送成功后即视为送达；以纸质载体发出的书面通知，按照提供联系地址交邮后的第五个自然日即视为送达。上述送达方式同样可适用于相关仲裁或司法程序（含起诉、审理、执行等各阶段），司法机关（如人民法院等）可以以短信、微信、电子邮件、运掌柜平台发送通知/公告等现代通讯工具或邮寄方式向您送达法律文书（包括但不限于受理通知书、判决书、裁定书等诉讼文书）。
              <MBText style={[styles.strongText, styles.bottomLine]}>
                您应当保证所提供的联系方式是准确、有效的，并进行适时更新，如因提供的联系方式不准确或怠于更新等不可归责于运掌柜的原因，导致相关通知、文件、文书无法送达或及时送达，您将自行承担由此可能产生的法律后果。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.14 本协议所有条款的标题仅为阅读方便，本身并无实际涵义，不能作为本协议涵义解释的依据。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.15 本协议条款无论因何种原因部分无效或不可执行，其余条款仍有效，对双方具有约束力。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;13.16
              如您对本协议内容或在使用本服务过程中有任何疑问，或存在任何投诉举报需求，您可以通过运掌柜平台上提供的联系方式或拨打客服电话025-69859997与我们联系并作充分描述。
            </MBText>
          </View>
        </SafeAreaView>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  content: {
    paddingTop: autoFix(60),
    paddingHorizontal: autoFix(24),
    paddingBottom: autoFix(50),
    backgroundColor: '#fff',
  },

  pageTitle: {
    fontSize: autoFix(40),
    color: '#333333',
    lineHeight: autoFix(48),
    textAlign: 'center',
    fontWeight: 'bold',
  },

  h2Title: {
    fontSize: autoFix(34),
    color: '#333333',
    lineHeight: autoFix(42),
    marginBottom: autoFix(40),
  },

  text: {
    lineHeight: autoFix(42),
    marginBottom: autoFix(36),
  },

  strongText: {
    fontWeight: 'bold',
  },

  clearBottom: {
    marginBottom: 0,
  },

  bottomLine: {
    textDecorationLine: 'underline',
  },
});

export default User;
