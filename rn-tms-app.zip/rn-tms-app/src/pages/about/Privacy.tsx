import React from 'react';
import { SafeAreaView, View, StyleSheet, ScrollView } from 'react-native';
import { MBText, Splitline, Whitespace } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NavBar from '~/components/common/NavBar';

export interface PrivacyProps {
  navigation?: any;
  screenProps?: any;
}

const Privacy = function (props: PrivacyProps): JSX.Element {
  const { navigation, screenProps } = props;

  const onLeftClick = () => {
    if (screenProps.routername) {
      MBBridge.app.ui.closeWindow({});
      return;
    }
    navigation.goBack();
  };
  const goPages = () => {
    navigation.navigate('ProtocolLogout');
  };
  return (
    <View style={styles.container}>
      <NavBar title="隐私协议" leftClick={onLeftClick} />
      <ScrollView keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
        <SafeAreaView>
          <View style={styles.content}>
            <MBText style={styles.pageTitle}>运掌柜隐私政策</MBText>
            <Splitline />
            <Whitespace vertical={20} />
            <MBText style={styles.h3Title}>提示条款</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;运掌柜平台是一款可为您提供订单管理、调度分配、行车管理、GPS车辆定位系统、车辆管理、人员管理、数据报表管理及其他相关服务的物流运输管理系统。为说明运掌柜（或简称“我们”）如何收集、使用和存储您的个人信息及您享有的权利，我们通过本政策向您阐述相关事宜。本政策适用于“运掌柜”PC版、客户端、以及相关微信公众号、小程序平台产品及服务（统称“
              <MBText style={styles.strongText}>运掌柜平台</MBText>”）。
            </MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;本政策将帮助您了解以下内容：</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1. 我们如何收集您的个人信息</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;2. 我们如何使用 Cookie 和同类技术</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3. 我们如何存储和保护您的个人信息</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;4. 我们如何使用您的个人信息</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;5. 我们如何共享、转让、公开披露您的个人信息</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;6. 您的权利</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;7. 本政策的更新</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;8. 如何联系我们</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;9. 运掌柜平台账户注销须知</MBText>

            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;【特别提示】本政策与您使用我们的服务关系紧密，请您在使用我们的产品/服务前，仔细阅读并充分理解本政策，做出您认为适当的选择。对本政策中与您的权益存在重大关系的条款和个人敏感信息，我们将采用粗体字进行标注以提示您注意。为给您带来更好的产品和服务体验，我们在持续努力改进我们的技术，随之我们可能会不时推出新的或优化后的功能，可能需要收集、使用新的个人信息或变更个人信息使用目的或方式。对此，我们将通过更新本政策、弹窗、页面提示等方式另行向您说明对应信息的收集目的、范围及使用方式，并为您提供自主选择同意的方式，且在征得您明示同意后收集、使用。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;如对本隐私政策或相关事宜有任何问题，您可随时通过访问我们的在线客服系统、或拨打客服电话（025-69859997）等多种方式与我们联系。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1、我们如何收集您的个人信息</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;<MBText style={styles.strongText}>个人信息</MBText>（出自于
              <MBText style={styles.strongText}>GB/T 35273-2020《信息安全技术 个人信息安全规范》</MBText>
              ）是指以电子或者其他方式记录的能够单独或者与其他信息结合识别特定自然人身份或者反映特定自然人活动情况的各种信息。本隐私政策中包括：
              <MBText style={[styles.strongText, styles.bottomLine]}>
                个人资料信息（包括但不限于姓名、身份证信息、身份证照片、真实头像照片、面部识别特征、住所地、手机号码、电子邮箱地址及其他相关附加信息）、支付账户信息、银行账户信息、征信信息、验证信息、验证信息凭证、手机通讯录、手机应用列表、通话记录、财产信息、信用信息、行程信息、位置信息、运单信息及交易状态、增值服务订单信息、支付信息、提现信息、IP地址、日志信息以及您在其他合法留存您信息的自然人、法人以及其他组织处留存的信息。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;<MBText style={styles.strongText}>个人敏感信息</MBText>（出自于
              <MBText style={styles.strongText}>GB/T 35273-2020《信息安全技术 个人信息安全规范》</MBText>
              ）是指一旦泄露、非法提供或滥用可能危害人身和财产安全，极易导致个人名誉、身心健康受到损害或歧视性待遇等的个人信息，本隐私政策中涉及的个人敏感信息包括：
              <MBText style={[styles.strongText, styles.bottomLine]}>
                手机号码、用户密码、身份证或其他身份证明、面部识别特征、征信信息、位置信息、行程信息、通话记录、录音录像、支付信息、提现记录、银行卡号、保单信息。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;匿名化处理后的信息以及其他无法识别特定自然人身份或者反映特定自然人活动情况的信息不属于个人信息。
            </MBText>
            <MBText style={styles.text}>&emsp;&emsp;我们仅会出于以下目的，收集和使用您的个人信息：</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.1 您须授权我们收集和使用您的个人信息的情形</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;我们的产品和服务包括一些基本业务功能和扩展业务功能。基本业务功能包含了实现物流信息交换及在线货物运输交易所必须的功能、及保障服务正常运行和交易安全所必须的功能。我们可能会收集、保存和使用下列与您有关的信息才能实现上述这些功能。如果您不提供相关信息，您将无法享受我们提供的产品与/或服务。这些基本业务功能必须收集的信息包括：
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.1.1 用户注册、认证所必需的信息</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;您使用运掌柜平台服务前，需要在运掌柜平台创建账号并完善个人资料。通过用户主动提供的方式，运掌柜会收集您的以下信息：
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（1）当您注册成为运掌柜用户或登录运掌柜账号时，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                您需要向运掌柜提供您本人的手机号码，并准确输入运掌柜以短信形式发送至您手机的验证码，我们以此识别您在运掌柜平台的网络身份，并为您提供运掌柜平台服务。
              </MBText>
              如果您拒绝提供手机号码和验证码，运掌柜平台将无法为您创建账号并提供服务。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（2）当您在平台进行实名认证时，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                您需要向运掌柜提供您个人的姓名、手机号、身份证号、本人真实头像照片、身份证照片以及手持身份证头像照片、面部识别特征信息或您的法定代表人/负责人/经营者/代表的姓名、身份证照片、身份证号码及/或公司的名称、名片照片、统一信用代码证照片、营业执照照片、住所地。
              </MBText>
              运掌柜收集上述信息，是基于法律法规要求、保护用户人身财产安全、保障交易真实、依照平台规则处理用户纠纷之需要。为进行实名认证，运掌柜将向运掌柜合作的第三方提交您的前述信息，并从合法保存有您个人信息的第三方处获得、保存有关您身份信息的验证结果，如果您拒绝提供上述信息或拒绝运掌柜作前述信息分享、保存，您将无法作为运掌柜用户使用运掌柜平台服务。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.1.2 支付功能所必需的信息</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（1）为完成身份基本信息验证、绑定银行卡、支付、充值、提现、转账、收款功能必须，依据法律法规实名制管理相关规定，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                您需要向我们及合作的支付机构提供您的姓名、身份证号码、身份证照片、开户行名称、银行卡号、预留手机号，并允许我们将前述信息向合作方进行验证。我们将记录并保存您提供的上述信息以及您的账号、余额、支付记录、提现记录。如您使用银联信用卡支付，我们可能会获取您的卡片有效期及CVV2信息，以上信息仅用于完成银联卡交易，不会用于除此之外的任何其他用途。
              </MBText>
              如果您拒绝提供上述信息，您将无法使用运掌柜平台的银行卡支付功能、余额支付功能、提现功能，但不影响您使用其他服务。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（2）当您向他人付款时，我们需要对您的交易行为进行管理用以识别、防止套现或欺诈，同时也为了向您提供账单查询管理功能，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                我们将收集您的交易信息（包括支付金额、支付对象、商品/服务名称、配送信息）。
              </MBText>
              如您不同意我们记录前述信息，则可能无法完成交易，但不影响您使用我们提供的其他服务。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（3）您在运掌柜平台使用交易支付时，如果您使用第三方支付功能，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                运掌柜将获取您的支付工具、订单信息、支付账户风控信息及支付状态。
              </MBText>
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.1.3 客户服务所必需的信息</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;当您与运掌柜客服联系时，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                为验证您的身份，帮助您解决问题，或记录相关问题的处理方案及结果，我们可能会保存您与我们的通信/通话记录及相关内容（包括账号信息、订单信息、您为了证明相关事实提供的其他信息，或您留下的联系方式信息），如果您针对具体订单进行咨询、投诉或提供建议的，我们会使用您的账号信息和订单信息。
              </MBText>
            </MBText>

            <MBText style={[styles.text, styles.strongText, styles.bottomLine]}>
              &emsp;&emsp;为了提供服务与改进服务质量的合理需要，我们还可能使用的您的其他信息，包括您与客服联系时您提供的相关信息，您参与问卷调查时向我们发送的问卷答复信息。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.1.4 维护服务正常运行、保障交易安全所必需的信息</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;当你使用运掌柜平台时，为保障你正常使用我们的服务，维护我们服务的正常运行，改进及优化我们的服务体验以及保障你的账号安全，
              <MBText style={[styles.strongText, styles.bottomLine]}>
                我们会根据您在软件安装及/或使用中的具体操作，接收并记录您所使用的设常用设备信息（包括硬件型号、设备MAC地址、UUID、IDFA、IMEI、IMSI、MEID）、操作系统、登陆IP地址、运掌柜软件版本号、接入网络的方式、类型和状态、网络质量数据、设备加速器、设备所在位置相关信息（包括您授权的GPS位置以及WLAN接入点、蓝牙和基站此类传感器信息）以及您的操作日志、服务日志信息（可能包括您在搜索、查看的信息、服务故障信息、引荐网址信息）此类日志信息，这类信息是为提供服务必需收集的基础信息。
              </MBText>
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2 您可选择是否授权我们收集和使用您的个人信息的情况</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;除上述基本业务功能我们会收集和使用您的个人信息以外，我们的产品和服务还包括一些扩展业务功能，我们可能会在您使用扩展业务功能时收集和使用您的个人信息，如果您不提供这些个人信息，您依然可以实现物流运输管理系统功能，但您可能将无法使用这些扩展业务功能：
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.1 基于设备权限开启的扩展业务功能</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（1）位置信息的个性化推荐功能：
              <MBText style={[styles.strongText, styles.bottomLine]}>
                我们会收集您的位置信息（我们仅收集您当时所处的地理位置，但不会将您各时段的位置信息进行结合以判断您的行踪轨迹）来判断您所处的地点，自动为您推荐您所在区域的附近车源和货源。
              </MBText>
              您可以授权提供您的位置信息，以便您基于所在地点位置接受个性化推荐，获得您的允许后，我们会通过IP地址、GPS以及能够提供相关信息的其他传感器（可能包括WiFi接入点和基站信息）来获取您的位置信息。您可以主动将您的运单轨迹信息通过短信、微信方式分享给第三方，但这会暴露您的交易相对方的位置信息，请您取得对方同意后谨慎操作。如您拒绝我们获取您的位置信息，则您将需要手动定位您的位置。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（2）基于语音技术的扩展功能：您可以直接使用麦克风来进行语音记录、与我们的在线客服进行咨询和互动。
              <MBText style={[styles.strongText, styles.bottomLine]}>
                在这些功能中我们可能会在您使用语音功能时，收集您的录音内容以识别您的需求，识别交易中存在的风险，并在法律允许时用于纠纷解决。
              </MBText>
              您可以选择使用麦克风设备来进行语音输入（例如：语音消息），在使用过程中相关服务提供方需要收集
              <MBText style={[styles.strongText, styles.bottomLine]}>您的语音内容并进行必要的处理。</MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（3）基于摄像头（相机）的扩展功能：您可以授权运掌柜访问您的摄像头（相机）进行视频拍摄、拍照以及扫码，
              <MBText style={[styles.strongText]}>
                我们会识别您的视频、照片以及扫码信息来完成用户认证、客服服务、活体检测以及扫码支付功能，您拍照的内容将同步储存至您的储存卡。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（4）基于相册（图片库）的扩展功能：您可以授权运掌柜访问您的相册并在运掌柜上传您的照片来实现用户认证、客服服务以及评价功能，
              <MBText style={[styles.strongText]}>
                我们会使用您所上传的照片来识别您的认证信息、客户服务信息或使用包含您所上传图片的评价。
              </MBText>
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;（5）
              <MBText style={[styles.strongText]}>
                上述扩展功能可能需要您在您的设备中向我们开启您的地理位置（位置信息）、麦克风、相机、相册的访问权限，
              </MBText>
              以实现这些功能所涉及的信息的收集和使用。
              <MBText style={[styles.strongText]}>您可以在运掌柜通过“我的—设置—隐私”中逐项查看您上述权限的开启状态，</MBText>
              并可以决定将这些权限随时的开启或关闭（我们会指引您在您的设备系统中完成设置）。
              <MBText style={[styles.strongText]}>
                请您注意，您开启这些权限即代表您授权我们可以收集和使用这些个人信息来实现上述的功能，您关闭权限即代表您取消了这些授权，则我们将不再继续收集和使用您的这些个人信息，也无法为您提供上述与这些授权所对应的功能。您关闭权限的决定不会影响此前基于您的授权所进行的个人信息的处理。
              </MBText>
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.2 参与运营活动</MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;当您参加运掌柜的运营活动时，运掌柜需要您提供某些信息，可能会包含您的姓名、手机号码、电子邮箱地址、联系地址、银行卡号、车牌号码以及页面上提示您主动填写的其他信息。
              </MBText>
              这些信息可以帮助运掌柜对活动进行宣传、与您取得联系、向您发放礼品、对活动结果进行公示等。如果您拒绝提供此类信息，可能导致您无法参加相应活动，或无法收到礼品，无法享受优惠，但不影响您使用运掌柜平台基本业务功能。我们将会在运掌柜相关页面提示您自行填写并提交或单独征求您的授权同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.3 开具发票</MBText>
            <MBText style={styles.text}>
              <MBText style={[styles.strongText, styles.bottomLine]}>
                &emsp;&emsp;当您购买了运掌柜平台上的产品或服务需要取得发票时，运掌柜及/或产品、服务的提供方需要您提供发票抬头、纳税人识别号、税务登记地址、联系电话、开户行、银行卡号、电子邮箱、订单信息，收取发票的收件人姓名、联系电话、收件地址。
              </MBText>
              运掌柜收集前述信息后将向开具发票的第三方共享前述信息，运掌柜收集这些信息及共享是为向您开具、邮寄发票。如您拒绝提供前述信息，将导致您无法通过运掌柜开具、收取发票。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.4 商品/服务展示及推送服务</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;为节省您的系统使用效率，我们会利用我们的技术向您展示、推送更契合您需求的商品/服务，包括结合对您的位置、关注、历史订单、浏览记录向您推荐您可能需要的商品/服务（“找货”）
              <MBText style={[styles.strongText]}>
                如您不希望收到App页面上的消息通知，可以在移动端操作系统中的“通知”中心关掉对应的通知功能。如您不希望接收我们给您发送的推广短信，可通过信息中相应的退订功能进行退订，语音外呼退订可进入“我的-设置-隐私-隐私设置-语音通知”进行操作。如您希望接收更多不同的推荐内容或暂时不再使用该类个性化推荐服务，您可以进入“我的-设置-隐私-隐私设置-个性化推荐”进行操作。
              </MBText>
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.5 使用第三方服务的声明</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;请您注意，您的交易相对方、您通过运掌柜平台跳转功能访问的第三方网站经营者、
              <MBText style={[styles.strongText, styles.bottomLine]}>通过运掌柜接入的第三方服务（如有）可能有自己的隐私权保护政策；</MBText>
              当您查看第三方创建的网页或使用第三方开发的应用程序时，这些第三方可能会获取、使用您的个人信息，该等获取、使用不受运掌柜的控制及本政策的约束。运掌柜会尽商业上的合理努力去要求这些第三方对您的个人信息采取保护措施，但运掌柜无法保证这些第三方一定会按照运掌柜的要求采取保护措施，请您与这些第三方直接联系以获得关于他们的隐私权政策的详细情况。如您发现这些第三方创建的网页或第三方开发的应用程序存在风险时，建议您终止相关操作以保护您的合法权益。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.6 其他服务收集、使用、提供信息另行征得同意</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;如您选择使用我们提供的其他服务，基于该服务我们需要收集您的信息的，我们会另行向您说明信息收集的范围与目的，并征得您的同意。我们会按照本政策以及相应的用户协议约定使用、存储、对外提供及保护您的信息；如您选择不提供前述信息，您可能无法使用某项或某部分服务，但不影响您使用我们提供的其他服务。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;1.2.7 其他用途</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;我们将您的个人信息用于本政策未载明的其他用途，或者将基于特定目的收集而来的您的个人信息用于其他目的时，会单独征求您的授权同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText, styles.bottomLine]}>
              &emsp;&emsp;请注意：根据法律要求，若我们对个人信息采取技术措施和其他必要措施进行处理，使得数据接收方无法重新识别特定个人且不能复原，或我们可能会对收集的信息进行去标识化地研究、统计分析和预测，用于改善运掌柜的内容和布局，为商业决策提供产品或服务支撑，以及改进我们的产品和服务（包括使用匿名数据进行机器学习或模型算法训练），则此类处理后数据的使用无需另行向您通知并征得您的同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;2、我们如何使用Cookie和同类技术</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;Cookie是支持服务器端（或者脚本）在客户端上存储和检索信息的一种机制。当您使用运掌柜产品或服务时，为使您获得更轻松安全的访问体验，我们可能会使用Cookie或同类技术来收集和存储信息，在此过程中可能会向您的设备发送一个或多个
              Cookie
              或匿名标识符。这么做是为了收取您的信息用于了解您的偏好，进行咨询或数据分析，改善产品服务及用户体验，或及时发现并防范安全风险，为您提供更好的服务。我们不会将Cookie用于本政策所述目的之外的任何用途，您可根据自己的偏好留存或删除Cookie。您可清除软件内保存的所有Cookie，当您手动清除后您的相关信息即已删除。{' '}
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3、我们如何存储和保护您的个人信息</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3.1 信息保存期限</MBText>
            <MBText style={styles.text}>&emsp;&emsp;3.1.1 在用户使用运掌柜平台服务期间，运掌柜会持续保存用户的个人信息。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.1.2
              当您需要删除个人信息或注销账户，您可以通过访问运掌柜平台的“我的”-“设置”-“注销账号”进行在线操作，或自主联系运掌柜客服。运掌柜将按照法律、法规规定的为提供我们的服务之目的所必须的最短期间内保存您的个人信息，但您要求删除个人信息或注销账户的、或法律法规另有规定的除外，当您的个人信息超出上述保存期限，运掌柜将根据法律法规的要求删除您的个人信息或作匿名化处理。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.1.3
              为配合人民检察院、公安机关、国家安全机关侦查用户使用运掌柜服务过程中产生的犯罪行为、更好地保护其他用户的财产安全，当用户删除个人信息或注销账户时，运掌柜将在刑法规定的犯罪追诉时效期间内，加密隔离存档用户个人信息。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.1.4
              如您使用运掌柜平台服务的过程中，存在严重违反法律法规、平台协议、平台政策或规则等情形，您的违法、违约记录及相应的平台信用记录、个人信息，将被永久保存。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3.2 信息存放地域</MBText>
            <MBText style={styles.text}>&emsp;&emsp;3.2.1 运掌柜收集的您的个人信息，将在中国内地存储和使用。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.2.2
              目前运掌柜不存在向境外提供个人信息的场景。如将来涉及向境外传输个人信息，运掌柜将明确向您告知个人信息出境的目的、接收方、安全保障措施等情况，并另行征得您的同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3.3 安全保护措施</MBText>
            <MBText style={styles.text}>&emsp;&emsp;3.3.1 运掌柜仅为实现本政策所述目的保留您的个人信息。</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.3.2
              运掌柜会采用符合业界标准的安全防护措施，通过建立数据全生命周期的安全管理规范和相应的技术管控措施并使用相应的安全技术和管理程序来保护您的个人数据，在任何时候尽力做到使您的个人信息不被泄露、毁损、丢失、不当使用、未经授权阅览或披露。
            </MBText>
            <MBText style={styles.text}>&emsp;&emsp;3.3.3 运掌柜采取以下安全防护措施保护您的个人信息：</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（1）
              建立针对个人数据安全的纵深防御体系，数据从创建、存储、使用、传输、归档、销毁各环节上均采用管理与技术的双重控制措施，避免集中性的数据操作风险。
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）用户个人敏感信息被加密储并通过数据隔离措施降低数据的重标识风险。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）使用加密传输协议，保障数据传输安全。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）严格控制数据访问权限，设立完善的敏感数据访问权限申请、审批制度。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（5）建立数据安全监控和安全审计，进行全面数据安全控制。</MBText>

            <MBText style={styles.text}>&emsp;&emsp;3.3.4 运掌柜同时采取其他安全措施保护您的个人信息：</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（1） 建立公司网络信息安全工作领导小组，统一协调管理数据安全工作，并下设数据安全小组，推动各项数据安全活动。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（2）公司内部颁布实施数据安全管理规范，明确对用户数据（包括用户个人信息）的保护标准和要求。
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）新项目、新系统上线前对数据安全（包括用户个人信息数据）进行项目风险评估。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）与全体员工签署保密协议，并严格按照工作职责分配数据访问权限。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（5）定期开展面向全体员工的信息安全教育及培训。</MBText>

            <MBText style={styles.text}>
              &emsp;&emsp;3.3.5
              运掌柜积极践行国内国际安全的最佳实践，已通过信息安全等级保护三级认证，并与监管方、第三方安全服务提供商、测评认证机构建立良好的协调沟通机制，及时抵御并处置信息安全威胁，保护您的个人数据及隐私安全。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3.4 安全事件处置</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.4.1
              为应对个人信息泄露、毁损、丢失等可能出现的安全风险，已经在公司范围内颁布多项制度，明确了安全事故、安全漏洞的分类分级标准，以及针对上述安全事故和漏洞的内部处理流程和补救措施。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.4.2
              一旦发生安全事件，运掌柜将及时向您告知事件基本情况和风险、运掌柜已经采取或将要采取的措施、您如何自行降低风险的建议等。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.4.3
              运掌柜将及时以推送通知、信函或电话等方式将安全事件情况通知受影响的用户。当难以逐一通知用户时，运掌柜将通过发布平台公告的方式发布警示信息。同时，我们还将按照监管部门要求，主动上报个人信息安全事件的处置情况。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;3.5 停止运营</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.5.1 如运掌柜平台停止运营，运掌柜将至少提前30日在运掌柜平台发布公告，并及时停止收集个人信息。
            </MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;3.5.2
              停止运营后，运掌柜将停止对个人信息的商业化使用，并在满足法律法规规定的最短保存期后，对收集的个人信息进行匿名化处理。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;4、我们如何使用您的个人信息</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.1 您的个人信息会被用于本政策第1条“我们如何收集您的个人信息”条款明确列明的使用场景。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2 您的个人信息可能被用于以下与“我们如何收集您的个人信息”条款所声称的目的具有直接或合理关联的场景：
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2.1
              在运掌柜提供服务时，用于身份验证、用户服务、安全防范、诈骗监测、存档和备份用途，以提高运掌柜向您提供服务的安全性；用于预防、发现、调查欺诈以及危害安全、非法或违反与运掌柜签订的平台协议、运掌柜平台政策或规则的行为，以保护您、其他运掌柜用户、运掌柜及其他善意第三方的合法权益；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2.2 运掌柜可能利用个人信息统计数据为基础设计、开发、推广全新的产品及服务，或用于改善运掌柜平台现有服务；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2.3
              运掌柜可能将来自运掌柜平台某项服务的个人信息与来自其他项服务的信息或来自第三方的您的个人信息结合起来，做出特征模型并进行用户画像，从而针对性地回应您在语言设定、位置设定、个性化的帮助服务、展示、推荐和指示方面的个性化需求；前述情形的应用场景有消息通知、广告展示、油站推荐、保险产品推荐、运营活动推送。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2.4
              运掌柜会自行或委托第三方向您发送信息的通知，包括但不限于为保证服务完成所必需的验证信息、使用产品或服务时所必要的推送通知、服务状态通知、关于运掌柜平台的新闻、营销活动及其他商业性电子信息、运掌柜合作第三方的推广信息，或其他您可能感兴趣的内容。如您不希望继续接收上述信息，可以根据信息中提供的退订方式予以退订；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2.5
              运掌柜可能会对运掌柜平台服务进行统计，并可能会与公众或第三方分享这些统计信息，但这些统计信息不包含您的身份识别信息；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.2.6
              为了让您有更好的体验、改善运掌柜平台服务或您同意的其他个人信息用途，在符合相关法律法规的前提下，运掌柜可能将通过某一项运掌柜平台服务所收集的信息，以汇集信息或者个性化的方式，用于运掌柜的其他服务或者与运掌柜平台合作伙伴共享信息以便他们向您发送有关其产品和服务的信息。
            </MBText>

            <MBText style={[styles.text]}>&emsp;&emsp;4.3 您充分知晓，运掌柜收集、使用、向第三方提供以下信息无需征得您的授权同意：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.1 与运掌柜履行法律法规规定的义务相关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.2 与国家安全、国防安全有关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.3 与公共安全、公共卫生、重大公共利益有关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.4 与犯罪侦查、起诉、审判和判决执行等有关的；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.5 出于维护您或其他用户的生命、财产等重大合法权益但又很难得到您本人同意的；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.6 您自行向社会公众公开的您的个人信息；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.7 从合法公开披露的信息中收集的您的个人信息的，如合法的新闻报道、政府信息公开等渠道；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.8 根据您的要求签订和履行合同所必需的信息；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.9 用于维护所提供的产品与/或服务的安全稳定运行所必需的，例如发现、处置产品与/或服务的故障；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.10 为合法的新闻报道所必需的；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.11
              国家机关、事业单位、学术研究机构或该等单位授权的主体基于公共利益所必要或基于公共利益开展统计或学术研究所必要，且对外提供研究或描述的结果时，对结果中所包含的个人信息进行去标识化处理的；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.12 您在使用运掌柜平台服务时输入的其他用户或除本政策以外的第三方可在运掌柜平台上看见或知悉的信息；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.13
              运掌柜收集到的您在运掌柜平台发布的有关信息数据，包括但不限于货源信息、交易信息、参与活动、成交信息及评价详情；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4.3.14
              您的信用评价信息、您违反法律规定、《运掌柜用户服务协议》及/或运掌柜平台的其他规则向运掌柜平台提交的个人信息、实施的行为；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.15 其他用户对您的投诉、举报信息；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.16 因您发生本条第4.3.14、4.3.15项的情形，运掌柜对您采取的措施；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.17 运掌柜基于您及其他用户的个人信息进行的数据分析及得出的结论；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;4.3.18 其他依法不属于个人信息的信息。</MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;4.4
              凡是超出本政策第1条“我们如何收集您的个人信息”条款声称目的以及本条所述范围使用您的个人信息，运掌柜将再次向您告知并征得您的明示同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;5、 我们如何共享、转让、公开披露您的个人信息</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.1 共享</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.1 除以下情形外和本政策另有约定外，未经您同意，运掌柜不会与任何第三方分享您的个人信息：
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（1）实现本政策第1条所述为实现运掌柜基本业务功能必须收集的信息所述目的，只有共享您的个人信息，才能提供您所需要的服务；
            </MBText>
            <MBText style={[styles.text, styles.strongText, styles.bottomLine]}>
              &emsp;&emsp;（2）为便于平台上的其他用户通过您提供的手机号码与您联系，同时严肃交易秩序、建立交易双方的信任感、保障交易的真实性，提升平台信息撮合的成功率，我们会将您的真实姓名、头像信息向平台上的其他用户展示。如您不同意向平台上的其他用户展示您的真实姓名、头像信息，您可以通过“我的”-“设置”-“隐私”将真实姓名及头像的展示变为脱敏方式；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（3）处理您与他人的纠纷或争议（基于法定情形下：根据法律法规的规定、诉讼争议解决需要，或行政、司法等有权机关依法提出的要求）；
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）为了判断您的账户或交易是否安全；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（5）为遵守适用的法律法规、维护社会公共利益，或保护运掌柜、运掌柜的用户、雇员的人身、财产安全或其他合法权益所必须使用的合理用途；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（6）您出现违反有关法律规定或者《运掌柜用户服务协议》或平台规则的情况，需要向第三方披露您的个人信息；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（7）根据法律规定、行政监管、刑事侦查机关为调查犯罪，依法定程序调取的必要个人信息，或行政机关、司机机构依法定程序调取的必要个人信息；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（8）履行运掌柜在《运掌柜用户服务协议》或本政策中的义务和行使运掌柜的权利，以及其他运掌柜根据法律规定、《运掌柜用户服务协议》及/或运掌柜平台的其他规则认为有必要披露的情形。
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.2
              您在使用运掌柜平台第三方提供的服务或运掌柜与其他第三方进行联合推广活动时，运掌柜可能根据第三方要求收集您的相关信息提供给保险机构、贷款机构及/或贷款服务机构、ETC发行方及/或服务商、第三方征信机构、第三方商家等我们的合作伙伴，或共享活动过程中产生的、为完成活动所必要的个人信息。我们会在您接受服务前明确告知所涉及个人信息的目的、类型以及披露对象等，并征得您的明示同意。
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.3
              运掌柜可能将个人信息统计数据、脱敏数据及/或加密数据提供给运掌柜的合作方，用于进行产品测试、建造风控模型、基础设计、开发、推广全新的产品及服务，或用于改善运掌柜平台现有服务；/或贷款服务机构、ETC发行方及/或服务商、第三方征信机构、第三方商家等我们的合作伙伴，或共享活动过程中产生的、为完成活动所必要的个人信息。我们会在您接受服务前明确告知所涉及个人信息的目的、类型以及披露对象等，并征得您的明示同意。
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.4
              如您通过运掌柜渠道申请了融资或贷款服务，在您未及时足额还款的情况下，运掌柜可能将您的个人信息提供给第三方催收机构或发放贷款资金的主体。
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.5
              就您在运掌柜平台上确认、同意的协议、规则、政策、文档等（统称“协议文件”），运掌柜可能会将协议文件置于电子签约平台以数据电文形式在线签署并储存，并将您的个人信息（姓名、身份证号、手机号、银行卡号、电子邮箱地址及其他身份认证信息）报送给电子签约平台用于电子签名认证并生成数字证书，运掌柜合作的电子签约平台将托管并调用您的数字证书代您签署协议文件。运掌柜可能将协议文件内容发送到电子签约平台生成签约文本。协议文件使用的电子签约平台为可合法有效提供电子签约服务的电子签约平台。运掌柜将向电子签约平台调取协议文件、您的签约信息、您的身份认证信息及与证明协议文件有效性、您的电子签名有效性相关的其他信息。如您不同意前述电子签约相关事项，可能无法与运掌柜及或第三方达成交易。
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.6
              除本政策约定的运掌柜将您的个人信息提供给第三方的情形以外，如基于其他情况运掌柜需将您的个人信息提供给第三方，运掌柜将按照法律法规的要求以确认协议、具体场景下的文案确认动作等形式另行征得您的同意。
            </MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;5.1.7
              除本政策另有约定外，非经法定程序或获得您的同意，运掌柜不会将您的个人信息提供给任何第三方机构或个人。对运掌柜与之共享个人信息的公司、组织和个人，运掌柜会努力与之签署保密协议，要求他们遵守协议并采取相关的安全措施来保护您的个人信息。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;5.2 转让</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;随着运掌柜业务的持续发展，我们及我们的关联方有可能进行合并、收购、资产转让或类似的交易等变更，您同意授权运掌柜有权将您的个人信息作为此类交易的一部分而被转移。如涉及个人信息的转让，我们会要求受让您个人信息的公司、组织继续接受本隐私政策的约束，否则,我们将要求该公司、组织重新征求您的授权同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;5.3 公开披露</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;我们仅会在以下情况下，且采取符合业界标准的安全防护措施的前提下，才可能公开披露您的个人信息：
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.3.1 根据您的需求，在您明确同意的披露方式下披露您所指定的个人信息；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;5.3.2
              根据法律、法规的要求、强制性的行政执法或司法要求所必须提供您个人信息的情况下，我们可能会依据所要求的个人信息类型和披露方式公开披露您的个人信息。在符合法律法规的前提下，当我们收到上述披露信息的请求时，我们会要求必须出具与之相应的法律文件，如传票或调查函。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;5.4 共享、转让、公开披露个人信息时事先征得授权同意的例外</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;以下情形中，共享、转让、公开披露您的个人信息无需事先征得您的授权同意：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.1 与运掌柜履行法律法规规定的义务相关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.2 与国家安全、国防安全有关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.3 与公共安全、公共卫生、重大公共利益有关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.4 与犯罪侦查、起诉、审判和判决执行等有关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.5 出于维护您或其他个人的生命、财产等重大合法权益但又很难得到本人同意的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.6 其他维护公共利益的情形，例如您的信用评价信息需要被公开\共享；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;5.4.7 您自行向社会公众公开的个人信息；</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;5.4.8 从合法公开披露的信息中收集个人信息的，如合法的新闻报道、政府信息公开等渠道；
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;5.4.9
              根据法律规定，共享、转让、公开披露经去标识化处理的个人信息，且确保数据接收方无法复原并重新识别个人信息主体的，我们对此类数据的处理将无需另行向您通知并征得您的同意。
            </MBText>

            <MBText style={[styles.text, styles.strongText, styles.bottomLine]}>
              &emsp;&emsp;
              请注意：您在使用我们服务时自愿发布甚至公开分享的信息，可能会涉及您或他人的个人信息甚至个人敏感信息，如您的交易信息，以及您在评价时选择上传包含个人信息的文字、图片或视频等各种形式的信息。请您在使用我们的服务时更加谨慎地考虑，是否要发布甚至公开分享相关信息。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;6、 您的权利</MBText>
            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;6.1 访问、更正、删除您的个人信息</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;您可以通过以下方式管理您的信息：</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.1.1 账户信息：您可以通过您在运掌柜平台的“我的”-
              “设置”-“修改资料”页面访问、更正您提供的个人资料信息（身份认证信息除外），也可以更改您的密码、添加安全信息或关闭您的账户等，您可以通过访问网页及App在设置中执行此类操作；若您需更正您的身份认证信息，你可拨打客服热线申请更正。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.1.2
              订单信息：您可以在运掌柜平台的订单页面访问您的贷款、保险以及ETC服务订单信息及交易状态。您可以选择删除已完成的订单信息，但这样可能导致我们无法根据您的购买信息而准确提供相应的售后服务。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.1.3 钱包信息：您可以通过运掌柜平台的“我的”-“钱包余额”页面访问银行卡信息、支付方式、账单详情等信息。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;6.2 撤回同意</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;运掌柜将通过以下方式保障您撤回同意的权利：</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.2.1 运掌柜平台发送的定推和商业广告短信中，会向您说明具体退订方式，您可以按照短信中说明的退订方式撤回同意。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.2.2
              您可以通过“运掌柜”移动端的隐私设置方式改变您授权我们继续收集个人信息的范围或撤回您的授权，您也可以通过设备的设置功能，关闭相应权限（包括位置、通讯录、相机、照片、麦克风、录音、通知等），撤回对运掌柜获取您个人信息的授权。
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;6.2.3 您还可以通过解除银行卡绑定、删除信息等方式撤回部分授权。</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.2.4
              当您撤回同意或授权后，可能导致运掌柜无法为您继续提供撤回授权部分对应的服务。当您撤回同意或授权，不影响撤回前基于您的同意开展的个人信息收集及处理。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;6.3 注销账户</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;您有权注销您的运掌柜账户，您可以通过访问运掌柜平台的“我的”-“设置”-“账户与安全”-“注销账户”进行在线操作。如您无法通过上述链接申请注销账户，可电话联系运掌柜客服提交注销申请。有关注销账户的相关规则和流程，请参见《运掌柜平台账户注销须知》。除法律法规另有规定外，注销账户后运掌柜将停止为您提供服务，并在满足法律法规要求的最短保存期限要求的情况下，对您的个人信息进行删除或匿名化处理，且不再对您的个人信息进行商业化使用。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;6.4 响应您的上述请求</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.4.1
              如您无法通过上述方式访问、更正、删除个人信息、撤回同意或注销账户，您可以随时联系运掌柜客服。运掌柜客服可能需要验证您的身份，并在验证您的身份后30日内作出答复或合理解释。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;6.4.2
              对于您合理的请求，我们原则上不收取费用，但对多次重复、超出合理限度的请求，我们将视情收取一定成本费用。对于那些无端重复、需要过多技术手段（例如，需要开发新系统或从根本上改变现行惯例）、给他人合法权益带来风险或者非常不切实际（例如，涉及备份磁带上存放的信息）的请求，我们可能会予以拒绝。
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;6.4.3 在以下情形中，按照法律法规要求，我们将无法响应您的请求：</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（1）与国家安全、国防安全直接相关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（2）与公共安全、公共卫生、重大公共利益直接相关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（3）与犯罪侦查、起诉、审判和判决执行等直接相关的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（4）有充分证据表明您存在主观恶意或滥用权利的；</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（5）响应您的请求将导致您或其他个人、组织的合法权益受到严重损害的。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;（6）涉及商业秘密的。</MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;7、本政策的更新</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;7.1 如运掌柜平台发生以下变化，运掌柜将及时对本政策进行相应的修订：</MBText>
            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;7.1.1
              本政策生效后，本政策代替运掌柜之前发布的或您之前签署、确认的《运掌柜用户隐私权保护协议》；本政策生效前，仍按《运掌柜用户隐私权保护协议》执行，《运掌柜用户隐私权保护协议》中未尽的事宜，按本政策执行。
            </MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;7.1.2 运掌柜平台业务功能发生变更。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;7.1.3 用户个人信息保存地域发生变更。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;7.1.4 用户个人信息的收集、使用规则发生变更。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;7.1.5 运掌柜的联络方式及投诉渠道发生变更。</MBText>
            <MBText style={[styles.text]}>&emsp;&emsp;7.1.6 发生其他可能影响用户个人信息安全或影响用户隐私权利的变更等。</MBText>

            <MBText style={[styles.text]}>
              &emsp;&emsp;7.2
              本政策修订后，运掌柜会在运掌柜平台发布最新版本，并以显著的方式（包括我们会通过运掌柜公示的方式进行通知甚至向您提供弹窗提示）告知您，以便您及时了解最新版本的本政策，如无特殊说明，修订后的协议自公布之日起7日后生效。若您在本政策的内容发生修改、变更后，继续使用运掌柜平台服务的，视为您已阅读、了解并同意最新修订的本政策内容。
            </MBText>

            <MBText style={[styles.text, styles.strongText]}>&emsp;&emsp;8、如何联系我们</MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;运掌柜平台由上海运掌柜电子科技有限公司运营，公司注册地址为上海市长宁区天山支路
              <MBText style={styles.strongText}>158</MBText>号 <MBText style={styles.strongText}>4</MBText>楼
              <MBText style={styles.strongText}>407</MBText>，其个人信息保护相关负责人的联系方式为
              <MBText style={styles.strongText}>025-69859997</MBText>。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;本政策中的<MBText style={styles.strongText}>运掌柜</MBText>指上海运掌柜电子科技有限公司。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;如果您对于我们的个人信息处理行为存在任何投诉举报需求，您可以通过运掌柜平台上提供的联系方式、在线客服系统或拨打客服电话
              <MBText style={styles.strongText}>025-69859997</MBText>
              与我们联系并作充分描述，我们将在验证您身份的15日内答复您的请求并尽力解决。
            </MBText>
            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;如果您对我们的回复不满意，特别是认为我们的个人信息处理行为损害了您的合法权益，您还可以通过向被告住所地有管辖权的法院提起诉讼。
            </MBText>
            <View>
              <MBText style={[styles.text, styles.strongText]} color="primary" onPress={() => goPages()}>
                《运掌柜平台账户注销须知》
              </MBText>
            </View>
          </View>
        </SafeAreaView>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  content: {
    paddingTop: autoFix(60),
    paddingHorizontal: autoFix(24),
    paddingBottom: autoFix(50),
    backgroundColor: '#fff',
  },

  pageTitle: {
    fontSize: autoFix(40),
    color: '#333333',
    lineHeight: autoFix(48),
    textAlign: 'center',
    fontWeight: 'bold',
  },

  h1Title: {
    fontSize: autoFix(38),
    color: '#333333',
    lineHeight: autoFix(48),
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: autoFix(40),
  },

  h2Title: {
    fontSize: autoFix(32),
    color: '#333333',
    lineHeight: autoFix(42),
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: autoFix(40),
  },

  h3Title: {
    fontSize: autoFix(30),
    color: '#333333',
    lineHeight: autoFix(40),
    marginBottom: autoFix(40),
  },

  h4Title: {
    fontSize: autoFix(28),
    color: '#333333',
    lineHeight: autoFix(40),
    marginBottom: autoFix(40),
  },

  text: {
    lineHeight: autoFix(42),
    marginBottom: autoFix(36),
  },

  strongText: {
    fontWeight: 'bold',
  },

  bottomLine: {
    textDecorationLine: 'underline',
  },
});

export default Privacy;
