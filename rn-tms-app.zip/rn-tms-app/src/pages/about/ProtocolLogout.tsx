import React from 'react';
import { SafeAreaView, View, StyleSheet, ScrollView } from 'react-native';
import { MBText, Splitline, Whitespace } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NavBar from '~/components/common/NavBar';

export interface UserProps {
  navigation?: any;
  screenProps?: any;
}

const User = function (props: UserProps): JSX.Element {
  const { navigation, screenProps } = props;

  const onLeftClick = () => {
    if (screenProps.routername) {
      MBBridge.app.ui.closeWindow({});
      return;
    }
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <NavBar title="运掌柜平台账户注销须知" leftClick={onLeftClick} />
      <ScrollView keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
        <SafeAreaView>
          <View style={styles.content}>
            <MBText style={styles.text}>&emsp;&emsp;亲爱的运掌柜用户：</MBText>
            <MBText style={styles.text}>&emsp;&emsp;在您注销您的”运掌柜”APP（”运掌柜“）账户之前，请充分阅读、理解并同意下列事项：</MBText>
            <MBText style={styles.text}>
              &emsp;&emsp;我们在此善意地提醒您，您注销运掌柜账户的行为，将导致运掌柜终止对您提供服务，也可能会给您的交易维权带来诸多不便。
              您的运掌柜账户注销成功后，我们将删除您的个人信息，使其保持不可被检索、访问的状态，或对其进行匿名化处理。您知晓并理解，
              根据相关法律规定相关交易记录须在运掌柜保存3年甚至更长的时间。
            </MBText>
            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;1. 如果您仍执意注销运掌柜账户，您的账户需同时满足以下条件：
            </MBText>
            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;（1）您的账户与运掌柜钱包中均无余额、无已提现但未到账金额；{'\n'}
                （2）账户内无已完成但未支付的订单/服务；{'\n'}
                （3）账户内无尚未清偿的借款、利息或其他费用；{'\n'}
                （4）账户内无正在生效的保险单；{'\n'}
                （5）账户为正常使用的账户，无任何纠纷或被限制的记录（包括但不限于投诉举报或被投诉举报），且已解决了账户下所有问题。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;2. 在您的运掌柜账户注销期间，如果您的账户涉及争议纠纷，包括但不限于投诉、举报、诉讼、仲裁、国家有权机关调查等，
              运掌柜有权自行终止账户的注销而无需另行得到您的同意。
            </MBText>
            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;3.
              您的运掌柜账户一旦被注销将不可恢复，请您在操作之前自行备份账户相关的所有信息和数据。注销运掌柜账户，您将无法再使用运掌柜账户，
              也将无法找回您运掌柜账户中及与账户相关的任何内容或信息（即使您使用相同的手机号码再次注册并使用运掌柜），包括但不限于：
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;（1）您将无法登录、使用您的运掌柜账户（包括但不限于PC端、移动客户端等）；{'\n'}
                
              <MBText style={[styles.strongText, styles.bottomLine]}>
                （2）如您的平台权益未使用完毕或未到期，视为您自愿放弃相关权益；
              </MBText>
              {'\n'}
                （3）运掌柜账户的个人资料和历史信息（包括但不限于身份信息、账户信息、头像、历史交易信息等当前账号下所有相关信息）都将无法找回；
              {'\n'}
                （4）您通过运掌柜账号进行登录的所有记录将无法找回。您将无法再登录、使用与运掌柜账号相关的所有服务，您在该账号下曾获得的优惠券、红包、积分、卡券及其他虚拟资产等均视为您自行放弃，将无法继续使用。您理解并同意运掌柜无法协助您重新恢复前述服务及权益。
              {'\n'}
                （5）智能终端产品将无法使用运掌柜账户进行登录和使用；如需继续使用，您需要重新注册运掌柜账号并重新设置，本账号内的数据信息不会进行移转或继承。
            </MBText>
            <MBText style={[styles.text]}>
              &emsp;&emsp;4. 如果您的注销申请无法提交成功或对注销事宜有任何疑问，均可以通过运掌柜平台上提供的联系方式、
              在线客服系统或拨打客服电话（025-66928156）与我们联系并作充分描述，我们将在验证您身份后的30天内答复您的请求并尽力解决。
            </MBText>
            <MBText style={[styles.text, styles.strongText]}>
              &emsp;&emsp;5. 注销本运掌柜账户并不代表本运掌柜账户注销前的账户行为和相关责任得到豁免或减轻。
            </MBText>
          </View>
        </SafeAreaView>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  content: {
    paddingTop: autoFix(60),
    paddingHorizontal: autoFix(24),
    paddingBottom: autoFix(50),
    backgroundColor: '#fff',
  },

  pageTitle: {
    fontSize: autoFix(40),
    color: '#333333',
    lineHeight: autoFix(48),
    textAlign: 'center',
    fontWeight: 'bold',
  },

  h2Title: {
    fontSize: autoFix(34),
    color: '#333333',
    lineHeight: autoFix(42),
    marginBottom: autoFix(40),
  },

  text: {
    lineHeight: autoFix(42),
    marginBottom: autoFix(20),
  },

  strongText: {
    fontWeight: 'bold',
  },

  clearBottom: {
    marginBottom: 0,
  },

  bottomLine: {
    textDecorationLine: 'underline',
  },
});

export default User;
