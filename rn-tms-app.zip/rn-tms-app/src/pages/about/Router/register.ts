import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import AboutPage from '../index';
import IntroducePage from '../Introduce';
import PrivacyPage from '../Privacy';
import UserPage from '../User';
import ProtocolLogoutPage from '../ProtocolLogout';
/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 公司介绍
   */
  About = 'About',
  /**
   * 公司介绍
   */
  CompanyIntroduce = 'Introduce',
  /**
   * 用户协议
   */
  UserAgreement = 'User',
  /**
   * 隐私协议
   */
  PrivacyAgreement = 'Privacy',
  /**
   * 隐私协议
   */
  ProtocolLogout = 'ProtocolLogout',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        About: {
          screen: AboutPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        Introduce: {
          screen: IntroducePage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        User: {
          screen: UserPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        Privacy: {
          screen: PrivacyPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        ProtocolLogout: {
          screen: ProtocolLogoutPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
