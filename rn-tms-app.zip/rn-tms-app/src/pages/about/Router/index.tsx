import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { LayProvider } from '@ymm/rn-elements';
import { Provider } from 'mobx-react';

/**
 *
 * @param name 路由简写名
 * 关于我们：ymm://rn.tms/about
 * 隐私协议：ymm://rn.tms/about?routername=privacy
 * 服务协议：ymm://rn.tms/about?routername=user
 * 公司介绍：ymm://rn.tms/about?routername=company
 *
 */
function routerNameMap(name: string) {
  let routerName = 'About';
  switch (name) {
    case 'user':
      routerName = 'UserAgreement';
      break;
    case 'privacy':
      routerName = 'PrivacyAgreement';
      break;
    case 'company':
      routerName = 'CompanyIntroduce';
      break;
    default:
      routerName = 'About';
      break;
  }
  return routerName;
}

const About: React.FunctionComponent<any> = (props) => {
  const routerName = routerNameMap(props.routername);
  const RootStack = new RouterMap().getRouterMap(RouterPageName[routerName]);
  return (
    <Provider>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
      </LayProvider>
    </Provider>
  );
};

export default About;
