import React from 'react';
import { SafeAreaView, View, ScrollView, StyleSheet } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NavBar from '~/components/common/NavBar';

export interface IntroduceProps {
  navigation?: any;
  screenProps?: any;
}

const Introduce = function (props: IntroduceProps): JSX.Element {
  const { navigation, screenProps } = props;

  const onLeftClick = () => {
    // routername存在代表从外部直接跳转进入，直接返回关闭容器外部
    if (screenProps.routername) {
      MBBridge.app.ui.closeWindow({});
      return;
    }
    navigation.goBack();
  };

  const introduceArr = [
    {
      text:
        '运掌柜是一款面向第三方物流企业的SaaS型运输管理系统，隶属于上海运掌柜电子科技有限公司。运掌柜致力于通过运用云计算、大数据、物联网等最新技术，全面赋能三方物流企业，为其提供领先的物流信息化及车辆定位管理等专业解决方案，有效提升物流企业的综合效益。',
    },
    {
      text:
        '运掌柜TMS融合互联网技术、车辆定位技术，服务于三方物流企业中的零担、整车运输场景。系统包含了订单管理、回单管理、车辆管理、车辆定位、客户管理、员工审批、仓储管理、智能报表等八大模块，并通过连接发货人、收货人和不同承运企业，帮助三方物流企业更好、更快完成管货、管单、管车、管人、管财务的工作。',
    },
    {
      text:
        '运掌柜TMS系统基于SaaS模式，不需要企业购置高昂的服务器，也不需要自己维护服务网络，极大降低使用成本，让物流企业快速实现信息化管理。',
    },
    {
      text: '运掌柜，让物流管理更轻松！',
    },
  ];

  return (
    <View style={styles.container}>
      <NavBar title="公司介绍" leftClick={onLeftClick} />
      <ScrollView keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
        <SafeAreaView>
          <View style={styles.content}>
            {introduceArr.map((item) => {
              return <MBText style={styles.textStyle}>&emsp;&emsp;{item.text}</MBText>;
            })}
          </View>
        </SafeAreaView>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  content: {
    paddingTop: autoFix(60),
    paddingHorizontal: autoFix(24),
    paddingBottom: autoFix(50),
    backgroundColor: '#fff',
  },

  textStyle: {
    marginBottom: autoFix(40),
    lineHeight: autoFix(42),
  },
});

export default Introduce;
