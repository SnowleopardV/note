/**
 * Created by mao on 2019/7/16.
 * 司机端 - 待签协议
 */

'use strict'

import {
    action,
    useStrict,
    observable,
    runInAction,
} from 'mobx'

import server from '~/server';
import { MBToast, MBLog ,MBBridge} from '@ymm/rn-lib';

export default class PageStore {
    @observable dataList: Array<any> = []
    
    constructor(props: any) {
        this.getSettingsData({});
    }

  
  @action getSettingsData = async (params: any) => {
    try {
      const res = await server({
        url: '/saas-tms-trans/yzgApp/user/config/getSettingConfig',
        data: { pageCode:"CREATE_ORDER_SETTING" },
      });

      console.log('getSettingsData:',res)
      if (res && res.success && res?.data) {
        this.dataList = res?.data ?? []
      } 
    } catch (error) {
      MBLog.log({
        message: '获取设置数据失败',
        error: error,
      });
    } finally {

    }
  };

     // 保存设置
     @action submit = async (params: any) => {
      MBBridge.app.ui.showLoading({});
      try {
        const res = await server({
          url: '/saas-tms-trans/yzgApp/user/config/save/setting',
          data: { 
            pageCode:"CREATE_ORDER_SETTING",
            createOrderPageSetting:params
          }
        });
        MBBridge.app.ui.hideLoading({});
        if (res && res?.success) {
          MBToast.show('设置成功');
          setTimeout(() => {
            MBBridge.app.ui.closeWindow({});
          }, 300);
        }

      } catch (error) {
        MBBridge.app.ui.hideLoading({});
        MBLog.log({
          message: '设置失败',
          error: error,
        });
      } finally {
        MBBridge.app.ui.hideLoading({});
      }
    };

}
