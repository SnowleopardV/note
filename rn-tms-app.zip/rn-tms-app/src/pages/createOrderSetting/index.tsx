import React, { Component } from 'react';
import { LayProvider, Splitline, CellGroup, Whitespace, Switch } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import { View, SafeAreaView, StyleSheet } from 'react-native';
import { Provider, MBToast, MBBridge } from '@ymm/rn-lib';
import PageStore from './PageStore';
import { observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import EditFooter from './components/EditFooter';
import { ScrollView } from 'react-native-gesture-handler';

interface State {
  checked: boolean;
}

@observer
export default class CreateOrderSetting extends Component<any, State> {
  store: PageStore;
  constructor(props: any) {
    super(props);
    this.store = new PageStore(props);

  
  }

  onSwithChange = (item: any,indexPath:number) => {
    console.log('onSwithChange:::',item.title+indexPath);
    this.store.dataList.map((item,index) => {
      if(indexPath == index){
        item.selectedStatus = !item.selectedStatus
      }
      return item
    })
  };

  renderRightElement = (item: any,index:number) => {
    return (
      <Switch
        onChange={() => {
          this.onSwithChange(item,index);
        }}
        checked={item?.selectedStatus}
      />
    );
  };

  onSubmit = () => {
    console.log('ffffffff:',this.store.dataList);
    if(this.store.dataList?.length){
      this.store.submit(this.store.dataList)
    } else {
      MBToast.show('数据异常，请稍后重试！')
      MBBridge.app.ui.closeWindow({});
    }
  };

  render() {
    return (
      <Provider store={this.store}>
        <LayProvider theme={'blueTheme'}>
          <NavBar title="开单设置" />
          <View style={{ flex: 1, backgroundColor: '#F6F7F9' }}>
            <SafeAreaView style={{ flex: 1, marginTop: 10, borderRadius: 2 }}>
              <ScrollView style={{ flex: 1, marginBottom: 60 }}>
                <CellGroup withBottomLine>
                  {this.store.dataList.map((item,index) => {
                    return <Cell title={item?.title} titleStyle={styles.title} rightElement={this.renderRightElement(item,index)} />;
                  })}
                </CellGroup>

                <Whitespace vertical={10} />
              </ScrollView>
              <View style={{ backgroundColor: 'white', height: 60, position: 'absolute', bottom: 0, width: '100%' }}>
                <EditFooter
                  onSubmit={(type: number) => {
                    this.onSubmit();
                  }}
                />
              </View>
            </SafeAreaView>
          </View>
        </LayProvider>
      </Provider>
    );
  }
}

const styles = StyleSheet.create<any>({
  title: {
    color: '#333333',
    fontSize: 16,
  },
});
