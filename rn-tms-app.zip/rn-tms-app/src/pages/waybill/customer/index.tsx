import React from 'react';
import { SafeAreaView, View, StyleSheet, Platform, BackHandler, TouchableOpacity } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import ChooseContent from './components/ChooseContent';
import { RouterPageName } from './Router/register';
import { MBBridge, MBLog, MBToast } from '@ymm/rn-lib';
import server from '~/server/index';
import CustomerStore from '../customer/Store/Customer';
import WaybillCreateStore from '../create/store';
/**
 * 选择客户页
 * @param props
 * @returns
 */

export interface CustomerChooseIndexProps {
  screenProps: any;
  customerStore: CustomerStore;
  waybillCreateStore: WaybillCreateStore;
  navigation: any;
}

interface CustomerRequestParams {
  customerId: string;
  customerName: string;
}

class CustomerChooseIndex extends React.Component<CustomerChooseIndexProps, any> {
  state = {
    showFooterBtn: true,
  };
  constructor(props: CustomerChooseIndexProps) {
    super(props);
  }

  async UNSAFE_componentWillMount() {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }

  componentDidMount() {
    const {
      customerStore: { getCustomerAddHide },
    } = this.props;

    // PC端运单设置已勾选客户名称必须从下拉选
    getCustomerAddHide();
  }

  // 底部按钮 不能被键盘顶起
  onCommonBlurFocus = (val: boolean) => {
    this.setState({ showFooterBtn: val });
  };

  // 选中客户后回调
  confirmSelect = async (user: any) => {
    const {
      customerStore: { contactList, isFromSupplyWaybill },
    } = this.props;

    const handleContactList = contactList || [];

    if (isFromSupplyWaybill) {
      // 补录运单选择客户名称后，【装卸货地址、货物信息】模块不受客户名称下设置的默认值影响，其他带入逻辑不变
      // 补录运单不带入地址
      const { contactlist, ...restData } = user;
      this.confirmSelectCallBack(restData);
    } else {
      // 选客户时如果已存在装货地址/卸货地址，不带入最近发货地址
      if (!user.shipper && !user.consignee && !handleContactList[0]?.address && !handleContactList[1]?.address) {
        // 选中客户名称
        this.getLastDispather({ customerId: user.customerId, customerName: user.customerName });
      } else {
        // 选中历史记录
        this.confirmSelectCallBack(user);
      }
    }
  };

  // 查询最近一次收发货
  getLastDispather = async (params: CustomerRequestParams) => {
    const { customerId, customerName } = params;
    try {
      const res = await server({
        url: '/saas-tms-trans/yzgApp/order/getLastCustomerInfo',
        data: { ...params },
      });
      if (res.success) {
        const { shipper, consignee, ...restData } = res.data;
        const {
          customerStore: { chooseCustomerIntoTheLoadAddress, chooseCustomerIntoTheUnloadAddress },
        } = this.props;

        let handleShipper = null;
        let handleConsignee = null;

        if (chooseCustomerIntoTheLoadAddress && shipper) {
          handleShipper = { ...shipper };
        }

        if (chooseCustomerIntoTheUnloadAddress && consignee) {
          handleConsignee = { ...consignee };
        }

        this.confirmSelectCallBack({ ...restData, shipper: handleShipper, consignee: handleConsignee });
      }
    } catch (error) {
      // 查询最近一次收发货失败时不阻碍返回首页并展示用户名
      this.confirmSelectCallBack({
        customerId,
        customerName,
      });

      MBLog.log({
        message: '查询最近一次收发货失败',
        error: error,
      });
    }
  };

  confirmSelectCallBack = (user: any) => {
    // 成功后回调
    MBBridge.rnruntime.handlebackResult({ data: user ? JSON.stringify({ ...user, origin: 'customer' }) : '' });

    if (Platform.OS == 'ios') {
      setTimeout(() => {
        MBBridge.app.ui.closeWindow({});
      }, 300);
    }
  };

  /**
   * 点击：新增客户
   */
  onCustomerAdd = () => {
    const { navigation } = this.props;
    // 新增逻辑
    navigation.navigate(RouterPageName.CustomerCreate, {
      onSuccess: (user: any) => {
        this.confirmSelect({
          customerId: user.customerId,
          customerName: user.customerName,
          shipper: null,
          consignee: null,
        });
      },
    });
  };

  rightElement() {
    const {
      customerStore: { customeAddHide },
    } = this.props;

    return !customeAddHide ? (
      <TouchableOpacity
        onPress={() => {
          //设置客户权限则不允许添加
          if (!this.props.customerStore.isCustomerPermission) {
            this.onCustomerAdd();
          } else {
            MBToast.show('客户权限限制，不支持新增');
          }
        }}
      >
        <MBText color={this.props.customerStore.isCustomerPermission ? '#ccc' : 'primary'} size="sm">
          新增客户
        </MBText>
      </TouchableOpacity>
    ) : null;
  }

  render() {
    const { customerStore } = this.props;

    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', () => {
        MBBridge.app.ui.closeWindow({});
        return true;
      });
    }

    return (
      <View style={styles.container}>
        <NavBar title="客户名称" rightElement={this.rightElement()} key="customer" />
        <View style={styles.flexStyle}>
          <View style={styles.flexStyle}>
            <ChooseContent
              customerStore={customerStore}
              onSelect={this.confirmSelect}
              onCommonFocus={() => this.onCommonBlurFocus(false)}
              onCommonBlur={() => this.onCommonBlurFocus(true)}
            />
          </View>
        </View>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },
});

export default inject('customerStore', 'waybillCreateStore')(observer(CustomerChooseIndex));
