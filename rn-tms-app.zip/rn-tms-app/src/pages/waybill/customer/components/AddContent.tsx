import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { observer } from 'mobx-react';
import { CellGroup, MBText, Whitespace, RNElementsUtil } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import CustomerAddStore from '../Store/CustomerAdd';
import { ContactType } from '../proptypes';
import Cell from '~/components/common/Cell';
import Remark from '~/components/common/Remark';
import ModalSalesman from '../../more-info/components/ModalSalesman';
import ModalIsInvoice from '../../more-info/components/ModalIsInvoice';
import ModalPickupType from '../../create/components/ModalPickupType';
import ModalSettleType from '../../create/components/ModalSettleType';
import ModalOpenUpChannels from './ModalOpenUpChannels';

interface IAddContentProps {
  customerAddStore: CustomerAddStore;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
}

// 提货方式枚举过滤
const filterPickupType = (loadMode: number) => {
  let handlePickupType;

  switch (loadMode) {
    case 2:
      handlePickupType = '否';
      break;
    case 1:
      handlePickupType = '是';
      break;
    default:
      handlePickupType = '';
      break;
  }

  return handlePickupType;
};

// 结算方式枚举过滤
const filterSettleType = (settleType: number) => {
  let handleSettleType;
  switch (settleType) {
    case 1:
      handleSettleType = '现付';
      break;
    case 2:
      handleSettleType = '到付';
      break;
    case 3:
      handleSettleType = '回付';
      break;
    case 4:
      handleSettleType = '月结';
      break;
    case 5:
      handleSettleType = '油卡';
      break;
    default:
      handleSettleType = '';
      break;
  }

  return handleSettleType;
};

// 是否开票
const filterIsBilling = (isBilling: number) => {
  let handleIsBilling;

  switch (isBilling) {
    case 1:
      handleIsBilling = '是';
      break;
    case 0:
      handleIsBilling = '否';
      break;
    default:
      handleIsBilling = '';
      break;
  }

  return handleIsBilling;
};

// 是否开票
const filterOpenUpChannels = (openUpChannels: number) => {
  let handleOpenUpChannels;

  switch (openUpChannels) {
    case 1:
      handleOpenUpChannels = '公司开拓 ';
      break;
    case 2:
      handleOpenUpChannels = '个人开拓';
      break;
    default:
      handleOpenUpChannels = '';
      break;
  }

  return handleOpenUpChannels;
};

const AddContent: React.FunctionComponent<IAddContentProps> = (props) => {
  const { onCommonFocus, onCommonBlur } = props;
  const {
    stateData: {
      customerName,
      contactName,
      contactPhone,
      loadMode,
      settleType,
      isBilling,
      openUpChannels,
      operatorId,
      operatorName,
      insuranceRate,
      remark,
    },
    rules,
    operatorList,
    settleTypeModalVisible,
    pickupTypeModalVisible,
    openUpChannelsModalVisible,
    isInvoiceModalVisible,
    salesmanModalVisible,
    cleanErrorByIndex,
    setCustomerName,
    setContactName,
    setContactPhone,
    setInsuranceRate,
    setRemark,
    changePickupTypeModalVisible,
    changeSettleTypeModalVisible,
    changeIsInvoiceModalVisible,
    changeOpenUpChannelsModalVisible,
    changeSalesmanModalVisible,
    onConfirmOpenUpChannelsModal,
    onConfirmSalesmanModal,
    onConfirmIsInvoiceModal,
    onConfirmSettleTypeModal,
    onConfirmPickupTypeModal,
  } = props.customerAddStore;

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={styles.customerAdd}>
      <CellGroup withBottomLine>
        <InputItem
          value={customerName}
          title="客户名称"
          placeholder="请输入"
          maxLength={20}
          textAlign="right"
          required
          onChangeText={setCustomerName}
          extra={
            rules[0].isError && (
              <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                <MBText size="xs" color="#F54242" align="right">
                  {rules[0].message}
                </MBText>
                <Whitespace vertical={14} />
              </View>
            )
          }
          onFocus={() => {
            cleanErrorByIndex(0);
            onCommonFocus && onCommonFocus();
          }}
          onBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />
      </CellGroup>

      <Whitespace vertical={10} />

      <CellGroup withBottomLine>
        <InputItem
          value={contactName}
          title="联系人"
          placeholder="请输入"
          maxLength={100}
          textAlign="right"
          onChangeText={setContactName}
          onFocus={() => {
            onCommonFocus && onCommonFocus();
          }}
          onBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />

        <InputItem
          value={contactPhone}
          title="联系号码"
          keyboardType="numeric"
          placeholder="请输入"
          maxLength={11}
          textAlign="right"
          onChangeText={setContactPhone}
          onFocus={() => {
            onCommonFocus && onCommonFocus();
          }}
          onBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />

        <Cell
          name="pickupType"
          title="提货"
          align="right"
          value={filterPickupType(loadMode)}
          placeholder="请选择"
          onPress={changePickupTypeModalVisible}
        />

        <Cell
          name="settleType"
          title="结算方式"
          align="right"
          value={filterSettleType(settleType)}
          placeholder="请选择"
          onPress={changeSettleTypeModalVisible}
        />

        <Cell
          name="isBilling"
          title="是否开票"
          align="right"
          numberOfLines={1}
          value={filterIsBilling(isBilling)}
          placeholder="请选择"
          onPress={changeIsInvoiceModalVisible}
        />

        <Cell
          name="openUpChannels"
          title="开拓渠道"
          align="right"
          value={filterOpenUpChannels(openUpChannels)}
          placeholder="请选择"
          onPress={changeOpenUpChannelsModalVisible}
        />

        <Cell
          name="operatorId"
          title="对接业务员"
          align="right"
          value={operatorName}
          placeholder="请选择"
          onPress={changeSalesmanModalVisible}
        />

        <InputItem
          value={insuranceRate}
          title="保险费率"
          keyboardType="numeric"
          placeholder="请输入"
          maxLength={8}
          textAlign="right"
          extraNode={<MBText style={styles.itemUnit}>‰</MBText>}
          onChangeText={setInsuranceRate}
          onFocus={() => {
            onCommonFocus && onCommonFocus();
          }}
          onBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />

        <Remark
          value={remark}
          onChangeText={setRemark}
          onFocus={() => {
            onCommonFocus && onCommonFocus();
          }}
          onBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />
      </CellGroup>

      <ModalOpenUpChannels
        visible={openUpChannelsModalVisible}
        isInvoice={isBilling}
        onConfirm={onConfirmOpenUpChannelsModal}
        onCancel={changeOpenUpChannelsModalVisible}
      />

      <ModalSalesman
        visible={salesmanModalVisible}
        operatorList={operatorList}
        operatorId={operatorId}
        onConfirm={onConfirmSalesmanModal}
        onCancel={changeSalesmanModalVisible}
      />

      <ModalIsInvoice
        visible={isInvoiceModalVisible}
        isInvoice={isBilling}
        onConfirm={onConfirmIsInvoiceModal}
        onCancel={changeIsInvoiceModalVisible}
      />

      <ModalSettleType
        visible={settleTypeModalVisible}
        settleType={settleType}
        onConfirm={onConfirmSettleTypeModal}
        onCancel={changeSettleTypeModalVisible}
      />

      <ModalPickupType
        visible={pickupTypeModalVisible}
        loadMode={loadMode}
        onConfirm={onConfirmPickupTypeModal}
        onCancel={changePickupTypeModalVisible}
      />
    </ScrollView>
  );
};
const styles = StyleSheet.create<any>({
  customerAdd: {
    paddingVertical: 10,
  },

  inputStyle: {
    fontSize: 16,
    color: '#666',
    height: 53,
  },

  itemUnit: {
    marginLeft: 4,
    marginRight: 16,
    color: '#666666',
  },
});

export default observer(AddContent);
