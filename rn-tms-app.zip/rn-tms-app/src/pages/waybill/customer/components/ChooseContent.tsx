import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, FlatList, Image } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText, Splitline, Whitespace, Flex, Tabs, CellGroup } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import Cell from '~/components/common/Cell';
import MBSearchInput from '~/components/common/MBSearchInput';
import { ContactType, CustomerModel } from '../proptypes';
import CustomerStore from '../Store/Customer';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import RegTest from '~/utils/RegTest';
import Images from '../../../../../public/static/images/index';
import NativeBridge from '~/extends/NativeBridge';
import LevelTag from '~/components/LevelTag';

export interface ChooseContentProps {
  customerStore: CustomerStore;
  onSelect: (user: any) => void;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
}

interface tabsItemModel {
  name: string;
  title: string;
}
export interface RefreshListState {
  keyword: string;
  tabsName: tabsItemModel[];
  defaultIndex: number;
}
class ChooseContent extends React.Component<ChooseContentProps, RefreshListState> {
  get store() {
    return this.props.customerStore;
  }
  timer: NodeJS.Timer | null = null;
  constructor(props: ChooseContentProps) {
    super(props);
    this.state = {
      keyword: '',
      tabsName: [
        {
          name: 'historyRecord',
          title: '历史记录',
        },
        {
          name: 'allCustomer',
          title: '所有客户',
        },
      ],
      defaultIndex: 0,
    };
  }

  componentWillMount() {
    MBBridge.app.storage.getItem({ key: 'customerTabDefaultIndex' }).then((res) => {
      if (res.code === 0) {
        this.setState({
          defaultIndex: Number(res.data?.text),
        });
      }
    });
  }

  prepareSearch = (text: string) => {
    const _this = this;
    const startInput = text;
    if (RegTest.emoji(text)) return;

    this.store.isLoading = true;
    this.store.beforeRefresh();
    this.setState(
      {
        keyword: text,
      },
      () => {
        if (_this.timer) {
          clearTimeout(_this.timer);
          _this.timer = null;
        }
        const endInput = _this.state.keyword;
        if (startInput == endInput && endInput) {
          _this.timer = setTimeout(() => {
            _this.store.refresh(startInput);
          }, 1000);
        }
      }
    );
  };

  onSelect = (user: any) => {
    this.props.onSelect(user);
  };

  /**
   * 渲染卡片
   * @param item
   * @param onSelect
   * @returns
   */

  renderItem = (item: CustomerModel, onSelect: () => void): JSX.Element => {
    const { keyword } = this.state;
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onSelect} key={item.customerName}>
        <View style={styles.listItem}>
          {!!keyword && item.customerName?.indexOf(keyword) >= 0 ? (
            <View style={{ flexDirection: 'row' }}>
              {!!item.custLevel && <LevelTag text={item.custLevel} isFull={false} style={{ marginLeft: 0, marginTop: autoFix(2) }} />}
              <MBText style={styles.listItemTitle}>{item.customerName.substring(0, item.customerName.indexOf(keyword))}</MBText>
              <MBText style={[styles.listItemTitle, { color: '#4885FF' }]}>
                {item.customerName.substring(item.customerName.indexOf(keyword), item.customerName.indexOf(keyword) + keyword.length)}
              </MBText>
              <MBText style={styles.listItemTitle}>
                {item.customerName?.substring(item.customerName.indexOf(keyword) + keyword.length)}
              </MBText>
            </View>
          ) : (
            <View style={{ flexDirection: 'row' }}>
              {!!item.custLevel && <LevelTag text={item.custLevel} isFull={false} style={{ marginLeft: 0, marginTop: autoFix(2) }} />}
              <MBText style={[styles.listItemTitle]}>{item.customerName}</MBText>
            </View>
          )}
          {item.shipper || item.consignee ? (
            <View style={styles.cantactWrapper}>
              <View style={styles.shipperAddressWrapper}>
                <Image
                  style={[
                    styles.iconDashLineStyle,
                    !item.shipper?.contactName && !item.shipper?.contactPhone ? styles.iconDashLineShortStyle : {},
                  ]}
                  source={{ uri: Images.icon_dashLine }}
                />
                <View style={styles.addressWrapper}>
                  <View style={[styles.roundPonitStyle, styles.blueColorStyle]}></View>
                  <MBText style={styles.address} numberOfLines={1} ellipsizeMode="tail" size="xs">
                    {item.shipper?.address || '--'}
                  </MBText>
                </View>
              </View>

              {/* {item.shipper?.companyName ? (
                <View style={styles.namePhoneWrapper}>
                    <MBText style={[styles.address,{paddingLeft:0}]} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.shipper?.companyName}
                    </MBText>
                </View>
              ) : null} */}

              {item.shipper?.contactName || item.shipper?.contactPhone ? (
                <View style={styles.namePhoneWrapper}>
                  {item.shipper?.contactName ? (
                    <MBText style={styles.userName} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.shipper?.contactName}
                    </MBText>
                  ) : null}
                  <MBText size="xs" style={styles.tel}>
                    {item.shipper?.contactPhone}
                  </MBText>
                </View>
              ) : null}

              <View style={styles.consigneeAddressWrapper}>
                <View style={styles.addressWrapper}>
                  <View style={[styles.roundPonitStyle, styles.blackColorStyle]}></View>
                  <MBText style={styles.address} numberOfLines={1} ellipsizeMode="tail" size="xs">
                    {item.consignee?.address || '--'}
                  </MBText>
                </View>
              </View>

              {item.consignee?.contactName || item.consignee?.contactPhone ? (
                <View style={styles.namePhoneWrapper}>
                  {item.consignee?.contactName ? (
                    <MBText style={styles.userName} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.consignee?.contactName}
                    </MBText>
                  ) : null}

                  <MBText size="xs" style={styles.tel}>
                    {item.consignee?.contactPhone}
                  </MBText>
                </View>
              ) : null}
            </View>
          ) : null}
        </View>
        <Splitline />
      </TouchableOpacity>
    );
  };

  renderCustomerItem = (item: any, subItem: any, onCustomerSelect: () => void): JSX.Element => {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onCustomerSelect} key={item.customerName}>
        <View style={styles.customerNameWrapper}>
          <View style={styles.customerNameContent}>
            {!!item.custLevel && <LevelTag text={item.custLevel} isFull={false} style={{ marginLeft: 0, marginTop: autoFix(2) }} />}
            <MBText style={styles.customerNameStyle}>{item.customerName}</MBText>
          </View>
          {subItem.index !== subItem.iLength - 1 && <Splitline />}
        </View>
      </TouchableOpacity>
    );
  };

  /**
   * 全部客户渲染视图
   * @param store
   * @param keyword
   * @returns
   */
  renderAllCustomerView(store: CustomerStore, keyword: string) {
    return (
      <View>
        {!keyword && !store.isAllCustomerLoading && store.allCustomerList.length === 0 && (
          <View>
            <Whitespace vertical={14} />
            <MBText align="center" color="#ccc">
              无维护的客户
            </MBText>
          </View>
        )}
        {!keyword && !store.isAllCustomerLoading && store.allCustomerList.length > 0 && (
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{ backgroundColor: '#fff' }}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
          >
            <View>
              {store.allCustomerList.map((item) => {
                return (
                  <View key={item.index}>
                    <MBText color="#666" style={styles.customerLetterIndex}>
                      {item.index}
                    </MBText>
                    {item.customerList.map((e, i) => {
                      return this.renderCustomerItem(
                        {
                          customerId: String(e.id),
                          customerName: e.custName,
                          custLevel: e.custLevel,
                        },
                        {
                          index: i,
                          iLength: item.customerList.length,
                        },
                        () => {
                          const item = {
                            customerId: String(e.id),
                            customerName: e.custName,
                            shipper: null,
                            consignee: null,
                          };
                          MBBridge.app.storage.setItem({ key: 'customerTabDefaultIndex', text: '1' });
                          this.onSelect(item);
                        }
                      );
                    })}
                  </View>
                );
              })}
            </View>
          </ScrollView>
        )}
      </View>
    );
  }

  /**
   * 历史记录渲染视图
   * @param store
   * @param keyword
   * @returns
   */
  renderHistoryRecordView(store: CustomerStore, keyword: string) {
    return (
      <View>
        {!keyword && !store.isHistoryRecordLoading && store.historyRecordList.length === 0 && (
          <View>
            <Whitespace vertical={14} />
            <MBText align="center" color="#ccc">
              无最近发货方历史
            </MBText>
          </View>
        )}
        {!keyword && !store.isHistoryRecordLoading && store.historyRecordList.length > 0 && (
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{ backgroundColor: '#fff' }}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
          >
            <View style={styles.listWrapper}>
              {store.historyRecordList.map((item, index) => {
                return this.renderItem(
                  {
                    customerId: item.customerId,
                    customerName: item.customerName,
                    shipper: item.shipper,
                    consignee: item.consignee,
                    custLevel: item.custLevel,
                  },
                  () => {
                    MBBridge.app.storage.setItem({ key: 'customerTabDefaultIndex', text: '0' });
                    this.onSelect(item);
                  }
                );
              })}
            </View>
          </ScrollView>
        )}
      </View>
    );
  }

  /**
   * 搜索内容渲染视图
   * @param store
   * @param keyword
   * @returns
   */
  renderSearchContentView(store: CustomerStore, keyword: string) {
    return (
      <View>
        {!store.isLoading && store.shipperList.length === 0 && (
          <View>
            <Whitespace vertical={14} />
            <MBText align="center" color="#ccc">
              无搜索结果
            </MBText>
          </View>
        )}
        {!!keyword && store.shipperList.length > 0 && (
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{ backgroundColor: '#fff' }}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
          >
            <View style={styles.listWrapper}>
              {store.shipperList.map((item, index) => {
                return this.renderItem(
                  {
                    customerId: item.customerId,
                    customerName: item.customerName,
                    custLevel: item.custLevel,
                    shipper: null,
                    consignee: null,
                  },
                  () => {
                    this.onSelect(item);
                  }
                );
              })}
            </View>
          </ScrollView>
        )}
      </View>
    );
  }

  /**
   * 搜索框渲染视图
   * @param keyword
   * @returns
   */
  renderSearchInputView(keyword: string) {
    const { onCommonFocus, onCommonBlur } = this.props;
    return (
      <View style={styles.searchBar}>
        <MBSearchInput
          initialText={keyword}
          onChangeText={this.prepareSearch}
          placeholder="输入客户名称"
          onFocus={() => {
            onCommonFocus && onCommonFocus();
          }}
          onBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />
      </View>
    );
  }

  /**
   * tab切换
   * @param index
   * @param name
   */
  tabChange = (index: number, name: string) => {};

  render() {
    const { customerStore: store } = this.props;
    const { keyword, tabsName, defaultIndex } = this.state;

    return (
      <View style={styles.customerChoose}>
        {this.renderSearchInputView(keyword)}

        {!keyword ? (
          store.isFromSupplyWaybill ? (
            this.renderAllCustomerView(store, keyword)
          ) : (
            <Tabs defaultIndex={defaultIndex} activeTextStyle={styles.tabActive} onChange={this.tabChange} fixedWidth={true}>
              {tabsName.map((item, index) => {
                return (
                  <Tabs.TabPane key={item.title} position={index} title={item.title} name={item.name}>
                    {item.name === 'historyRecord'
                      ? this.renderHistoryRecordView(store, keyword)
                      : this.renderAllCustomerView(store, keyword)}
                  </Tabs.TabPane>
                );
              })}
            </Tabs>
          )
        ) : (
          this.renderSearchContentView(store, keyword)
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  customerChoose: {
    backgroundColor: '#F6F7F9',
    flex: 1,
  },

  searchBar: {
    backgroundColor: '#fff',
    paddingHorizontal: 14,
    paddingBottom: 14,
  },

  tabActive: {
    color: '#4885FF',
  },

  customerLetterIndex: {
    fontWeight: 'bold',
    color: '#333',
    backgroundColor: '#F6F7F9',
    paddingLeft: autoFix(52),
    paddingVertical: autoFix(8),
  },

  listWrapper: {
    marginTop: 6,
    paddingLeft: 16,
    backgroundColor: '#fff',
  },

  searchListWrapper: {
    paddingLeft: 16,
    backgroundColor: '#fff',
    flex: 1,
    // paddingBottom: 106,
  },

  listItem: {
    paddingRight: 16,
    paddingVertical: 14,
  },

  listItemTitle: {
    fontSize: autoFix(30),
    color: '#333',
    fontWeight: 'bold',
  },

  cantactWrapper: {
    marginTop: autoFix(28),
  },

  consigneeAddressWrapper: {
    marginTop: autoFix(26),
  },

  address: {
    color: '#333',
    fontSize: autoFix(28),
    flexShrink: 1,
    paddingLeft: autoFix(16),
  },

  userName: {
    color: '#666',
    fontSize: autoFix(28),
    marginRight: autoFix(12),
  },

  tel: {
    color: '#666',
    fontSize: autoFix(26),
  },

  shipperAddressWrapper: {
    position: 'relative',
  },

  addressWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  roundPonitStyle: {
    width: autoFix(14),
    height: autoFix(14),
    borderRadius: autoFix(14),
  },

  blueColorStyle: {
    backgroundColor: '#4885FF',
  },

  blackColorStyle: {
    backgroundColor: '#333333',
  },

  iconDashLineStyle: {
    width: autoFix(2),
    height: autoFix(112),
    position: 'absolute',
    top: autoFix(10),
    left: autoFix(5),
  },

  iconDashLineShortStyle: {
    height: autoFix(70),
  },

  namePhoneWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: autoFix(8),
    paddingLeft: autoFix(31),
  },

  customerNameWrapper: {
    backgroundColor: '#fff',
    paddingLeft: autoFix(52),
    paddingRight: autoFix(16),
  },

  customerNameContent: {
    paddingVertical: autoFix(20),
    flexDirection: 'row',
  },

  customerNameStyle: {
    color: '#333',
    fontSize: autoFix(30),
  },
});
export default observer(ChooseContent);
