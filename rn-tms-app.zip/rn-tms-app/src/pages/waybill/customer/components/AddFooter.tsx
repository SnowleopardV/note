import React from 'react';
import { StyleSheet } from 'react-native';
import { Button, MBText, Flex } from '@ymm/rn-elements';

const FlexItem = Flex.Item;
interface IAddFooterProps {
  onPress: () => void;
}
const AddFooter: React.FunctionComponent<IAddFooterProps> = (props) => (
  <Flex direction="row">
    <FlexItem style={styles.footer}>
      <Button type="primary" size="sm" radius style={styles.itemBtn} onPress={props.onPress}>
        <MBText color="#fff">确定</MBText>
      </Button>
    </FlexItem>
  </Flex>
);

const styles = StyleSheet.create<any>({
  footer: {
    // height: 60,
    paddingVertical: 10,
    paddingHorizontal: 14,
    alignItems: 'center',
    flexDirection: 'row',
  },

  itemBtn: {
    flex: 1,
    flexDirection: 'row',
  },
});

export default AddFooter;
