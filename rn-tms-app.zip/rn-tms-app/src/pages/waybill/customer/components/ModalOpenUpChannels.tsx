import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { Flex, Modal, MBText, Splitline, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalOpenUpChannels = (props: any) => {
  const { visible, onConfirm, onCancel, openUpChannels } = props;
  const [OpenUpChannelsList, setOpenUpChannelsList] = useState<any[]>([
    {
      openUpChannels: 1,
      settleName: '公司开拓',
    },
    {
      openUpChannels: 2,
      settleName: '个人开拓',
    },
  ]);

  const [OpenUpChannelsItem, setOpenUpChannelsItem] = useState<any>({
    openUpChannels: null,
  });

  useEffect(() => {
    setOpenUpChannelsItem(() => {
      const lastOpenUpChannelsArr = OpenUpChannelsList.filter((item) => item.openUpChannels === openUpChannels);
      return lastOpenUpChannelsArr.length ? lastOpenUpChannelsArr[0] : { openUpChannels: null };
    });
  }, [openUpChannels]);

  //  开拓渠道确认
  const onModalConfirm = (value: number) => {
    setOpenUpChannelsItem(value);
    onConfirm && onConfirm(value);
  };

  return (
    <View style={{ flex: 1 }}>
      <Modal
        title="请选择开拓渠道"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        contentStyle={styles.contentStyle}
        headerLine={false}
        onMaskClose={() => {
          onCancel && onCancel();
        }}
        onRequestClose={() => {
          onCancel && onCancel();
        }}
      >
        {OpenUpChannelsList.map((item: any, index: number) => {
          return (
            <View key={item.id} style={{ width: '100%' }}>
              <TouchableOpacity
                activeOpacity={0.2}
                onPress={() => {
                  onModalConfirm(item.openUpChannels);
                }}
              >
                <Flex direction="row">
                  <FlexItem style={styles.selectItem}>
                    <MBText align="center" style={OpenUpChannelsItem.openUpChannels === item.openUpChannels && styles.selected}>
                      {item.settleName}
                    </MBText>
                  </FlexItem>
                </Flex>
              </TouchableOpacity>
              {index !== OpenUpChannelsList.length - 1 && <Splitline />}
            </View>
          );
        })}
        <View style={styles.splitline}></View>
        <View style={{ width: '100%' }}>
          <TouchableOpacity
            onPress={() => {
              onCancel && onCancel();
            }}
          >
            <Flex direction="row">
              <FlexItem style={styles.selectItem}>
                <MBText align="center">取消</MBText>
              </FlexItem>
            </Flex>
          </TouchableOpacity>
        </View>
        <Whitespace vertical={20} />
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  contentStyle: {
    paddingHorizontal: 0,
  },

  selectItem: {
    height: 55,
    justifyContent: 'center',
  },

  splitline: {
    backgroundColor: '#F7F7F7',
    width: '100%',
    height: 10,
  },

  selected: {
    fontWeight: 'bold',
  },
});

export default ModalOpenUpChannels;
