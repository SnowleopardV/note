import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import CustomerPage from '../index';
import CustomerAddPage from '../Add';
/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 选择客户
   */
  CustomerSelector = 'CustomerSelector',

  /**
   * 新增客户
   */
  CustomerCreate = 'CustomerCreate',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        CustomerSelector: {
          // 选择客户
          screen: CustomerPage,
          navigationOptions: () => ({
            header: null,
          }),
          // screen: SecondPage,
          // navigationOptions: () => ({
          //   header: null
          // })
        },

        CustomerCreate: {
          // 新增客户
          screen: CustomerAddPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
