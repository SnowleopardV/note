import * as React from 'react';
import { View, Platform } from 'react-native';
import { observer, Provider } from 'mobx-react';
import RouterMap, { RouterPageName } from './register';
import { LayProvider } from '@ymm/rn-elements';
import CustomerStore from '../Store/Customer';
import { JsonParse } from '@ymm/rn-lib/src/utils';
import CustomerAddStore from '../Store/CustomerAdd';
import WaybillCreateStore from '~/pages/waybill/create/store';

const RootStack = new RouterMap().getRouterMap(RouterPageName.CustomerSelector);

const CustomerSelector: React.FunctionComponent<any> = (props) => {
  const {
    contacttype,
    customerid,
    customername,
    contactlist,
    isfromsupplywaybill,
    choosecustomerintotheloadaddress,
    choosecustomerintotheunloadaddress,
  } = props;

  let handlecontactlist = contactlist;
  const handlechoosecustomerintotheloadaddress = JsonParse.parse(choosecustomerintotheloadaddress);
  const handlechoosecustomerintotheunloadaddress = JsonParse.parse(choosecustomerintotheunloadaddress);
  if (Platform.OS === 'android') {
    handlecontactlist = JsonParse.parse(contactlist);
  }

  const customerStore = new CustomerStore(
    Number(contacttype),
    customerid,
    customername,
    isfromsupplywaybill,
    handlecontactlist,
    handlechoosecustomerintotheloadaddress,
    handlechoosecustomerintotheunloadaddress
  );
  const customerAddStore = new CustomerAddStore(Number(contacttype));
  const waybillCreateStore = new WaybillCreateStore(null);

  return (
    <Provider customerStore={customerStore} customerAddStore={customerAddStore} waybillCreateStore={waybillCreateStore}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
      </LayProvider>
    </Provider>
  );
};

export default CustomerSelector;
