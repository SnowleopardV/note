export enum MapType {
  Baidu = 1,
  Gaode = 2,
}
export enum ContactType {
  Consignor = 1,
  Consignee = 2,
}

export interface AddressModel extends AddressType {
  mapType: MapType; // 1：百度，2：高德
}

export interface BaseUserModel extends AddressModel {
  contactName: string;
  contactType: ContactType;
  contactPhone: string;
}
/**
 * 发货人类型
 */
export interface ShipperUser extends BaseUserModel {
  contactType: 1;
  companyName:string
}
/**
 * 收货人类型
 */
export interface ConsigneeUser extends BaseUserModel {
  contactType: 2;
  companyName:string
}
/**
 * 通用类型声明
 * 发货人|收货人
 */
export interface UserModel extends BaseUserModel {
  contactType: ContactType;
}
/**
 * 发货人查询数据
 */
export interface CustomerModel {
  customerId: string;
  customerName: string;
  shipper: ShipperUser;
  consignee: ConsigneeUser;
  custLevel?: string;
}

/**
 * 所有客户查询数据
 */
export interface CustomerItemModel {
  id: number;
  custName: string;
  billingRate: number; // 保费费率，null 表示未配置。
}

export interface AllCustomerModel {
  index: string;
  customerList: CustomerItemModel[];
}
