import { MBLog } from '@ymm/rn-lib';
import { action, computed, observable } from 'mobx';
import server from '~/server/index';
import { RequestDateTime } from '~/components/common/MBDatetimePicker/proptypes';
import { CustomerModel, ContactType, AllCustomerModel, UserModel } from '../proptypes';

export interface ContactUser extends UserModel {
  handlingTime?: RequestDateTime;
}

const defaultContact = {
  contactName: '',
  contactPhone: '',
  province: 0,
  provinceName: '',
  city: 0,
  cityName: '',
  area: 0,
  areaName: '',
  longitude: '0',
  latitude: '0',
  mapType: 2,
  address: '',
};

class CustomerStore {
  @observable pageNo = 1;
  @observable pageSize = 20;
  // 发货人列表
  @observable shipperList: CustomerModel[] = [];
  // 收货人列表
  @observable consigneeList: CustomerModel[] = [];
  // 历史记录列表
  @observable historyRecordList: CustomerModel[] = [];
  // 全部客户信息
  @observable allCustomerList: AllCustomerModel[] = [];
  // 收货历史信息
  @observable consigneeHistoryList: CustomerModel[] = [];
  @observable isEnd = false;

  @observable isLoading: boolean = false;
  @observable isHistoryRecordLoading: boolean = false;
  @observable isAllCustomerLoading: boolean = false;
  @observable contactList: ContactUser[] = [
    {
      ...defaultContact,
      contactType: 1,
    },
    {
      ...defaultContact,
      contactType: 2,
    },
  ];
  @observable isCustomerPermission: boolean = false;
  contactType = 1;
  customerId?: string;
  customerName?: string;
  isFromSupplyWaybill?: boolean;

  // 新增客户隐藏
  @observable customeAddHide: boolean = true;
  // 选择客户是否带入装卸货地址
  @observable chooseCustomerIntoTheLoadAddress: boolean = true;
  @observable chooseCustomerIntoTheUnloadAddress: boolean = true;

  constructor(
    contacttype: number,
    customerid: string,
    customername: string,
    isfromsupplywaybill: string,
    contactlist: ContactUser[],
    choosecustomerintotheloadaddress: boolean,
    choosecustomerintotheunloadaddress: boolean
  ) {
    this.contactType = contacttype;
    this.customerId = customerid;
    this.customerName = customername;
    this.isFromSupplyWaybill = isfromsupplywaybill === 'true';
    this.contactList = contactlist;
    this.chooseCustomerIntoTheLoadAddress = choosecustomerintotheloadaddress;
    this.chooseCustomerIntoTheUnloadAddress = choosecustomerintotheunloadaddress;
    this.fetchHistory();
    this.checkCustomerPermission();
  }

  @action fetchHistory(): void {
    this.fetchHistoryRecord();
    this.fetcAllCustomer();
  }

  /**
   * 历史记录
   */
  fetchHistoryRecord() {
    console.log(this.customerName, 'this.customerName');
    this.isHistoryRecordLoading = true;
    server({
      url: '/saas-tms-trans/yzgApp/crm/cust/last_2',
      data: {
        customerName: this.customerName ? this.customerName : '',
        type: 0, // 去重类型： 0-全部 1-发货 2-卸货
      },
    })
      .then(
        action((response: any) => {
          this.historyRecordList = response.data || [];
        })
      )
      .catch((er) => {
        MBLog.log({
          message: '查询最近30天发货历史失败',
          error: er,
        });
      })
      .finally(() => {
        this.isHistoryRecordLoading = false;
      });
  }

  /**
   * 全部客户
   */
  fetcAllCustomer() {
    this.isAllCustomerLoading = true;
    server({
      url: '/saas-tms-trans/yzgApp/crm/selectCustomerList',
      data: {},
    })
      .then(
        action((response: any) => {
          this.allCustomerList = response.data?.list || [];
        })
      )
      .catch((er) => {
        MBLog.log({
          message: '查询所有客户失败',
          error: er,
        });
      })
      .finally(() => {
        this.isAllCustomerLoading = false;
      });
  }

  /**
   * 收货人历史信息
   */
  // fetchConsigneeHistory() {
  //   this.isLoading = true;
  //   server({
  //     url: '/saas-tms-trans/yzgApp/crm/consignees/last',
  //     data: {
  //       customerName: this.customerName,
  //     },
  //   })
  //     .then(
  //       action((response: any) => {
  //         this.consigneeHistoryList = response.data || [];
  //       })
  //     )
  //     .catch((er) => {
  //       MBLog.log({
  //         message: '查询最近30天发货历史失败',
  //         error: er,
  //       });
  //     })
  //     .finally(() => {
  //       this.isLoading = false;
  //     });
  // }

  @action beforeRefresh = () => {
    this.shipperList = [];
    this.consigneeList = [];
  };
  @action refresh = (keyword: string) => {
    this.pageNo = 1;
    this.isEnd = false;
    this.search(keyword);
  };

  @action loadmore = (keyword: string) => {
    if (this.isEnd) {
      return;
    }
    this.pageNo += 1;
    this.search(keyword);
  };
  @action search = (keyword: string) => {
    this.isLoading = true;
    this.searchShipper(keyword);
    // if (this.contactType === ContactType.Consignor) {
    //   this.searchShipper(keyword);
    // } else {
    //   this.searchConsignee(keyword);
    // }
  };
  /**
   * 收货人搜索
   * @param keyword
   */
  // searchConsignee = (keyword: string): void => {
  //   server(
  //     {
  //       url: '/saas-tms-trans/yzgApp/crm/consignees/page',
  //       data: {
  //         keyword,
  //         customerName: this.customerName,
  //         pageNo: this.pageNo,
  //         pageSize: this.pageSize,
  //       },
  //     },
  //     { showLoading: false }
  //   )
  //     .then(
  //       action((response: any) => {
  //         this.isEnd = !response.data.hasNextPage;
  //         if (response.data.pageNum > 1) {
  //           this.consigneeList = this.consigneeList.concat(response.data.list);
  //         } else {
  //           this.consigneeList = response.data.list || [];
  //         }
  //         this.isLoading = false;
  //       })
  //     )
  //     .catch(
  //       action((er) => {
  //         MBLog.log({
  //           message: '搜索客户名失败',
  //           error: er,
  //         });
  //       })
  //     );
  // };
  /**
   * 发货人搜索
   * @param keyword
   */
  searchShipper = (keyword: string): void => {
    server({
      url: '/saas-tms-trans/yzgApp/crm/customer/page',
      data: {
        customerName: keyword,
        pageNo: this.pageNo,
        pageSize: this.pageSize,
      },
    })
      .then(
        action((response: any) => {
          this.isEnd = !response.data.hasNextPage;
          if (response.data.pageNum > 1) {
            this.shipperList = this.shipperList.concat(response.data.list);
          } else {
            this.shipperList = response.data.list || [];
          }
          this.isLoading = false;
        })
      )
      .catch(
        action((er) => {
          MBLog.log({
            message: '搜索客户名失败',
            error: er,
          });
          this.isLoading = false;
        })
      );
  };

  // 校验当前操作人是否设置了客户权限
  @action
  checkCustomerPermission = () => {
    return server({
      url: '/saas-tms-trans/yzgApp/crm/checkCustomerPermission',
      data: {},
    }).then(({ data }: { data: boolean }) => {
      this.isCustomerPermission = data;
    });
  };

  // 查询PC端运单设置已勾选客户名称必须从下拉选
  @action
  getCustomerAddHide = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/user/config/queryConfigHide',
          data: {},
        },
        { showLoading: false }
      );
      if (res.success) {
        console.log(res.data?.customerHide, '---customeAddHide111---');
        this.customeAddHide = res.data?.customerHide;
      }
    } catch (error) {
      MBLog.log({
        message: '查询PC端运单设置已勾选客户名称必须从下拉选数据失败',
        error: error,
      });
    }
  };
}

export default CustomerStore;
