import { computed, observable, action } from 'mobx';
import { MBToast } from '@ymm/rn-lib';
import BaseStore from '~/extends/BaseStore';
import { pattern } from '~/extends/verification';
import { MapType, AddressModel, ContactType } from '../proptypes';
import RegTest from '~/utils/RegTest';
import server from '~/server/index';

export interface RuleType {
  name: string;
  required: boolean;
  isError: boolean;
  message: string;
  validator?: () => { success: boolean; message?: string };
}

interface CustomerAddModuleData {
  selectPlaceholder: string;
  inputPlaceholder: string;
}
interface CustomerAddStateData {
  customerName: string;
  contactName: string | null;
  contactPhone: string | null;
  loadMode: number | null; // 提货方式
  settleType: number | null;
  isBilling: number | null;
  operatorId: number | null;
  operatorName: string | null;
  openUpChannels: number | null;
  insuranceRate: string | null;
  remark: string | null;
}
interface operatorProps {
  id: number;
  name: string;
}

class CustomerAddStore extends BaseStore<CustomerAddModuleData, CustomerAddStateData> {
  constructor(props: any) {
    super(props);
    this.init();
    this.setRules();
    this.getOperatorList();
  }

  init = () => {
    this.saveStateData({
      customerName: '',
      contactName: '',
      contactPhone: '',
      loadMode: null, // 提货方式
      settleType: null,
      isBilling: null,
      operatorId: null,
      operatorName: null,
      openUpChannels: null,
      insuranceRate: null,
      remark: '',
    });
    this.saveModuleData({
      selectPlaceholder: '请选择',
      inputPlaceholder: '请输入',
    });
  };

  @observable rules: RuleType[] = [];
  @observable operatorList: operatorProps[] = [];
  @observable settleTypeModalVisible: boolean = false;
  @observable pickupTypeModalVisible: boolean = false;
  @observable isInvoiceModalVisible: boolean = false;
  @observable openUpChannelsModalVisible: boolean = false;
  @observable salesmanModalVisible: boolean = false;

  // 获取业务员
  @action
  getOperatorList = async () => {
    const url = '/saas-permission-app/yzgApp/permission/buttOperator';
    const res = await server({ url, data: {} });

    if (res.success) {
      this.operatorList = res.data;
    }
  };

  // 结算方式
  @action
  changeSettleTypeModalVisible = () => {
    const visible = this.settleTypeModalVisible;
    this.settleTypeModalVisible = !visible;
  };

  // 提货方式
  @action
  changePickupTypeModalVisible = () => {
    const visible = this.pickupTypeModalVisible;
    this.pickupTypeModalVisible = !visible;
  };

  // 是否开票
  @action
  changeIsInvoiceModalVisible = () => {
    const visible = this.isInvoiceModalVisible;
    this.isInvoiceModalVisible = !visible;
  };

  // 业务员
  @action
  changeSalesmanModalVisible = () => {
    const visible = this.salesmanModalVisible;
    this.salesmanModalVisible = !visible;
  };

  @action
  changeOpenUpChannelsModalVisible = () => {
    const visible = this.openUpChannelsModalVisible;
    this.openUpChannelsModalVisible = !visible;
  };

  @action setCustomerName = (value: string): void => {
    if (RegTest.emoji(value)) return;
    this.stateData.customerName = value;
  };

  @action setContactName = (value: string): void => {
    if (RegTest.emoji(value)) return;
    this.stateData.contactName = value;
  };

  @action setContactPhone = (value: string): void => {
    if (RegTest.emoji(value)) return;
    this.stateData.contactPhone = value;
  };

  @action setInsuranceRate = (value: string): void => {
    if (!RegTest.zeroHundredFivePrecision(value) && value) return;
    if (RegTest.emoji(value)) return;
    this.stateData.insuranceRate = value;
  };

  @action setRemark = (value: string): void => {
    if (RegTest.emoji(value)) return;
    this.stateData.remark = value;
  };

  @action
  onConfirmIsInvoiceModal = (type: number) => {
    this.stateData.isBilling = type;
    this.changeIsInvoiceModalVisible();
  };

  @action
  onConfirmSalesmanModal = (salesmanItem: operatorProps) => {
    const { id, name } = salesmanItem;
    this.stateData.operatorId = id;
    this.stateData.operatorName = name;
    this.changeSalesmanModalVisible();
  };

  @action
  onConfirmOpenUpChannelsModal = (value: number) => {
    this.stateData.openUpChannels = value;
    this.changeOpenUpChannelsModalVisible();
  };

  @action
  onConfirmSettleTypeModal = (type: number) => {
    this.stateData.settleType = type;
    this.changeSettleTypeModalVisible();
  };

  @action
  onConfirmPickupTypeModal = (type: number) => {
    this.stateData.loadMode = type;
    this.changePickupTypeModalVisible();
  };

  @action cleanErrorByIndex = (index: number) => {
    this.rules[index].isError = false;
  };

  @action reset = () => {
    this.saveStateData({
      customerName: '',
      contactName: '',
      contactPhone: '',
      loadMode: null,
      settleType: null,
      isBilling: null,
      operatorId: null,
      operatorName: null,
      openUpChannels: null,
      insuranceRate: '',
      remark: '',
    });

    this.rules = this.rules.map((rule) => {
      rule.isError = false;
      return rule;
    });
  };

  @action setRules = () => {
    this.rules = [
      {
        name: 'customerName',
        required: true,
        message: '客户名称为空',
        isError: false,
      },
    ];
  };
  /**
   * 校验
   * @returns boolean
   */
  @action validate = (): boolean => {
    let bool = true;
    const _this = this;

    const _rules = _this.rules.map((_rule) => {
      const rule = { ..._rule };
      if (rule.required) {
        if (rule.validator) {
          // 如果有自身验证方法，就优先调用
          const result = rule.validator.call(_this);
          bool = result.success;
          if (!bool) {
            rule.message = result.message || '';
          }
        } else if (rule.name) {
          bool = !!_this.stateData[rule.name];
        }
        rule.isError = !bool;
      }
      return rule;
    });
    this.rules = _rules;
    return this.rules.every((rule) => rule.isError === false);
  };
}

export default CustomerAddStore;
