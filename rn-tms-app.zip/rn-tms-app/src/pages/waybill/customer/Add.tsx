import React from 'react';
import { SafeAreaView, View, StyleSheet, BackHandler, NativeEventSubscription, Platform, KeyboardAvoidingView } from 'react-native';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import AddContent from './components/AddContent';
import AddFooter from './components/AddFooter';
import server from '~/server/index';
import CustomerAddStore from './Store/CustomerAdd';
import { MBLog } from '@ymm/rn-lib';
interface CustomerAddProps {
  customerAddStore: CustomerAddStore;
  navigation: any;
  screenProps: any;
}
@inject('customerAddStore')
@observer
export default class CustomerAddIndex extends React.Component<CustomerAddProps, any> {
  backHandler?: NativeEventSubscription;
  state = {
    showFooterBtn: true,
  };
  timerBtn: any = null;
  constructor(props: CustomerAddProps) {
    super(props);
  }

  componentWillMount(): void {
    if (Platform.OS === 'android') {
      this.backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        this.onBackButtonPressAndroid //处理返回事件函数
      );
    }
  }

  componentWillUnmount(): void {
    this.backHandler?.remove();
  }

  onBackButtonPressAndroid = (): boolean => {
    this.goBack();
    return true;
  };

  runtimeback = (response: any): void => {
    const {
      navigation,
      customerAddStore: { stateData },
    } = this.props;

    // 回调
    navigation.state?.params?.onSuccess({
      customerName: stateData.customerName,
      customerId: response.data,
    });
    this.goBack();
  };

  // 创建新客户
  onSubmit = (): void => {
    const {
      customerAddStore: { stateData, validate },
    } = this.props;
    const { customerName, ...restData } = stateData;
    const params = { ...restData, custName: customerName };

    // 调保存并使用接口
    if (validate()) {
      const url = '/saas-tms-trans/yzgApp/crm/addCustomer';
      // 提交接口
      server({
        url,
        data: params,
      })
        .then(this.runtimeback)
        .catch((er) => {
          MBLog.log('新增客户失败');
        });
    }
  };

  goBack = (): void => {
    const { navigation, customerAddStore } = this.props;
    customerAddStore.reset();
    navigation?.goBack();
  };

  // 底部按钮 不能被键盘顶起
  onCommonBlurFocus = (val: boolean) => {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ showFooterBtn: val });
    }, 10);
  };

  renderContent = () => {
    const { customerAddStore } = this.props;
    const { showFooterBtn } = this.state;
    return (
      <View style={styles.container}>
        <NavBar key="addcustomer" title="新增客户" leftClick={this.goBack} />
        <SafeAreaView style={styles.flexStyle}>
          <View style={styles.flexStyle}>
            <AddContent
              customerAddStore={customerAddStore}
              onCommonFocus={() => this.onCommonBlurFocus(false)}
              onCommonBlur={() => this.onCommonBlurFocus(true)}
            />
          </View>
          {showFooterBtn ? <AddFooter onPress={this.onSubmit} /> : null}
        </SafeAreaView>
      </View>
    );
  };

  render(): JSX.Element {
    if (Platform.OS == 'ios') {
      return (
        <KeyboardAvoidingView behavior="padding" style={[styles.container]}>
          {this.renderContent()}
        </KeyboardAvoidingView>
      );
    } else {
      return this.renderContent();
    }
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },
});
