/* eslint-disable max-lines */
import { observable, action, computed } from 'mobx';
import { Platform } from 'react-native';
import RegTest from '~/utils/RegTest';
import { xyzMath } from '~/utils/xyzMath';
import BaseStore from '~/extends/BaseStore';
import dayjs from 'dayjs';
import server from '~/server';
import { Modal } from '@ymm/rn-elements';
import { MBToast, MBLog, MBBridge, MBJournal } from '@ymm/rn-lib';
import Bridge from '~/extends/NativeBridge';

const Confirm = Modal.Confirm;

export interface FeeInfo {
  feeCode: number;
  feeCodeDesc: string;
  amount: string | number | null;
  isDeductionFee: boolean;
  isRequired: boolean;
}

export interface AllFeeListType {
  feeCode: number;
  feeDesc: string;
}
export interface OrganizeListType {
  orgId: string;
  orgName: string;
  status?: number;
}

interface WaybillCreateModuleData {
  selectPlaceholder: string;
  inputPlaceholder: string;
}
interface WaybillCreateStateData {
  orgId: number | null;
  orgName: string | null;
  feeList: FeeInfo[];
  settleType: number | null;
  loadMode: number | null;
  taskType: string | null;
  receiptCount: string | null;
  setRegular: boolean;
  pointBillingTime: number;
  priceSnapshot: any;
  freightFeePriceType: number; // 0无, 1为分摊图标，2合并计费图标
  loadFeePriceType: number; // 0无, 1为分摊图标，2合并计费图标
  pickupFeePriceType: number; // 0无, 1为分摊图标，2合并计费图标
  deliFeePriceType: number; // 0无, 1为分摊图标，2合并计费图标
  modifyMonitor: boolean; // 是否修改了 可以触发价格调用的字段
  ext: any; // 自定义字段，发货车型车长
  dispatcherMode: any; // 调度方式
  transType: string | null; // 运输方式
}

export interface RuleType {
  name: string;
  required: boolean;
  isError: boolean;
  message: string;
  validator?: () => { success: boolean; message?: string };
}

class WaybillCreateStore extends BaseStore<WaybillCreateModuleData, WaybillCreateStateData> {
  constructor(props: any) {
    super(props);
    this.init();
    this.getAppInfo();
  }

  init = () => {
    this.saveStateData({
      orgId: null, // 组织
      orgName: null, // 组织
      settleType: 4, // 结算方式  1：现付 2：到付 3：回付 4：月结 5： 油卡
      loadMode: 2, // 提货方式  1：小车上门提货 2：大车直送客户
      taskType: null, // 提货类型
      receiptCount: null, // 回单数量
      setRegular: false, // 是否存为常发运单
      pointBillingTime: dayjs().valueOf(), // 开单时间
      // 应收费用列表
      feeList: [],
      priceSnapshot: {},
      freightFeePriceType: 0,
      loadFeePriceType: 0,
      pickupFeePriceType: 0,
      deliFeePriceType: 0,
      modifyMonitor: false, // 是否修改了 可以触发价格调用的字段
      ext: {},
      dispatcherMode: null,
      transType: null,
    });
    this.saveModuleData({
      selectPlaceholder: '请选择',
      inputPlaceholder: '请输入',
    });
  };

  // 页面请求loading
  @observable isLoading: boolean = true;
  @observable settleTypeModalVisible: boolean = false; // 结算方式弹窗
  @observable pickupTypeModalVisible: boolean = false; // 提货方式弹窗
  @observable organizeModalVisible: boolean = false; // 组织弹窗
  @observable transTypeVisible: boolean = false; // 运输方式弹窗
  @observable createWaybillId: number | null = null; // 调度失败但创建运单成功的运单ID
  @observable transOrderNo: number | null = null; // 调度失败但创建运单成功的运单号
  @observable supplyModalVisible: boolean = false;
  @observable firstSupply: boolean = false;
  @observable showPermissionVisible: boolean = false;
  @observable supllyGuideData = {};
  @observable appSupplementErrorData = {};
  // app来源
  @observable isFromTms: boolean = true;
  // 修改运单
  /**
   * 编辑条件枚举：
   * ONE-运单提货状态=无需调度&运单任务状态=待任务调度&财务上游未生成对账单且未结算or无需对账且无需结算
   * TWO-运单提货状态=无需调度&运单任务状态=待任务调度&财务上游已生成对账单或已结算
   * THREE-已生成任务单或提货单&未生成客户对账单未核销客户运单
   * FOUR-已生成任务单或提货单&财务上游已生成对账单或已结算（包含部分对账或部分结算）
   */
  @observable editEnum: string = '';
  // 是否不能查看应收权限
  @observable editNotReceivable: boolean = false;
  // 运单详情id
  @observable waybillDetailId: string = '';
  // 组织列表
  @observable organizeList: OrganizeListType[] = [];
  // 组织是否可编辑
  @observable enableEditOrg: boolean = true;
  // 补录运单详情id
  @observable supplementWaybillId: string = '';
  // 客户名称存在且下拉框选择
  @observable checkCustomeNamePass: boolean = true;
  // 当前是否在补录运单下
  @observable isFromSupplyWaybill: boolean = false;
  // 价格快照
  @observable priceSnapshot = {};
  // 保险费率
  @observable insuranceRate = null;
  // 敏感词汇集合
  @observable sensitiveWordList: any = [];
  // 所属行业
  @observable industryData: any = {
    industryFlag: false,
    industryExtendCode: '',
    industryOptions: [],
  };
  @observable requiredConfig: any = {};
  @observable switchConfigs: any = {}; // 开关配置
  @observable provinceCityAreaSelect: boolean = false; // 开启省市区地址选择

  @observable carTypeLengthData: any = {}; // 发货车型车长
  @observable carTypeLengthVisible: boolean = false; // 发货车型车长弹窗显示
  @observable carTypeCode: string = ''; // 发货车型code
  @observable carLengthCode: string = ''; // 发货车长code
  @observable transTypeNecessarily: boolean = false; // transTypeNecessarily 运输方式是否必填 true/false
  @observable showWarnTips: boolean = false; // 显示校验失败的提示

  @action setFromSupplyWaybill(val: any) {
    this.isFromSupplyWaybill = val;
  }

  @computed get getTotalFeeInfo() {
    const { feeList } = this.stateData;
    const {
      moreInfoStore: {
        stateData: { taxWay },
      },
    } = this.pageStore;
    // 筛选有值的费用
    const detailFeeList = feeList.filter((item: any) => item.amount);
    // 应收合计费用
    let totalFee = null;
    if (!this.editNotReceivable) {
      const firstComputedValue = this.computedSumFee(feeList);
      // 应收合计不含税
      if (taxWay === 2) {
        totalFee = xyzMath.add(firstComputedValue, this.updateTax);
      } else {
        // 应收合计含税, 不选择计税方式 = 应收合计含税
        totalFee = firstComputedValue;
      }
    }

    return {
      totalFee,
      detailFeeList,
    };
  }

  // 根据已确定的税率计算税金
  @computed get updateTax() {
    const { feeList } = this.stateData;
    const {
      moreInfoStore: {
        stateData: { billingRate, taxWay },
      },
    } = this.pageStore;

    // 合计费用；脱敏时, 相关费用传null
    const totalFee = this.computedSumFee(feeList);

    // 当合计费用计算结果<=0时，税金修改为0元
    if (totalFee !== null && totalFee <= 0) {
      return 0;
    }

    // 税金 = 合计费用 * 税率, 费用脱敏*时税金为null
    let multiplyTax = null;
    // 税率值除以100
    const divideBillingRate = billingRate ? xyzMath.divide(billingRate, 100) : null;
    if (!this.editNotReceivable && totalFee) {
      // 应收合计含税
      if (taxWay === 1) {
        // 1＋适用税率
        const firstComputedValue = xyzMath.add(1, divideBillingRate);
        //  应付合计含税价÷（1＋适用税率）
        const secondComputedValue = divideBillingRate ? xyzMath.divide(totalFee, firstComputedValue) : null;
        // 税额 = 应付合计含税价÷（1＋适用税率）*税率
        multiplyTax = secondComputedValue ? xyzMath.multiply(secondComputedValue, divideBillingRate) : null;
      }

      // 应收合计不含税
      if (taxWay === 2) {
        multiplyTax = divideBillingRate ? xyzMath.multiply(totalFee, divideBillingRate) : null;
      }
    }
    // 税金去掉小数点后多余的0
    const handletax = multiplyTax ? multiplyTax.toFixed(2).replace(/[.]?0+$/, '') : null;
    return handletax;
  }

  // 费用求和
  @action
  computedSumFee = (data: FeeInfo[]) => {
    // 筛选有值的费用
    const hasFeeValueList = data.filter((item: any) => item.amount);
    // 合计费用；脱敏时, 相关费用传null
    let sumFee = null;
    if (!this.editNotReceivable) {
      sumFee = hasFeeValueList.reduce((total, item) => {
        if (item.isDeductionFee) {
          return xyzMath.subtract(total, item.amount);
        }
        return xyzMath.add(total, item.amount);
      }, 0);
    }
    return sumFee;
  };

  // app来源
  @action
  getAppInfo = async () => {
    const {
      data: { appId },
    } = await MBBridge.app.base.appInfo({});

    this.isFromTms = appId === 'com.tms.merchant' || appId === 'com.tms8.merchant';
  };

  @action
  onModalSupplyOpen = () => {
    this.supplyModalVisible = true;
  };

  @action
  onModalSupplyConfirm = () => {
    if (this.firstSupply) {
      this.confirmInserGuidePopRecord();
    }

    this.supplyModalVisible = false;
  };

  @action
  onModalSupplyCancel = () => {
    this.supplyModalVisible = false;
  };

  // 整理运单各项参数
  @action
  handleParams = () => {
    const { totalFee } = this.getTotalFeeInfo;
    // 创建运单首页信息
    const { feeList, ...restWaybillCreateData } = this.stateData;
    const handleFeeList = feeList.map((item) => {
      let amount = null;
      // 费用脱敏*时为null
      if (!this.editNotReceivable) {
        amount = item.amount ? xyzMath.multiply(item.amount, 100) : null;
      }

      return {
        feeCode: item.feeCode,
        amount,
      };
    });

    const handleWaybillCreateData = { ...restWaybillCreateData, ...{ feeList: handleFeeList } };
    // 地址信息
    const { contactList, ...restDeliveryAddressData } = this.pageStore.stores.deliveryAddressStore.getStateData();
    const handleContactList = contactList.map((item: any) => {
      const { contactType, address, provinceName, cityName, areaName } = item;
      if (contactType === 2 && !address) {
        item.address = provinceName + cityName + areaName;
      }
      return item;
    });
    const handleDeliveryAddressData = { ...restDeliveryAddressData, ...{ contactList: handleContactList } };
    // 货物信息
    const { stockValue, ...restGoodsInfo } = this.pageStore.stores.goodsInfoStore.getStateData();
    // 申明价值 单位：元换算为分
    const handleStockValue = stockValue ? xyzMath.multiply(stockValue, 100) : null;
    const handleGoodsInfoData = { ...restGoodsInfo, ...{ stockValue: handleStockValue } };
    // 更多信息
    const { costMileage, billingRate, isBilling, tmsDispatcherPhone, ...restMoreInfo } = this.pageStore.stores.moreInfoStore.getStateData();
    // 线路里程 单位：公里换算为米
    const handleCostMileage = costMileage ? xyzMath.multiply(costMileage, 1000) : null;
    // 处理最新的税金 单位：元换算为分
    let handleTax = this.updateTax ? xyzMath.multiply(this.updateTax, 100) : null;
    // 税率除以100, 费用脱敏*时为null,税率number类型转为string，防止ios手机传参京都缺失
    let handleBillingRate = null;
    if (!this.editNotReceivable) {
      handleBillingRate = billingRate ? xyzMath.divide(billingRate, 100) + '' : null;
    }

    // 开票选择否，税金，税金都传null
    if (!isBilling) {
      handleTax = null;
      handleBillingRate = null;
    }

    const handleMoreInfoData = {
      ...restMoreInfo,
      ...{ costMileage: handleCostMileage, isBilling, tax: handleTax, billingRate: handleBillingRate },
    };

    // 总费用 单位：元换算为分
    const handleTotalFee = totalFee ? xyzMath.multiply(totalFee, 100) : null;

    return {
      ...handleWaybillCreateData,
      ...handleDeliveryAddressData,
      ...handleGoodsInfoData,
      ...handleMoreInfoData,
      totalFee: handleTotalFee,
    };
  };

  @action validatePackageUnit = (list: any, isRequired: boolean): boolean => {
    const item = list.find((item: any) => {
      return isRequired && !item.packageUnit;
    });

    if (!item) return true;

    if (!item?.packageUnit) {
      MBToast.show('请选择包装方式');
      return false;
    }
    return true;
  };

  @action validatePackageQuantity = (list: any, isRequired: boolean): boolean => {
    const item = list.find((item: any) => {
      return isRequired && !item.packageQuantity;
    });

    if (!item) return true;

    if (!item?.packageQuantity) {
      MBToast.show('请输入件数');
      return false;
    }
    return true;
  };

  /**
   * @param type 1：仅创建，2：创建并指派, 3：确认生成, 4：修改运单
   */
  @action
  onSubmit = async (type: number) => {
    const deliveryAddressRule = this.pageStore.stores.deliveryAddressStore.validateRule();
    const { orgId, orgName } = this.stateData;
    const { customerName } = this.pageStore.stores.deliveryAddressStore.getStateData();
    const {
      consignerCompanyNameIsRequired,
      consignerContactIsRequired,
      consignerPhoneIsRequired,
      deliveryTimeIsRequired,
      consigneeCompanyNameIsRequired,
      consigneeContactIsRequired,
      consigneePhoneIsRequired,
      arriveTimeIsRequired,
      unitIsRequired,
      quantityIsRequired,
      customerOrderNoIsRequired,
      salesmanIdIsRequired,
      tmsDispatcherIdIsRequired,
      remarkIsRequired,
    } = this.requiredConfig;

    // 组织数大于1时，组织校验必填项
    if (this.organizeList.length > 1 && !orgId && !orgName) {
      MBToast.show('请选择运单所属组织');
      return;
    }

    // 客户名称、装卸货地址校验必填项
    if (!deliveryAddressRule.success) {
      MBToast.show(deliveryAddressRule.message || '');
      return;
    }

    // 货物信息校验
    if (!this.pageStore.goodsInfoStore.goodsValidateAndTip()) {
      return;
    }

    // 应收费用校验必填项
    if (!this.feeReceiveValidate()) {
      MBToast.show('应收费用必填项未填写');
      return;
    }

    // 客户名称存在且下拉框选择校验
    await this.getCheckCustomeName({ customerName });
    if (!this.checkCustomeNamePass) {
      MBToast.show('客户名称在客户主数据中不存在，请重新选择');
      return;
    }

    // 整理运单各项参数
    const params = this.handleParams();

    const { contactList, tmsDispatcherId, operatorName, customerOrderNo, remark, cargoList, ext, transType } = params;
    const carTypeCode = this.carTypeCode;
    const carLengthCode = this.carLengthCode;
    const carTypeCodeRequired = !!carTypeCode && !!ext && !ext[carTypeCode]?.length;
    const carLengthCodeRequired = !!carLengthCode && !!ext && !ext[carLengthCode]?.length;

    // 发货车型车长校验
    if (carTypeCodeRequired || carLengthCodeRequired) {
      return MBToast.show('请选择发货车型车长');
    }

    // 运输方式校验
    if (!!this.transTypeNecessarily && !transType) {
      this.showWarnTips = true;
      return MBToast.show('请选择运输方式');
    }

    // 包装校验
    if (!this.validatePackageUnit(cargoList, !!unitIsRequired)) {
      return;
    }

    // 件数校验
    if (!this.validatePackageQuantity(cargoList, !!quantityIsRequired)) {
      return;
    }

    if (consignerCompanyNameIsRequired && !contactList[0]?.companyName) {
      return MBToast.show('请输入发货单位');
    }

    if (consignerContactIsRequired && !contactList[0]?.contactName) {
      return MBToast.show('请输入发货人姓名');
    }

    if (consignerPhoneIsRequired && !contactList[0]?.contactPhone) {
      return MBToast.show('请输入联系电话');
    }

    if (deliveryTimeIsRequired && !contactList[0]?.handlingTime) {
      return MBToast.show('请选择预计装货时间');
    }

    if (consigneeCompanyNameIsRequired && !contactList[1]?.companyName) {
      return MBToast.show('请输入卸货单位');
    }

    if (consigneeContactIsRequired && !contactList[1]?.contactName) {
      return MBToast.show('请输入卸货人姓名');
    }

    if (consigneePhoneIsRequired && !contactList[1]?.contactPhone) {
      return MBToast.show('请输入联系电话');
    }

    if (arriveTimeIsRequired && !contactList[1]?.handlingTime) {
      return MBToast.show('请选择预计卸货时间');
    }

    if (customerOrderNoIsRequired && !customerOrderNo) {
      return MBToast.show('请输入客户单号');
    }

    if (salesmanIdIsRequired && !operatorName) {
      return MBToast.show('请选择业务员');
    }

    if (tmsDispatcherIdIsRequired && !tmsDispatcherId) {
      return MBToast.show('请选择调度员');
    }

    if (remarkIsRequired && !remark) {
      return MBToast.show('请输入备注信息');
    }

    const updateParams = { ...params, ...{ id: this.createWaybillId, transOrderNo: this.transOrderNo } };

    MBBridge.ui.showLoading({});

    // 1：仅创建
    if (type === 1) {
      if (this.createWaybillId && this.transOrderNo) {
        this.onWaybillCreateUpdate(2, updateParams);
      } else {
        this.onWaybillCreateUpdate(1, params);
      }
    }

    // 2：创建并指派
    if (type === 2) {
      // 调度失败但创建运单成功的运单ID，为再次调度时更新运单信息，防止再次创建运单
      const url = `ymm://rn.tms/dispatch?form=${encodeURIComponent(JSON.stringify(updateParams))}&source=createdispatch`;
      MBBridge.ui.hideLoading({});
      MBBridge.app.base.openSchemeForResult({ schemeUrl: url }).then((res: any) => {
        if (res.data) {
          let data = null;
          try {
            data = JSON.parse(res.data);
          } catch (error) {
            data = res.data;
          }
          this.createWaybillId = data?.id || null;
          this.transOrderNo = data?.transOrderNo || null;
          if (data.refresh) {
            this.pageStore.deliveryAddressStore.saveStateData({
              ...this.pageStore.deliveryAddressStore.stateData,
              customerId: '',
              customerName: '',
            });
          }
          if (data.getCreateOrganizeFail) {
            // 用户选择的组织无权限或者停用时，重新获取组织数据
            this.getCreateOrganize();
          }
        }
      });
    }

    // 3：确认生成
    if (type === 3) {
      this.onSupplyWaybillCreate(params);
    }

    // 4：修改运单
    if (type === 4) {
      this.onWaybillEdit(params);
    }
  };

  // 获取用户地址、增加按钮等开关配置
  @action
  getUserCreateOrderConfigs = () => {
    server({
      url: '/saas-tms-trans/yzgApp/order/init/page',
      data: {
        pageCode: 'CREATE_ORDER_SETTING',
      },
    })
      .then((response) => {
        if (response.success) {
          this.switchConfigs = response.data;
          const { loadUnloadAdministrativeDivisionOpen } = response.data;
          this.provinceCityAreaSelect = !!loadUnloadAdministrativeDivisionOpen;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '查询用户开关配置失败',
          error: er,
        });
      });
  };

  // 获取生成新手指引
  @action
  getSupllyGuide = () => {
    server({
      url: '/saas-tms-trans/yzgApp/supplement/supllyGuide',
      data: {},
    })
      .then((response) => {
        if (response.success) {
          this.supllyGuideData = response.data;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取新手指引数据失败',
          error: er,
        });
      });
  };

  // 关闭新手指引
  @action
  confirmInserGuidePopRecord = () => {
    server(
      {
        url: '/saas-tms-trans/yzgApp/supplement/inserGuidePopRecord',
        data: {},
      },
      { showLoading: false }
    )
      .then((response) => {
        if (response.success) {
          MBLog.log({
            message: '新手指引-我知道了',
          });
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '关闭新手指引失败',
          error: er,
        });
      });
  };

  /**
   * 创建/更新运单接口
   * @param type 1：创建；2:更新
   * @param params
   */
  @action
  onWaybillCreateUpdate = (type: number, params: any) => {
    let url = '/saas-tms-trans/yzgApp/order/create';
    if (type === 2) {
      url = '/saas-tms-trans/yzgApp/order/update';
    }
    server(
      {
        url,
        data: params,
      },
      { showLoading: false }
    )
      .then((response) => {
        const schemeUrl = `ymm://rn.tms/waybilldetail?id=${response?.data?.id}&source=create`;
        MBBridge.app.page.closeAndJump({
          url: schemeUrl,
        });
        // 运单创建成功记录埋点
        if (type === 1) {
          this.trackCreateSuccess(response?.data?.id);
        }
      })
      .catch((er) => {
        if (er.code === '4700001') {
          // 用户选择的组织无权限或者停用时，重新获取组织数据
          this.getCreateOrganize();
        }
        if (er.code === '900001') {
          this.pageStore.deliveryAddressStore.saveStateData({
            ...this.pageStore.deliveryAddressStore.stateData,
            customerId: '',
            customerName: '',
          });
        }

        MBLog.log({
          message: type === 1 ? '运单创建失败' : '运单更新失败',
          error: er,
        });
      })
      .finally(() => {
        MBBridge.ui.hideLoading({});
      });
  };

  /**
   * 修改运单接口
   */
  @action
  onWaybillEdit = (params: any) => {
    server({
      url: '/saas-tms-trans/yzgApp/order/update',
      data: params,
    })
      .then((response) => {
        if (response.success) {
          MBToast.show('修改运单成功');
          MBBridge.rnruntime.handlebackResult({});
          if (Platform.OS == 'ios') {
            setTimeout(() => {
              MBBridge.app.ui.closeWindow({});
            }, 300);
          }
        }
      })
      .catch((er) => {
        if (er.code === '50018' || er.code === '60021') {
          // 运单更新失败刷新页面数据
          this.getEditWaybillDetail(this.waybillDetailId);
        }

        if (er.code === '4700001') {
          // 运单更新失败，重新获取默认组织，组织权限状态
          this.updateEditEnableEditOrg(this.waybillDetailId);
          // 用户选择的组织无权限或者停用时，重新获取组织数据
          this.getEditOrganize(this.waybillDetailId);
        }
        if (er.code === '900001') {
          this.pageStore.deliveryAddressStore.saveStateData({
            ...this.pageStore.deliveryAddressStore.stateData,
            customerId: '',
            customerName: '',
          });
        }

        MBLog.log({
          message: '运单更新失败',
          error: er,
        });
      })
      .finally(() => {
        MBBridge.ui.hideLoading({});
      });
  };

  // 确定生成(补录)
  @action
  onSupplyWaybillCreate = (params: any) => {
    server({
      url: '/saas-tms-trans/yzgApp/supplement/create',
      data: params,
    })
      .then((response) => {
        if (response.success) {
          MBToast.show('生成运单成功');
          const schemeUrl = `ymm://rn.tms/waybilldetail?id=${response?.data}&source=supplywaybill`;
          MBBridge.app.page.closeAndJump({ url: schemeUrl });
        }
      })
      .catch((er) => {
        if (er.code === '4700001') {
          // 补录运单失败，重新获取组织数据
          this.getSupplementOrganize(this.supplementWaybillId);
          // 补录运单失败，重新获取默认组织，组织权限状态
          this.updateSupplementEnableEditOrg(this.supplementWaybillId);
        }
        if (er.code === '900001') {
          this.pageStore.deliveryAddressStore.saveStateData({
            ...this.pageStore.deliveryAddressStore.stateData,
            customerId: '',
            customerName: '',
          });
        }

        MBLog.log({
          message: '创建生成失败',
          error: er,
        });
      })
      .finally(() => {
        MBBridge.ui.hideLoading({});
      });
  };

  // 鉴权
  @action
  getAuthentication = (params: any) => {
    this.isLoading = true;
    server({
      url: '/saas-tms-trans/yzgApp/tenant/config/authentication',
      data: params,
    })
      .then((res) => {
        if (res.success) {
          this.appSupplementErrorData = res.data;
          this.showPermissionVisible = !res.data?.hasPermission;
        }
        // 系统鉴权，单独处理
        if (res.code === '710012' || res.code === '710013') {
          this.appSupplementErrorData = {
            image: 'https://image.ymm56.com/ymmfile/saas-tms-pub/detail.png',
            msg: res.msg,
          };
          this.showPermissionVisible = true;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取鉴权失败',
          error: er,
        });
      })
      .finally(() => {
        this.isLoading = false;
      });
  };

  // 运单创建成功记录埋点
  @action
  trackCreateSuccess = (id: number) => {
    MBJournal.tapJournal({
      elementId: 'create_success_waybill',
      pageName: 'waybill_create_edit',
      referPageName: '',
      extraDict: {
        waybill_id: id,
      },
    });
  };

  // 记录PV埋点
  @action
  trackPageView = () => {
    MBJournal.pageViewJournal({
      pageName: 'waybill_supply_edit',
      referPageName: '',
      extraDict: {},
    });
  };

  // 点击返回，二次弹窗是否保存草稿
  @action
  onConfirmSaveDraft = () => {
    const { totalFee } = this.getTotalFeeInfo;
    const carTypeCode = this.carTypeCode;
    const carLengthCode = this.carLengthCode;
    // 总费用 单位：元换算为分
    const handleTotalFee = totalFee ? xyzMath.multiply(totalFee, 100) : null;
    const params: any = {
      ...this.pageStore.stores.waybillCreateStore.getStateData(),
      ...this.pageStore.stores.deliveryAddressStore.getStateData(),
      ...this.pageStore.stores.goodsInfoStore.getStateData(),
      ...this.pageStore.stores.moreInfoStore.getStateData(),
      totalFee: handleTotalFee,
    };
    const { feeList, contactList, cargoList, receiptCount, customerId, stockValue, costMileage, operatorId, isBilling, remark, ext } =
      params;
    const hasValueFeeList = feeList.filter((item: any) => item.amount);
    const carTypeCodeHasValue = !!carLengthCode && !!ext && !!ext[carTypeCode]?.length;
    const carLengthCodeHasValue = !!carLengthCode && !!ext && !!ext[carLengthCode]?.length;
    // 如果没有填写任何一项，点击直接返回不需要提醒保存草稿
    if (
      !hasValueFeeList.length &&
      !contactList[0].contactName &&
      !contactList[0].address &&
      !contactList[1].contactName &&
      !contactList[1].address &&
      !contactList[0].handlingTime?.endTimestamp &&
      !contactList[1].handlingTime?.endTimestamp &&
      cargoList.length === 1 &&
      !cargoList[0].cargoName &&
      !cargoList[0].weight &&
      !cargoList[0].volume &&
      !cargoList[0].packageUnit &&
      !cargoList[0].packageQuantity &&
      !cargoList[0].remark &&
      !receiptCount &&
      !customerId &&
      !stockValue &&
      !costMileage &&
      !operatorId &&
      !isBilling &&
      !remark &&
      !carTypeCodeHasValue &&
      !carLengthCodeHasValue
    ) {
      this.onNotSaveDraft();
    } else {
      Confirm({
        closable: true,
        headerLine: false,
        title: '保存为草稿？',
        content: '保存草稿后可继续填写运单信息',
        cancelText: '不保存退出',
        confirmText: '存为草稿',
        onCancel: () => {
          this.onNotSaveDraft();
        },
        onConfirm: () => {
          this.onSaveDraft(params);
        },
      });
    }
  };

  // 保存草稿
  @action
  onSaveDraft = (params: any) => {
    // 保存草稿接口
    const url = '/saas-tms-trans/yzgApp/order/saveDraft';

    server({
      url,
      data: params,
    })
      .then((response) => {
        MBBridge.app.ui.closeWindow({});
      })
      .catch((er) => {
        MBLog.log({
          message: '保存草稿失败',
          error: er,
        });
      });
  };

  // 不保存草稿
  @action
  onNotSaveDraft = () => {
    const url = '/saas-tms-trans/yzgApp/order/notSaveDraft';
    server(
      {
        url,
        data: {},
      },
      { showLoading: false }
    )
      .then((response) => {
        MBBridge.app.ui.closeWindow({});
      })
      .catch((er) => {
        MBBridge.app.ui.closeWindow({});
        MBLog.log({
          message: '不保存草稿失败',
          error: er,
        });
      });
  };

  // 获取草稿
  @action
  getLoadDraft = () => {
    const url = '/saas-tms-trans/yzgApp/order/loadDraft';
    this.isLoading = true;
    server({
      url,
      data: {},
    })
      .then((response) => {
        if (response.success) {
          const {
            orgId,
            orgName,
            customerId,
            customerName,
            contactList,
            feeList,
            settleType,
            loadMode,
            receiptCount,
            setRegular,
            stockValue,
            cargoList,
            billingTime,
            ext,
            ...restProps
          } = response.data.draftData;

          // 处理应收费用
          const handleFeeList = this.handleAllFeeList(feeList);

          // 创建运单首页
          this.pageStore.waybillCreateStore.saveStateData({
            feeList: handleFeeList,
            settleType: settleType ? settleType : 4,
            loadMode: loadMode ? loadMode : 2,
            receiptCount,
            setRegular,
            pointBillingTime: dayjs().valueOf(),
            orgId: orgId ? orgId : this.stateData.orgId, // 读取草稿返回的组织，否则默认组织，
            orgName: orgName ? orgName : this.stateData.orgName,
            ext: ext ? ext : this.stateData.ext,
          });

          // 收发货
          if (contactList && contactList.length) {
            this.pageStore.deliveryAddressStore.saveStateData({
              customerId,
              customerName,
              contactList: contactList,
            });
          }

          // 货物信息
          if (cargoList && cargoList.length) {
            this.pageStore.goodsInfoStore.saveStateData({
              stockValue,
              cargoList: cargoList.map((item: any) => {
                item.weight = xyzMath.round(item.weight, this.pageStore.goodsInfoStore.systemInit.orderWeightTonPoint);
                return item;
              }),
            });
          }

          // 更多信息
          this.pageStore.moreInfoStore.saveStateData({ ...restProps });
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取创建运单草稿失败',
          error: er,
        });
      })
      .finally(() => {
        this.isLoading = false;
      });
  };

  // 获取生成（补录）单信息
  @action
  getSupllyWaybillDetail = (id: string) => {
    const url = '/saas-tms-trans/yzgApp/supplement/loadMybOrder';
    this.isLoading = true;
    server({ url, data: { mybOrderId: id } })
      .then((response) => {
        if (response.success) {
          const {
            mybOrderId,
            customerId,
            customerName,
            contactList,
            feeList,
            settleType,
            loadMode,
            receiptCount,
            setRegular,
            stockValue,
            cargoList,
            billingTime,
            firstSupply,
            pointBillingTime,
            ext,
            ...restProps
          } = response.data;

          this.supplyModalVisible = firstSupply;
          this.firstSupply = firstSupply;
          this.showPermissionVisible = false;
          if (!firstSupply) {
            // 如果已经 显示过“什么是生成运单” 提示弹窗，就查询本地记录，再显示一次toost提示“生成运单后，即可随时查看车辆精准北斗定位”
            this.firstTipsToasted();
          }
          // 处理应收费用
          const handleFeeList = this.handleAllFeeList(feeList);

          // 创建运单首页
          this.pageStore.waybillCreateStore.saveStateData({
            feeList: handleFeeList,
            settleType: settleType ? settleType : 4,
            loadMode: loadMode ? loadMode : 2,
            receiptCount,
            setRegular,
            pointBillingTime,
            mybOrderId,
            ext: ext ? ext : this.stateData.ext,
          });

          // 收发货
          if (contactList && contactList.length) {
            this.pageStore.deliveryAddressStore.saveStateData({
              customerId,
              customerName: customerName ? customerName : '',
              contactList: contactList,
            });
          }

          // 货物信息
          if (cargoList && cargoList.length) {
            this.pageStore.goodsInfoStore.saveStateData({
              stockValue: stockValue ? xyzMath.divide(stockValue, 100) : null,
              cargoList: cargoList.map((item: any) => {
                item.weight = xyzMath.round(item.weight, this.pageStore.goodsInfoStore.systemInit.orderWeightTonPoint);
                return item;
              }),
            });
          }

          // 更多信息
          this.pageStore.moreInfoStore.saveStateData({ ...restProps });

          // 更新运费匹配价格
          this.updateFeeMatch(false, false);
        } else if (response.code === '90000') {
          this.appSupplementErrorData = response.data?.appSupplementError;
          this.showPermissionVisible = true;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取生成运单详情失败',
          error: er,
        });
      })
      .finally(() => {
        this.isLoading = false;
      });
  };
  // 每个用户只提示一次该toost。
  async firstTipsToasted() {
    try {
      const res = await Bridge.tmsUserGet('firstToasted');
      if (!res) {
        MBToast.show('生成运单后，即可随时查看车辆精准北斗定位');
        await Bridge.tmsUserSet('firstToasted', true);
      }
      // await Bridge.tmsUserSet('firstToasted', false);
    } catch (error) {}
  }
  // 获取运单详情
  @action
  getEditWaybillDetail = async (id: string) => {
    try {
      this.isLoading = true;
      // 记录运单详情id
      this.waybillDetailId = id;
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/dispatch/dispatchDetail',
          data: { id },
        },
        { showLoading: false }
      );

      if (res.success) {
        const {
          orgId,
          orgName,
          mybOrderId,
          customerId,
          customerName,
          contactList,
          feeList,
          settleType,
          loadMode,
          receiptCount,
          setRegular,
          stockValue,
          cargoList,
          billingTime,
          pointBillingTime,
          editEnum,
          notReceivable,
          enableEditOrg,
          taskType,
          priceSnapshot,
          freightFeePriceType,
          loadFeePriceType,
          pickupFeePriceType,
          deliFeePriceType,
          settlementList,
          ext,
          transType,
          ...restProps
        } = res.data;
        // 修改运单-显隐藏依据
        this.editEnum = editEnum;
        this.editNotReceivable = notReceivable;
        // 组织字段显隐藏
        this.enableEditOrg = enableEditOrg;

        // 处理应收费用
        const handleFeeList = this.handleAllFeeList(feeList);

        // 创建运单首页
        this.pageStore.waybillCreateStore.saveStateData({
          feeList: handleFeeList,
          settleType: settleType ? settleType : 4,
          loadMode: loadMode ? loadMode : 2,
          receiptCount,
          setRegular,
          pointBillingTime: pointBillingTime ? dayjs(pointBillingTime).valueOf() : '',
          mybOrderId,
          orgId,
          orgName,
          taskType,
          ext: ext ? ext : this.stateData.ext,
          transType,
        });

        // 收发货
        if (contactList && contactList.length) {
          this.pageStore.deliveryAddressStore.saveStateData({
            customerId,
            customerName,
            contactList: contactList,
          });
        }

        // 货物信息
        if (cargoList && cargoList.length) {
          this.pageStore.goodsInfoStore.saveStateData({
            stockValue: stockValue ? xyzMath.divide(stockValue, 100) : null,
            cargoList: cargoList.map((item: any) => {
              item.weight = xyzMath.round(item.weight, this.pageStore.goodsInfoStore.systemInit.orderWeightTonPoint);
              return item;
            }),
          });
        }

        // 更多信息
        this.pageStore.moreInfoStore.saveStateData({ ...restProps });
        // 初始化价格快照等信息
        this.stateData.priceSnapshot = priceSnapshot || {};
        this.stateData.freightFeePriceType = freightFeePriceType;
        this.stateData.loadFeePriceType = loadFeePriceType;
        this.stateData.pickupFeePriceType = pickupFeePriceType;
        this.stateData.deliFeePriceType = deliFeePriceType;

        // 更新运费匹配价格,设置了禁止查看费用时不更新价格
        this.updateFeeMatch(true, false);
      }
    } catch (er) {
      if (er?.code === '900002') {
        MBBridge.rnruntime.handlebackResult({});
        if (Platform.OS == 'ios') {
          setTimeout(() => {
            MBBridge.app.ui.closeWindow({});
          }, 300);
        }
      }
      MBLog.log({
        message: '获取运单详情失败',
        error: er,
      });
    } finally {
      this.isLoading = false;
    }
  };

  // 补录运单，组织权限发生变化时，重新请求补录运单详情接口的enableEditOrg字段
  @action
  updateSupplementEnableEditOrg = (id: string) => {
    const url = '/saas-tms-trans/yzgApp/supplement/loadMybOrder';
    server({
      url,
      data: { mybOrderId: id },
    })
      .then((response) => {
        if (response.success) {
          const { enableEditOrg, orgId, orgName } = response.data;
          // 组织字段显隐藏
          this.enableEditOrg = enableEditOrg;
          this.stateData.orgId = orgId;
          this.stateData.orgName = orgName;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取生成运单详情失败',
          error: er,
        });
      });
  };

  // 修改运单，组织权限发生变化时，重新请求运单详情接口的enableEditOrg字段
  @action
  updateEditEnableEditOrg = (id: string) => {
    const url = '/saas-tms-trans/yzgApp/dispatch/dispatchDetail';
    server({
      url,
      data: { id },
    })
      .then((response) => {
        if (response.success) {
          const { enableEditOrg, orgId, orgName } = response.data;
          // 组织字段显隐藏
          this.enableEditOrg = enableEditOrg;
          this.stateData.orgId = orgId;
          this.stateData.orgName = orgName;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取运单详情失败',
          error: er,
        });
      });
  };

  // 获取创建运单-组织列表
  @action
  getCreateOrganize = () => {
    const url = '/saas-tms-trans/yzgApp/org/create/order/list';
    server(
      {
        url,
        data: {},
      },
      { showLoading: false }
    )
      .then((res) => {
        if (res.success) {
          const data = res.data;
          this.organizeList = data;
          if (data?.length) {
            this.stateData.orgId = data[0].orgId;
            this.stateData.orgName = data[0].orgName;
          }
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取组织列表失败',
          error: er,
        });
      });
  };

  // 获取生成（补录）运单-组织列表
  @action
  getSupplementOrganize = (id: string) => {
    const url = '/saas-tms-trans/yzgApp/org/supplement/order/list';
    this.supplementWaybillId = id;
    server(
      {
        url,
        data: { mybOrderId: id },
      },
      { showLoading: false }
    )
      .then((res) => {
        if (res.success) {
          const data = res.data;
          this.organizeList = data;
          if (data?.length) {
            this.stateData.orgId = data[0].orgId;
            this.stateData.orgName = data[0].orgName;
          }
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取组织列表失败',
          error: er,
        });
      });
  };

  // 获取修改运单-组织列表
  @action
  getEditOrganize = (id: string) => {
    const url = '/saas-tms-trans/yzgApp/org/update/order/list';
    server(
      {
        url,
        data: { id },
      },
      { showLoading: false }
    )
      .then((res) => {
        if (res.success) {
          const data = res.data;
          this.organizeList = data;
        }
      })
      .catch((er) => {
        MBLog.log({
          message: '获取组织列表失败',
          error: er,
        });
      });
  };

  // 获取客户名称存在且下拉框选择
  @action
  getCheckCustomeName = async (params: any) => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/crm/checkExistsByConfigAndName',
          data: { ...params },
        },
        { showLoading: false }
      );

      if (res.success) {
        this.checkCustomeNamePass = res.data;
      }
    } catch (er) {
      MBLog.log({
        message: '获取获取客户名称存在且下拉框选择失败',
        error: er,
      });
    } finally {
      MBBridge.ui.hideLoading({});
    }
  };

  // 应收费用处理-增加amount字段，来源于详情的补充费用全部字段
  @action
  handleAllFeeList = (data: any) => {
    const { feeList } = this.stateData;
    let handleData = feeList;
    if (data && data.length) {
      handleData = feeList.map((item: any) => {
        item.amount = null;
        item.isDeductionFee = false;
        data.forEach((e: any) => {
          // 记录下详情里的初始值，用于提交修改是判断是否被修改
          if (item.feeCode === e.feeCode) {
            item.isDeductionFee = e.amount < 0;
            item.amount = e.amount && e.amount !== 0 ? Math.abs(e.amount) : null;
            item.priceType = e.priceType;
          }
        });
        return item;
      });
    }

    return handleData;
  };

  // 应收费用确定按钮
  @action
  onConfirmFreightReceive = (data: any) => {
    this.stateData.feeList = [...data];
  };
  /** 标记 是否 触发价格调用*/
  @action
  onGetFeeMatch = (data: boolean) => {
    this.stateData.modifyMonitor = data;
  };

  @action
  changeSettleTypeModalVisible = () => {
    const visible = this.settleTypeModalVisible;
    this.settleTypeModalVisible = !visible;
  };

  @action
  changePickupTypeModalVisible = () => {
    const visible = this.pickupTypeModalVisible;
    this.pickupTypeModalVisible = !visible;
  };

  @action
  changeOrganizeModalVisible = () => {
    const visible = this.organizeModalVisible;
    this.organizeModalVisible = !visible;
  };

  @action
  onConfirmSettleTypeModal = (type: number) => {
    this.stateData.settleType = type;
    this.changeSettleTypeModalVisible();
  };

  // 结算方式枚举过滤
  @computed get filterSettleType() {
    let handleSettleType;
    switch (this.stateData.settleType) {
      case 1:
        handleSettleType = '现付';
        break;
      case 2:
        handleSettleType = '到付';
        break;
      case 3:
        handleSettleType = '回付';
        break;
      case 4:
        handleSettleType = '月结';
        break;
      case 5:
        handleSettleType = '油卡';
        break;
      default:
        handleSettleType = '';
        break;
    }
    return handleSettleType;
  }

  @action
  onConfirmPickupTypeModal = (type: number) => {
    this.stateData.loadMode = type;
    this.changePickupTypeModalVisible();
  };

  @action
  onConfirmOrganizeModal = (data: any) => {
    this.stateData.orgId = data.orgId;
    this.stateData.orgName = data.orgName;
    this.changeOrganizeModalVisible();
  };

  // 回单数量
  @action
  onChangeReceiptCount = (value: string) => {
    if (!RegTest.positiveInteger(value) && value) return;
    if (RegTest.emoji(value)) return;

    this.stateData.receiptCount = value;
  };

  // 是否存为常发运单
  @action
  onChangeSetRegular = (checked: boolean) => {
    this.stateData.setRegular = checked;
  };

  @action
  saveStateData = (stateData: WaybillCreateStateData | any) => {
    if (stateData && Object.keys(stateData).length) {
      this.stateData = { ...this.stateData, ...stateData };
    }
  };

  @action
  getFeeReceiveList = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/tenant/config/getTaskFeeInputBoxes',
          data: { code: 'trans_order_create' },
        },
        { showLoading: false }
      );

      if (res.success) {
        const filterData = res.data ? res.data.filter((item: any) => item.feeCode !== -1 && item.feeCode !== 18) : [];
        this.stateData.feeList = [...filterData];
      }
    } catch (er) {
      MBLog.log({
        message: '获取全部应收费用类别失败',
        error: er,
      });
    }
  };

  // 应收费用必填校验
  feeReceiveValidate = () => {
    if (this.editEnum === 'TWO' || this.editEnum === 'FOUR' || this.editNotReceivable) {
      return true;
    }
    const handleFeeList = this.stateData.feeList.map((item: any) => {
      if (item.isRequired) {
        // amount可填写为0（number/string）
        item.isError = !item.amount && item.amount !== '0' && item.amount !== 0;
      }
      return item;
    });

    // 检测数组所有元素isError均为false
    return handleFeeList.every((item: any) => !item.isError);
  };

  // 更新获取匹配运费价格
  @action
  updateFeeMatch = (isEdit: boolean, isUpdata: boolean = true) => {
    // 财务校验不通过，不获取匹配运费价格
    if (this.editEnum === 'TWO' || this.editEnum === 'FOUR' || this.editNotReceivable) {
      return;
    }
    // 调用时机：创建运单/补录运单均为createBill
    let callMoment = 'createBill';
    if (isEdit) {
      callMoment = 'updateBill';
      if (isUpdata) {
        this.onGetFeeMatch(true);
      }
    }
    // 整理运单各项参数
    const { contactList, cargoList, customerId, pointBillingTime, operatorId, transOrderNo } = this.handleParams();

    const moreInfoStateData = this.pageStore.stores.moreInfoStore.getStateData();
    // carriageTimes， customerIds 参数预设为数组类型，方便后续拓展
    const carriageTime = pointBillingTime ? dayjs(pointBillingTime).format('YYYY-MM-DD HH:mm:ss') : '';
    const params = {
      callMoment,
      priceType: 1,
      contactList,
      cargoList,
      customerIds: customerId ? [customerId] : [],
      carriageTimes: [carriageTime],
      chargeMileage: moreInfoStateData.costMileage,
      salesmanId: operatorId,
      transOrderNo: isEdit ? transOrderNo || null : null,
    };

    this.getFeeMatch(params, isEdit);
  };

  // 获取自动匹配运费价格
  @action
  getFeeMatch = async (params: any, isEdit: boolean) => {
    // 查看价格调用，判断是否需要显示合并费用，如果没有还是走老逻辑，只有在修改运单时才有可能会显示合并费用
    const url = isEdit ? '/saas-tms-trans/yzgApp/price/match' : '/saas-tms-price/yzgApp/priceRule/match';

    try {
      const res = await server(
        {
          url: url,
          data: { ...params },
        },
        { showLoading: false }
      );
      // 未设置匹配价格 priceContexts字段为null
      if (res.success && res.data?.priceContexts) {
        this.handleFeeListMatch(res.data.priceContexts, isEdit);
      }
    } catch (er) {
      MBLog.log({
        message: '获取自动匹配运费价格失败',
        error: er,
      });
    }
  };

  @action
  handleFeeListMatch = (data: any[], isEdit: boolean) => {
    const { feeList } = this.stateData;
    const handleFeeList = [...feeList];
    const dataMap = {};
    data.map((item: any) => {
      if (item.feeTypeCode > -1) {
        dataMap[item.feeTypeCode] = item;
      }
    });
    handleFeeList.forEach((row: any) => {
      const item = dataMap[row.feeCode];
      if (item && (item?.appPriceSnapshotMap || item?.priceMergeRulesHitInfo)) {
        // 1、手动修改过运费后，不再默认自动匹配价格， priceType： 0 手动填写，1 自动计算, 2 合并计费
        // 2、创建运单时
        if (isEdit) {
          if (row.priceType || row.priceType === undefined) {
            row.amount = item.price;
            row.appPriceSnapshotItem = item;
          }
        } else {
          if (row.priceType || row.priceType === undefined) {
            row.amount = item.price;
            row.priceType = 1;
            row.appPriceSnapshotItem = item;
          }
        }

        row.appPriceSnapshotMap = {
          ...item.appPriceSnapshotMap,
          priceMergeRulesHitInfo: item.priceMergeRulesHitInfo,
          priceType: row.priceType,
        };
        this.handlePriceSnapshot(row.feeCode, row.priceType, item);
      }
    });

    this.stateData.feeList = [...handleFeeList];
  };

  // 处理priceSnapshot字段
  @action
  handleFeeListPriceSnapshot = () => {
    const { feeList } = this.stateData;
    feeList.forEach((item: unknown) => {
      this.handlePriceSnapshot(item.feeCode, item.priceType, item.appPriceSnapshotItem);
    });
  };

  @action
  handlePriceSnapshot = (feeCode: number, priceType: number, appPriceSnapshotItem?: any) => {
    let priceTypeKey = '';
    let priceSnapshotItemKey = '';
    if (feeCode === 0) {
      priceTypeKey = 'freightFeePriceType';
      priceSnapshotItemKey = 'freightPriceInfo';
    }
    if (feeCode === 1) {
      priceTypeKey = 'loadFeePriceType';
      priceSnapshotItemKey = 'loadPriceInfo';
    }
    if (feeCode === 6) {
      priceTypeKey = 'pickupFeePriceType';
      priceSnapshotItemKey = 'pickUpPriceInfo';
    }
    if (feeCode === 20) {
      priceTypeKey = 'deliFeePriceType';
      priceSnapshotItemKey = 'deliPriceInfo';
    }
    // 需要在运费、装卸费、提货费、送货费四种类型中才会匹配价格
    if (priceTypeKey) {
      this.stateData[priceTypeKey] = priceType ? priceType : 0;
    }

    if (priceSnapshotItemKey) {
      if (priceType && appPriceSnapshotItem) {
        this.stateData.priceSnapshot[priceSnapshotItemKey] = appPriceSnapshotItem;
      } else {
        // 手动输入的费用删除对应快照
        delete this.stateData.priceSnapshot[priceSnapshotItemKey];
      }
    }
  };

  // 查询系统配置数据
  @action
  getSystemInit = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/trans/system/init',
          data: {},
        },
        { showLoading: false }
      );
      if (res.success && res.data) {
        this.transTypeNecessarily = res.data?.transTypeNecessarily || false; // 运输方式是否必填 true/false
        this.sensitiveWordList = res.data?.sensitiveWordList || [];
        this.industryData = {
          industryFlag: res.data?.industryFlag,
          industryExtendCode: res.data?.industryExtendCode,
          industryOptions: res.data?.industryOptions || [],
        };

        // 发货车型车长 carTypeLengthData
        const extendFields = res.data?.extendFields || [];
        const carTypeList = extendFields.filter((item: any) => item.name === '发货车型');
        const carLengthList = extendFields.filter((item: any) => item.name === '发货车长');
        const carTypeData = carTypeList.length ? carTypeList[0] : null;
        const carLengthData = carLengthList.length ? carLengthList[0] : null;
        let carType: any = {};
        let carLength: any = {};

        if (carTypeData?.code) {
          // 维护ext参数格式
          this.stateData.ext[carTypeData.code] = [];
          this.carTypeCode = carTypeData.code;

          for (const item of carTypeList[0].options) {
            carType[item.value] = item.text;
          }
        }

        if (carLengthData?.code) {
          this.stateData.ext[carLengthData.code] = [];
          this.carLengthCode = carLengthData.code;
          for (const item of carLengthList[0].options) {
            carLength[item.value] = item.text;
          }
        }

        if (carLengthData?.code || carLengthData?.code) {
          const handleCarTypeLengthData = {
            carTypePlate: carType,
            carLengthPlate: carLength,
          };
          this.carTypeLengthData = { ...handleCarTypeLengthData };
        }
      }
    } catch (error) {
      MBLog.log({
        message: '查询系统配置数据失败',
        error: error,
      });
    }
  };

  // 查询必填配置
  @action
  getRequiredConfig = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/user/config/getAppPageFieldsConfig',
          data: {},
        },
        { showLoading: false }
      );
      if (res.success) {
        this.requiredConfig = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '查询必填配置失败',
        error: error,
      });
    }
  };

  @action
  changeCarTypeLengthModalVisible = () => {
    const visible = this.carTypeLengthVisible;
    this.carTypeLengthVisible = !visible;
  };

  @action
  changeTransTypeVisible = (val: boolean) => {
    this.transTypeVisible = val;
  };
  @action
  handleCarTypeLengthChange = (val: any) => {
    if (val) {
      // ext 发货车型车长等字段
      const carTypeCode = this.carTypeCode;
      const carLengthCode = this.carLengthCode;
      const carType = val.carType.map((item: any) => item.id); // 车型
      const carLength = val.carLength.map((item: any) => item.id); // 车长
      // 存储车型车长传参字段
      if (carTypeCode) {
        this.stateData.ext[carTypeCode] = carType;
      }
      if (carLengthCode) {
        this.stateData.ext[carLengthCode] = carLength;
      }
    }
    this.changeCarTypeLengthModalVisible();
  };
}

export default WaybillCreateStore;
