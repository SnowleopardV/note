import React from 'react';
import {
  SafeAreaView,
  View,
  StyleSheet,
  ImageBackground,
  BackHandler,
  Platform,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  Keyboard,
  EmitterSubscription,
  Button,
} from 'react-native';
import { App, MBAutoPVComponent } from '@ymm/rn-lib';
import { inject, observer } from 'mobx-react';
import Images from '../../../../public/static/images';
import NavBar from '~/components/common/NavBar';
import CreateContent from './components/CreateContent';
import CreateFooter from './components/CreateFooter';
import SupplyFooter from './components/SupplyFooter';
import TotalFreightReceive from './components/TotalFreightReceive';
import PageStore from '../store/index';
import WaybillCreateStore from './store';
import { MBText } from '@ymm/rn-elements';
import ModalSupply from './components/ModalSupply';
import { MBBridge } from '@ymm/rn-lib';
import EmptyPage from '~/components/common/EmptyPage';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export interface CreateIndexProps {
  pageStore: PageStore;
  waybillCreateStore: WaybillCreateStore;
  navigation: any;
}

class CreateIndex extends MBAutoPVComponent<CreateIndexProps, any> {
  refreshListioner: any; // 刷新监听
  keyboardHideListener?: EmitterSubscription;
  state = {
    showFooterBtn: true,
    pageTitle: '创建运单',
    // 是否来源生成
    isFromSupplyWaybill: false,
  };
  timerBtn: any = null;
  constructor(props: CreateIndexProps) {
    super(props);
    if (Platform.OS === 'android') {
      this.keyboardHideListener = Keyboard.addListener('keyboardDidHide', this.keyboardHide);
    }
  }

  async UNSAFE_componentWillMount() {
    const { source } = this.props.pageStore;
    // 判断来源
    this.setState({
      pageTitle: source === 'supplywaybill' ? '生成运单' : '创建运单',
      isFromSupplyWaybill: source === 'supplywaybill',
    });
    this.props.waybillCreateStore.setFromSupplyWaybill(source === 'supplywaybill'); // 记录下是否在补录运单下
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }

  async componentDidMount() {
    super.componentDidMount();
    const { isFromSupplyWaybill } = this.state;
    const {
      waybillCreateStore: {
        getLoadDraft,
        trackPageView,
        getSupllyWaybillDetail,
        getSupllyGuide,
        getAppInfo,
        getAuthentication,
        getFeeReceiveList,
        getCreateOrganize,
        getSupplementOrganize,
        getSystemInit,
        getRequiredConfig,
        getUserCreateOrderConfigs,
      },
      pageStore: { id },
    } = this.props;
    // 调度后回到列表页
    this.refreshListioner = App.receiveEvent('closeWaybillCreateView', (data: any) => {
      if (data?.isClose) {
        if (Platform.OS === 'android') {
          setTimeout(() => {
            MBBridge.app.ui.closeWindow({});
          }, 20);
        } else {
          setTimeout(() => {
            MBBridge.app.ui.closeWindow({});
          }, 100);
        }
      }
    });

    // 获取权限
    getAuthentication({ permissionCode: '100100' });
    // 获取所有费用
    getFeeReceiveList();
    // 获取app来源
    await getAppInfo();
    const {
      waybillCreateStore: { isFromTms },
    } = this.props;

    // 系统配置接口（包含查询敏感词数据）
    await getSystemInit();

    // 来自运掌柜tms才读取草稿
    if (isFromTms) {
      // 获取草稿
      getLoadDraft();
    }

    // 来自生成，获取生成单详情、生成指引
    if (isFromSupplyWaybill) {
      getSupllyWaybillDetail(id);
      getSupllyGuide();
      getSupplementOrganize(id);
    } else {
      // 来自tms创建运单或者 ymm/hcb企业服务创建运单；获取组织
      getCreateOrganize();
    }

    // 必填配置接口
    getRequiredConfig();

    // 用户地址、增加按钮等配置
    getUserCreateOrderConfigs();

    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', this.backAction);
    }
  }

  componentWillUnmount() {
    super.componentWillUnmount();
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener('hardwareBackPress', this.backAction);
    }

    App.removeEmitListener(this.refreshListioner);
  }

  getPageName() {
    return 'waybill_supply_edit';
  }

  backAction = () => {
    const {
      waybillCreateStore: { onConfirmSaveDraft, isFromTms },
    } = this.props;

    // 来自运掌柜tms,返回时二次确认保存草稿
    if (isFromTms) {
      onConfirmSaveDraft && onConfirmSaveDraft();
    } else {
      MBBridge.app.ui.closeWindow({});
    }
    return true;
  };

  // 键盘消失时底部按钮显示（兼容vivo x20a机型上底部按钮不显示问题）
  keyboardHide = () => {
    this.setState({ showFooterBtn: true });
  };

  // 失焦底部按钮显示，聚焦底部按钮隐藏
  onCommonBlurFocus = (val: boolean) => {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ showFooterBtn: val });
    }, 10);
  };

  rightElement = () => {
    const { isFromSupplyWaybill } = this.state;
    const {
      waybillCreateStore: { onModalSupplyOpen },
    } = this.props;

    if (isFromSupplyWaybill) {
      return (
        <TouchableOpacity onPress={onModalSupplyOpen}>
          <View style={styles.supplyQuestionWrapper}>
            <Image source={{ uri: Images.icon_question }} style={styles.iconQuestion} />
            <MBText color="primary" size="sm" style={styles.supplyQuestionText}>
              生成运单
            </MBText>
          </View>
        </TouchableOpacity>
      );
    } else {
      return '';
    }
  };

  renderContent() {
    const {
      navigation,
      waybillCreateStore: {
        getTotalFeeInfo: { totalFee, detailFeeList },
        onSubmit,
        supplyModalVisible,
        onModalSupplyConfirm,
        onModalSupplyCancel,
        supllyGuideData,
        isLoading,
        showPermissionVisible,
        appSupplementErrorData,
      },
    } = this.props;
    const { showFooterBtn, pageTitle, isFromSupplyWaybill } = this.state;
    return (
      <View style={styles.container}>
        <NavBar title={pageTitle} leftClick={this.backAction} rightElement={this.rightElement()} />
        {!isLoading ? (
          <View style={styles.flexStyle}>
            {showPermissionVisible ? (
              <EmptyPage errorData={appSupplementErrorData} />
            ) : (
              <ImageBackground source={{ uri: Images.icon_bg_map }} style={styles.imageBackground}>
                <View style={styles.flexStyle}>
                  <CreateContent
                    navigation={navigation}
                    isFromSupplyWaybill={isFromSupplyWaybill}
                    onCommonFocus={() => this.onCommonBlurFocus(false)}
                    onCommonBlur={() => this.onCommonBlurFocus(true)}
                  />
                  {showFooterBtn ? (
                    <View style={styles.shadowStyle}>
                      {detailFeeList && detailFeeList.length ? (
                        <TotalFreightReceive detailFeeList={detailFeeList} totalFee={totalFee} />
                      ) : null}
                      {isFromSupplyWaybill ? <SupplyFooter onSubmit={onSubmit} /> : <CreateFooter onSubmit={onSubmit} />}
                    </View>
                  ) : null}
                </View>
                <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
              </ImageBackground>
            )}
            <ModalSupply
              visible={supplyModalVisible}
              onConfirm={onModalSupplyConfirm}
              onCancel={onModalSupplyCancel}
              supllyGuideData={supllyGuideData}
            />
          </View>
        ) : null}
      </View>
    );
  }
  render() {
    const {
      waybillCreateStore: { isFromTms },
    } = this.props;
    if (Platform.OS == 'ios' && isFromTms) {
      return (
        <KeyboardAvoidingView behavior="padding" style={[styles.container]}>
          <View style={{ flex: 1 }}>{this.renderContent()}</View>
        </KeyboardAvoidingView>
      );
    }

    return <View style={styles.container}>{this.renderContent()}</View>;
  }
}

const styles = StyleSheet.create<any>({
  shadowStyle: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },

  container: {
    flex: 1,
  },

  imageBackground: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },

  supplyQuestionWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },

  supplyQuestionText: {
    marginLeft: autoFix(2),
  },

  iconQuestion: {
    width: autoFix(30),
    height: autoFix(30),
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default inject('waybillCreateStore')(observer(CreateIndex));
