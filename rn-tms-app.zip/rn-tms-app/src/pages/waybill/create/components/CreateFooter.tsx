import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Whitespace, Flex, MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import TouchableThrottle from '~/components/TouchableThrottle';

const FlexItem = Flex.Item;

const CreateFooter = (props: any) => (
  <Flex direction="row" justify="center" style={styles.footer}>
    <FlexItem>
      <TouchableThrottle
        onPress={() => {
          props.onSubmit(1);
        }}
      >
        <View style={[styles.bntCommonStyle, styles.createText]}>
          <MBText style={styles.btnText} color="#4885FF">
            仅创建
          </MBText>
        </View>
      </TouchableThrottle>
    </FlexItem>
    <Whitespace type="horizontal" horizontal={5} />
    <FlexItem flex={2}>
      <TouchableThrottle
        onPress={() => {
          props.onSubmit(2);
        }}
      >
        <View style={[styles.bntCommonStyle, styles.createDispathText]}>
          <MBText style={styles.btnText} color="#fff">
            创建并调度
          </MBText>
        </View>
      </TouchableThrottle>
    </FlexItem>
  </Flex>
);

const styles = StyleSheet.create<any>({
  footer: {
    paddingVertical: autoFix(20),
    paddingHorizontal: autoFix(28),
    backgroundColor: '#fff',
  },

  bntCommonStyle: {
    height: autoFix(80),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 40,
  },

  btnText: {
    fontSize: autoFix(32),
  },

  createText: {
    borderWidth: autoFix(1),
    borderColor: '#4885FF',
  },

  createDispathText: {
    backgroundColor: '#4885FF',
  },
});

export default CreateFooter;
