import React from 'react';
import { View, StyleSheet, ScrollView, Image } from 'react-native';
import { inject, observer } from 'mobx-react';
import { ActionSheet, CellGroup, MBText, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import InputItem from '~/components/common/InputItem';
import ModalSettleType from './ModalSettleType';
import ModalPickupType from './ModalPickupType';
import ModalOrganize from './ModalOrganize';
import DeliveryAddress from '../../delivery-address';
import { RouterPageName } from '../../Router/register';
import WaybillCreateStore from '../store';
import GoodsInfoStore from '../../goods-info/store';
import MoreInfoStore from '../../more-info/store';
import GoodsInfo from '../../goods-info';
import CellOneMoreOrder from '../../OneMoreOrder/CellOneMoreOrder';
import { TagContent } from '@ymm/rn-lib';
import images from '~public/static/images';
import ModalCarTypeLength from '~/pages/dispatch/components/ModalCarTypeLength';
import { transTypeEnum } from '~/pages/enums';
import ActionSheetModal from '~/components/ActionSheetModal';

interface CreateContentProps {
  waybillCreateStore: WaybillCreateStore;
  goodsInfoStore: GoodsInfoStore;
  moreInfoStore: MoreInfoStore;
  navigation: any;
  isFromSupplyWaybill: boolean;
  isEdit: boolean;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
}

const CreateContent: React.FunctionComponent<CreateContentProps> = (props) => {
  const { navigation, waybillCreateStore, goodsInfoStore, moreInfoStore, isFromSupplyWaybill, isEdit, onCommonFocus, onCommonBlur } = props;
  const {
    stateData: { feeList, loadMode, orgId, orgName, ext, transType },
    pickupTypeModalVisible,
    editEnum,
    editNotReceivable,
    organizeModalVisible,
    carTypeLengthVisible,
    transTypeVisible,
    organizeList,
    enableEditOrg,
    saveStateData,
    changeTransTypeVisible,
    changePickupTypeModalVisible,
    changeOrganizeModalVisible,
    changeCarTypeLengthModalVisible,
    onConfirmPickupTypeModal,
    onConfirmOrganizeModal,
    handleCarTypeLengthChange,
    filterSettleType,
    getTotalFeeInfo: { totalFee, detailFeeList },
    // onChangeSetRegular,
    carTypeCode,
    carLengthCode,
    carTypeLengthData,
    transTypeNecessarily, // 运输方式是否必填 true/false
    showWarnTips, // 显示校验失败的提示
  } = waybillCreateStore;

  const { displayMoreInfoText } = moreInfoStore;
  const carTypeCodeHasValue = !!carLengthCode && !!ext && !!ext[carTypeCode]?.length;
  const carLengthCodeHasValue = !!carLengthCode && !!ext && !!ext[carLengthCode]?.length;
  const carTypeName = carTypeCodeHasValue ? ext[carTypeCode].map((item: string) => carTypeLengthData.carTypePlate[item]).join('、') : '';
  const carLengthName = carLengthCodeHasValue
    ? ext[carLengthCode].map((item: string) => carTypeLengthData.carLengthPlate[item]).join('、')
    : '';
  const carTypeId = carTypeCodeHasValue ? ext[carTypeCode].map((item: any) => item) : [];
  const carLengthId = carLengthCodeHasValue ? ext[carLengthCode].map((item: any) => item) : [];
  const displayCarTypeLengthText = carTypeName && carLengthName ? `${carTypeName || '-'} / ${carLengthName || '-'}` : '';

  const rightElement = () => {
    let temTotalFee = totalFee + '';
    if (editEnum === 'TWO' || editEnum === 'FOUR' || editNotReceivable) {
      temTotalFee = '***';
    }
    let total = `<b><font #333333>应收合计</font><font color=#FF6969>${temTotalFee}元</font>,${filterSettleType}</b>`;
    return (detailFeeList && detailFeeList.length) || filterSettleType ? (
      <View style={{ flexDirection: 'row', marginRight: -5 }}>
        <TagContent size={15} content={total} />
        <Image style={{ width: 16, height: 16 }} source={{ uri: images.icon_arrow_gray }} />
      </View>
    ) : null;
  };

  const feeDetailsRequired = feeList.find((item: any) => item.isRequired);
  const renderContent = () => {
    return (
      <View style={styles.container}>
        {organizeList && organizeList.length ? (
          <View>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <Cell
                name="organize"
                title="组织"
                align="right"
                readonly={organizeList.length === 1 || !enableEditOrg || isFromSupplyWaybill}
                required
                value={orgName}
                numberOfLines={1}
                placeholder="请选择运单所属组织"
                onPress={changeOrganizeModalVisible}
              />
            </CellGroup>
          </View>
        ) : null}

        <Whitespace vertical={10} />
        {/* 客户名称，装卸货地址，装卸货时间 */}
        <DeliveryAddress
          editEnum={editEnum}
          isFromSupplyWaybill={isFromSupplyWaybill}
          waybillCreateStore={waybillCreateStore}
          goodsInfoStore={goodsInfoStore}
          isEdit={isEdit}
        />

        <Whitespace vertical={10} />
        {/* 货物信息 */}
        <GoodsInfo
          navigation={navigation}
          screenProps={{ pageStore: { goodsInfoStore } }}
          isEdit={isEdit}
          onCommonFocus={() => {
            onCommonFocus && onCommonFocus();
          }}
          onCommonBlur={() => {
            onCommonBlur && onCommonBlur();
          }}
        />
        <CellGroup withBottomLine>
          {(!!carTypeCode && !!carTypeLengthData.carTypePlate) || (!!carLengthCode && !!carTypeLengthData.carLengthPlate) ? (
            <Cell
              name="carTypeLength"
              title="发货车型车长"
              align="right"
              value={displayCarTypeLengthText}
              numberOfLines={1}
              required={true}
              placeholder={'请选择'}
              onPress={changeCarTypeLengthModalVisible}
            />
          ) : null}
          <Cell
            name="transType"
            title="运输方式"
            align="right"
            showClear
            value={transTypeEnum.find((item: any) => item.value == transType)?.label}
            numberOfLines={1}
            required={!!transTypeNecessarily}
            placeholder={'请选择'}
            onPress={() => waybillCreateStore.changeTransTypeVisible(true)}
            onClearPress={() => saveStateData({ transType: null })}
            TipsText={!!transTypeNecessarily && !!showWarnTips && !transType ? '运输方式未填' : null}
          />
        </CellGroup>

        {<Whitespace vertical={10} />}

        <CellGroup withBottomLine>
          <Cell
            name="freightReceive"
            title="应收费用"
            align="right"
            numberOfLines={1}
            required={!!feeDetailsRequired}
            readonly={editEnum === 'TWO' || editEnum === 'FOUR' || editNotReceivable}
            placeholder={(detailFeeList && detailFeeList.length) || filterSettleType ? '' : '请输入'}
            onPress={() => {
              navigation.navigate(RouterPageName.FeeReceive);
            }}
            rightElement={rightElement()}
          />
        </CellGroup>
        <Whitespace vertical={10} />
        <CellGroup withBottomLine>
          <Cell
            name="moreInfo"
            title="更多信息"
            align="right"
            value={displayMoreInfoText}
            numberOfLines={1}
            placeholder="请输入"
            onPress={() => {
              navigation.navigate(RouterPageName.MoreInfo, { isEdit });
            }}
          />
        </CellGroup>
        {/* <Whitespace horizontal={34} vertical={32}>
          <Checkbox size="sm" onChange={onChangeSetRegular}>
            存为常发运单
          </Checkbox>
        </Whitespace> */}

        <ModalPickupType
          visible={pickupTypeModalVisible}
          loadMode={loadMode}
          onConfirm={onConfirmPickupTypeModal}
          onCancel={changePickupTypeModalVisible}
        />

        <ModalOrganize
          visible={organizeModalVisible}
          orgId={orgId}
          organizeList={organizeList}
          onConfirm={onConfirmOrganizeModal}
          onCancel={changeOrganizeModalVisible}
        />
        {(carTypeCode && carTypeLengthData.carTypePlate) || (carLengthCode && carTypeLengthData.carLengthPlate) ? (
          <ModalCarTypeLength
            visible={carTypeLengthVisible}
            multiple={true}
            onChange={handleCarTypeLengthChange}
            item={{ platformCarLength: carLengthId, platformCarType: carTypeId }}
            carTypeLengthData={carTypeLengthData}
          />
        ) : null}
        {!!transTypeVisible && (
          <ActionSheetModal
            visible={true}
            list={transTypeEnum}
            title="请选择运输方式"
            defaultData={transType}
            onConfirm={(item) => {
              saveStateData({ transType: item.value });
              changeTransTypeVisible(false);
            }}
            onCancel={() => changeTransTypeVisible(false)}
          />
        )}
      </View>
    );
  };

  return (
    <ScrollView
      keyboardShouldPersistTaps="handled"
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      style={{ flex: 1 }}
    >
      {!isEdit && !isFromSupplyWaybill && <CellOneMoreOrder {...props} text="再来一单" />}
      <View style={styles.inner}>{renderContent()}</View>
    </ScrollView>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  inner: {
    flex: 1,
    paddingBottom: 40,
  },
});

export default inject('waybillCreateStore', 'goodsInfoStore', 'moreInfoStore')(observer(CreateContent));
