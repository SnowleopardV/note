import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import TouchableThrottle from '~/components/TouchableThrottle';

const SupplyFooter = (props: any) => (
  <TouchableThrottle
    onPress={() => {
      props.onSubmit(3);
    }}
  >
    <View style={styles.footer}>
      <MBText style={styles.confirmText}>确认生成</MBText>
      <MBText style={styles.tipText}>生成订单后将同步至运掌柜系统供财务查看</MBText>
    </View>
  </TouchableThrottle>
);

const styles = StyleSheet.create<any>({
  footer: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: autoFix(20),
    paddingBottom: autoFix(10),
    backgroundColor: '#fff',
  },

  confirmText: {
    fontSize: autoFix(32),
    fontWeight: 'bold',
    color: '#333',
    lineHeight: autoFix(36),
  },

  tipText: {
    fontSize: autoFix(26),
    color: '#666',
    marginTop: autoFix(4),
    marginBottom: autoFix(8),
  },
});

export default SupplyFooter;
