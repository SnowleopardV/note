import React from 'react';
import { View, StyleSheet, TouchableOpacity, Image, Dimensions, ScrollView } from 'react-native';
import { MBText, Splitline, Flex } from '@ymm/rn-elements';
import Images from '../../../../../public/static/images';
const { height } = Dimensions.get('window');
const FlexItem = Flex.Item;
export interface feeList {
  feeCode: number;
  feeCodeDesc: string;
  amount: string | number | null;
}

export interface TotalFreightReceiveProps {
  totalFee: string | number | null;
  detailFeeList?: feeList[];
  editNotReceivable?: boolean;
}

class TotalFreightReceive extends React.Component<TotalFreightReceiveProps, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      detailVisible: false,
    };
  }

  // 明细展示
  onTotalDetail = () => {
    this.setState({
      detailVisible: !this.state.detailVisible,
    });
  };

  render() {
    const { detailVisible } = this.state;
    const { detailFeeList, totalFee, editNotReceivable } = this.props;

    return (
      <View style={styles.shadowStyle}>
        {detailVisible && detailFeeList && detailFeeList.length ? (
          <ScrollView style={{ maxHeight: height * 0.7 }}>
            {detailFeeList.map((item: any) => {
              return item.amount ? (
                <View style={styles.detailItem} key={item.feeCodeDesc}>
                  <MBText>{item.feeCodeDesc}（元）</MBText>
                  <MBText>{item.amount}</MBText>
                </View>
              ) : null;
            })}
            <Splitline />
          </ScrollView>
        ) : null}

        <Flex direction="row" justify="center" align="center" style={styles.feeWrapper}>
          <MBText>应收费用合计</MBText>
          <Flex direction="row" justify="center" align="flex-end" style={styles.totalFeeMarginWrapper}>
            {!editNotReceivable ? (
              <MBText color="#F54242" size="xs" bold style={styles.totalFeeMargin}>
                ¥
              </MBText>
            ) : null}

            <MBText color="#F54242" size="md" bold>
              {!editNotReceivable ? totalFee : '*'}
            </MBText>
          </Flex>
          <TouchableOpacity style={styles.flexRow} onPress={this.onTotalDetail}>
            <MBText style={styles.detailText}>明细</MBText>
            <Image style={[styles.icon, detailVisible && styles.upturned]} source={Images.icon_pull_down} />
          </TouchableOpacity>
        </Flex>
        <Splitline />
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  shadowStyle: {
    // borderTopColor: '#eeeeee',
    // borderTopWidth: 2,
  },

  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  upturned: {
    transform: [{ rotateZ: '180deg' }],
  },

  icon: {
    width: 15,
    height: 15,
  },

  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 40,
    paddingHorizontal: 20,
  },

  feeWrapper: {
    paddingVertical: 15,
    backgroundColor: '#fff',
  },

  totalFeeMarginWrapper: {
    marginLeft: 5,
  },

  totalFeeMargin: {
    marginBottom: 2,
  },

  detailText: {
    color: '#666666',
    marginLeft: 20,
  },
});

export default TotalFreightReceive;
