import React, { useState, useEffect } from 'react';
import { SafeAreaView, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalOrganize = (props: any) => {
  const { visible, onConfirm, onCancel, organizeList, orgId } = props;
  const [item, setItem] = useState<any>({});
  const [lastOrganizeIndex, setLastOrganizeIndex] = useState(0); // 上次选中索引

  useEffect(() => {
    setItem(() => {
      const lastOrganizeArr = organizeList.filter((item: any) => item.orgId === orgId);
      return lastOrganizeArr.length ? lastOrganizeArr[0] : organizeList[0];
    });
  }, [orgId]);

  useEffect(() => {
    organizeList.forEach((item: any, index: number) => {
      if (item.orgId === orgId) {
        setLastOrganizeIndex(index);
      }
    });
  }, [orgId]);

  const onModalConfirm = () => {
    onConfirm && onConfirm(item);
  };

  const onModalCancel = () => {
    onCancel && onCancel();
  };

  const onChange = (position: number, item: any) => {
    setItem(item);
  };

  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请选择运单所属组织"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onCancel={onModalCancel}
        onConfirm={onModalConfirm}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
      >
        <Flex direction="row" justify="center">
          <FlexItem>
            <Selector
              scaleFont={true}
              value={lastOrganizeIndex}
              rowTitle="orgName"
              list={organizeList}
              onChange={(position: number, item: any) => {
                onChange(position, item);
              }}
            />
          </FlexItem>
        </Flex>
        <Whitespace vertical={20} />
      </Modal>
    </SafeAreaView>
  );
};

export default ModalOrganize;
