import React, { useState, useEffect } from 'react';
import { TouchableOpacity, View, StyleSheet, SafeAreaView, Image } from 'react-native';
import { Flex, Modal, MBText, Button } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Images from '../../../../../public/static/images';
import NativeBridge from '~/extends/NativeBridge';

const FlexItem = Flex.Item;

const ModalSupply = (props: any) => {
  const { visible, onConfirm, onCancel, supllyGuideData } = props;

  const { title, content, tel } = supllyGuideData;

  const onTel = () => {
    NativeBridge.dial({ telephone: tel });
  };

  return (
    <Modal
      title={title}
      position="center"
      visible={visible}
      autoAdjustPosition={true}
      headerStyle={styles.headerStyle}
      contentStyle={styles.contentStyle}
      headerLine={false}
      onRequestClose={() => {
        onCancel && onCancel();
      }}
    >
      <View style={{ width: '100%' }}>
        <View>
          <MBText style={styles.content}>{content}</MBText>
        </View>

        <View style={styles.concactWrapper}>
          <TouchableOpacity activeOpacity={0.3} onPress={onTel} style={styles.onPressWrapper}>
            <Image source={{ uri: Images.icon_customerService }} style={styles.iconCustomeService} />
            <MBText style={styles.concact}>联系客服了解</MBText>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Button
            type="primary"
            size="sm"
            radius
            onPress={() => {
              onConfirm && onConfirm();
            }}
          >
            <MBText color="#fff">我知道了</MBText>
          </Button>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create<any>({
  btnWrapper: {
    width: '100%',
  },

  headerStyle: {
    paddingTop: autoFix(30),
  },

  contentStyle: {
    paddingHorizontal: autoFix(67),
    paddingTop: autoFix(36),
    paddingBottom: autoFix(48),
  },

  content: {
    fontSize: autoFix(28),
    color: '#333',
    lineHeight: autoFix(56),
  },

  concactWrapper: {
    marginTop: autoFix(80),
    justifyContent: 'center',
    alignItems: 'center',
  },

  onPressWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },

  iconCustomeService: {
    width: autoFix(30),
    height: autoFix(30),
  },

  concact: {
    fontSize: autoFix(28),
    color: '#4885FF',
    paddingLeft: autoFix(8),
  },

  footer: {
    marginTop: autoFix(40),
  },
});

export default ModalSupply;
