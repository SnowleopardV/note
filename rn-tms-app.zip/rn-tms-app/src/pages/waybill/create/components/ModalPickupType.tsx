import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { Flex, Modal, Whitespace, MBText, Splitline } from '@ymm/rn-elements';
import { MBToast } from '@ymm/rn-lib';

const FlexItem = Flex.Item;

const ModalPickupType = (props: any) => {
  const { visible, onConfirm, onCancel, loadMode } = props;
  const [pickupTypeList, setPickupTypeList] = useState<any[]>([
    {
      pickupType: 2,
      pickupName: '否',
    },
    {
      pickupType: 1,
      pickupName: '是',
      pickupSubName: '暂不支持「小车上门提货」，若需要请前往pc端操作',
      disabled: true,
    },
  ]);
  const [pickupTypeItem, setPickupTypeItem] = useState<any>({
    pickupType: 2,
  });

  useEffect(() => {
    setPickupTypeItem(() => {
      const lastPickupTypeArr = pickupTypeList.filter((item) => item.pickupType === loadMode);
      return lastPickupTypeArr.length ? lastPickupTypeArr[0] : { pickupType: 2 };
    });
  }, [loadMode]);

  // 提货方式确认
  const onModalConfirm = (value: number) => {
    setPickupTypeItem(value);
    onConfirm && onConfirm(value);
  };

  return (
    <View style={{ flex: 1 }}>
      <Modal
        position="bottom"
        title="请选择是否提货"
        visible={visible}
        contentStyle={styles.contentStyle}
        autoAdjustPosition={true}
        headerLine={false}
        onMaskClose={() => {
          onCancel && onCancel();
        }}
        onRequestClose={() => {
          onCancel && onCancel();
        }}
      >
        {pickupTypeList.map((item: any, index: number) => {
          const selected = pickupTypeItem.pickupType === item.pickupType;
          return (
            <View key={item.id} style={{ width: '100%' }}>
              <TouchableOpacity
                activeOpacity={item.disabled ? 1 : 0.2}
                onPress={() => {
                  if (item.disabled) {
                    MBToast.show(item.pickupSubName);
                    return;
                  }
                  onModalConfirm(item.pickupType);
                }}
              >
                <Flex direction="row">
                  <FlexItem style={styles.selectItem}>
                    <MBText
                      align="center"
                      color={item.disabled ? '#ccc' : selected ? 'primary' : ''}
                      style={selected ? styles.selected : ''}
                      
                    >
                      {item.pickupName}
                    </MBText>
                    <Whitespace vertical={2} />
                    {item.pickupSubName && (
                      <MBText align="center" color="#ccc" size="xs">
                        {item.pickupSubName}
                      </MBText>
                    )}
                  </FlexItem>
                </Flex>
              </TouchableOpacity>
              {index !== pickupTypeList.length - 1 && <Splitline />}
            </View>
          );
        })}
        <View style={styles.splitline}></View>
        <View style={{ width: '100%' }}>
          <TouchableOpacity
            onPress={() => {
              onCancel && onCancel();
            }}
          >
            <Flex direction="row">
              <FlexItem style={styles.selectItem}>
                <MBText align="center">取消</MBText>
              </FlexItem>
            </Flex>
          </TouchableOpacity>
        </View>
        <Whitespace vertical={20} />
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  contentStyle: {
    paddingHorizontal: 0,
  },

  selectItem: {
    height: 55,
    justifyContent: 'center',
  },

  splitline: {
    backgroundColor: '#F7F7F7',
    width: '100%',
    height: 10,
  },

  selected: {
    fontWeight: 'bold',
  },
});

export default ModalPickupType;
