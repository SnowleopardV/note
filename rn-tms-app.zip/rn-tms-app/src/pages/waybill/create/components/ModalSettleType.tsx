import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { Flex, Modal, MBText, Splitline, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalSettleType = (props: any) => {
  const { visible, onConfirm, onCancel, settleType } = props;
  const [settleTypeList, setSettleTypeList] = useState<any[]>([
    {
      settleType: 1,
      settleName: '现付',
    },
    {
      settleType: 2,
      settleName: '到付',
    },
    {
      settleType: 3,
      settleName: '回付',
    },
    {
      settleType: 4,
      settleName: '月结',
    },
    // {
    //   settleType: 5,
    //   settleName: '油卡',
    // },
  ]);
  const [settleTypeItem, setSettleTypeItem] = useState<any>({
    settleType: 4,
  });

  useEffect(() => {
    setSettleTypeItem(() => {
      const lastSettleTypeArr = settleTypeList.filter((item) => item.settleType === settleType);
      return lastSettleTypeArr.length ? lastSettleTypeArr[0] : { settleType: 4 };
    });
  }, [settleType]);

  // 结算方式确认
  const onModalConfirm = (value: number) => {
    setSettleTypeItem(value);
    onConfirm && onConfirm(value);
  };

  return (
    <View style={{ flex: 1 }}>
      <Modal
        title="请选择结算方式"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        contentStyle={styles.contentStyle}
        headerLine={false}
        onMaskClose={() => {
          onCancel && onCancel();
        }}
        onRequestClose={() => {
          onCancel && onCancel();
        }}
      >
        {settleTypeList.map((item: any, index: number) => {
          const selected = settleTypeItem.settleType === item.settleType;
          return (
            <View key={item.id} style={{ width: '100%' }}>
              <TouchableOpacity
                activeOpacity={0.2}
                onPress={() => {
                  onModalConfirm(item.settleType);
                }}
              >
                <Flex direction="row">
                  <FlexItem style={styles.selectItem}>
                    <MBText align="center" color={selected ? 'primary' : ''} style={selected ? styles.selected : ''}>
                      {item.settleName}
                    </MBText>
                  </FlexItem>
                </Flex>
              </TouchableOpacity>
              {index !== settleTypeList.length - 1 && <Splitline />}
            </View>
          );
        })}
        <View style={styles.splitline}></View>
        <View style={{ width: '100%' }}>
          <TouchableOpacity
            onPress={() => {
              onCancel && onCancel();
            }}
          >
            <Flex direction="row">
              <FlexItem style={styles.selectItem}>
                <MBText align="center">取消</MBText>
              </FlexItem>
            </Flex>
          </TouchableOpacity>
        </View>
        <Whitespace vertical={20} />
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  contentStyle: {
    paddingHorizontal: 0,
  },

  selectItem: {
    height: 55,
    justifyContent: 'center',
  },

  splitline: {
    backgroundColor: '#F7F7F7',
    width: '100%',
    height: 10,
  },

  selected: {
    fontWeight: 'bold',
  },
});

export default ModalSettleType;
