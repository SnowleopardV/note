import { observable, action, computed } from 'mobx';
import server from '~/server/index';
import RegTest from '~/utils/RegTest';
import { xyzMath } from '~/utils/xyzMath';
import BaseStore from '~/extends/BaseStore';
import keyMap from '~/pages/dispatch/keyMap';
import dayjs from 'dayjs';

export interface RequestDateTime {
  startTimestamp: number;
  endTimestamp: number;
  displayValue: string; // 显示文案
  dateCode: string;
  timeInterval: number;
  hourPeriod: number;
}

export interface costMileageProps {
  loadAddressLatitude: number | string;
  loadAddressLongitude: number | string;
  unloadAddressLatitude: number | string;
  unloadAddressLongitude: number | string;
}

export interface operatorProps {
  id: number;
  name: string;
}

export interface dispatcherProps {
  tmsDispatcherId: number;
  tmsDispatcherName: string;
  tmsDispatcherPhone: string;
}

interface MoreInfoStoreModuleData {
  selectPlaceholder: string;
  inputPlaceholder: string;
}
interface MoreInfoStoreStateData {
  costMileage: string | null;
  operatorId: number | null;
  operatorName: string | null;
  customerOrderNo: string | null;
  isBilling: number | null;
  taxWay: number | null;
  billingRate: string | null;
  remark: string | null;
  tmsDispatcherId: number | null;
  tmsDispatcherName: string | null;
  tmsDispatcherPhone: string | null;
  dispatcherId: string | null;
  dispatcherName: string | null;
  dispatcherPhone: string | null;
  carLength: any;
  carType: any;
}

class MoreInfoStore extends BaseStore<MoreInfoStoreModuleData, MoreInfoStoreStateData> {
  constructor(props: any) {
    super(props);
    this.init();
  }

  init = () => {
    this.saveStateData({
      costMileage: null, // 线路里程
      operatorId: null, // 业务员id
      operatorName: null, // 业务员name
      customerOrderNo: null, // 客户单号（多个客户单号由逗号隔开）
      isBilling: null, // 是否开票，0否 1是
      taxWay: 1, // 计税方式，1包含税价 2不包含税价
      billingRate: null, // 税率，单位%
      remark: null, // 备注
      tmsDispatcherId: null, // 调度员id
      tmsDispatcherName: null, // 调度员name
      tmsDispatcherPhone: null, // 调度员电话
      dispatcherId: null,
      dispatcherName: null,
      dispatcherPhone: null,
      carLength: null,
      carType: null,
    });
    this.saveModuleData({
      selectPlaceholder: '请选择',
      inputPlaceholder: '请输入',
    });
  };
  // 业务员列表
  @observable operatorList: operatorProps[] = [];
  // 调度员列表
  @observable dispatcherList: dispatcherProps[] = [];
  // 未确定的更多信息
  @observable unsaveMoreInfoData: MoreInfoStoreStateData = {
    costMileage: null,
    operatorId: null,
    operatorName: null,
    customerOrderNo: null,
    isBilling: null,
    taxWay: 1,
    billingRate: null,
    remark: null,
    tmsDispatcherId: null,
    tmsDispatcherName: null,
    tmsDispatcherPhone: null,
    dispatcherId: null,
    dispatcherName: null,
    dispatcherPhone: null,
    carLength: null,
    carType: null,
  };
  // 车型车长
  @observable truckTypeLengthVisible: boolean = false;
  // 业务员弹窗
  @observable salesmanModalVisible: boolean = false;
  @observable isInvoiceModalVisible: boolean = false;
  @observable computeTaxModalVisible: boolean = false;
  @observable dispatcherModalVisible: boolean = false;
  @observable requiredConfig: any = {};
  @observable unsaveFeeList: any = [];

  // 根据应收费用和税率计算税金, 暂未确定时的税金展示。此处修改计算的化，请同步修改 taxFee ！！！！！！
  @computed get tax() {
    const {
      waybillCreateStore: {
        stateData: { feeList },
        editNotReceivable,
      },
    } = this.pageStore;

    const { billingRate, taxWay } = this.unsaveMoreInfoData;

    const newFeeList = [...feeList];
    // 筛选有值的费用
    const detailFeeList = newFeeList.filter((item: any) => item.amount);

    // 合计费用；脱敏*时为null
    let totalFee = null;
    if (!editNotReceivable) {
      totalFee = detailFeeList.reduce((total, item) => {
        if (item.isDeductionFee) {
          return xyzMath.subtract(total, item.amount);
        }
        return xyzMath.add(total, item.amount);
      }, 0);
    }

    // 当合计费用计算结果<=0时，税金修改为0元
    if (totalFee !== null && totalFee <= 0) {
      return 0;
    }

    // 税金 = 合计费用 * 税率, 费用脱敏*时税金为null
    let multiplyTax = null;
    // 税率值除以100
    const divideBillingRate = billingRate ? xyzMath.divide(billingRate, 100) : null;
    if (!editNotReceivable && totalFee) {
      // 应收合计含税
      if (taxWay === 1) {
        // 1＋适用税率
        const firstComputedValue = xyzMath.add(1, divideBillingRate);
        //  应付合计含税价÷（1＋适用税率）
        const secondComputedValue = divideBillingRate ? xyzMath.divide(totalFee, firstComputedValue) : null;
        // 税额 = 应付合计含税价÷（1＋适用税率）*税率
        multiplyTax = secondComputedValue ? xyzMath.multiply(secondComputedValue, divideBillingRate) : null;
      }

      // 应收合计不含税
      if (taxWay === 2) {
        multiplyTax = divideBillingRate ? xyzMath.multiply(totalFee, divideBillingRate) : null;
      }
    }
    // 税金去掉小数点后多余的0
    const handletax = multiplyTax ? multiplyTax.toFixed(2).replace(/[.]?0+$/, '') : null;

    return handletax;
  }

  // 临时保存费用数据，用于计算税金
  @action setUnsaveFeeLisList (feeList:[]) {
      this.unsaveFeeList = feeList
  };

  // 用于改变运费时实时显示税金
  @computed get taxFee() {
    const {
      waybillCreateStore: {
        stateData: { feeList },
        editNotReceivable,
      },
    } = this.pageStore;

    const { billingRate, taxWay } = this.unsaveMoreInfoData;

    const newFeeList = [...this.unsaveFeeList];
    // 筛选有值的费用
    const detailFeeList = newFeeList.filter((item: any) => item.amount);

    // 合计费用；脱敏*时为null
    let totalFee = null;
    if (!editNotReceivable) {
      totalFee = detailFeeList.reduce((total, item) => {
        if (item.isDeductionFee) {
          return xyzMath.subtract(total, item.amount);
        }
        return xyzMath.add(total, item.amount);
      }, 0);
    }

    // 当合计费用计算结果<=0时，税金修改为0元
    if (totalFee !== null && totalFee <= 0) {
      return 0;
    }

    // 税金 = 合计费用 * 税率, 费用脱敏*时税金为null
    let multiplyTax = null;
    // 税率值除以100
    const divideBillingRate = billingRate ? xyzMath.divide(billingRate, 100) : null;
    if (!editNotReceivable && totalFee) {
      // 应收合计含税
      if (taxWay === 1) {
        // 1＋适用税率
        const firstComputedValue = xyzMath.add(1, divideBillingRate);
        //  应付合计含税价÷（1＋适用税率）
        const secondComputedValue = divideBillingRate ? xyzMath.divide(totalFee, firstComputedValue) : null;
        // 税额 = 应付合计含税价÷（1＋适用税率）*税率
        multiplyTax = secondComputedValue ? xyzMath.multiply(secondComputedValue, divideBillingRate) : null;
      }

      // 应收合计不含税
      if (taxWay === 2) {
        multiplyTax = divideBillingRate ? xyzMath.multiply(totalFee, divideBillingRate) : null;
      }
    }
    // 税金去掉小数点后多余的0
    const handletax = multiplyTax ? multiplyTax.toFixed(2).replace(/[.]?0+$/, '') : null;

    return handletax;
  }

  // 开单时间为进入创建运单页的本地时间
  @computed get pointBillingTime() {
    const {
      waybillCreateStore: {
        stateData: { pointBillingTime },
      },
    } = this.pageStore;

    return pointBillingTime;
  }

  @computed get displayMoreInfoText() {
    let str: string = '';
    // 取已确定填写的税率计算出的税金显示
    const {
      waybillCreateStore: { updateTax, editNotReceivable },
    } = this.pageStore;
    const { isBilling, billingRate, customerOrderNo, operatorName, tmsDispatcherName, costMileage, remark } = this.stateData;
    // 展示排序
    const fllterParams = {
      // isBilling,
      // billingRate: !editNotReceivable ? billingRate : '*', // 禁止查看费用时脱敏展示
      // tax: !editNotReceivable ? updateTax : '*', // 禁止查看费用时脱敏展示
      customerOrderNo,
      operatorName,
      tmsDispatcherName,
      costMileage,
      billingTime: this.pointBillingTime,
      remark,
    };
    const list = this.objToArr(fllterParams);

    str = list.reduce((total: string, item: any, index: number) => {
      const semi = !item || index === list.length - 1 ? '' : ',';
      return total + item + semi;
    }, '');
    return str;
  }

  objToArr = (obj: any) => {
    const arr = [];
    for (const key of Object.keys(obj)) {
      let value = '';
      const isValueNull = obj[key] === null;

      // if (key === 'isBilling') {
      //   value = isValueNull ? '' : obj[key] === 1 ? '开票' : '不开票';
      // } else if (key === 'billingRate') {
      //   value = isValueNull ? '' : obj.isBilling === 1 ? `税率: ${obj[key]}%` : '';
      // } else if (key === 'tax') {
      //   value = isValueNull ? '' : obj.isBilling === 1 ? `税金: ${obj[key]}元` : '';
      // } else 
      
      if (key === 'billingTime') {
        value = isValueNull ? '' : dayjs(obj[key]).format('YYYY-MM-DD HH:mm:ss');
      } else if (key === 'costMileage') {
        value = isValueNull ? '' : `${obj[key]} 公里`;
      } else {
        value = isValueNull ? '' : obj[key];
      }

      if (value) arr.push(value);
    }
    return arr;
  };

  // 获取业务员
  @action
  getOperatorList = async () => {
    const url = '/saas-permission-app/yzgApp/permission/buttOperator';
    const res = await server({ url, data: {} });

    if (res.success) {
      this.operatorList = res.data;
    }
  };

  // 获取调度员
  @action
  getDispatcherList = async () => {
    const url = '/saas-permission-app/yzgApp/employee/dispatcherList';
    const res = await server({ url, data: {} });

    if (res.success) {
      this.dispatcherList = res.data;
    }
  };

  // 获取平台车型
  @action
  getTruckTypeList = async (params: any) => {
    if (Object.keys(keyMap.carTypePlate).length) {
      return;
    }
    const url = '/saas-tms-trans/yzgApp/capacity/getTruckTypes';
    const res = await server({ url, data: { ...params } }, { showLoading: false });
    if (res.success && res.data) {
      const carType: any = {};
      for (const item of res.data) {
        carType[item.typeId] = item.typeName;
      }
      keyMap.carTypePlate = carType; // 修改 枚举里的值
    }
  };

  // 获取平台车长
  @action
  getTruckLengthList = async (params: any) => {
    if (Object.keys(keyMap.carLengthPlate).length) {
      return;
    }
    const url = '/saas-tms-trans/yzgApp/capacity/getTruckLengths';
    const res = await server({ url, data: { ...params } }, { showLoading: false });

    if (res.success && res.data) {
      const carLength: any = {};
      for (const item of res.data) {
        carLength[item.lengthId] = item.lengthName;
      }
      keyMap.carLengthPlate = carLength; // 修改 枚举里的值
    }
  };

  @action
  onChangeCostMileage = (value: string) => {
    const valueArr = value.split('.')[0];
    if (valueArr.length > 9) return;
    if (!RegTest.twoPrecision(value) && value) return;
    if (RegTest.emoji(value)) return;

    this.unsaveMoreInfoData.costMileage = value;
  };

  @action
  onChangeCustomerOrderNo = (value: string) => {
    if (RegTest.emoji(value)) return;

    this.unsaveMoreInfoData.customerOrderNo = value;
  };

  @action
  changeTruckTypeLengthModalVisible = () => {
    const visible = this.truckTypeLengthVisible;
    this.truckTypeLengthVisible = !visible;
  };

  @action
  changeSalesmanModalVisible = () => {
    const visible = this.salesmanModalVisible;
    this.salesmanModalVisible = !visible;
  };

  @action
  changeDispatcherModalVisible = () => {
    const visible = this.dispatcherModalVisible;
    this.dispatcherModalVisible = !visible;
  };

  @action
  changeIsInvoiceModalVisible = () => {
    const visible = this.isInvoiceModalVisible;
    this.isInvoiceModalVisible = !visible;
  };

  @action
  changeComputeTaxModalVisible = () => {
    const visible = this.computeTaxModalVisible;
    this.computeTaxModalVisible = !visible;
  };

  @action
  handleCarTypeLengthChange = (val: any) => {
    if (val) {
      const carType = val.carType.map((item: any) => item.id); // 车型
      const carLength = val.carLength.map((item: any) => item.id); // 车长
      if (carType.length) {
        this.unsaveMoreInfoData.carType = carType[0];
      }
      if (carLength.length) {
        this.unsaveMoreInfoData.carLength = carLength[0];
      }
    }
    this.changeTruckTypeLengthModalVisible();
  };

  @action
  onConfirmSalesmanModal = (salesmanItem: operatorProps) => {
    const { id, name } = salesmanItem;
    if (id) {
      this.unsaveMoreInfoData.operatorId = id;
    }
    if (name) {
      this.unsaveMoreInfoData.operatorName = name;
    }
    this.changeSalesmanModalVisible();
  };

  @action
  onConfirmDispatcherModal = (dispatcherItem: dispatcherProps) => {
    const { tmsDispatcherId, tmsDispatcherName, tmsDispatcherPhone } = dispatcherItem;
    this.unsaveMoreInfoData.tmsDispatcherId = tmsDispatcherId;
    this.unsaveMoreInfoData.tmsDispatcherName = tmsDispatcherName;
    this.unsaveMoreInfoData.tmsDispatcherPhone = tmsDispatcherPhone;
    this.changeDispatcherModalVisible();
  };

  @action
  onConfirmIsInvoiceModal = (type: number) => {
    this.unsaveMoreInfoData.isBilling = type;
    this.changeIsInvoiceModalVisible();
    this.onConfirm() // 是否开票保存数据
  };

  @action
  onConfirmComputeTaxModal = (type: number) => {
    this.unsaveMoreInfoData.taxWay = type;
    this.changeComputeTaxModalVisible();
    this.onConfirm() // 计税方式保存数据
  };

  @action
  onChangeBillingRate = (value: string) => {
    if (!RegTest.zeroHundredTwoPrecision(value) && value) return;
    if (RegTest.emoji(value)) return;

    this.unsaveMoreInfoData.billingRate = value;
    this.onConfirm() // 税率数据保存
  };

  @action
  onChangeRemark = (value: string) => {
    this.unsaveMoreInfoData.remark = value;
  };

  // @action
  // onChangeBillingTime = (value: any) => {
  //   this.unsaveMoreInfoData.billingTime = value;
  // };

  // 点击返回不保存修改值，点击确定时保存
  @action
  onConfirm = (type: string = '') => {
    if (type === 'goback') {
      this.unsaveMoreInfoData = { ...this.stateData };
    } else {
      this.stateData = { ...this.unsaveMoreInfoData };
    }
  };

  @action
  saveStateData = (stateData: MoreInfoStoreStateData) => {
    if (stateData && Object.keys(stateData).length) {
      const { tmsDispatcherId, tmsDispatcherName, tmsDispatcherPhone } = this.stateData;
      const handleDispatcherInfo = {
        tmsDispatcherId: stateData.tmsDispatcherId || tmsDispatcherId,
        tmsDispatcherName: stateData.dispatcherName || tmsDispatcherName,
        tmsDispatcherPhone: stateData.dispatcherPhone || tmsDispatcherPhone,
      };
      this.stateData = {
        ...this.stateData,
        ...handleDispatcherInfo,
        ...stateData,
      };
      this.unsaveMoreInfoData = {
        ...this.unsaveMoreInfoData,
        ...handleDispatcherInfo,
        ...stateData,
      };
    }
  };
}

export default MoreInfoStore;
