import React from 'react';
import { inject, observer } from 'mobx-react';
import { StyleSheet, Image, View, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { CellGroup, MBText, Whitespace } from '@ymm/rn-elements';
import { MBToast } from '@ymm/rn-lib';
import dayjs from 'dayjs';
import Cell from '~/components/common/Cell';
import InputItem from '~/components/common/InputItem';
import Remark from '~/components/common/Remark';
import ModalCarTypeLength from '~/pages/dispatch/components/ModalCarTypeLength';
import ModalSalesman from './ModalSalesman';
import ModalDispatcher from './ModalDispatcher';
import MoreInfoStore from '../store';
import WaybillCreateStore from '../../create/store';
import keyMap from '~/pages/dispatch/keyMap';
import ModalPickupType from '../../create/components/ModalPickupType';

interface MoreInfoContentProps {
  waybillCreateStore: WaybillCreateStore;
  moreInfoStore: MoreInfoStore;
  navigation: any;
  keyBoardHeight: number;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
}

@inject('waybillCreateStore', 'moreInfoStore')
@observer
class MoreInfoContent extends React.Component<MoreInfoContentProps, any> {
  refScrollView: ScrollView | null = null;
  refScrollLayout: any;
  scrollViewHeight: number = 0;
  remarkLayout: any;
  constructor(props: MoreInfoContentProps) {
    super(props);
  }

  componentDidMount() {
    const {
      moreInfoStore: { getOperatorList, getDispatcherList },
    } = this.props;
    // 获取业务员
    getOperatorList();
    // 获取调度员
    getDispatcherList();
  }

  rightElement = (extraValue: string, readonly?: boolean) => {
    return <MBText style={[styles.itemUnit, readonly ? { color: '#ccc' } : {}]}>{extraValue}</MBText>;
  };

  onLeftClick = () => {
    const {
      navigation,
      moreInfoStore: { onConfirm },
    } = this.props;
    onConfirm && onConfirm('goback');
    navigation.goBack();
  };
  remarkFocus = () => {
    const { onCommonFocus } = this.props;
    onCommonFocus && onCommonFocus();
    setTimeout(() => {
      if (Platform.OS == 'ios') {
        const { y, height } = this.remarkLayout;
        const scrollY = this.refScrollLayout?.contentOffset?.y || 0;
        const viewHeight = this.scrollViewHeight - this.props.keyBoardHeight - height - 40;
        const isScroll = y > scrollY + viewHeight;
        if (isScroll) {
          this.refScrollView?.scrollTo({ y: y - viewHeight });
        }
      }
    }, 650);
  };

  // 提货方式枚举过滤
  filterPickupType = () => {
    const {
      waybillCreateStore: {
        stateData:{ loadMode },
      }
    } = this.props
    let handlePickupType;
      switch (loadMode) {
        case 2:
          handlePickupType = '否';
          break;
        case 1:
          handlePickupType = '是';
          break;
        default:
          handlePickupType = '';
          break;
      }
      return handlePickupType;
  };

  renderContent() {
    const {
      navigation,
      waybillCreateStore: {
        editEnum,
        editNotReceivable,
        onChangeReceiptCount,
        stateData:{ receiptCount, loadMode,taskType },
        requiredConfig: { customerOrderNoIsRequired, salesmanIdIsRequired, tmsDispatcherIdIsRequired, remarkIsRequired },
        pickupTypeModalVisible,
        changePickupTypeModalVisible,
        onConfirmPickupTypeModal
      },
      moreInfoStore: {
        unsaveMoreInfoData: {
          costMileage,
          operatorId,
          operatorName,
          customerOrderNo,
          remark,
          tmsDispatcherId,
          tmsDispatcherName,
          tmsDispatcherPhone,
          carType,
          carLength,
        },
        operatorList,
        dispatcherList,
        pointBillingTime,
        truckTypeLengthVisible,
        salesmanModalVisible,
        dispatcherModalVisible,
        onChangeCostMileage,
        onChangeCustomerOrderNo,
        changeSalesmanModalVisible,
        changeTruckTypeLengthModalVisible,
        changeDispatcherModalVisible,
        handleCarTypeLengthChange,
        onConfirmSalesmanModal,
        onConfirmDispatcherModal,
        onChangeRemark,
      },
      onCommonFocus,
      onCommonBlur,
    } = this.props;
    const { isEdit } = navigation.state.params;

    let dispatcherName = '';
    if (tmsDispatcherName && tmsDispatcherPhone) {
      dispatcherName = `${tmsDispatcherName}-${tmsDispatcherPhone}`;
    } else if (tmsDispatcherName && !tmsDispatcherPhone) {
      dispatcherName = tmsDispatcherName;
    } else if (!tmsDispatcherName && tmsDispatcherPhone) {
      dispatcherName = tmsDispatcherPhone;
    } else {
      dispatcherName = '';
    }

    const carTypeText = !!carType ? keyMap.carTypePlate[carType] || '' : '';
    const carLengthText = !!carLength ? keyMap.carLengthPlate[carLength] || '' : '';
    const carTypeLength = carTypeText + (carTypeText ? ' / ' + carLengthText : carLengthText) || '';
    const carTypePlateLength = Object.keys(keyMap.carTypePlate).length;
    const carLengthPlateLength = Object.keys(keyMap.carLengthPlate).length;

    return (
      <View>
        <Whitespace vertical={10} />
        <CellGroup withBottomLine>
          <InputItem
            title="线路里程"
            placeholder="请输入"
            keyboardType="numeric"
            maxLength={9}
            value={costMileage ? costMileage + '' : ''}
            onChangeText={onChangeCostMileage}
            textAlign="right"
            extraNode={this.rightElement('公里')}
            onFocus={() => {
              onCommonFocus && onCommonFocus();
            }}
            onBlur={() => {
              onCommonBlur && onCommonBlur();
            }}
          />
          <Cell
            name="pointBillingTime"
            title="开单时间"
            align="right"
            numberOfLines={1}
            value={pointBillingTime ? dayjs(pointBillingTime).format('YYYY-MM-DD HH:mm:ss') : ''}
            onPress={() => {
              MBToast.show('暂不支持修改，可前往运掌柜pc端进行修改');
            }}
          />
        </CellGroup>
        <Whitespace vertical={10} />
        <CellGroup withBottomLine>
          <InputItem
            title="客户单号"
            placeholder="请输入"
            maxLength={200}
            required={!!customerOrderNoIsRequired}
            keyboardType={Platform.OS == 'ios' ? 'numbers-and-punctuation' : 'numeric'}
            value={customerOrderNo}
            onChangeText={onChangeCustomerOrderNo}
            textAlign="right"
            onFocus={() => {
              onCommonFocus && onCommonFocus();
            }}
            onBlur={() => {
              onCommonBlur && onCommonBlur();
            }}
          />
          <Cell
            name="truckTypeLength"
            title="需求车型车长"
            align="right"
            value={carTypeLength}
            placeholder="请选择"
            onPress={changeTruckTypeLengthModalVisible}
          />
        </CellGroup>
        <Whitespace vertical={10} />
        <CellGroup withBottomLine>
          <Cell
            name="pickupType"
            title="提货"
            align="right"
            readonly={editEnum === 'THREE' || (isEdit && loadMode === 1 && taskType === '1')}
            value={this.filterPickupType()}
            placeholder="请选择"
            onPress={changePickupTypeModalVisible}
          />
          <Cell
            name="operatorId"
            title="业务员"
            align="right"
            required={!!salesmanIdIsRequired}
            value={operatorName}
            placeholder="请选择"
            onPress={changeSalesmanModalVisible}
          />
          <Cell
            name="dispatcher"
            title="调度员"
            required={!!tmsDispatcherIdIsRequired}
            align="right"
            value={dispatcherName}
            placeholder="请选择"
            onPress={changeDispatcherModalVisible}
          />
          <InputItem
            title="回单数量"
            placeholder="请输入"
            keyboardType="numeric"
            maxLength={9}
            textAlign="right"
            value={receiptCount?.toString()}
            onChangeText={onChangeReceiptCount}
            onFocus={() => {
              onCommonFocus && onCommonFocus();
            }}
            onBlur={() => {
              onCommonBlur && onCommonBlur();
            }}
          />
        </CellGroup>
        <Whitespace vertical={10} />
        <View onLayout={(el) => (this.remarkLayout = el.nativeEvent.layout)}>
          <CellGroup withBottomLine>
            <Remark
              value={remark || undefined}
              onChangeText={onChangeRemark}
              required={!!remarkIsRequired}
              onFocus={() => this.remarkFocus()}
              onBlur={() => {
                onCommonBlur && onCommonBlur();
              }}
            />
          </CellGroup>
        </View>

        {!!carTypePlateLength && !!carLengthPlateLength ? (
          <ModalCarTypeLength
            visible={truckTypeLengthVisible}
            onChange={handleCarTypeLengthChange}
            item={{ platformCarType: carType ? [carType] : [], platformCarLength: carLength ? [carLength] : [] }}
          />
        ) : null}

        <ModalSalesman
          visible={salesmanModalVisible}
          operatorList={operatorList}
          operatorId={operatorId}
          onConfirm={onConfirmSalesmanModal}
          onCancel={changeSalesmanModalVisible}
        />

        <ModalDispatcher
          visible={dispatcherModalVisible}
          dispatcherList={dispatcherList}
          dispatcherId={tmsDispatcherId}
          onConfirm={onConfirmDispatcherModal}
          onCancel={changeDispatcherModalVisible}
        />
        <ModalPickupType
          visible={pickupTypeModalVisible}
          loadMode={loadMode}
          onConfirm={onConfirmPickupTypeModal}
          onCancel={changePickupTypeModalVisible}
        />
      </View>
    );
  }
  render() {
    const { keyBoardHeight } = this.props;
    return (
      <ScrollView
        ref={(el) => (this.refScrollView = el)}
        onScroll={(event) => (this.refScrollLayout = event.nativeEvent)}
        scrollEventThrottle={200}
        onLayout={(el) => (this.scrollViewHeight = el.nativeEvent.layout.height)}
        keyboardShouldPersistTaps="handled"
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        style={{ flex: 1 }}
      >
        <View style={{ flex: 1 }}>{this.renderContent()}</View>
        <Whitespace vertical={keyBoardHeight + 40} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  inner: {
    flex: 1,
    paddingBottom: 40,
  },

  itemUnit: {
    marginLeft: 4,
    marginRight: 16,
    color: '#666666',
  },

  itemArrow: {
    width: 8,
    height: 14,
  },

  taxValueStyle: {
    marginRight: 0,
  },
});

export default MoreInfoContent;
