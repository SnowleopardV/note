import React, { useState } from 'react';
import { SafeAreaView, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalIsInvoice = (props: any) => {
  const { visible, onConfirm, onCancel, isInvoice } = props;
  const [isInvoiceList, setIsInvoiceList] = useState<any[]>([
    {
      isInvoice: 1,
      isInvoiceName: '是',
      content: (selected: boolean) => {
        return (
          <Flex direction="row" justify="center" align="center">
            <MBText bold={selected} color={selected ? 'primary' : 'base'} size={selected ? 'md' : 'sm'} numberOfLines={1}>
              是
            </MBText>
          </Flex>
        );
      },
    },
    {
      isInvoice: 0,
      isInvoiceName: '否',
      content: (selected: boolean) => {
        return (
          <Flex direction="row" justify="center" align="center">
            <MBText bold={selected} color={selected ? 'primary' : 'base'} size={selected ? 'md' : 'sm'} numberOfLines={1}>
              否
            </MBText>
          </Flex>
        );
      },
    },
  ]);
  const [isInvoiceItem, setIsInvoiceItem] = useState<any>(() => {
    const lastIsInvoiceArr = isInvoiceList.filter((item) => item.isInvoice === isInvoice);
    return lastIsInvoiceArr.length ? lastIsInvoiceArr[0] : { isInvoice: 1 };
  });

  // 筛选默认选中索引
  let lastPackIndex = 0;
  isInvoiceList.forEach((item, index) => {
    if (item.isInvoice === isInvoice) {
      lastPackIndex = index;
    }
  });

  const onModalConfirm = () => {
    const { isInvoice } = isInvoiceItem;

    onConfirm && onConfirm(isInvoice);
  };

  const handleChangeIsInvoice = (position: number, value: string) => {
    setIsInvoiceItem(value);
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请选择是否开票"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={() => {
          onCancel && onCancel();
        }}
        onMaskClose={() => {
          onCancel && onCancel();
        }}
        onRequestClose={() => {
          onCancel && onCancel();
        }}
      >
        <Flex direction="row" justify="center">
          <FlexItem>
            <Selector
              scaleFont={true}
              value={lastPackIndex}
              rowTitle="content"
              list={isInvoiceList}
              onChange={(position: number, value: string) => {
                handleChangeIsInvoice(position, value);
              }}
            />
          </FlexItem>
        </Flex>
        <Whitespace vertical={40} />
      </Modal>
    </SafeAreaView>
  );
};

export default ModalIsInvoice;
