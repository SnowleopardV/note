import React, { useState, useEffect } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';
import MBSearchInput from '~/components/common/MBSearchInput';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

const FlexItem = Flex.Item;

const ModalSalesman = (props: any) => {
  const { visible, onConfirm, onCancel, operatorList, operatorId } = props;
  const [salesmanItem, setSalesmanItem] = useState<any>(() => {
    return operatorList.length ? operatorList[0] : {};
  });
  const [salesmanList, setSalesmanList] = useState<any>(operatorList);
  const [keyword, setKeyword] = useState<any>('');
  const [lastOperatorIndex, setLastOperatorIndex] = useState<any>(0);

  useEffect(() => {
    setSalesmanList(() => {
      return operatorList.length ? operatorList : [];
    });
  }, [operatorId, operatorList.length]);

  useEffect(() => {
    setSalesmanItem(() => {
      const lastSalesmanArr = operatorList.filter((item: any) => item.id === operatorId);
      return lastSalesmanArr.length ? lastSalesmanArr[0] : operatorList.length ? operatorList[0] : {};
    });
  }, [operatorId, operatorList.length]);

  useEffect(() => {
    operatorList.forEach((item: any, index: number) => {
      if (item.id === operatorId) {
        setLastOperatorIndex(index);
      }
    });
  }, [operatorId, operatorList.length]);

  useEffect(() => {
    // 筛选出没值
    if (!salesmanList.length) {
      if (operatorId) {
        // 1、operatorId存在, 点击确定带入上一次值
        operatorList.forEach((item: any, index: number) => {
          if (item.id === operatorId) {
            setLastOperatorIndex(index);
            setSalesmanItem(item);
          }
        });
      } else {
        // 2、operatorId不存在, 点击确定返回空
        setLastOperatorIndex(0);
        setSalesmanItem({});
      }
    } else {
      if (operatorId) {
        // 1、operatorId存在&在筛选的salesmanList数组里, 点击确定带入上一次值
        const lastSalesmanArr = salesmanList.filter((item: any) => item.id === operatorId);
        if (lastSalesmanArr.length) {
          salesmanList.forEach((item: any, index: number) => {
            if (item.id === operatorId) {
              setLastOperatorIndex(index);
              setSalesmanItem(item);
            }
          });
        } else {
          setLastOperatorIndex(0);
          setSalesmanItem(salesmanList[0]);
        }
      } else {
        // 2、operatorId不存在, 点击确定返回空
        setLastOperatorIndex(0);
        setSalesmanItem(salesmanList[0]);
      }
    }
  }, [salesmanList, salesmanList.length]);

  const onModalConfirm = () => {
    setKeyword('');
    if (operatorList.length) {
      setSalesmanList(operatorList);
    }

    onConfirm && onConfirm(salesmanItem);
  };

  const onModalCancel = () => {
    setKeyword('');
    if (operatorList.length) {
      setSalesmanList(operatorList);
    }
    onCancel && onCancel();
  };

  const handleChangeSalesman = (value: any) => {
    setSalesmanItem(value);
  };

  const onChangeText = (value: string) => {
    setKeyword(value);
    let filterOperatorList = operatorList;
    if (!!value) {
      filterOperatorList = operatorList.filter((item: any) => item.name.includes(value));
    }
    setSalesmanList(filterOperatorList);
  };

  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      headerLeft="取消"
      headerRight={rightElement()}
      title="请选择业务员"
      position="bottom"
      visible={visible}
      autoAdjustPosition={true}
      headerLine={false}
      onConfirm={onModalConfirm}
      onCancel={onModalCancel}
      onMaskClose={onModalCancel}
      onRequestClose={onModalCancel}
    >
      <View style={styles.content}>
        <MBSearchInput parentStyle={styles.searchStyle} initialText={keyword} onChangeText={onChangeText} placeholder="输入业务员" />
        <Flex direction="row" justify="center">
          {salesmanList.length ? (
            <FlexItem>
              <Selector
                scaleFont={true}
                value={lastOperatorIndex}
                rowTitle="name"
                type={2}
                list={salesmanList}
                onChange={(position, value) => {
                  handleChangeSalesman(value);
                }}
              />
            </FlexItem>
          ) : (
            <View>
              <Whitespace vertical={40} />
              <MBText color="#999999">暂无数据</MBText>
            </View>
          )}
        </Flex>
        <Whitespace vertical={40} />
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  content: {
    width: '100%',
  },

  searchStyle: {
    borderRadius: autoFix(10),
  },
});

export default ModalSalesman;
