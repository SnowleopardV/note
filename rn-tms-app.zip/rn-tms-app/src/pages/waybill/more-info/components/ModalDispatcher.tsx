import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity, Text } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';
import MBSearchInput from '~/components/common/MBSearchInput';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

const FlexItem = Flex.Item;

const ModalDispatcher = (props: any) => {
  const { visible, onConfirm, onCancel, dispatcherList, dispatcherId } = props;
  const [dispatcherItem, setDispatcherItem] = useState<any>(() => {
    return dispatcherList.length ? dispatcherList[0] : {};
  });
  const handleDispatcherList = dispatcherList.map((item: any) => {
    const { tmsDispatcherName, tmsDispatcherPhone } = item;
    let displayValue = '';
    if (tmsDispatcherName && tmsDispatcherPhone) {
      displayValue = `${tmsDispatcherName}-${tmsDispatcherPhone}`;
    } else if (tmsDispatcherName && !tmsDispatcherPhone) {
      displayValue = tmsDispatcherName;
    } else if (!tmsDispatcherName && tmsDispatcherPhone) {
      displayValue = tmsDispatcherPhone;
    } else {
      displayValue = '';
    }

    item.displayValue = displayValue;

    return item;
  });
  const [list, setList] = useState<any>(handleDispatcherList);
  const [keyword, setKeyword] = useState<any>('');
  const [lastIndex, setLastIndex] = useState<any>(0);

  useEffect(() => {
    setList(() => {
      return handleDispatcherList.length ? handleDispatcherList : [];
    });
  }, [dispatcherId, handleDispatcherList.length]);

  useEffect(() => {
    setDispatcherItem(() => {
      const lastDispatcherArr = handleDispatcherList.filter((item: any) => item.tmsDispatcherId === dispatcherId);
      return lastDispatcherArr.length ? lastDispatcherArr[0] : handleDispatcherList.length ? handleDispatcherList[0] : {};
    });
  }, [dispatcherId, handleDispatcherList.length]);

  useEffect(() => {
    list.forEach((item: any, index: number) => {
      if (item.tmsDispatcherId === dispatcherId) {
        setLastIndex(index);
      }
    });
  }, [dispatcherId, handleDispatcherList.length]);

  useEffect(() => {
    console.log(list.length, dispatcherId, '----dispatcherId---');
    // 筛选出没值
    if (!list.length) {
      if (dispatcherId) {
        // 1、dispatcherId存在, 点击确定带入上一次值
        dispatcherList.forEach((item: any, index: number) => {
          if (item.tmsDispatcherId === dispatcherId) {
            setLastIndex(index);
            setDispatcherItem(item);
          }
        });
      } else {
        // 2、operatorId不存在, 点击确定返回空
        setLastIndex(0);
        setDispatcherItem({});
      }
    } else {
      if (dispatcherId) {
        // 1、operatorId存在&在筛选的list数组里, 点击确定带入上一次值
        const lastListArr = list.filter((item: any) => item.tmsDispatcherId === dispatcherId);
        if (lastListArr.length) {
          list.forEach((item: any, index: number) => {
            if (item.tmsDispatcherId === dispatcherId) {
              setLastIndex(index);
              setDispatcherItem(item);
            }
          });
        } else {
          setLastIndex(0);
          setDispatcherItem(list[0]);
        }
      } else {
        // 2、operatorId不存在, 点击确定返回空
        setLastIndex(0);
        setDispatcherItem(list[0]);
      }
    }
  }, [list, list.length]);

  const onModalConfirm = () => {
    setKeyword('');
    if (handleDispatcherList.length) {
      setList(handleDispatcherList);
    }
    onConfirm && onConfirm(dispatcherItem);
  };

  const onModalCancel = () => {
    setKeyword('');
    if (handleDispatcherList.length) {
      setList(handleDispatcherList);
    }
    onCancel && onCancel();
  };

  const handleChangeDispatcher = (value: any) => {
    console.log(value, '---------888----');
    setDispatcherItem(value);
  };

  const onChangeText = (value: string) => {
    setKeyword(value);
    let filterList = handleDispatcherList;
    if (!!value) {
      filterList = handleDispatcherList.filter((item: any) => item.displayValue.includes(value));
    }
    setList(filterList);
  };

  const rightElement = (
    <TouchableOpacity activeOpacity={0.8} onPress={onModalConfirm}>
      <View style={styles.textWrap}>
        <MBText color="primary" style={[styles.confirmText, !dispatcherList.length && styles.confirmTextDisabled]}>
          确定
        </MBText>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement}
        title="请选择调度员"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
      >
        <View style={styles.content}>
          <MBSearchInput parentStyle={styles.searchStyle} initialText={keyword} onChangeText={onChangeText} placeholder="输入调度员" />
          <Flex direction="row" justify="center">
            {list.length ? (
              <FlexItem>
                <Selector
                  scaleFont={true}
                  value={lastIndex}
                  rowTitle="displayValue"
                  type={2}
                  list={list}
                  onChange={(position, value) => {
                    handleChangeDispatcher(value);
                  }}
                />
              </FlexItem>
            ) : (
              <View>
                <Whitespace vertical={40} />
                <MBText color="#999999">暂无数据</MBText>
              </View>
            )}
          </Flex>
          <Whitespace vertical={40} />
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create<any>({
  content: {
    width: '100%',
  },

  searchStyle: {
    borderRadius: autoFix(10),
  },

  confirmText: {
    color: '#4885FF',
    fontSize: autoFix(32),
  },

  confirmTextDisabled: {
    color: '#CCCCCC',
    fontSize: autoFix(32),
  },

  textWrap: {
    paddingVertical: autoFix(20),
    paddingLeft: autoFix(20),
  },
});

export default ModalDispatcher;
