import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, MBText } from '@ymm/rn-elements';

export interface MoreInfoFooterProps {
  onConfirm: () => void;
}

const MoreInfoFooter = (props: MoreInfoFooterProps) => (
  <View style={styles.footer}>
    <Button type="primary" size="sm" radius style={styles.itemBtn} onPress={props.onConfirm}>
      <MBText color="#fff">确定</MBText>
    </Button>
  </View>
);

const styles = StyleSheet.create<any>({
  footer: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    flexDirection: 'row',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },

  itemBtn: {
    flex: 1,
  },
});

export default MoreInfoFooter;
