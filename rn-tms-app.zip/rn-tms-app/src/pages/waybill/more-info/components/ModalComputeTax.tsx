import React, { useState } from 'react';
import { SafeAreaView, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const contentElement = (selected: boolean, text: string) => {
  return (
    <Flex direction="row" justify="center" align="center">
      <MBText bold={selected} color={selected ? 'primary' : 'base'} size={selected ? 'md' : 'sm'} numberOfLines={1}>
        {text}
      </MBText>
    </Flex>
  );
};

const ModalComputeTax = (props: any) => {
  const { visible, onConfirm, onCancel, computeTax } = props;
  const [computeTaxList, setComputeTaxList] = useState<any[]>([
    {
      computeTax: 1,
      computeTaxName: '应收合计含税',
      content: (selected: boolean)=> contentElement(selected, '应收合计含税'),
    },
    {
      computeTax: 2,
      computeTaxName: '应收合计不含税',
      content: (selected: boolean)=> contentElement(selected, '应收合计不含税'),
    },
  ]);
  const [computeTaxItem, setComputeTaxItem] = useState<any>(() => {
    const lastComputeTaxArr = computeTaxList.filter((item) => item.computeTax === computeTax);
    return lastComputeTaxArr.length
      ? lastComputeTaxArr[0]
      : {
          computeTax: 1,
          computeTaxName: '应收合计含税',
          content: (selected: boolean)=> contentElement(selected, '应收合计含税'),
        };
  });

  // 筛选默认选中索引
  let lastPackIndex = 0;
  computeTaxList.forEach((item, index) => {
    if (item.computeTax === computeTax) {
      lastPackIndex = index;
    }
  });

  const onModalConfirm = () => {
    const { computeTax } = computeTaxItem;

    onConfirm && onConfirm(computeTax);
  };

  const handleChangeComputeTax = (position: number, value: string) => {
    setComputeTaxItem(value);
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请选择计税方式"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={() => {
          onCancel && onCancel();
        }}
        onMaskClose={() => {
          onCancel && onCancel();
        }}
        onRequestClose={() => {
          onCancel && onCancel();
        }}
      >
        <Flex direction="row" justify="center">
          <FlexItem>
            <Selector
              scaleFont={true}
              value={lastPackIndex}
              rowTitle="content"
              list={computeTaxList}
              onChange={(position: number, value: string) => {
                handleChangeComputeTax(position, value);
              }}
            />
          </FlexItem>
        </Flex>
        <Whitespace vertical={40} />
      </Modal>
    </SafeAreaView>
  );
};

export default ModalComputeTax;
