import React from 'react';
import { inject, observer } from 'mobx-react';
import { SafeAreaView, View, StyleSheet, Platform, BackHandler, Keyboard } from 'react-native';
import { LayProvider } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import MoreInfoContent from './components/MoreInfoContent';
import MoreInfoFooter from './components/MoreInfoFooter';
import { MBBridge, MBToast } from '@ymm/rn-lib';

export interface MoreInfoIndexProps {
  navigation: any;
  screenProps: any;
}

class MoreInfoIndex extends React.Component<MoreInfoIndexProps, any> {
  keyboardWillShowListener: any;
  keyboardWillHideListener: any;
  state = {
    showFooterBtn: true,
    isEdit: false,
    keyBoardHeight: 0,
  };
  timerBtn: any = null;
  backHandleListener: any;
  constructor(props: MoreInfoIndexProps) {
    super(props);
  }

  UNSAFE_componentWillMount = (): void => {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  };

  componentDidMount() {
    const { navigation } = this.props;
    const {
      screenProps: {
        pageStore: {
          moreInfoStore: { getTruckTypeList, getTruckLengthList },
        },
      },
    } = this.props;
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        navigation?.goBack();
        return true;
      });
    } else {
      this.keyboardWillShowListener = Keyboard.addListener('keyboardDidShow', (el) => this.onKeyboardDidShow(el));
      this.keyboardWillHideListener = Keyboard.addListener('keyboardDidHide', (el) => this.onKeyboardDidHide(el));
    }
    const { isEdit } = navigation.state.params;
    this.setState({ isEdit });

    // 获取平台车型
    getTruckTypeList({ toPlatform: true, queryType: 1 });
    // 获取平台车长
    getTruckLengthList({ toPlatform: true, queryType: 1 });
  }

  componentWillUnmount() {
    if (Platform.OS === 'android') {
      this.backHandleListener?.remove();
    } else {
      this.keyboardWillShowListener?.remove();
      this.keyboardWillHideListener?.remove();
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }
  onKeyboardDidShow(el: any): void {
    this.setState({ keyBoardHeight: el.endCoordinates.height });
  }

  onKeyboardDidHide(el: any): void {
    this.setState({ keyBoardHeight: 0 });
  }
  // 底部按钮 不能被键盘顶起
  onCommonBlurFocus = (val: boolean) => {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ showFooterBtn: val });
    }, 10);
  };

  // 更新运费匹配价格
  onUpdateFeeMatch = () => {
    const { isEdit } = this.state;
    const {
      screenProps: {
        pageStore: {
          waybillCreateStore: { updateFeeMatch },
        },
      },
    } = this.props;
    updateFeeMatch(isEdit);
  };

  onSubmit = (type: string) => {
    const {
      navigation,
      screenProps: {
        pageStore: {
          moreInfoStore: { onConfirm },
        },
      },
    } = this.props;

    if (type === 'goback') {
      onConfirm && onConfirm('goback');
      navigation.goBack();
    } else {
      const {
        screenProps: {
          pageStore: {
            waybillCreateStore: {
              requiredConfig: { customerOrderNoIsRequired, salesmanIdIsRequired, tmsDispatcherIdIsRequired, remarkIsRequired },
            },
            moreInfoStore: {
              unsaveMoreInfoData: { customerOrderNo, operatorId, tmsDispatcherId, remark },
            },
          },
        },
      } = this.props;

      if (customerOrderNoIsRequired && !customerOrderNo) {
        return MBToast.show('请输入客户单号');
      }

      if (salesmanIdIsRequired && !operatorId) {
        return MBToast.show('请选择业务员');
      }

      if (tmsDispatcherIdIsRequired && !tmsDispatcherId) {
        return MBToast.show('请选择调度员');
      }

      if (remarkIsRequired && !remark) {
        return MBToast.show('请输入备注信息');
      }

      onConfirm && onConfirm();
      this.onUpdateFeeMatch();
      navigation.goBack();
    }
  };

  render() {
    const { navigation } = this.props;

    const { showFooterBtn, keyBoardHeight } = this.state;
    return (
      <LayProvider theme="skyblue" style={styles.container}>
        <View style={styles.flexStyle}>
          <NavBar
            title="更多信息"
            leftClick={() => {
              this.onSubmit('goback');
            }}
          />
          <View style={styles.flexStyle}>
            <View style={styles.flexStyle}>
              <MoreInfoContent
                navigation={navigation}
                keyBoardHeight={keyBoardHeight}
                onCommonFocus={() => this.onCommonBlurFocus(false)}
                onCommonBlur={() => this.onCommonBlurFocus(true)}
              />
            </View>
            {showFooterBtn ? (
              <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}>
                <MoreInfoFooter
                  onConfirm={() => {
                    this.onSubmit('');
                  }}
                />
              </SafeAreaView>
            ) : null}
          </View>
        </View>
      </LayProvider>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },
});

export default inject('moreInfoStore')(observer(MoreInfoIndex));
