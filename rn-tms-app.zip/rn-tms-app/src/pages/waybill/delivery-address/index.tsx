import React from 'react';
import { View, StyleSheet, Image, Platform } from 'react-native';
import { Flex, MBText, Splitline, CellGroup, Whitespace, RNElementsUtil } from '@ymm/rn-elements';
import { URLUtils, MBBridge, MBLog } from '@ymm/rn-lib';
import Cell from '~/components/common/Cell';
import Images from '../../../../public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import { ContactType, UserModel } from '../customer/proptypes';
import { inject, observer } from 'mobx-react';
import DeliveryAddressStore, { ContactUser } from './store';
import TouchableThrottle from '~/components/TouchableThrottle';
import goodsInfoStore from '../goods-info/store';
import WaybillCreateStore from '../create/store';
import server from '~/server';
const FlexItem = Flex.Item;
const icon = 'https://image.ymm56.com/ymmfile/operation-biz/a0361c79-1f0e-4846-827d-4ee6a69a4cc3.png';

export interface DeliveryAddressProps {
  deliveryAddressStore?: DeliveryAddressStore;
  editEnum?: string;
  isFromSupplyWaybill?: boolean;
  goodsInfoStore: goodsInfoStore;
  waybillCreateStore: WaybillCreateStore;
  isEdit: boolean;
}
@inject('deliveryAddressStore', 'goodsInfoStore', 'waybillCreateStore')
@observer
export default class DeliveryAddress extends React.Component<DeliveryAddressProps, any> {
  get store() {
    return this.props.deliveryAddressStore!;
  }
  // listener: EmitterSubscription;
  constructor(props: DeliveryAddressProps) {
    super(props);
    this.state = {
      commonLabelList: [], // { selected: true, customerName: '客户名称', customerId: '' },
    };
  }
  componentDidMount(): void {
    this.api_customerLabel();
    this.store.getGoodsLabel(false);
    this.store.getAddressConfig();
  }
  componentWillUnmount(): void {
    this.store.init();
    // this.listener?.remove();
  }
  /**
   * 选择客户后回调
   * 历史地址也用该方法
   * @param user
   */
  confirmCustomer = async (user: any) => {
    const {
      stateData,
      getCostMileage,
      getCustomerHistoryInfo,
      addressRequiredConfig: { loadAddressConfig, unloadAddressConfig },
    } = this.store;

    const { updateFeeMatch } = this.props.waybillCreateStore;
    const { isFromSupplyWaybill, isEdit } = this.props;
    // 填充数据
    const customerId = user.customerId || this.store.stateData.customerId;
    const customerName = user.customerName || this.store.stateData.customerName;
    const contactList = [
      (!loadAddressConfig && user.shipper) || (loadAddressConfig && !!Number(user.shipper?.longitude) && !!Number(user.shipper?.latitude))
        ? user.shipper
        : stateData.contactList[0],
      (!unloadAddressConfig && user.consignee) ||
      (unloadAddressConfig && !!Number(user.consignee?.longitude) && !!Number(user.consignee?.latitude))
        ? user.consignee
        : stateData.contactList[1],
    ];
    this.store.saveStateData({
      customerId: customerId,
      customerName: customerName,
      contactList: contactList,
    });
    // 根据发货人获取客户信息：结算方式、是否开票、税率、对接业务员，作为默认显示
    getCustomerHistoryInfo();

    // 根据收发货地址经纬度获取货物历史订单、历史线路里程
    // getCargoList();
    // getCargoNameList();
    await getCostMileage();
    //只有选择客户的时候才可调用, 补录不执行以下方法
    if (user.origin === 'customer' && !isFromSupplyWaybill) {
      this.props.goodsInfoStore.customerCallback(user, () => {
        // 更新自动匹配运费价格
        updateFeeMatch(isEdit);
      });
    } else {
      // 更新自动匹配运费价格
      updateFeeMatch(isEdit);
    }
    //查询货物标签
    this.store.getGoodsLabel(isFromSupplyWaybill ?? false);
  };

  jump = (contactType: ContactType) => {
    const { isFromSupplyWaybill } = this.props;
    const {
      sensitiveWordList,
      requiredConfig,
      switchConfigs: { loadUnloadAdministrativeDivisionOpen, chooseCustomerIntoTheLoadAddress, chooseCustomerIntoTheUnloadAddress },
    } = this.props.waybillCreateStore;
    let url = `ymm://rn.tms/customer?contacttype=${contactType}`;
    if (!!contactType) {
      // 装卸货点击进入装卸货地址二级页面
      url = `ymm://rn.tms/cargoaddress?contacttype=${contactType}`;
    }

    const handleUrl = URLUtils.appendParamsToUrl(url, {
      customerid: this.store.stateData.customerId,
      customername: this.store.stateData.customerName,
      contactlist: this.store.stateData.contactList,
      isfromsupplywaybill: isFromSupplyWaybill,
      sensitivewordlist: sensitiveWordList,
      requiredconfig: requiredConfig,
      provincecityareaselect: !!loadUnloadAdministrativeDivisionOpen,
      choosecustomerintotheloadaddress: !!chooseCustomerIntoTheLoadAddress,
      choosecustomerintotheunloadaddress: !!chooseCustomerIntoTheUnloadAddress,
    });

    MBBridge.app.base.openSchemeForResult({ schemeUrl: handleUrl }).then((result) => {
      if (result && result?.data) {
        const data = Platform.OS === 'ios' ? JSON.parse(result?.data) : result?.data;
        this.confirmCustomer(data);
        if (!contactType) {
          this.store.setShowCommonLabels(false); // 进入客户选择二级页面回来不再显示常用标签
        }
      }
    });
  };

  renderUserItem = (user: ContactUser, index: number): JSX.Element => {
    const { moduleData } = this.store;
    const {
      switchConfigs: { loadUnloadAdministrativeDivisionOpen },
    } = this.props.waybillCreateStore;

    const provincecityareaselect = !!loadUnloadAdministrativeDivisionOpen;
    const provinceCityAreaName = user.provinceName + user.cityName + user.areaName;

    return (
      <TouchableThrottle
        activeOpacity={0.8}
        waitSecond={3}
        onPress={() => {
          this.jump(user.contactType);
        }}
      >
        <View key={user.contactType} style={styles.deliveryAddressContent}>
          <Flex direction="row" style={styles.addressWarpper}>
            <FlexItem style={styles.flexItemStyle}>
              <View style={styles.iconWrapper}>
                <Image style={styles.itemIcon} source={{ uri: user.contactType === 1 ? Images.icon_shipper : Images.icon_consignee }} />
              </View>

              <View style={styles.addressWrapper}>
                {user.address || user.provinceName ? (
                  <MBText ellipsizeMode={'tail'} numberOfLines={1} style={styles.inputStyle}>
                    {provincecityareaselect ? provinceCityAreaName : user.address}
                  </MBText>
                ) : (
                  <MBText style={styles.placeholderStyle}>
                    {user.contactType === 1 ? moduleData.shipperPlaceholder : moduleData.consigneePlaceholder}
                  </MBText>
                )}
              </View>

              <Image style={styles.itemArrow} source={{ uri: Images.icon_arrow_gray }} />
            </FlexItem>
          </Flex>
          {provincecityareaselect && user.address ? (
            <Flex direction="row" style={styles.addressWarpper}>
              <FlexItem style={styles.flexItemStyle}>
                <View style={styles.iconWrapper}>
                  <Image style={styles.itemIcon} source={{ uri: '' }} />
                </View>

                <View style={styles.addressWrapper}>
                  <MBText ellipsizeMode={'tail'} numberOfLines={1} style={styles.inputStyle}>
                    {user.address}
                  </MBText>
                </View>
              </FlexItem>
            </Flex>
          ) : null}

          {user.companyName ? (
            <Flex direction="row" style={styles.namePhoneWarpper}>
              <FlexItem style={styles.namePhoneStyle}>
                <View style={styles.iconWrapper}>
                  <Image style={styles.itemIcon} source={{ uri: Images.companyName_icon }} />
                </View>
                <MBText ellipsizeMode={'tail'} numberOfLines={1} style={[styles.inputStyle, { flex: 1 }]}>
                  {user.companyName}
                </MBText>
                {/* {user.contactPhone ? <View style={styles.linkRight}></View> : null}
                {user.contactPhone ? <MBText style={styles.inputStyle}>{user.contactPhone}</MBText> : null} */}
              </FlexItem>
            </Flex>
          ) : null}

          {user.contactName || user.contactPhone ? (
            <Flex direction="row" style={styles.namePhoneWarpper}>
              <FlexItem style={styles.namePhoneStyle}>
                <View style={styles.iconWrapper}>
                  <Image style={styles.itemIcon} source={{ uri: Images.icon_peopleGary }} />
                </View>

                <MBText ellipsizeMode={'tail'} numberOfLines={1} style={[styles.inputStyle, styles.contactName]}>
                  {user.contactName}
                </MBText>
                {user.contactPhone ? <View style={styles.linkRight}></View> : null}
                {user.contactPhone ? <MBText style={styles.inputStyle}>{user.contactPhone}</MBText> : null}
              </FlexItem>
            </Flex>
          ) : null}

          {user.handlingTime?.displayValue ? (
            <Flex direction="row" style={styles.dateWarpper}>
              <FlexItem style={styles.namePhoneStyle}>
                <View style={styles.iconWrapper}>
                  <Image style={styles.itemIcon} source={{ uri: icon }} />
                </View>

                <View>
                  <MBText style={styles.inputStyle}>{user.handlingTime?.displayValue}</MBText>
                </View>
              </FlexItem>
            </Flex>
          ) : null}

          {index === 0 && <Splitline />}
        </View>
      </TouchableThrottle>
    );
  };
  api_customerLabel() {
    server({ url: '/saas-tms-trans/yzgApp/crm/customer/label', data: {} }).then((res: any) => {
      if (res.data) {
        this.setState({ commonLabelList: res.data.slice(0, 3) });
      }
    });
  }
  // 查询最近一次收发货
  getLastDispather = async (params: any) => {
    try {
      const res = await server({ url: '/saas-tms-trans/yzgApp/order/getLastCustomerInfo', data: { ...params } });
      if (res.success) {
        const { shipper, consignee, ...restData } = res.data;
        const {
          switchConfigs: { chooseCustomerIntoTheLoadAddress, chooseCustomerIntoTheUnloadAddress },
        } = this.props.waybillCreateStore;

        let handleShipper = null;
        let handleConsignee = null;

        if (chooseCustomerIntoTheLoadAddress && shipper) {
          handleShipper = { ...shipper };
        }

        if (chooseCustomerIntoTheUnloadAddress && consignee) {
          handleConsignee = { ...consignee };
        }

        this.confirmCustomer({ ...restData, shipper: handleShipper, consignee: handleConsignee, origin: 'customer' });
      }
    } catch (error) {
      MBLog.log({ message: '查询最近一次收发货失败', error: error });
    }
  };
  selectLabel(index: any, selected: boolean) {
    const { commonLabelList } = this.state;
    commonLabelList.forEach((el: any, i: number) => {
      if (i === index && el.selected) {
        el.selected = false;
      } else {
        el.selected = i === index;
      }
    });
    const { customerName, customerId } = commonLabelList[index];
    if (selected) {
      this.store.setStateData({ customerName: '', customerId: '' });
    } else {
      // 如果已经存在地址信息就不再带入
      const contactList = this.store.stateData.contactList;
      if (!this.props.isFromSupplyWaybill && !contactList[0]?.address && !contactList[1]?.address) {
        this.getLastDispather({ customerName, customerId }); // 获取最近一次发货的地址信息
      } else {
        this.confirmCustomer({
          customerId: customerId,
          customerName: customerName,
          contactList: contactList,
          origin: 'customer',
        });
      }
    }
    this.forceUpdate();
  }
  labelbox(item: any, index: number) {
    return (
      <MBText
        color={item.selected ? '#4885FF' : '#666666'}
        size="xs"
        style={{
          backgroundColor: item.selected ? '#E9F0FF' : '#EEEEEE',
          lineHeight: RNElementsUtil.autoFix(48),
          paddingHorizontal: 6,
          marginBottom: autoFix(18),
          borderRadius: 2,
          marginLeft: 10,
        }}
        onPress={() => this.selectLabel(index, item.selected)}
        key={item.customerId}
      >
        {item.customerName}
      </MBText>
    );
  }
  /** 常用标签 */
  commonLabels() {
    const { commonLabelList } = this.state;
    const { showCommonLabels } = this.store;
    if (showCommonLabels && commonLabelList?.length) {
      return (
        <View style={{ flexDirection: 'row', width: '100%', paddingRight: RNElementsUtil.autoFix(20) }}>
          <MBText color="#C9C9C9" size="xs" style={{ lineHeight: RNElementsUtil.autoFix(48) }}>
            常发客户:
          </MBText>
          <View style={{ flexDirection: 'row', flex: 1, flexWrap: 'wrap', justifyContent: 'flex-start' }}>
            {commonLabelList.map((item: any, index: number) => this.labelbox(item, index))}
          </View>
        </View>
      );
    } else {
      return null;
    }
  }
  render(): JSX.Element {
    const { stateData } = this.store;
    const { editEnum } = this.props;

    return (
      <View>
        <CellGroup withBottomLine>
          <Cell
            name="clientName"
            title="客户名称"
            align="right"
            required
            readonly={editEnum === 'TWO' || editEnum === 'FOUR'}
            placeholder="请选择"
            value={stateData.customerName}
            onPress={() => this.jump(0)}
            extra={this.commonLabels()}
          />
        </CellGroup>
        <Whitespace vertical={10} />

        <CellGroup withBottomLine>
          <View style={styles.deliveryAddressContentWrapper}>{stateData.contactList.map(this.renderUserItem)}</View>
        </CellGroup>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  deliveryAddressContentWrapper: {
    paddingVertical: autoFix(9),
  },

  deliveryAddressContent: {
    paddingHorizontal: autoFix(28),
    paddingTop: autoFix(20),
  },

  addressWarpper: {
    paddingBottom: autoFix(20),
  },

  namePhoneWarpper: {
    paddingBottom: autoFix(20),
  },

  dateWarpper: {
    paddingBottom: autoFix(20),
  },

  flexStyle: {
    paddingVertical: autoFix(28),
    paddingRight: autoFix(28),
  },

  companyName: {
    fontSize: autoFix(30),
    color: '#666',
    marginBottom: 10,
  },

  iconWrapper: {
    marginRight: autoFix(28),
  },

  placeholder: {
    fontSize: autoFix(30),
    color: '#CCC',
  },

  area: {
    marginBottom: 6,
    color: '#333',
    fontWeight: 'bold',
    fontSize: autoFix(32),
  },

  addressWrapper: {
    flex: 1,
  },

  address: {
    marginBottom: 4,
    fontSize: autoFix(26),
    color: '#666',
  },

  userInfo: {
    fontSize: autoFix(26),
    color: '#666',
  },

  itemArrow: {
    width: 8,
    height: 14,
  },

  inputStyle: {
    fontSize: autoFix(26),
    color: '#666',
  },

  contactName: {
    width: autoFix(260),
  },

  placeholderStyle: {
    fontSize: autoFix(26),
    color: '#ccc',
  },

  cellStyle: {
    paddingLeft: 0,
  },

  itemIcon: {
    width: autoFix(42),
    height: autoFix(42),
  },

  flexItemStyle: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  linkRight: {
    width: autoFix(1),
    height: autoFix(24),
    backgroundColor: '#E8E8E8',
    marginHorizontal: autoFix(32),
  },

  namePhoneStyle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});
