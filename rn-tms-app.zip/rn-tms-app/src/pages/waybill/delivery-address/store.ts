import { action, observable, observe } from 'mobx';
import BaseStore from '~/extends/BaseStore';
import { UserModel } from '../customer/proptypes';
import { RequestDateTime } from '~/components/common/MBDatetimePicker/proptypes';
import server from '~/server';
import { xyzMath } from '~/utils/xyzMath';
import { unique } from '~/utils/common';
import { MBLog } from '@ymm/rn-lib';

export interface ContactUser extends UserModel {
  handlingTime?: RequestDateTime;
  companyName?: string;
}
interface DeliveryAddressStateData {
  customerId: string;
  customerName: string;
  contactList: ContactUser[];
}
interface DeliveryAddressModuleData {
  shipperPlaceholder: string;
  consigneePlaceholder: string;
  deliveryDatePlaceholder: string;
  receiveDatePlaceholder: string;
}
const defaultContact = {
  contactName: '',
  contactPhone: '',
  province: 0,
  provinceName: '',
  city: 0,
  cityName: '',
  area: 0,
  areaName: '',
  longitude: '0',
  latitude: '0',
  mapType: 2,
  address: '',
  companyName: '',
};

export interface costMileageProps {
  loadAddressLatitude: number | string;
  loadAddressLongitude: number | string;
  unloadAddressLatitude: number | string;
  unloadAddressLongitude: number | string;
}

export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}

export interface emptyItemdataProps {
  cargoName: string | null;
  weight: string | null;
  volume: string | null;
  packageUnit: string | null;
  packageQuantity: string | null;
  remark: string | null;
}

const emptyItemData: emptyItemdataProps = {
  cargoName: null,
  weight: null,
  volume: null,
  packageUnit: null,
  packageQuantity: null,
  remark: null,
};

interface addressRequiredConfigModel {
  loadAddressConfig: boolean; // 装货地址是否必有经纬度
  unloadAddressConfig: boolean; // 卸货地址是否必有经纬度
}
export default class DeliveryAddressStore extends BaseStore<DeliveryAddressModuleData, DeliveryAddressStateData> {
  // 装卸货地址是否必需配置
  @observable addressRequiredConfig: addressRequiredConfigModel = {
    loadAddressConfig: false,
    unloadAddressConfig: false,
  };
  @observable showCommonLabels = true; // 是否显示常用标签，如果进入二级页面选择了客户名称就不再显示常用标签
  constructor(props: any) {
    super(props);
    this.init();
  }
  init = () => {
    this.saveStateData({
      customerId: '',
      customerName: '',
      contactList: [
        {
          ...defaultContact,
          contactType: 1,
        },
        {
          ...defaultContact,
          contactType: 2,
        },
      ],
    });
    this.saveModuleData({
      shipperPlaceholder: '必填，请输入装货地址',
      consigneePlaceholder: '必填，请输入卸货地址',
      deliveryDatePlaceholder: '请选择预计装货时间',
      receiveDatePlaceholder: '请选择预计卸货时间',
    });
  };
  // 设置 是否显示 历史名称标签
  @action setShowCommonLabels(val: boolean) {
    this.showCommonLabels = val;
  }
  // 根据收发货地址获取历史订单
  @action
  getCargoList = async () => {
    const params: cargoParamsProps = {
      customerName: this.stateData.customerName || '',
      shipperContactAddress: this.stateData.contactList[0]?.address,
      consigneeContactAddress: this.stateData.contactList[1]?.address,
    };

    const { customerName, shipperContactAddress, consigneeContactAddress } = params;

    if (customerName && shipperContactAddress && consigneeContactAddress) {
      const url = '/saas-tms-trans/yzgApp/order/last/order/cargo';
      const res = await server({ url, data: params });

      if (res.success) {
        if (res.data && res.data.length) {
          this.pageStore.goodsInfoStore.saveStateData({
            cargoList: res.data.map((item: any) => {
              item.weight = xyzMath.round(item.weight, this.pageStore.goodsInfoStore.systemInit.orderWeightTonPoint);
              return item;
            }),
            stockValue: null,
          });
        } else {
          // 当无历史货物订单时，默认显示一个空对象
          this.pageStore.goodsInfoStore.saveStateData({
            cargoList: [{ ...emptyItemData }],
            stockValue: null,
          });
        }
      }
    }
  };

  // 根据收发货地址获取历史货物名称
  @action
  getCargoNameList = async () => {
    const params: cargoParamsProps = {
      customerName: this.stateData.customerName || '',
      shipperContactAddress: this.stateData.contactList[0]?.address,
      consigneeContactAddress: this.stateData.contactList[1]?.address,
    };

    const { customerName, shipperContactAddress, consigneeContactAddress } = params;

    if (customerName && shipperContactAddress && consigneeContactAddress) {
      const url = '/saas-tms-trans/yzgApp/order/last/cargo';
      const res = await server({ url, data: params });
      if (res.success) {
        if (res.data && res.data.length) {
          this.pageStore.goodsInfoStore.cargoNameList = unique(res.data, 'cargoName');
        }
      }
    }
  };

  // 根据发货人获取关联的业务员、是否开票、税率、税金
  @action
  getCustomerHistoryInfo = async () => {
    const customerName = this.stateData.customerName;

    if (customerName) {
      const url = '/saas-tms-trans/yzgApp/crm/query/cust';
      const res = await server({ url, data: { customerName } });

      if (res.success && res.data) {
        const { settlementMethod, custServiceId, custServiceName, isBilling, billingRate, insuranceRate } = res.data;

        this.pageStore.waybillCreateStore.saveStateData({
          settleType: settlementMethod ? settlementMethod : 1,
        });

        // 保险费率
        this.pageStore.waybillCreateStore.insuranceRate = insuranceRate;

        this.pageStore.moreInfoStore.saveStateData({
          operatorId: custServiceId,
          operatorName: custServiceName,
          isBilling: isBilling,
          billingRate: billingRate ? xyzMath.multiply(res.data.billingRate, 100) : null,
        });
      }
    }
  };

  // 根据收发货经纬度获取线路里程
  @action
  getCostMileage = async () => {
    const params: costMileageProps = {
      loadAddressLatitude: this.stateData.contactList[0]?.latitude,
      loadAddressLongitude: this.stateData.contactList[0]?.longitude,
      unloadAddressLatitude: this.stateData.contactList[1]?.latitude,
      unloadAddressLongitude: this.stateData.contactList[1]?.longitude,
    };

    const { loadAddressLatitude, loadAddressLongitude, unloadAddressLatitude, unloadAddressLongitude } = params;

    if (
      loadAddressLatitude &&
      loadAddressLatitude !== '0' &&
      loadAddressLongitude &&
      loadAddressLongitude !== '0' &&
      unloadAddressLatitude &&
      unloadAddressLatitude !== '0' &&
      unloadAddressLongitude &&
      unloadAddressLongitude !== '0'
    ) {
      const url = '/saas-tms-trans/yzgApp/address/distance';
      const res = await server({ url, data: params });

      if (res.data) {
        this.pageStore.moreInfoStore.saveStateData({ costMileage: res.data?.toString() });
      }
    }
  };

  /**
   * 装/卸货时间
   * @param index
   * @param value
   */
  @action updateDatetime = (index: number, value: any = {}): void => {
    this.stateData.contactList[index].handlingTime = { ...value };
  };
  /**
   * 校验规则
   * @returns
   */
  validateRule = () => {
    const { provinceCityAreaSelect } = this.pageStore.waybillCreateStore;
    // if (!this.stateData.contactList.length || !this.stateData.contactList[0].contactName) {
    //   return {
    //     success: false,
    //     message: '请选择发货方',
    //   };
    // }
    if (!this.stateData.customerName) {
      return {
        success: false,
        message: '请选择客户名称',
      };
    }

    if (!this.stateData.contactList[0]?.address) {
      return {
        success: false,
        message: '请选择装货方地址',
      };
    }
    // if (!this.stateData.contactList[0].handlingTime?.endTimestamp) {
    //   return {
    //     success: false,
    //     message: '请选择装货时间',
    //   };
    // }
    // if (!this.stateData.contactList[1].contactName) {
    //   return {
    //     success: false,
    //     message: '请选择收货方',
    //   };
    // }
    // if (!provinceCityAreaSelect && contactType === 2 && !contactList[1]?.address) {
    //   return MBToast.show('请输入卸货详细地址');
    // }
    if (provinceCityAreaSelect && !this.stateData.contactList[1]?.provinceName) {
      return {
        success: false,
        message: '请选择卸货方地址',
      };
    }

    if (!provinceCityAreaSelect && !this.stateData.contactList[1]?.address) {
      return {
        success: false,
        message: '请选择卸货方地址',
      };
    }
    // if (!this.stateData.contactList[1].handlingTime?.endTimestamp) {
    //   return {
    //     success: false,
    //     message: '请选择卸货时间',
    //   };
    // }
    if (this.stateData.contactList[0].handlingTime?.endTimestamp && this.stateData.contactList[1].handlingTime?.endTimestamp) {
      if (this.stateData.contactList[0].handlingTime?.endTimestamp > this.stateData.contactList[1].handlingTime?.endTimestamp) {
        return {
          success: false,
          message: '卸货时间不能小于装货时间',
        };
      }
    }
    return {
      success: true,
    };
  };

  @action
  getGoodsLabel = (isFromSupplyWaybill: boolean) => {
    if (isFromSupplyWaybill) return; // 补录不执行以下方法
    const { customerName, contactList } = this.stateData;
    server({
      url: '/saas-tms-trans/yzgApp/order/last/cargo',
      data: {
        customerName,
        shipperContactAddress: contactList[0].address,
        consigneeContactAddress: contactList[1].address,
      },
    }).then((result) => {
      this.pageStore.goodsInfoStore.labelList = result.data ?? [];
    });
  };

  /** 获取用户配置 地址中是否必选要有经纬度 */
  @action getAddressConfig = () => {
    server({ url: '/saas-tms-trans/yzgApp/tenant/config/getAddressConfig', data: {} }, { showLoading: true })
      .then(
        action((response: any) => {
          if (response.success) {
            this.addressRequiredConfig = response.data;
          }
        })
      )
      .catch((er) => {
        MBLog.log({ message: '查询经纬度开关失败', error: er });
      });
  };
  /** 填充地址信息 */
  @action
  setStateData = (data: DeliveryAddressStateData | any) => {
    this.stateData = { ...this.stateData, ...data };
  };
}
