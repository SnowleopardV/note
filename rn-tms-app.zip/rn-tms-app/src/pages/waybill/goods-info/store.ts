import { observable, action, computed } from 'mobx';
import { Modal } from '@ymm/rn-elements';
import server from '~/server';
import BaseStore from '~/extends/BaseStore';
import { MBToast } from '@ymm/rn-lib';
import { object } from 'prop-types';

const Confirm = Modal.Confirm;

export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}

export interface emptyItemdataProps {
  cargoName: string | null;
  weight: string | null;
  volume: string | null;
  packageUnit: string | null;
  packageQuantity: string | null;
  remark: string | null;
  chargeType: number | null;
  freightUnitPrice: number | null;
  totalFreightFee: number | null;
  isNeedRecalculate: boolean | null;
  ext: any;
}

interface GoodsInfoStoreModuleData {
  selectPlaceholder: string;
  inputPlaceholder: string;
}
interface GoodsInfoStoreStateData {
  cargoList: emptyItemdataProps[];
  stockValue: string | null;
}

interface systemInitData {
  orderWeightTonPoint: number | null;
  orderWeightKgPoint: number | null;
}
class GoodsInfoStore extends BaseStore<GoodsInfoStoreModuleData, GoodsInfoStoreStateData> {
  constructor(props: any) {
    super(props);
    this.init();
  }

  init = () => {
    this.stateData = {
      ...this.stateData,
      cargoList: [
        {
          cargoName: null,
          weight: null,
          volume: null,
          packageUnit: null,
          packageQuantity: null,
          remark: null,
          chargeType: null,
          freightUnitPrice: null,
          totalFreightFee: null,
          isNeedRecalculate: null,
          ext: null,
        },
      ],
    };
    this.saveModuleData({
      selectPlaceholder: '请选择',
      inputPlaceholder: '请输入',
    });
  };

  // 空货物信息对象
  @observable emptyItemData: emptyItemdataProps = {
    cargoName: null,
    weight: null,
    volume: null,
    packageUnit: null,
    packageQuantity: null,
    remark: null,
    chargeType: null,
    freightUnitPrice: null,
    totalFreightFee: null,
    isNeedRecalculate: null,
    ext: null,
  };
  @observable cargoNameList: any = [];
  @observable listItem: any = {};
  @observable listItemIndex: any = null;
  @observable goodsNameModalVisible: boolean = false;
  @observable weightVolumeModalVisible: boolean = false;
  @observable industryModalVisible: boolean = false;
  @observable packageUnitModalVisible: boolean = false;
  @observable packageQuantityModalVisible: boolean = false;
  @observable stockValueModalVisible: boolean = false;
  // 页面显示未填项提示
  @observable isShowError: boolean = false;

  //货物下方的label数据
  @observable labelList: { cargoName: string }[] = [];

  //
  @observable systemInit: systemInitData = {
    orderWeightTonPoint: 6, // 运单重量输入框默认可输入 6位小数 （单位吨）
    orderWeightKgPoint: 6, // 运单重量输入框默认可输入 6位小数 （单位公斤）
  };

  @computed get displayCargoText() {
    let str: string = '';
    const list = [...this.stateData.cargoList];

    if (list.length) {
      str = list.reduce((total: string, item: any, index: number) => {
        const semi = index === list.length - 1 ? '' : '；';
        return (
          total +
          (item.cargoName ? item.cargoName : '') +
          (item.weight ? `/${item.weight}吨` : '') +
          (item.volume ? `/${item.volume}方` : '') +
          (item.packageUnit ? `/${item.packageUnit}` : '') +
          (item.packageQuantity ? `/${item.packageQuantity}件` : '') +
          (item.remark ? `/${item.remark}` : '') +
          semi
        );
      }, '');
    }

    return str;
  }

  @action
  onAddGoodsItem = () => {
    this.stateData.cargoList.push({ ...this.emptyItemData });
    this.saveStateData({ ...this.stateData });
  };

  @action
  onDeleteGoodsItem = (item: any, index: number) => {
    const handleCargoList = this.stateData.cargoList.filter((e: any, i: number) => i !== index);
    this.saveStateData({ ...this.stateData, cargoList: handleCargoList });
  };

  @action
  onDeleteGoodsItemConfirm = (item: any, index: number) => {
    Confirm({
      closable: true,
      headerLine: false,
      hideHeader: true,
      content: '删除该货物？',
      cancelText: '取消',
      confirmText: '删除',
      onConfirm: () => {
        this.onDeleteGoodsItem(item, index);
      },
    });
  };

  // 货物名称
  @action
  changeGoodsNameModalVisible = () => {
    const visible = this.goodsNameModalVisible;
    this.goodsNameModalVisible = !visible;
  };

  @action
  onClickGoodsName = (item: any, index: number) => {
    this.listItem = item;
    this.listItemIndex = index;
    this.changeGoodsNameModalVisible();
  };

  @action
  onConfirmGoodsNameModal = (data: any) => {
    const list = this.stateData.cargoList.map((item: any, index: number) => {
      if (index === data.listItemIndex) {
        item.cargoName = data.cargoName;
      }
      return item;
    });

    this.stateData.cargoList = [...list];
    this.changeGoodsNameModalVisible();
  };

  // 重量体积
  @action
  changeWeightVolumeModalVisible = () => {
    const visible = this.weightVolumeModalVisible;
    this.weightVolumeModalVisible = !visible;
  };

  // 所属行业
  @action
  changeIndustryModalVisible = () => {
    const visible = this.industryModalVisible;
    this.industryModalVisible = !visible;
  };

  // 货物更多点事件
  @action
  onClickMore = (index: number, item: emptyItemdataProps) => {
    this.listItem = item;
    this.listItemIndex = index;
  };

  @action
  onClickWeightVolume = (item: any, index: number) => {
    this.listItem = item;
    this.listItemIndex = index;
    this.changeWeightVolumeModalVisible();
  };

  @action
  onClickIndustry = (item: any, index: number) => {
    this.listItem = item;
    this.listItemIndex = index;
    this.changeIndustryModalVisible();
  };

  @action
  onConfirmWeightVolumeModal = (data: any) => {
    const list = this.stateData.cargoList.map((item: any, index: number) => {
      if (index === data.listItemIndex) {
        item.weight = data.weight;
        item.volume = data.volume;
      }
      return item;
    });

    this.stateData.cargoList = [...list];
    this.changeWeightVolumeModalVisible();
  };

  @action
  onConfirmIndustryModal = (data: any) => {
    const { key, value, listItemIndex } = data;
    const list = this.stateData.cargoList.map((item: any, index: number) => {
      if (index === listItemIndex) {
        if (!item.ext) {
          item.ext = {};
        }

        item.ext[key] = value;
      }
      return item;
    });

    this.stateData.cargoList = [...list];
    this.changeIndustryModalVisible();
  };

  @action
  onConfirmPackTypeModal = (data: any) => {
    console.log('选中的包装方式：', data);
    const list = this.stateData.cargoList.map((item: any, index: number) => {
      if (index === data.listItemIndex) {
        item.packageUnit = data.packageUnit;
      }
      return item;
    });

    this.stateData.cargoList = [...list];
  };

  // 件数
  @action
  changePieceModalVisible = () => {
    const visible = this.packageQuantityModalVisible;
    this.packageQuantityModalVisible = !visible;
  };

  @action
  onClickPiece = (item: any, index: number) => {
    this.listItem = item;
    this.listItemIndex = index;
    this.changePieceModalVisible();
  };

  @action
  onConfirmPieceModal = (data: any) => {
    const list = this.stateData.cargoList.map((item: any, index: number) => {
      if (index === data.listItemIndex) {
        item.packageQuantity = data.packageQuantity;
      }
      return item;
    });

    this.stateData.cargoList = [...list];
    this.changePieceModalVisible();
  };

  // 备注
  @action
  onChangeRemark = (value: string, listItemIndex: number) => {
    const list = this.stateData.cargoList.map((item: any, index: number) => {
      if (index === listItemIndex) {
        item.remark = value;
      }
      return item;
    });

    this.stateData.cargoList = [...list];
  };

  // 声明价值
  @action
  onConfirmStockValueModal = (data: any) => {
    const { stockValue } = data;
    //this.unSaveStockValue = stockValue;
    this.stateData.stockValue = stockValue;
    this.stateData = { ...this.stateData, stockValue };
  };

  @action
  onBack = (index: number, item: {}) => {
    const list = this.stateData.cargoList;
    list[index] = { ...list[index], ...item };
    this.stateData = { ...this.stateData, cargoList: list };
  };

  @action
  saveStateData = (stateData: GoodsInfoStoreStateData) => {
    if (stateData && Object.keys(stateData).length) {
      this.stateData = { ...stateData };
    }
  };

  @action
  addCargoError = (value: boolean) => {
    const list = [...this.stateData.cargoList];
    this.stateData.cargoList = list.map((item: any) => {
      item.isError = value;
      return item;
    });
  };

  /**
   * 校验
   * @returns boolean
   */
  @action validate = (): boolean => {
    const {
      waybillCreateStore: {
        industryData: { industryFlag, industryExtendCode },
        isFromSupplyWaybill,
      },
    } = this.pageStore.stores;
    const list = [...this.stateData.cargoList];
    const item = list.find((item) => {
      return (
        !item.cargoName || !(item.weight || item.volume) || (industryFlag && (!item.ext || !(item.ext && item.ext[industryExtendCode])))
      );
    });
    if (!item) return true;
    if (!item?.cargoName) {
      MBToast.show('货物名称未填写');
      return false;
    }
    if (!(item?.weight || item?.volume)) {
      MBToast.show('货物重量体积未填写');
      return false;
    }
    if (!isFromSupplyWaybill && industryFlag && (!item.ext || !(item.ext && item.ext[industryExtendCode]))) {
      MBToast.show('所属行业未填写');
      return false;
    }
    return true;
  };
  /** 货物校验并作出提示
   * @returns {Boolean} 校验是否通过 true 通过 false 未通过
   */
  @action
  goodsValidateAndTip = () => {
    if (this.validate()) {
      this.addCargoError(false);
      return true;
    } else {
      this.addCargoError(true);
      return false;
    }
  };
  /**
   * 校验规则 新增收发货方时，无历史订单，此时未进入货物信息页，直接创建需要校验必填项
   * @returns
   */
  validateRule = () => {
    if (
      this.stateData.cargoList.length === 1 &&
      !this.stateData.cargoList[0].cargoName &&
      (!this.stateData.cargoList[0].weight || !this.stateData.cargoList[0].volume)
    ) {
      return {
        success: false,
        message: '请选择货物信息',
      };
    }
    return {
      success: true,
    };
  };

  //选择客户名称后的回调
  @action
  customerCallback = (user: { customerId: number }, callback: any) => {
    this.getDefaultGoodsList(user).then((result) => {
      //如果有默认货物显示，否则初始化成最初状态
      if (Array.isArray(result.data) && result.data.length > 0) {
        this.stateData = { ...this.stateData, cargoList: result.data };
      } else {
        this.init();
      }
      callback && callback();
    });
  };
  // 查询客户默认货物列表
  private getDefaultGoodsList = (user: { customerId: number }) => {
    return server({
      url: '/saas-tms-trans/yzgApp/order/default/order/cargo',
      data: {
        customerId: user.customerId,
      },
    });
  };
  // 返回运单重量小数点位数配置
  private getSystemInit = (): void => {
    server(
      {
        url: '/saas-tms-trans/yzgApp/trans/system/init',
        data: {},
      },
      { showLoading: false, toastError: false }
    ).then((res: any) => {
      if (res.data) {
        const { orderWeightTonPoint, orderWeightKgPoint } = res.data;
        this.systemInit = {
          orderWeightTonPoint: orderWeightTonPoint || 6, // 运单重量输入框默认可输入 6位小数 （单位吨）
          orderWeightKgPoint: orderWeightKgPoint || 6, // 运单重量输入框默认可输入 6位小数 （单位公斤）
        };
      }
    });
  };
}

export default GoodsInfoStore;
