import React, { useState, useEffect } from 'react';
import { SafeAreaView, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalPackType = (props: any) => {
  const { visible, onConfirm, onCancel, listItem, listItemIndex } = props;
  const [packTypeList, setPackTypeList] = useState<any[]>([
    {
      packType: '纸箱',
    },
    {
      packType: '木箱',
    },
    {
      packType: '铁桶',
    },
    {
      packType: '纤袋',
    },
    {
      packType: '麻袋',
    },
    {
      packType: '木架',
    },
    {
      packType: '托盘',
    },
    {
      packType: '其他',
    },
  ]);
  const [packTypeItem, setPackTypeItem] = useState<any>({ packType: '纸箱' });
  const [lastPackIndex, setLastPackIndex] = useState(0); // 上次选中索引

  useEffect(() => {
    setPackTypeItem(() => {
      const lastPackTypeArr = packTypeList.filter((item) => item.packType === listItem.packageUnit);

      return lastPackTypeArr.length
        ? lastPackTypeArr[0]
        : {
            packType: '纸箱',
          };
    });
  }, [listItem.packageUnit]);

  useEffect(() => {
    const packageUnit = listItem.packageUnit || '纸箱';

    packTypeList.forEach((item, index) => {
      if (item.packType === packageUnit) {
        setLastPackIndex(index);
      }
    });
  }, [listItem.packageUnit]);

  const onModalConfirm = () => {
    const { packType } = packTypeItem;
    const selectItem = {
      packageUnit: packType,
      listItemIndex,
    };

    onConfirm && onConfirm(selectItem);
  };

  const onModalCancel = () => {
    onCancel && onCancel();
  };

  const handleChangePackType = (position: number, value: string) => {
    setPackTypeItem(value);
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请选择包装方式"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
      >
        <Flex direction="row" justify="center">
          <FlexItem>
            <Selector
              scaleFont={true}
              value={lastPackIndex}
              rowTitle="packType"
              list={packTypeList}
              onChange={(position: number, value: string) => {
                handleChangePackType(position, value);
              }}
            />
          </FlexItem>
        </Flex>
        <Whitespace vertical={20} />
      </Modal>
    </SafeAreaView>
  );
};

export default ModalPackType;
