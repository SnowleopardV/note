import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, SafeAreaView, Keyboard, Platform, TouchableOpacity } from 'react-native';
import { Flex, MBText, Modal, Input, Whitespace, Splitline } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import RegTest from '~/utils/RegTest';
import { MBBridge } from '@ymm/rn-lib';

const FlexItem = Flex.Item;

const ModalWeightVolume = (props: any) => {
  const { visible, onConfirm, onCancel, listItem, listItemIndex, orderWeightTonPoint } = props;
  const [weight, setWeight] = useState(null);
  const [volume, setVolume] = useState(null);
  const [unsaveWeight, setUnsaveWeight] = useState(null);
  const [unsaveVolume, setUnsaveVolume] = useState(null);
  const inputRef = useRef(null);

  // modal开启时关闭IQKeyboard，modal关闭中打开IQKeyboard
  useEffect(() => {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }

    return function cleanup() {
      if (Platform.OS == 'ios') {
        MBBridge.rnruntime.IQKeyboard({ enable: true });
      }
    };
  });

  useEffect(() => {
    const weight = listItem.weight;
    const volume = listItem.volume;

    setWeight(weight);
    setVolume(volume);
    setUnsaveWeight(weight);
    setUnsaveVolume(volume);
  }, [listItem.weight, listItem.volume]);

  useEffect(() => {
    if (visible) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    }
  }, [visible]);

  const onChangeWeight = (value: string) => {
    const valueArr = value.split('.')[0];
    if (valueArr.length > 9) return;
    if (!RegTest.numPrecision(value, orderWeightTonPoint) && value) return;
    if (RegTest.emoji(value)) return;

    setUnsaveWeight(value);
  };

  const onChangeVolume = (value: string) => {
    const valueArr = value.split('.')[0];
    if (valueArr.length > 9) return;
    if (!RegTest.numPrecision(value,6) && value) return;
    setUnsaveVolume(value);
  };

  const onModalConfirm = () => {
    if (judgeInputItemEmpty()) return;
    const inputItem = {
      listItemIndex,
      weight: unsaveWeight,
      volume: unsaveVolume,
    };
    onConfirm && onConfirm(inputItem);
  };

  const onModalCancel = () => {
    setUnsaveWeight(weight);
    setUnsaveVolume(volume);
    onCancel && onCancel();
  };

  // 都为空或填写0时，确定按钮置灰不可点击
  const judgeInputItemEmpty = () => {
    // 0 0.00 000 确定按钮置灰
    const flagWeight = unsaveWeight === '0' || (unsaveWeight && !RegTest.isDigit(unsaveWeight));
    const flagVolume = unsaveVolume === '0' || (unsaveVolume && !RegTest.isDigit(unsaveVolume));

    // 2个值都不填写确定按钮置灰
    const flag2 = !unsaveWeight && !unsaveVolume;

    return flagWeight || flagVolume || flag2;
  };

  const titleElement = (
    <View>
      <MBText align="center">请输入重量/体积</MBText>
    </View>
  );

  const rightElement = (
    <TouchableOpacity activeOpacity={0.8} onPress={onModalConfirm}>
      <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
        <MBText color="primary" style={[styles.confirmText, judgeInputItemEmpty() && styles.confirmTextDisabled]}>
          确定
        </MBText>
      </View>
    </TouchableOpacity>
  );
  return (
    <SafeAreaView style={{ flex: 1, flexDirection: 'column' }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement}
        title={titleElement}
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
      >
        <View style={styles.subTitleWrapper}>
          <MBText style={styles.subTitle} align="center">
            货重体积必填一项
          </MBText>
        </View>
        <Whitespace vertical={14} />
        <Flex direction="row" style={styles.inputItem}>
          <MBText>重量（吨）</MBText>
          <FlexItem>
            <Input
              placeholder="请输入"
              type="number"
              returnKeyType="done"
              onSubmitEditing={Keyboard.dismiss}
              ref={inputRef}
              style={styles.inputStyle}
              value={unsaveWeight ? unsaveWeight + '' : ''}
              onChangeText={onChangeWeight}
            />
          </FlexItem>
        </Flex>
        <Splitline />
        <Flex direction="row" style={styles.inputItem}>
          <MBText>体积（方）</MBText>
          <FlexItem>
            <Input
              placeholder="请输入"
              type="number"
              returnKeyType="done"
              onSubmitEditing={Keyboard.dismiss}
              style={styles.inputStyle}
              value={unsaveVolume ? unsaveVolume + '' : ''}
              onChangeText={onChangeVolume}
            />
          </FlexItem>
        </Flex>
        <Splitline />
        <Whitespace vertical={20} />
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create<any>({
  subTitleWrapper: {
    position: 'absolute',
    left: 0,
    top: -8,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
  },

  subTitle: {
    color: '#999',
    fontSize: autoFix(24),
  },

  inputItem: {
    paddingVertical: 12,
  },

  inputStyle: {
    fontSize: autoFix(30),
    paddingHorizontal: 16,
  },

  confirmText: {
    fontSize: autoFix(32),
  },

  confirmTextDisabled: {
    color: '#CCCCCC',
  },
});

export default ModalWeightVolume;
