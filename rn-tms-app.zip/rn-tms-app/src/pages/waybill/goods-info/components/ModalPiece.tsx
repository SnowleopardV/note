import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, SafeAreaView, Keyboard, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Input, Whitespace, Splitline } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import RegTest from '~/utils/RegTest';

const FlexItem = Flex.Item;

const ModalPiece = (props: any) => {
  const { visible, onConfirm, onCancel, listItem, listItemIndex } = props;
  const [piece, setPiece] = useState(null);
  const [unsavePiece, setUnsavePiece] = useState(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (visible) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    }
  }, [visible]);

  useEffect(() => {
    const packageQuantity = listItem.packageQuantity;
    setPiece(packageQuantity);
    setUnsavePiece(packageQuantity);
  }, [listItem.packageQuantity]);

  const onChangePiece = (value: string) => {
    if (!RegTest.positiveInteger(value) && value) return;
    if (RegTest.emoji(value)) return;
    setUnsavePiece(value);
  };

  const onModalConfirm = () => {
    const inputItem = {
      packageQuantity: unsavePiece,
      listItemIndex,
    };

    onConfirm && onConfirm(inputItem);
  };

  const onModalCancel = () => {
    setUnsavePiece(piece);
    onCancel && onCancel();
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请输入件数"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
      >
        <Flex direction="row" style={styles.inputItem}>
          <FlexItem flex={0}>
            <MBText>件数</MBText>
          </FlexItem>

          <FlexItem flex={1}>
            <Input
              ref={inputRef}
              placeholder="请输入"
              type="number"
              returnKeyType="done"
              onSubmitEditing={Keyboard.dismiss}
              style={styles.inputStyle}
              maxLength={9}
              value={unsavePiece ? unsavePiece + '' : ''}
              onChangeText={onChangePiece}
            />
          </FlexItem>
        </Flex>
        <Splitline />
        <Whitespace vertical={20} />
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create<any>({
  inputItem: {
    paddingVertical: 12,
  },

  inputStyle: {
    fontSize: autoFix(30),
    paddingHorizontal: 16,
  },
});

export default ModalPiece;
