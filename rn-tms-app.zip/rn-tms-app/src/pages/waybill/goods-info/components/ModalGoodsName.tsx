import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity, Image } from 'react-native';
import { Flex, MBText, Modal, Input, Whitespace, Splitline, TagGroup, Tag } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Images from '../../../../../public/static/images';
import RegTest from '~/utils/RegTest';

const FlexItem = Flex.Item;

const ModalGoodsName = (props: any) => {
  const [goodsName, setGoodsName] = useState<string>('');
  const { visible, onConfirm, onCancel, listItemIndex, cargoNameList } = props;
  const inputRef = useRef(null);

  useEffect(() => {
    if (visible) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    }
  }, [visible]);

  const onItemClick = (item: any) => {
    const selectItem = {
      cargoName: item.cargoName,
      listItemIndex,
    };
    onConfirm && onConfirm(selectItem);
  };

  const onClearGoodName = () => {
    setGoodsName('');
  };

  const onChangeText = (value: string) => {
    if (RegTest.emoji(value)) return;
    setGoodsName(value);
  };

  const onModalConfirm = () => {
    if (!goodsName) return;
    const selectItem = {
      cargoName: goodsName,
      listItemIndex,
    };
    setGoodsName('');
    onConfirm && onConfirm(selectItem);
  };

  const onModalCancel = () => {
    onClearGoodName();
    onCancel && onCancel();
  };

  const rightElement = (
    <TouchableOpacity activeOpacity={0.8} onPress={onModalConfirm}>
      <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
        <MBText color="primary" style={[styles.confirmText, !goodsName && styles.confirmTextDisabled]}>
          确定
        </MBText>
      </View>
    </TouchableOpacity>
  );
  return (
    <SafeAreaView style={{ flex: 1, flexDirection: 'column' }}>
      <Modal
        headerLeft="取消"
        headerRight={rightElement}
        title="请输入货物名称"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
      >
        <View style={{ width: '100%' }}>
          <Flex direction="row" style={styles.goodsName}>
            <FlexItem flex={0}>
              <MBText>货物名称</MBText>
            </FlexItem>

            <FlexItem flex={1} style={styles.flexItemStyle}>
              <Input
                ref={inputRef}
                placeholder="请输入"
                style={styles.inputStyle}
                maxLength={200}
                value={goodsName}
                returnKeyType="done"
                onChangeText={onChangeText}
              />

              {goodsName ? (
                <TouchableOpacity activeOpacity={0.3} onPress={onClearGoodName}>
                  <Image style={styles.iconClear} source={{ uri: Images.icon_close }} />
                </TouchableOpacity>
              ) : null}
            </FlexItem>
          </Flex>
          <Splitline />
          <Whitespace vertical={4} />
          {!goodsName ? (
            <TagGroup rowId="id" space={10} rowSize={3} autoCollapse moreText="更多>" onPress={onItemClick}>
              {(cargoNameList || []).map((item: any, index: number) => {
                return (
                  <Tag key={index} item={item}>
                    <MBText numberOfLines={1} style={styles.text}>
                      {item.cargoName}
                    </MBText>
                  </Tag>
                );
              })}
            </TagGroup>
          ) : null}
          <Whitespace vertical={20} />
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create<any>({
  goodsName: {
    paddingVertical: 12,
  },

  inputStyle: {
    flex: 1,
    fontSize: autoFix(30),
    paddingHorizontal: 16,
  },

  confirmText: {
    color: '#4885FF',
    fontSize: autoFix(32),
  },

  confirmTextDisabled: {
    color: '#CCCCCC',
    fontSize: autoFix(32),
  },

  flexItemStyle: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  iconClear: {
    width: 16,
    height: 16,
  },

  tagText: {
    color: '#666666',
    fontSize: autoFix(26),
  },
});

export default ModalGoodsName;
