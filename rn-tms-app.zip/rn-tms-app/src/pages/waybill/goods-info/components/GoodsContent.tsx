import React from 'react';
import { View, StyleSheet, TouchableOpacity, Image, Keyboard } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText, CellGroup, Whitespace, Flex, RNElementsUtil } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import Images from '../../../../../public/static/images';
import ModalIndustry from './ModalIndustry';
import GoodsInfoStore from '../store';
import RegTest from '~/utils/RegTest';
import WaybillCreateStore from '../../create/store';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
const FlexItem = Flex.Item;

interface GoodsContentProps {
  waybillCreateStore: WaybillCreateStore;
  goodsInfoStore: GoodsInfoStore;
  navigation: any;
  keyboardHeight: number;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
  isEdit: boolean;
}

@inject('waybillCreateStore', 'goodsInfoStore')
@observer
class GoodsContent extends React.Component<GoodsContentProps, any> {
  constructor(props: GoodsContentProps) {
    super(props);
  }

  componentDidMount() {
    this.props.goodsInfoStore?.getSystemInit();
  }

  labelbox(item: any, index: number, itemLabel: any) {
    const {
      navigation,
      isEdit,
      goodsInfoStore: { onClickMore },
    } = this.props;
    return (
      <MBText
        color={item.selected ? '#4885FF' : '#666666'}
        size="xs"
        style={{
          backgroundColor: item.selected ? '#E9F0FF' : '#EEEEEE',
          lineHeight: RNElementsUtil.autoFix(48),
          paddingHorizontal: 6,
          marginBottom: autoFix(18),
          borderRadius: 2,
          marginLeft: 10,
        }}
        onPress={() => {
          item.cargoName = itemLabel.cargoName;
          onClickMore(index, item);
          this.onUpdateFeeMatch();
          navigation.navigate('GoodsMore', { isEdit });
        }}
        key={item.customerId}
      >
        {itemLabel.cargoName?.length > 6 ? itemLabel.cargoName.substring(0, 6) + '...' : itemLabel.cargoName}
      </MBText>
    );
  }
  /** 常用标签 */
  commonLabels(item: any, index: number, labelList: any[]) {
    if (!item.cargoName && labelList?.length) {
      return (
        <View style={{ flexDirection: 'row', width: '100%', paddingRight: RNElementsUtil.autoFix(20) }}>
          <MBText color="#C9C9C9" size="xs" style={{ lineHeight: RNElementsUtil.autoFix(48) }}>
            常发货物:
          </MBText>
          <View style={{ flexDirection: 'row', flex: 1, flexWrap: 'wrap', justifyContent: 'flex-start' }}>
            {labelList.slice(0, 3).map((itemLabel) => this.labelbox(item, index, itemLabel))}
          </View>
        </View>
      );
    } else {
      return null;
    }
  }

  // 货物名称失去焦点、选中货物标签，更新运费匹配价格
  onUpdateFeeMatch = () => {
    const {
      isEdit,
      waybillCreateStore: { updateFeeMatch },
    } = this.props;
    updateFeeMatch(isEdit);
  };

  // 显示吨方件
  handleWeightVolume = (item: any) => {
    var weightVolume = `${item.weight ? item.weight : ''}${item.weight ? '吨' : ''}${item.weight && item.volume ? '/' : ''}${
      item.volume ? item.volume : ''
    }${item.volume ? '方' : ''}`;

    var combind = weightVolume;
    if (weightVolume?.length && item?.packageQuantity > 0) {
      combind = combind + '/' + item?.packageQuantity + '件';
    }
    return combind;
  };
  // 货物信息拼接 name，packageUnit，吨/方/件，remark
  handleGoodInfo = (item: any) => {
    var goodInfo = item?.cargoName ?? '';
    goodInfo = goodInfo && item?.packageUnit ? goodInfo + ',' + item?.packageUnit : goodInfo;
    goodInfo = goodInfo && this.handleWeightVolume(item) ? goodInfo + ',' + this.handleWeightVolume(item) : goodInfo;
    goodInfo = goodInfo && item?.remark ? goodInfo + ',' + item?.remark : goodInfo;
    return goodInfo;
  };

  // 筛选所属行业，显示text
  filterExt = (data: any) => {
    const {
      waybillCreateStore: {
        industryData: { industryExtendCode, industryOptions },
      },
    } = this.props;
    let extDisplayText = '';

    if (!!data) {
      for (let i in data) {
        if (i === industryExtendCode) {
          const value = data[i];
          const industryArr = industryOptions.filter((item: any) => item.value === value);
          if (industryArr?.length) {
            extDisplayText = industryArr[0]?.text;
          }
        }
      }
    }
    return extDisplayText;
  };

  render() {
    const {
      navigation,
      waybillCreateStore: {
        switchConfigs: { addCargoButton = true },
        isFromSupplyWaybill,
        industryData: { industryFlag, industryExtendCode, industryOptions },
      },
      goodsInfoStore: {
        stateData: { cargoList },
        listItem,
        listItemIndex,
        industryModalVisible,
        onAddGoodsItem,
        onDeleteGoodsItemConfirm,
        onClickIndustry,
        onConfirmIndustryModal,
        changeIndustryModalVisible,
        onClickMore,
        labelList,
        systemInit: { orderWeightTonPoint },
      },
      isEdit,
    } = this.props;

    const renderAddCargoCell = (item: any, index: number) => {
      return (
        <View style={styles.addGoodsWrapper}>
          <Flex direction="row" justify="center" align="center">
            <FlexItem style={styles.addGoods}>
              <TouchableOpacity style={styles.touchableOpacity} onPress={onAddGoodsItem}>
                <Image style={styles.addGoodsIcon} source={{ uri: Images.icon_add_circle }} />
                <MBText color="#4885FF" style={styles.controlButtonText}>
                  新增货物
                </MBText>
              </TouchableOpacity>
            </FlexItem>
            {cargoList.length > 1 && (
              <FlexItem style={styles.addGoods}>
                <TouchableOpacity style={styles.touchableOpacity} onPress={() => onDeleteGoodsItemConfirm(item, index)}>
                  <Image style={styles.addGoodsIcon} source={{ uri: Images.icon_del_circle }} />
                  <MBText color="#999" style={styles.controlButtonText}>
                    删除货物
                  </MBText>
                </TouchableOpacity>
              </FlexItem>
            )}
          </Flex>
        </View>
      );
    };

    const renderContent = () => {
      return (
        <View>
          <View style={styles.goodsContent}>
            {cargoList.map((item: any, index: number) => {
              return (
                <View key={index} style={styles.goodsItem}>
                  <View>
                    <CellGroup withBottomLine style={{ marginHorizontal: 0 }}>
                      <Cell
                        title="货物信息"
                        required
                        align="right"
                        numberOfLines={1}
                        placeholder="请输入"
                        // 把对象转换成字符串显示
                        value={this.handleGoodInfo(item)}
                        onPress={() => {
                          onClickMore(index, item);
                          navigation.navigate('GoodsMore', { isEdit });
                        }}
                        extra={this.commonLabels(item, index, labelList)}
                      ></Cell>
                      {!isFromSupplyWaybill && industryFlag ? (
                        <Cell
                          name="ext"
                          title="所属行业"
                          align="right"
                          required
                          value={this.filterExt(item.ext)}
                          placeholder="请选择"
                          onPress={() => {
                            onClickIndustry(item, index);
                          }}
                        />
                      ) : null}
                      {addCargoButton && renderAddCargoCell(item, index)}
                    </CellGroup>
                  </View>
                </View>
              );
            })}
          </View>

          <ModalIndustry
            visible={industryModalVisible}
            industryList={industryOptions}
            industryExtendCode={industryExtendCode}
            listItem={listItem}
            listItemIndex={listItemIndex}
            onConfirm={onConfirmIndustryModal}
            onCancel={changeIndustryModalVisible}
          />
        </View>
      );
    };
    return <View style={styles.inner}>{renderContent()}</View>;
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  inner: {
    flex: 1,
  },

  itemTitle: {
    paddingHorizontal: 14,
  },

  addGoodsWrapper: {
    paddingHorizontal: 10,
  },

  addGoods: {
    backgroundColor: '#fff',
    height: 50,
    borderRadius: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  touchableOpacity: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  addGoodsIcon: {
    width: autoFix(40),
    height: autoFix(40),
    marginRight: 8,
  },
  controlButtonText: {
    fontSize: autoFix(30),
  },
  goodsItem: {
    marginBottom: autoFix(20),
  },
  labelItem: {
    paddingHorizontal: autoFix(8),
    paddingVertical: autoFix(4),
    backgroundColor: '#EEEEEE',
    marginLeft: autoFix(12),
    borderRadius: 2,
  },
  labelView: {
    display: 'flex',
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: autoFix(18),
    paddingRight: autoFix(28),
  },
  goodsContent: {
    paddingHorizontal: autoFix(20),
  },
});

export default GoodsContent;
