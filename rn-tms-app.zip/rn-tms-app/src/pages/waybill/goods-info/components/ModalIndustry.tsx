import React, { useState, useEffect } from 'react';
import { SafeAreaView, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalIndustry = (props: any) => {
  const { visible, onConfirm, onCancel, industryList, industryExtendCode, listItem, listItemIndex } = props;
  const [industryItem, setIndustryItem] = useState(industryList[0]);
  const [lastIndustryIndex, setLastIndustryIndex] = useState(0); // 上次选中索引

  useEffect(() => {
    setIndustryItem(() => {
      const data = listItem.ext;
      let lastIndustryArr = [];
      if (!!data) {
        for (let i in data) {
          if (i === industryExtendCode) {
            const value = data[i];
            lastIndustryArr = industryList.filter((item: any) => item.value === value);
          }
        }
      }
      return lastIndustryArr.length ? lastIndustryArr[0] : industryList[0];
    });
  }, [listItem.ext, listItem.ext ? listItem.ext[industryExtendCode] : '']);

  useEffect(() => {
    const value = listItem.ext ? listItem.ext[industryExtendCode] : '';
    if (value) {
      industryList.forEach((item: any, index: number) => {
        if (item.value === value) {
          setLastIndustryIndex(index);
        }
      });
    } else {
      setLastIndustryIndex(0);
    }
  }, [listItem.ext, listItem.ext ? listItem.ext[industryExtendCode] : '']);

  const onModalConfirm = () => {
    const { value } = industryItem;

    const selectItem = {
      key: industryExtendCode,
      value,
      listItemIndex,
    };

    onConfirm && onConfirm(selectItem);
  };

  const onModalCancel = () => {
    onCancel && onCancel();
  };

  const handleChangeIndustry = (position: number, value: string) => {
    setIndustryItem(value);
  };

  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      headerLeft="取消"
      headerRight={rightElement()}
      title="请选择所属行业"
      position="bottom"
      visible={visible}
      autoAdjustPosition={true}
      headerLine={false}
      onConfirm={onModalConfirm}
      onCancel={onModalCancel}
      onMaskClose={onModalCancel}
      onRequestClose={onModalCancel}
    >
      <Flex direction="row" justify="center">
        <FlexItem>
          <Selector
            scaleFont={true}
            value={lastIndustryIndex}
            rowTitle="text"
            list={industryList}
            onChange={(position: number, value: string) => {
              handleChangeIndustry(position, value);
            }}
          />
        </FlexItem>
      </Flex>
      <Whitespace vertical={20} />
    </Modal>
  );
};

export default ModalIndustry;
