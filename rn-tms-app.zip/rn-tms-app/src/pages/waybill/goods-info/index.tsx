import { MBBridge } from '@ymm/rn-lib';
import React from 'react';
import { View, StyleSheet, Platform, Keyboard } from 'react-native';
import GoodsContent from './components/GoodsContent';

export interface GoodsInfoIndexProps {
  navigation: any;
  screenProps: any;
  isEdit: boolean;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
}

class GoodsInfoIndex extends React.Component<GoodsInfoIndexProps, any> {
  keyboardWillShowListener: any;
  keyboardWillHideListener: any;
  state = {
    showFooterBtn: true,
    keyboardHeight: 0,
  };
  constructor(props: GoodsInfoIndexProps) {
    super(props);
  }

  render() {
    const { navigation, isEdit, onCommonFocus, onCommonBlur } = this.props;

    const { keyboardHeight } = this.state;

    return (
      <View style={styles.flexStyle}>
        <GoodsContent
          navigation={navigation}
          keyboardHeight={keyboardHeight}
          onCommonFocus={onCommonFocus}
          onCommonBlur={onCommonBlur}
          isEdit={isEdit}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },
});

export default GoodsInfoIndex;
