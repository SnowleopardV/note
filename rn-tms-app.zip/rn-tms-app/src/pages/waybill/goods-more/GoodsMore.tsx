import React from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  NativeEventSubscription,
  BackHandler,
  Keyboard,
  KeyboardEvent,
} from 'react-native';
import { MBToast } from '@ymm/rn-lib';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText, Whitespace } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import Remark from '~/components/common/Remark';
import PackTypeTagsBox from './PackTypeTagsBox';
import ModalPiece from '../goods-info/components/ModalPiece';
import GoodsInfoStore from '../goods-info/store';
import InputItem from '~/components/common/InputItem';
import RegTest from '~/utils/RegTest';
import WaybillCreateStore from '../create/store';
import NavBar from '~/components/common/NavBar';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import ModalGoodsName from '../goods-info/components/ModalGoodsName';
export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}
interface GoodsContentProps {
  waybillCreateStore: WaybillCreateStore;
  goodsInfoStore: GoodsInfoStore;
  navigation: any;
  onCommonFocus: () => void;
  onCommonBlur: () => void;
}

@inject('waybillCreateStore', 'goodsInfoStore')
@observer
class GoodsContent extends React.Component<GoodsContentProps, any> {
  keyboardWillShowListener: any;
  keyboardWillHideListener: any;
  backHandleListener?: NativeEventSubscription;
  timerBtn: any = null;

  refInput: any;
  inputRef: any;

  constructor(props: GoodsContentProps) {
    super(props);
    const {
      goodsInfoStore: {
        listItem
      },
    } = props;

    const weight = listItem.weight;
    const volume = listItem.volume;
    this.state = {
      copyCurrentItem: { ...props.goodsInfoStore.listItem },
      isEdit: false,
      keyboardHeight: 0,
      showFooterBtn: true,
      unsaveWeight: weight,
      unsaveVolume: volume
    };
  }
  componentDidMount() {
    const {
      navigation,
      goodsInfoStore: {
        stateData: { cargoList },
        listItemIndex,
      },
    } = this.props;
    const { isEdit } = navigation.state.params;

    this.setState({
      isEdit,
    });
    /**实现安卓物理键返回页面功能 */
    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', this.backAction);
    }

    if(cargoList[listItemIndex].cargoName?.length){
      setTimeout(() => {
        this.inputRef?.focus();
      }, 300);
    } else {
      setTimeout(() => {
        this.refInput?.focus();
      }, 300);
    }
    
    this.keyboardWillShowListener = Keyboard.addListener('keyboardDidShow', (e: KeyboardEvent) => this.onKeyboardDidShow(e));
    this.keyboardWillHideListener = Keyboard.addListener('keyboardDidHide', () => this.onKeyboardDidHide());
  }

  componentWillUnmount() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener('hardwareBackPress', this.backAction);
    }

    this.keyboardWillShowListener?.remove();
    this.keyboardWillHideListener?.remove();
  }

  backAction = () => {
    const { navigation } = this.props;
    navigation.goBack();
    return true;
  };

  onKeyboardDidShow(e: KeyboardEvent) {
    this.setState({
      keyboardHeight: e?.endCoordinates?.height ?? 140,
    });
  }

  onKeyboardDidHide() {
    this.setState({
      keyboardHeight: 0,
    });
  }

  // 失焦底部按钮显示，聚焦底部按钮隐藏
  onCommonBlurFocus = (val: boolean) => {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ showFooterBtn: val });
    }, 10);
  };

  onChangeItem = (value: string, item: any, key: string, isInt: boolean) => {
    if (isInt && !RegTest.positiveInteger(value) && value) return;
    if (RegTest.emoji(value)) return;
    item[key] = value;
  };

  onChangeWeight = (value: string) => {
    const {
      goodsInfoStore: {
        systemInit: { orderWeightTonPoint },
      },
    } = this.props;

    const valueArr = value.split('.')[0];
    if (valueArr.length > 9) return;
    if (!RegTest.numPrecision(value, orderWeightTonPoint) && value) return;
    if (RegTest.emoji(value)) return;
    this.setState({
      unsaveWeight: value
    })
  };

  onChangeVolume = (value: string) => {
    const valueArr = value.split('.')[0];
    if (valueArr.length > 9) return;
    if (!RegTest.numPrecision(value,6) && value) return;
    this.setState({
      unsaveVolume: value
    })
  };

  // 都为空或填写0时，确定按钮置灰不可点击
  judgeInputItemEmpty = () => {
    const {unsaveWeight , unsaveVolume} =  this.state
    // 0 0.00 000 确定按钮置灰
    const flagWeight = unsaveWeight === '0' || (unsaveWeight && !RegTest.isDigit(unsaveWeight));
    const flagVolume = unsaveVolume === '0' || (unsaveVolume && !RegTest.isDigit(unsaveVolume));

    // 2个值都不填写确定按钮置灰
    const flag2 = !unsaveWeight && !unsaveVolume;

    return flagWeight || flagVolume || flag2;
  };

  // 更新货重和体积
  onUpdateWeightVolume = () => {
    const {unsaveWeight , unsaveVolume} =  this.state
    const {
      goodsInfoStore: {
        listItemIndex,
      },
      goodsInfoStore: { onConfirmWeightVolumeModal },
    } = this.props;

    const inputItem = {
      listItemIndex,
      weight: unsaveWeight,
      volume: unsaveVolume,
    };
    onConfirmWeightVolumeModal && onConfirmWeightVolumeModal(inputItem)
  };

  // 更新运费匹配价格
  onUpdateFeeMatch = () => {
    const { isEdit } = this.state;
    const {
      waybillCreateStore: { updateFeeMatch },
    } = this.props;

    this.onUpdateWeightVolume()
    updateFeeMatch(isEdit);
  };

  onSubmit = () => {
    const {
      navigation,
      waybillCreateStore: {
        requiredConfig: { unitIsRequired, quantityIsRequired },
      },
      goodsInfoStore: {
        stateData: { cargoList },
        listItemIndex,
      },
    } = this.props;

    if (!cargoList[listItemIndex].cargoName) {
      return MBToast.show('请输入货物名称');
    }

    if (unitIsRequired && !cargoList[listItemIndex].packageUnit) {
      return MBToast.show('请选择包装方式');
    }

    if (this.judgeInputItemEmpty()) {
      return MBToast.show('重量和体积至少填写一个大于0的值');
    }

    if (quantityIsRequired && !cargoList[listItemIndex].packageQuantity) {
      return MBToast.show('请输入件数');
    }

    this.onUpdateFeeMatch();
    navigation.goBack();
  };

  render() {
    const {
      waybillCreateStore: {
        isFromTms,
        requiredConfig: { quantityIsRequired },
      },
      navigation,
      goodsInfoStore: {
        stateData: { cargoList },
        cargoNameList,
        listItem,
        listItemIndex,
        goodsNameModalVisible,
        onConfirmGoodsNameModal,
        changeGoodsNameModalVisible,
        packageQuantityModalVisible,
        onConfirmPackTypeModal,
        onConfirmPieceModal,
        changePieceModalVisible,
        onChangeRemark,
        onBack,
      },
    } = this.props;

    const { keyboardHeight, showFooterBtn } = this.state;

    const renderContent = () => {
      return (
        <View>
          <NavBar
            title="货物信息"
            leftClick={() => {
              console.log(this.state.copyCurrentItem, 'weqeqeqqqweqeq');
              onBack(listItemIndex, this.state.copyCurrentItem);
              navigation.goBack();
            }}
          />
          <View style={styles.goodsContent}>
            <CellGroup withBottomLine>
            <InputItem
                bottomLine={false}
                required
                title="货物名称"
                placeholder="请输入"
                ref={(el) => this.refInput = el}
                value={cargoList[listItemIndex].cargoName ?? ''}
                onChangeText={(value) => this.onChangeItem(value, cargoList[listItemIndex], 'cargoName', false)}
                textAlign="right"
                maxLength={200}
                returnKeyType="done"
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onUpdateFeeMatch();
                  this.onCommonBlurFocus(true);
                }}
                onTitlePress={() => {
                  Keyboard.dismiss();
                  this.onCommonBlurFocus(true);
                }}
              />
              <PackTypeTagsBox listItem={listItem} listItemIndex={listItemIndex} onConfirm={onConfirmPackTypeModal}/>
              <InputItem
                title="重量（吨）"
                placeholder="货重体积必填一项"
                keyboardType="numeric"
                ref={(el) => this.inputRef = el}
                onSubmitEditing={Keyboard.dismiss}
                value={this.state.unsaveWeight ?? ''}
                onChangeText={(value) => this.onChangeWeight(value)}
                textAlign="right"
                returnKeyType="done"
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
              <InputItem
                title="体积（方）"
                placeholder="货重体积必填一项"
                keyboardType="numeric"
                onSubmitEditing={Keyboard.dismiss}
                value={this.state.unsaveVolume ?? ''}
                onChangeText={(value) => this.onChangeVolume(value)}
                textAlign="right"
                returnKeyType="done"
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
              <InputItem
                title="件数"
                placeholder="请输入"
                required={!!quantityIsRequired}
                keyboardType="numeric"
                value={cargoList[listItemIndex].packageQuantity ?? ''}
                onChangeText={(value) => this.onChangeItem(value, cargoList[listItemIndex], 'packageQuantity', true)}
                textAlign="right"
                maxLength={9}
                returnKeyType="done"
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
            </CellGroup>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine >
            <Remark
                value={cargoList[listItemIndex].remark ?? ''}
                onChangeText={(value) => onChangeRemark(value, listItemIndex)}
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
            </CellGroup>
          </View>

          <ModalGoodsName
            visible={goodsNameModalVisible}
            cargoNameList={cargoNameList}
            listItemIndex={listItemIndex}
            onConfirm={onConfirmGoodsNameModal}
            onCancel={changeGoodsNameModalVisible}
          />          
          <ModalPiece
            visible={packageQuantityModalVisible}
            listItem={listItem}
            listItemIndex={listItemIndex}
            onConfirm={onConfirmPieceModal}
            onCancel={changePieceModalVisible}
          />
        </View>
      );
    };

    //渲染底部按钮
    const renderFooter = showFooterBtn ? (
      <View style={styles.buttonView}>
        <TouchableOpacity style={styles.buttonTouch} onPress={this.onSubmit}>
          <View style={styles.button}>
            <MBText color="#fff">确定</MBText>
          </View>
        </TouchableOpacity>
      </View>
    ) : null;

    if (Platform.OS == 'ios' && isFromTms) {
      return (
        <KeyboardAvoidingView behavior="padding" style={[styles.container]}>
          <ScrollView keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
            <View style={{ flex: 1, paddingBottom: keyboardHeight ? 40 + keyboardHeight : 40 }}>{renderContent()}</View>
          </ScrollView>
          {renderFooter}
        </KeyboardAvoidingView>
      );
    }

    return (
      <>
        <ScrollView keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
          <View style={styles.inner}>{renderContent()}</View>
        </ScrollView>
        {renderFooter}
      </>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  inner: {
    flex: 1,
    paddingBottom: 40,
  },

  itemTitle: {
    paddingHorizontal: 14,
  },

  addGoodsWrapper: {
    paddingHorizontal: 10,
  },
  goodsContent: {
    marginTop: autoFix(20),
    // flex: 1,
  },
  addGoods: {
    backgroundColor: '#fff',
    height: 50,
    borderRadius: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  touchableOpacity: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  addGoodsIcon: {
    width: 17,
    height: 17,
    marginRight: 8,
  },
  buttonView: {
    paddingHorizontal: autoFix(28),
    paddingVertical: autoFix(20),
    backgroundColor: '#fff',
  },
  buttonTouch: {
    width: '100%',
    backgroundColor: '#4885FF',
    borderRadius: autoFix(40),
    height: autoFix(80),
  },
  button: {
    height: '100%',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default GoodsContent;
