import React from 'react';
import { View } from 'react-native';
import { MBText, Whitespace, Splitline } from '@ymm/rn-elements';
import { TagGroup, Tag } from '@ymm/rn-elements';

const packTypeList = [
  { id: 0, packType: '纸箱' },
  { id: 1, packType: '木箱' },
  { id: 2, packType: '铁桶' },
  { id: 3, packType: '纤袋' },
  { id: 4, packType: '麻袋' },
  { id: 5, packType: '木架' },
  { id: 6, packType: '托盘' },
  { id: 7, packType: '其他' },
];

export interface PackTypeTagsProps {
  listItem: any;
  listItemIndex: number;
  onConfirm: (item: any) => void;
}

export default class PackTypeTagsBox extends React.Component<PackTypeTagsProps, any> {
  constructor(props: any) {
    super(props);
    console.log('PackTypeTagsBox:', props?.lastItem);
    const { listItem } = props;

    var seletedIds: any = [];
    packTypeList.forEach((item, index) => {
      if (item.packType === listItem?.packageUnit) {
        seletedIds = [item.id];
      }
    });
    this.state = {
      seleteds: seletedIds,
    };
  }

  componentWillReceiveProps(nextProps: any) {
    const { listItem } = nextProps;
    var seletedIds: any = [];
    packTypeList.forEach((item, index) => {
      if (item.packType === listItem?.packageUnit) {
        seletedIds = [item.id];
      }
    });
    this.state = {
      seleteds: seletedIds,
    };
  }

  onItemClick = (item: any) => {
    const { onConfirm, listItemIndex } = this.props;
    const selectItem = {
      packageUnit: item?.packType,
      listItemIndex,
    };
    onConfirm && onConfirm(selectItem);
  };

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#fff', paddingHorizontal: 14, marginTop: 14 }}>
        <MBText>包装方式</MBText>
        <TagGroup
          defaultSelected={this.state.seleteds}
          rowId="id"
          space={10}
          rowSize={4}
          autoCollapse
          moreText="更多>"
          onPress={this.onItemClick}
          style={{ marginTop: 4 }}
        >
          {packTypeList.map((item) => {
            return (
              <Tag key={item.id} item={item}>
                {item.packType}
              </Tag>
            );
          })}
        </TagGroup>
        <Whitespace vertical={14} />
        <Splitline />
      </View>
    );
  }
}
