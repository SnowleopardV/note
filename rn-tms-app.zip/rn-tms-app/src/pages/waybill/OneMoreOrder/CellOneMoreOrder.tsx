import { MBText } from '@ymm/rn-elements';
import React, { PureComponent } from 'react';
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import images from '~public/static/images';
// 再来一单 cell 文本
export interface Props {
  navigation?: any;
  text?: string;
}

export default class CellOneMoreOrder extends PureComponent<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {};
  }
  onPress = () => {
    const { navigation } = this.props;
    navigation.navigate('OneMoreOrderPage');
  };

  render() {
    const { text } = this.props;
    return (
      <View style={styles.cellItem}>
        <TouchableOpacity onPress={this.onPress} style={{ flexDirection: 'row', alignItems: 'center' }}>
          <MBText color="#4885FF">{text}</MBText>
          <Image style={{ width: 6, height: 12, marginLeft: 8 }} source={images.icon_left_bule} />
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  cellItem: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingTop: 16,
    paddingHorizontal: 24,
  },
});
