import React from 'react';
import { View, StyleSheet, Platform, BackHandler, Image } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText, RefreshList } from '@ymm/rn-elements';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NavBar from '~/components/common/NavBar';
import renderItem from './components/renderItem';
import TouchableThrottle from '~/components/TouchableThrottle';
import { MBLog } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';
import API from '../../waybill-manage/api';
import server from '~/server';
import filterFormat from '~/extends/filterFormat';
import { xyzMath } from '~/utils/xyzMath';
import dayjs from 'dayjs';
// 备注
@inject('goodsInfoStore', 'waybillCreateStore', 'deliveryAddressStore', 'moreInfoStore')
@observer
export default class OneMoreOrderPage extends React.Component<any, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      isEnd: false,
      listForm: { pageNo: 0, pageSize: 20 },
      list: [],
      btnList: [
        {
          name: '详情',
          onSubmit: (item: any) => {
            if (item.id) {
              // 请求运单详情 看看是否有权限查看详情
              API.getWaybillDetail({ id: item.id })
                ?.then(() => {
                  NativeBridge.setOpenUrl({ url: 'ymm://rn.tms/waybilldetail?source=oneMoreOrder&id=' + item.id });
                })
                .catch((err: any) => {
                  MBLog.log({ message: '请求运单详情失败', error: err });
                });
            }
          },
        },
        {
          name: '再来一单',
          onSubmit: (item: any) => {
            this.api_orderDetail(item.id)
              .then((res) => {
                if (res) {
                  this.fillInForm(res);
                }
              })
              .catch((err) => {
                MBLog.log({ message: '再来一单错误', error: err });
              });
          },
        },
      ],
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  // 获取列表
  api_list(pageNo: number) {
    this.state.listForm.pageNo = pageNo ? pageNo : 1;
    return server({ url: '/saas-tms-trans/yzgApp/order/another/order/list', data: this.state.listForm }, { showLoading: false })
      .then((res: any) => {
        const { list } = this.state;
        let listData = res.data?.list || [];
        listData = pageNo ? list.concat(listData) : listData;
        this.state.listForm.pageNo += this.state.listForm.pageNo;
        this.setState({ list: listData, isEnd: !res.data?.hasNextPage });
      })
      .catch((err: any) => {
        MBLog.log({ message: '获取运单列表失败', error: err });
      });
  }
  onRefresh() {
    return this.api_list(0).finally(() => Promise.resolve());
  }
  onLoadMore() {
    return this.api_list(this.state.listForm.pageNo).finally(() => Promise.resolve());
  }
  /** 再来一单入参字段，可直接填充到表单中
   * yzgApp/order/another/order/detail
   *
   **/
  api_orderDetail(id: number) {
    const data = { id: id };
    return server({ url: '/saas-tms-trans/yzgApp/order/another/order/detail', data: data }).then((res: any) => {
      return res.data;
    });
  }
  /** 填充表单 */
  fillInForm(data: any) {
    const { goodsInfoStore, waybillCreateStore, deliveryAddressStore, moreInfoStore } = this.props;
    const feeListMap = {};
    const { priceSnapshot, freightFeePriceType, loadFeePriceType, pickupFeePriceType, deliFeePriceType, transType } = data;
    const { getCustomerHistoryInfo } = deliveryAddressStore;
    data.feeList.map((row: any) => {
      row.amount = filterFormat.moneyDecFormat(row.amount);
      feeListMap[row.feeCode] = row;
    });
    // ----------------------合并字段
    // 货物信息
    goodsInfoStore?.saveStateData({
      cargoList: data.cargoList.map((item: any) => {
        item.weight = xyzMath.round(item.weight, goodsInfoStore.systemInit.orderWeightTonPoint);
        return item;
      }),
      stockValue: data.stockValue ? xyzMath.divide(data.stockValue, 100) : goodsInfoStore.stateData.stockValue,
    });
    // 组织 应收费用 结算方式 提货方式 等等字段
    waybillCreateStore?.saveStateData({
      feeList: waybillCreateStore.stateData.feeList?.map((item: any) => {
        const amount = feeListMap[item.feeCode]?.amount;
        item.isDeductionFee = amount < 0;
        item.amount = amount && amount != 0 ? Math.abs(amount) : null;
        // 0 手动输入，1 自动匹配
        item.priceType = feeListMap[item.feeCode]?.priceType;
        return item;
      }),
      settleType: data.settleType || waybillCreateStore.stateData.settleType,
      loadMode: data.loadMode || waybillCreateStore.stateData.loadMode,
      receiptCount: data.receiptCount || waybillCreateStore.stateData.receiptCount,
      setRegular: data.setRegular || waybillCreateStore.stateData.setRegular,
      pointBillingTime: dayjs().valueOf(),
      priceSnapshot: priceSnapshot || {}, // 初始化价格快照等信息
      freightFeePriceType,
      loadFeePriceType,
      pickupFeePriceType,
      deliFeePriceType,
      ext: data.ext ? data.ext : {},
      transType,
    });
    // 客户、地址信息
    deliveryAddressStore?.setStateData({
      customerId: data.customerId || deliveryAddressStore.stateData.customerId,
      customerName: data.customerName || deliveryAddressStore.stateData.customerName,
      contactList: deliveryAddressStore.stateData.contactList?.map((item: any) => {
        const rowData = data.contactList.find((row: any) => item.contactType == row.contactType);
        return rowData || item;
      }),
    });

    // 更多信息
    moreInfoStore?.saveStateData({
      costMileage: data.costMileage ? xyzMath.divide(data.costMileage, 1000) : moreInfoStore.stateData.costMileage, // 线路里程
      operatorId: data.operatorId || moreInfoStore.stateData.operatorId, // 业务员id
      operatorName: data.operatorName || moreInfoStore.stateData.operatorName, // 业务员name
      customerOrderNo: data.customerOrderNo || moreInfoStore.stateData.customerOrderNo, // 客户单号（多个客户单号由逗号隔开）
      isBilling: data.isBilling >= 0 ? data.isBilling : moreInfoStore.stateData.isBilling, // 是否开票，0否 1是
      taxWay: data.taxWay || moreInfoStore.stateData.taxWay, // 计税方式，1包含税价 2不包含税价
      billingRate: data.billingRate || moreInfoStore.stateData.billingRate, // 税率，单位%
      remark: data.remark || moreInfoStore.stateData.remark, // 备注
      tmsDispatcherId: data.tmsDispatcherId || moreInfoStore.stateData.tmsDispatcherId, // 调度员id
      tmsDispatcherName: data.tmsDispatcherName || moreInfoStore.stateData.tmsDispatcherName, // 调度员name
      tmsDispatcherPhone: data.tmsDispatcherPhone || moreInfoStore.stateData.tmsDispatcherPhone, // 调度员电话
    });
    deliveryAddressStore.setShowCommonLabels(false); // 选择了再来一单后就不再显示 历史名称标签

    // 根据customerName获取保险费率
    getCustomerHistoryInfo();

    // 更新运费匹配价格
    waybillCreateStore.updateFeeMatch(false);
    this.goBack();
  }
  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <Image source={{ uri: images.icon_no_data }} style={styles.emptyIcon}></Image>
        <MBText style={styles.emptyText}>暂无数据</MBText>
      </View>
    );
  };
  goBack() {
    this.props.navigation?.goBack();
  }
  renderItem(item: any, index: any) {
    const { btnList } = this.state;
    return renderItem(
      item,
      <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'flex-end', padding: 10 }}>
        {btnList?.map((row: any) => (
          <TouchableThrottle key={row.name + index} activeOpacity={0.8} onPress={() => row?.onSubmit(item)}>
            <View style={styles.btn}>
              <MBText style={styles.btnTxt}>{row.name}</MBText>
            </View>
          </TouchableThrottle>
        ))}
      </View>
    );
  }
  render() {
    const { isEnd, list } = this.state;
    return (
      <View style={{ flex: 1 }}>
        <NavBar title="再来一单" leftClick={() => this.goBack()} />
        <RefreshList
          key="OneMoreOrderPage"
          footerNoMoreDataText="已全部加载完毕"
          isEnd={isEnd}
          data={list}
          showsVerticalScrollIndicator={false}
          renderItem={(item: any, index) => this.renderItem(item, index)}
          emptyRender={this.renderEmpty}
          onRefresh={this.onRefresh.bind(this)}
          onLoadMore={this.onLoadMore.bind(this)}
          getLayoutTypeForIndex={() => 215}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  emptyIcon: {
    width: autoFix(287),
    height: autoFix(272),
  },
  empty: {
    height: 600,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchEmptyText: {
    color: '#A2ADC7',
    fontSize: autoFix(28),
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
  },
  btn: {
    paddingVertical: 5,
    paddingHorizontal: 16,
    borderRadius: 15,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 6,
  },
  btnTxt: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4885FF',
  },
});
