import { StyleSheet, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  item: {
    flexDirection: 'column',
    flex: 1,
    marginTop: 10,
    marginHorizontal: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 2,
  },
  empty: {
    height: 600,
    width: '100%',
    justifyContent: 'center',
    textAlignVertical: 'center',
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
  },
  stepLine: {
    position: 'relative',
    top: -4,
    left: 3,
    height: 8,
  },
  point: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    marginRight: 8,
  },
});
