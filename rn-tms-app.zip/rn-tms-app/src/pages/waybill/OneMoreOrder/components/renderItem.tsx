import React from 'react';
import { Image, TouchableWithoutFeedback, View } from 'react-native';
import { MBText, Splitline } from '@ymm/rn-elements';
import styles from './styles';
import images from '~public/static/images';

const renderItem = (item: any, footBox: any): JSX.Element => {
  return (
    <TouchableWithoutFeedback key={item.id}>
      <View style={styles.item}>
        <View style={{ padding: 15 }}>
          <View style={[styles.flexRow, { justifyContent: 'space-between' }]}>
            <MBText color="#999999">{item.createTime}</MBText>
          </View>
          <View style={[styles.flexRow, { marginTop: 10, justifyContent: 'space-between', alignItems: 'flex-start' }]}>
            <MBText color="#333333" size="md" bold ellipsis="middle">
              {item.custName}
            </MBText>
          </View>
          <View style={{ marginVertical: 5 }}>
            <MBText color="#999999">{item.cargoInfoForDisplay}</MBText>
          </View>
          <View style={styles.flexRow}>
            <View style={[styles.point, { backgroundColor: '#4885FF' }]}></View>
            <MBText color="#333333" size="sm">
              {item.loadMessage.address}
            </MBText>
          </View>
          <View style={styles.stepLine}>
            <Image style={{ height: 16, width: 0.8 }} source={images.line_vertical} />
          </View>
          <View style={styles.flexRow}>
            <View style={[styles.point, { backgroundColor: '#333333' }]}></View>
            <MBText color="#333333" size="sm">
              {item.unloadMessage.address}
            </MBText>
          </View>
        </View>
        <Splitline color="#E8E8E8"></Splitline>
        {footBox}
      </View>
    </TouchableWithoutFeedback>
  );
};

export default renderItem;
