import React from 'react';
import { StyleSheet } from 'react-native';
import { Button, MBText, Flex } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const CargoFooter = (props: any) => (
  <Flex direction="row">
    <FlexItem style={styles.footer}>
      <Button type="primary" size="sm" radius style={styles.itemBtn} onPress={props.onPress}>
        <MBText color="#fff">{props.buttonText || '确定'}</MBText>
      </Button>
    </FlexItem>
  </Flex>
);

const styles = StyleSheet.create<any>({
  footer: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    flexDirection: 'row',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  itemBtn: {
    flex: 1,
  },

  subBtnTitle: {
    marginTop: 2,
    opacity: 0.8,
  },
});

export default CargoFooter;
