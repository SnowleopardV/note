import * as React from 'react';
import { View, Platform } from 'react-native';
import { observer, Provider } from 'mobx-react';
import { SafeAreaView } from 'react-native';
import RouterMap, { RouterPageName } from './register';
import { LayProvider } from '@ymm/rn-elements';
import { JsonParse } from '@ymm/rn-lib/src/utils';
import CargoAddressStore from '../store';

const RootStack = new RouterMap().getRouterMap(RouterPageName.CargoAddress);

const CargoAddress: React.FunctionComponent<any> = (props) => {
  const { contacttype, customerid, customername, contactlist, sensitivewordlist, requiredconfig, provincecityareaselect } = props;
  console.log(props, '---props000---');
  let handlecontactlist = contactlist;
  let handlesensitivewordlist = sensitivewordlist;
  let handlerequiredconfig = requiredconfig;
  const handleprovincecityareaselect = JsonParse.parse(provincecityareaselect);
  if (Platform.OS === 'android') {
    handlecontactlist = JsonParse.parse(contactlist);
    handlesensitivewordlist = JsonParse.parse(sensitivewordlist);
    handlerequiredconfig = JsonParse.parse(requiredconfig);
  }
  const cargoAddressStore = new CargoAddressStore(
    Number(contacttype),
    customerid,
    customername,
    handlecontactlist,
    handlesensitivewordlist,
    handlerequiredconfig,
    handleprovincecityareaselect
  );

  return (
    <Provider cargoAddressStore={cargoAddressStore}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </LayProvider>
    </Provider>
  );
};

export default CargoAddress;
