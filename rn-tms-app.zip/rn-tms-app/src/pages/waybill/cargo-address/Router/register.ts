import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import CargoAddressPage from '../index';
/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 装卸货地址
   */
  CargoAddress = 'CargoAddress',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        CargoAddress: {
          // 装卸货地址
          screen: CargoAddressPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
