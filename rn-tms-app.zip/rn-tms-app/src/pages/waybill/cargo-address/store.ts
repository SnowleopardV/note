import { MBLog } from '@ymm/rn-lib';
import { action, computed, observable } from 'mobx';
import server from '~/server/index';
import { CustomerModel, ContactType, AllCustomerModel } from './proptypes';
import { RequestDateTime } from '~/components/common/MBDatetimePicker/proptypes';
import { UserModel } from '../customer/proptypes';
import { throttle } from 'lodash';

export interface ContactUser extends UserModel {
  handlingTime?: RequestDateTime;
  companyName: string; //收发货单位
}

const defaultContact = {
  contactName: '',
  contactPhone: '',
  province: 0,
  provinceName: '',
  city: 0,
  cityName: '',
  area: 0,
  areaName: '',
  longitude: '0',
  latitude: '0',
  mapType: 2,
  address: '',
  companyName: '',
};

interface HistoryRequestParams {
  address: string;
  isNoNeedCode: boolean;
}

interface AssociateRequestParams {
  adCode: number;
  keyWords: string;
  cityLimit: boolean;
}

interface addressRequiredConfigModel {
  loadAddressConfig: boolean;
  unloadAddressConfig: boolean;
}

interface AssociateResponseParams {
  cityName: string;
  coordinate: {
    latitude: string;
    longitude: string;
  };
  detailAddress: string;
  districtName: string;
  poiName: string;
  provinceName: string;
  regionAddress: string;
  streetAddress: string;
  regionAddressWithSpace: string;
}

class CargoAddressStore {
  // 发货人列表
  @observable shipperList: CustomerModel[] = [];
  // 收货人列表
  @observable consigneeList: CustomerModel[] = [];
  // 历史记录列表
  @observable historyRecordList: CustomerModel[] = [];
  @observable hasConsigneehistory: boolean = false;
  @observable hasShipperhistory: boolean = false;
  // 搜索联想地址
  @observable addressAssociateList: AssociateResponseParams[] = [];
  // 历史发货地址
  @observable hisAssociateList: AssociateResponseParams[] = [];
  // 上一次收发货地址
  @observable lastCustomerList: CustomerModel[] = [];
  // 装卸货地址是否必需配置
  @observable addressRequiredConfig: addressRequiredConfigModel = {
    loadAddressConfig: false,
    unloadAddressConfig: false,
  };
  // 搜索联想地址loading
  @observable searchAddressLoading: boolean = false;

  // 展示数据
  @observable moduleData = {
    shipperPlaceholder: '必填，请输入装货地址',
    consigneePlaceholder: '必填，请输入卸货地址',
    shipperProvinceCityAreaPlaceholder: '必填，请选择装货省市区',
    consigneeProvinceCityAreaPlaceholder: '必填，请选择卸货省市区',
    deliveryDatePlaceholder: '请选择预计装货时间',
    consigneeDatePlaceholder: '请选择预计卸货时间',
    deliveryNamePlaceholder: '请输入装货人姓名',
    consigneeNamePlaceholder: '请输入卸货人姓名',
    phonePlaceholder: '联系电话',
    shipmentsPlaceHolder: '请输入发货单位',
    receivingPlaceHolder: '请输入卸货单位',
    detailShipperAddressPlaceHolder: '必填，请输入详细地址',
    detailConsigneeAddressPlaceHolder: '请输入详细地址',
  };

  // 发货人列表
  @observable contactList: ContactUser[] = [
    {
      ...defaultContact,
      contactType: 1,
    },
    {
      ...defaultContact,
      contactType: 2,
    },
  ];

  @observable isLoading: boolean = false;
  @observable sensitiveWordList: any = [];
  @observable requiredConfig: any = {};
  @observable regionData: any = [];
  @observable provinceCityAreaSelect: boolean = false;

  contactType = 1;
  customerId: string;
  customerName: string;

  constructor(
    contacttype: number,
    customerid: string,
    customername: string,
    contactlist: ContactUser[],
    sensitivewordlist: any,
    requiredconfig: any,
    provincecityareaselect: any
  ) {
    this.contactType = contacttype;
    this.customerId = customerid;
    this.customerName = customername;
    this.contactList = contactlist;
    this.sensitiveWordList = sensitivewordlist;
    this.requiredConfig = requiredconfig;
    this.provinceCityAreaSelect = provincecityareaselect;
    this.fetchHistory();
    this.getAddressConfig();
    this.getAllAdRegionList();
  }

  @action
  initContactList = () => {
    this.contactList = [
      {
        ...defaultContact,
        contactType: 1,
      },
      {
        ...defaultContact,
        contactType: 2,
      },
    ];
  };

  @action
  fetchHistory = () => {
    this.fetchHistoryRecord();
  };

  @action
  saveContactList = (contactList: ContactUser[]) => {
    this.contactList = contactList;
  };

  @action
  clearAddressAssociateList = () => {
    this.addressAssociateList = [];
  };

  @action
  clearhisAssociateList = () => {
    this.hisAssociateList = [];
  };

  @action
  getAddressConfig = () => {
    server(
      {
        url: '/saas-tms-trans/yzgApp/tenant/config/getAddressConfig',
        data: {},
      },
      { showLoading: false }
    )
      .then(
        action((response: any) => {
          if (response.success) {
            this.addressRequiredConfig = response.data;
          }
        })
      )
      .catch((er) => {
        MBLog.log({
          message: '查询经纬度开关失败',
          error: er,
        });
      });
  };

  @action
  getMapAddress = (params: AssociateRequestParams) => {
    this.searchAddressLoading = true;
    server(
      {
        url: '/saas-tms-trans/yzgApp/address/search',
        data: { ...params },
      },
      { showLoading: false }
    )
      .then(
        action((response: any) => {
          if (!response || !response.dataList) {
            return;
          }

          this.addressAssociateList = response.dataList.map((item: any) => {
            const { coordinate, detailAddress, districtName, provinceCode, cityCode, districtCode, ...restItem } = item;

            const diffParams = {
              address: detailAddress,
              province: provinceCode,
              city: cityCode,
              area: districtCode,
              areaName: districtName,
              longitude: coordinate.longitude,
              latitude: coordinate.latitude,
              mapType: 2,
            };

            return { ...restItem, ...diffParams };
          });
        })
      )
      .catch((er) => {
        MBLog.log({
          message: '查询联想地址失败',
          error: er,
        });
      })
      .finally(() => {
        this.searchAddressLoading = false;
      });
  };

  @action
  fetchAddressAssociate = throttle(this.getMapAddress, 1000, {
    leading: true,
    trailing: true,
  });

  @action
  getHistoryAddress = (params: HistoryRequestParams) => {
    const customerId = this.customerId === 'undefined' || this.customerId === 'null' ? '' : this.customerId ? this.customerId : '';
    this.searchAddressLoading = true;
    server(
      {
        url: '/saas-tms-trans/yzgApp/address/history',
        data: { ...params, customerId },
      },
      { showLoading: false }
    )
      .then(
        action((response: any) => {
          if (!response || !response.data) {
            return;
          }

          this.hisAssociateList = response.data.map((item: any) => {
            const { coordinate, detailAddress, districtName, provinceCode, cityCode, districtCode, ...restItem } = item;

            const diffParams = {
              address: detailAddress,
              province: provinceCode,
              city: cityCode,
              area: districtCode,
              areaName: districtName,
              longitude: coordinate?.longitude || null,
              latitude: coordinate?.latitude || null,
              mapType: 2,
            };

            return { ...restItem, ...diffParams };
          });
        })
      )
      .catch((er) => {
        MBLog.log({
          message: '查询联想地址失败',
          error: er,
        });
      })
      .finally(() => {
        this.searchAddressLoading = false;
      });
  };

  @action
  fetchHisAssociate = throttle(this.getHistoryAddress, 1000, {
    leading: true,
    trailing: true,
  });

  /**
   * 历史记录
   */
  fetchHistoryRecord() {
    this.isLoading = true;
    console.log(typeof this.customerName, 'this.customerName');
    server({
      url: '/saas-tms-trans/yzgApp/crm/cust/last_2',
      data: {
        customerName: this.customerName ? this.customerName : '',
        type: this.contactType, // 去重类型： 0-全部 1-发货 2-卸货
      },
    })
      .then(
        action((response: any) => {
          this.historyRecordList = response.data || [];
          const shipperhistoryRecordList = this.historyRecordList.filter((item) => item.shipper);
          const consigneehistoryRecordList = this.historyRecordList.filter((item) => item.consignee);
          this.hasShipperhistory = !!shipperhistoryRecordList.length;
          this.hasConsigneehistory = !!consigneehistoryRecordList.length;
        })
      )
      .catch((er) => {
        MBLog.log({
          message: '查询最近30天发货历史失败',
          error: er,
        });
      })
      .finally(() => {
        this.isLoading = false;
      });
  }

  /**
   * 装/卸货时间
   * @param index
   * @param value
   */
  @action updateDatetime = (index: number, value: any = {}) => {
    this.contactList[index].handlingTime = { ...value };
  };

  // 省市区数据
  @action
  getAllAdRegionList = async () => {
    if (this.regionData && this.regionData.length) return;

    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/address/getNewAllAdRegionList',
          data: {},
        },
        { showLoading: false }
      );
      if (res.success) {
        this.regionData = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '查询省市区数据失败',
        error: error,
      });
    }
  };
}

export default CargoAddressStore;
