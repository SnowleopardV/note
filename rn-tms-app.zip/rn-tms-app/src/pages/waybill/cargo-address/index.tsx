import React from 'react';
import { ScrollView, SafeAreaView, View, StyleSheet, Image, Keyboard, TouchableOpacity, Platform, BackHandler } from 'react-native';
import { Flex, MBText, Splitline, CellGroup, Whitespace } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import { MBToast, MBBridge } from '@ymm/rn-lib';
import Cell from '~/components/common/Cell';
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import Images from '../../../../public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import { inject, observer } from 'mobx-react';
import { ContactUser } from './store';
import InputItem from '~/components/common/InputItem';
import { AssociateResponseParams, CustomerModel } from './proptypes';
import CargoFooter from './components/CargoFooter';
import AddressList from '~/components/AddressListNew';
import PlacePicker from '@fta/components-place-picker';
import TouchableThrottle from '~/components/TouchableThrottle';

const FlexItem = Flex.Item;
const icon = 'https://image.ymm56.com/ymmfile/operation-biz/a0361c79-1f0e-4846-827d-4ee6a69a4cc3.png';

const defaultContact = {
  contactName: '',
  contactPhone: '',
  province: 0,
  provinceName: '',
  city: 0,
  cityName: '',
  area: 0,
  areaName: '',
  longitude: '0',
  latitude: '0',
  mapType: 2,
  address: '',
  companyName: '',
};

class CargoAddress extends React.Component<any> {
  backHandleListener: any;
  placePicker: any;
  constructor(props: any) {
    super(props);
  }

  state = {
    loadVisible: false,
    unLoadVisible: false,
    focusAddress: false,
    isAddressChanged: false,
    showFooterBtn: true,
    addressKeyWord: '', // 装卸货地址关键词
  };
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        MBBridge.app.ui.closeWindow({});
        return true;
      });
    }
  }
  componentDidMount() {
    const {
      cargoAddressStore: { provinceCityAreaSelect, contactType, contactList },
    } = this.props;
    const user = contactList[contactType - 1];
    setTimeout(() => {
      if (provinceCityAreaSelect && !user.provinceName && !user.areaName && !user.cityName) {
        this.onPlacePicker();
      }
    }, 1800);
  }

  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  // 底部按钮 不能被键盘顶起
  onCommonBlurFocus = (val: boolean) => {
    this.setState({ showFooterBtn: val });
  };

  // 选中客户后回调
  confirmSelect = (user: any) => {
    // 成功后回调
    MBBridge.rnruntime.handlebackResult({ data: user ? JSON.stringify(user) : '' });
    if (Platform.OS == 'ios') {
      setTimeout(() => {
        MBBridge.app.ui.closeWindow({});
      }, 300);
    }
  };

  onSubmit = () => {
    const {
      cargoAddressStore: {
        contactList,
        contactType,
        addressRequiredConfig,
        requiredConfig: {
          consignerCompanyNameIsRequired,
          consignerContactIsRequired,
          consignerPhoneIsRequired,
          deliveryTimeIsRequired,
          consigneeCompanyNameIsRequired,
          consigneeContactIsRequired,
          consigneePhoneIsRequired,
          arriveTimeIsRequired,
        },
        provinceCityAreaSelect,
      },
    } = this.props;

    const item = {
      shipper: contactType === 1 ? contactList[0] : null,
      consignee: contactType === 2 ? contactList[1] : null,
    };

    if (provinceCityAreaSelect && contactType === 1 && !contactList[0]?.provinceName) {
      return MBToast.show('请选择装货省市区');
    }

    if (contactType === 1 && !contactList[0]?.address) {
      return MBToast.show('请输入装货详细地址');
    }

    if (provinceCityAreaSelect && contactType === 2 && !contactList[1]?.provinceName) {
      return MBToast.show('请选择卸货省市区');
    }

    if (!provinceCityAreaSelect && contactType === 2 && !contactList[1]?.address) {
      return MBToast.show('请输入卸货详细地址');
    }

    if (
      (contactType === 1 &&
        addressRequiredConfig.loadAddressConfig &&
        contactList[0]?.longitude === '0' &&
        contactList[0]?.latitude === '0') ||
      (contactType === 2 &&
        addressRequiredConfig.unloadAddressConfig &&
        contactList[1]?.longitude === '0' &&
        contactList[1]?.latitude === '0')
    ) {
      MBToast.show('地址必须从搜索下拉框中选择');
      return;
    }

    if (contactType === 1) {
      if (consignerCompanyNameIsRequired && !contactList[0]?.companyName) {
        return MBToast.show('请输入发货单位');
      }

      if (consignerContactIsRequired && !contactList[0]?.contactName) {
        return MBToast.show('请输入发货人姓名');
      }

      if (consignerPhoneIsRequired && !contactList[0]?.contactPhone) {
        return MBToast.show('请输入联系电话');
      }

      if (deliveryTimeIsRequired && !contactList[0]?.handlingTime) {
        return MBToast.show('请选择预计装货时间');
      }
    }

    if (contactType === 2) {
      if (consigneeCompanyNameIsRequired && !contactList[1]?.companyName) {
        return MBToast.show('请输入卸货单位');
      }

      if (consigneeContactIsRequired && !contactList[1]?.contactName) {
        return MBToast.show('请输入卸货人姓名');
      }

      if (consigneePhoneIsRequired && !contactList[1]?.contactPhone) {
        return MBToast.show('请输入联系电话');
      }

      if (arriveTimeIsRequired && !contactList[1]?.handlingTime) {
        return MBToast.show('请选择预计卸货时间');
      }
    }

    this.confirmSelect(item);
  };

  // 联想地址选择
  onSelectAddressAssociate = (item: AssociateResponseParams) => {
    const { addressKeyWord } = this.state;
    const { poiName, address } = item;
    const {
      cargoAddressStore: { clearAddressAssociateList, clearhisAssociateList, contactType, sensitiveWordList },
    } = this.props;

    let handleAddress = '';
    let isSensitiveWordpoiName = false;
    let isSensitiveWordAddress = false;
    if (poiName) {
      isSensitiveWordpoiName = sensitiveWordList.some((item: any) => {
        return poiName.includes(item);
      });
    }

    isSensitiveWordAddress = sensitiveWordList.some((item: any) => {
      return address.includes(item);
    });

    if (isSensitiveWordpoiName) {
      handleAddress = address;
    }

    if (isSensitiveWordAddress) {
      handleAddress = poiName;
    }

    if (!isSensitiveWordpoiName && !isSensitiveWordAddress) {
      /**
       * 1、poiName中包含检索值keyWord，选中值 = address + poiName
       * 2、poiName和detailAddress中都包含检索值keyWord，选中值 = detailAddress
       * 3、poiName中不包含检索值keyWord，选中值 = detailAddress
       */
      handleAddress = address;
      if (addressKeyWord && poiName && poiName.includes(addressKeyWord) && !address.includes(addressKeyWord)) {
        handleAddress = address + poiName;
      }
    }

    const handleItem = { ...item, address: handleAddress, contactType };

    this.setState({
      isAddressChanged: false,
    });
    clearAddressAssociateList();
    clearhisAssociateList();
    this.onSaveContactList(handleItem);
    Keyboard.dismiss();
  };

  // 保存装货人信息/卸货人信息
  onSaveContactList = (item: any) => {
    const {
      cargoAddressStore: { contactList, contactType, saveContactList },
    } = this.props;

    if (contactType === 1) {
      // 仅修改发货人
      const shipper = Object.assign(contactList[0], item);
      saveContactList([shipper, contactList[1]]);
    } else {
      // 仅修改收货人
      const consignee = Object.assign(contactList[1], item);
      saveContactList([contactList[0], consignee]);
    }
  };

  // 选择装货卸货时间
  handleDateTimePress = (index: number) => {
    if (index === 1) {
      this.setState({
        loadVisible: true,
      });
    } else {
      this.setState({
        unLoadVisible: true,
      });
    }
  };

  // 输入地址、姓名、电话
  onChangeCargoInfo = (item: any) => {
    const {
      cargoAddressStore: {
        fetchAddressAssociate,
        fetchHisAssociate,
        clearAddressAssociateList,
        clearhisAssociateList,
        contactList,
        contactType,
        saveContactList,
        provinceCityAreaSelect,
      },
    } = this.props;
    const { isAddressChanged } = this.state;
    const cargoKey = Object.keys(item)[0];

    // 搜索联想地址
    if (cargoKey === 'address') {
      // 保存装卸货搜索keyword
      this.setState({
        addressKeyWord: item.address,
      });

      if (contactType === 1) {
        // 仅修改发货人
        const { contactName, contactPhone, handlingTime, companyName, provinceName, ...restData } = contactList[0];
        const handleItem = {
          contactType,
          contactName,
          contactPhone,
          handlingTime,
          companyName,
          address: item.address,
        };
        let shipper = { ...contactList[0], ...handleItem };

        if ((provinceCityAreaSelect && !provinceName) || (!provinceCityAreaSelect && !item.address)) {
          shipper = { ...defaultContact, ...handleItem };
        }

        saveContactList([shipper, contactList[1]]);
      } else {
        // 仅修改收货人
        const { contactName, contactPhone, handlingTime, companyName, provinceName, ...restData } = contactList[1];
        const handleItem = {
          contactType,
          contactName,
          contactPhone,
          handlingTime,
          companyName,
          address: item.address,
        };

        let consignee = { ...contactList[1], ...handleItem };

        if ((provinceCityAreaSelect && !provinceName) || (!provinceCityAreaSelect && !item.address)) {
          consignee = { ...defaultContact, ...handleItem };
        }
        saveContactList([contactList[0], consignee]);
      }

      if (!isAddressChanged) {
        this.setState({
          isAddressChanged: true,
        });
      }

      // item.address为空时，联想接口报错，故拦截不再查询
      if (!item.address) {
        clearAddressAssociateList();
        clearhisAssociateList();
        return;
      }

      fetchHisAssociate({
        address: item.address,
        type: contactType,
        shipperAddress: contactList[0]?.address ? contactList[0]?.address : null, // 仅需要装货地址参数
      });

      const adCode = contactList[contactType - 1]?.area;
      fetchAddressAssociate({
        adCode,
        keyWords: item.address,
        cityLimit: !!adCode,
      });
    } else {
      this.onSaveContactList(item);
    }
  };

  // 省市区确认选择
  confirmAddress = (data: any) => {
    const {
      cargoAddressStore: { contactType, contactList, saveContactList, addressRequiredConfig },
    } = this.props;
    const { currentProvinceItem, currentCityItem, currentRegionItem } = data;
    const provinceName = currentProvinceItem?.shortName || '';
    const cityName = currentCityItem?.shortName || '';
    const areaName = currentRegionItem?.shortName || '';
    // 经纬度选择： 区 > 市 > 省
    const latitude = currentRegionItem?.lat || currentCityItem?.lat || currentProvinceItem?.lat;
    const longitude = currentRegionItem?.lon || currentCityItem?.lon || currentProvinceItem?.lon;
    const province = currentProvinceItem?.id;
    const city = currentCityItem?.id;
    const area = currentRegionItem?.id;
    const item = {
      province: province ? Number(province) : 0,
      provinceName,
      area: currentRegionItem?.deep === 4 ? currentRegionItem?.parentId : area ? Number(area) : 0, // 直筒子市下，存其父级parentId
      areaName,
      city: city ? Number(city) : 0,
      cityName,
      companyName: '',
      contactId: 0,
      contactName: '',
      contactPhone: '',
      custId: null,
      custName: '',
      isFromResolution: 0,
      latitude: latitude + '',
      longitude: longitude + '',
      mapType: 2,
      address: '',
      poiName: '',
    };
    // 是否下拉框选择
    let addressRequired = false;
    if (contactType === 1) {
      addressRequired = addressRequiredConfig.loadAddressConfig;
    } else {
      addressRequired = addressRequiredConfig.unloadAddressConfig;
    }

    if (contactType === 1) {
      // 仅修改装货地址
      const shipper = Object.assign(contactList[0], { ...item, contactType: 1 });
      saveContactList([shipper, contactList[1]]);
    } else {
      // 仅修改卸货地址
      let consignee = contactList[1];
      let address = consignee.address || '';

      /**
       * 卸货地址：开启省市区
       * 1：详细地址有值：选完省市区
       *   1.1：开启下拉框选择 且 选择的区id不等于原有的区id，则详细地址address等于现选择的省市区名称拼接
       *   1.1：不开启下拉框选择，详细地址address不变，保持原有值
       * 2：详细地址没值：选完省市区，详细地址address等于省市区名称拼接
       */
      if ((!!address && !addressRequired && consignee?.area && item?.area !== consignee?.area) || !address) {
        address = provinceName + cityName + areaName;
      }
      consignee = Object.assign(contactList[1], { ...item, contactType: 2, address });
      saveContactList([contactList[0], consignee]);
    }
  };

  // 打开省市区组件
  onPlacePicker = () => {
    const {
      cargoAddressStore: { contactType, contactList },
    } = this.props;
    const user = contactList[contactType - 1];
    this.placePicker.show({
      level: 3,
      defaultPlaceId: user.area || null,
    });
  };

  // 清空装货/卸货地址相关的所有信息
  clearPageInfo = () => {
    const {
      cargoAddressStore: { initContactList },
    } = this.props;
    initContactList();
  };

  renderUserItem = (user: ContactUser): JSX.Element => {
    const {
      cargoAddressStore: {
        moduleData,
        contactType,
        clearAddressAssociateList,
        clearhisAssociateList,
        requiredConfig: {
          consignerCompanyNameIsRequired,
          consignerContactIsRequired,
          consignerPhoneIsRequired,
          deliveryTimeIsRequired,
          consigneeCompanyNameIsRequired,
          consigneeContactIsRequired,
          consigneePhoneIsRequired,
          arriveTimeIsRequired,
        },
        provinceCityAreaSelect,
      },
    } = this.props;
    const { focusAddress } = this.state;

    let companyNameRequired = contactType === 1 ? consignerCompanyNameIsRequired : consigneeCompanyNameIsRequired;
    let contactNameRequired = contactType === 1 ? consignerContactIsRequired : consigneeContactIsRequired;
    let contactPhoneRequired = contactType === 1 ? consignerPhoneIsRequired : consigneePhoneIsRequired;
    let deliveryConsigneeDateRequired = contactType === 1 ? deliveryTimeIsRequired : arriveTimeIsRequired;
    const provinceCityAreaName = user.provinceName + user.cityName + user.areaName;

    return (
      <View key={contactType}>
        {!provinceCityAreaSelect ? (
          <Flex direction="row">
            <FlexItem style={styles.flexItemStyle}>
              <View style={styles.itemLableIcon}>
                <Image style={styles.itemIcon} source={{ uri: user.contactType === 1 ? Images.icon_shipper : Images.icon_consignee }} />
                <MBText style={styles.itemRequired}>*</MBText>
              </View>
              <View style={styles.flexStyle}>
                <InputItem
                  placeholder={contactType === 1 ? moduleData.shipperPlaceholder : moduleData.consigneePlaceholder}
                  value={user.address}
                  maxLength={100}
                  inputStyle={styles.inputStyle}
                  onChangeText={(value: string) => {
                    this.onChangeCargoInfo({ address: value });
                  }}
                  onSubmitEditing={() => {
                    this.setState({
                      isAddressChanged: false,
                    });
                    clearAddressAssociateList();
                    clearhisAssociateList();
                  }}
                  onFocus={() => {
                    this.setState({
                      focusAddress: true,
                    });
                    this.onCommonBlurFocus(false);
                  }}
                  onBlur={() => {
                    this.setState({
                      focusAddress: false,
                    });
                    this.onCommonBlurFocus(true);
                  }}
                />
              </View>
            </FlexItem>
            <TouchableOpacity activeOpacity={0.8} onPress={() => this.onChangeCargoInfo({ address: '' })}>
              <View style={styles.iconClearBtn}>
                <Image source={Images.icon_clear} style={{ width: 16, height: 16 }} />
              </View>
            </TouchableOpacity>
          </Flex>
        ) : null}

        {provinceCityAreaSelect ? (
          <TouchableThrottle activeOpacity={0.8} waitSecond={3} onPress={this.onPlacePicker}>
            <Flex direction="row" style={styles.addressWarpper}>
              <FlexItem style={styles.flexItemStyle}>
                <View style={styles.iconWrapper}>
                  <Image style={styles.itemIcon} source={{ uri: user.contactType === 1 ? Images.icon_shipper : Images.icon_consignee }} />
                  <MBText style={styles.itemRequired}>*</MBText>
                </View>

                <View style={styles.addressWrapper}>
                  {provinceCityAreaName ? (
                    <MBText ellipsizeMode={'tail'} numberOfLines={1} style={styles.inputStyle}>
                      {provinceCityAreaName}
                    </MBText>
                  ) : (
                    <MBText style={styles.placeholderStyle}>
                      {user.contactType === 1
                        ? moduleData.shipperProvinceCityAreaPlaceholder
                        : moduleData.consigneeProvinceCityAreaPlaceholder}
                    </MBText>
                  )}
                </View>
              </FlexItem>
            </Flex>
          </TouchableThrottle>
        ) : null}

        {provinceCityAreaSelect ? (
          <Flex direction="row">
            <FlexItem style={styles.flexItemStyle}>
              <View style={styles.itemLableIcon}>
                <Image style={styles.itemIcon} source={{ uri: '' }} />
                {user.contactType === 1 ? <MBText style={styles.itemRequired}>*</MBText> : null}
              </View>
              <View style={styles.flexStyle}>
                <InputItem
                  placeholder={
                    user.contactType === 1 ? moduleData.detailShipperAddressPlaceHolder : moduleData.detailConsigneeAddressPlaceHolder
                  }
                  value={user.address}
                  maxLength={100}
                  inputStyle={styles.addressInputStyle}
                  onChangeText={(value: string) => {
                    this.onChangeCargoInfo({ address: value });
                  }}
                  onSubmitEditing={() => {
                    this.setState({
                      isAddressChanged: false,
                    });
                    clearAddressAssociateList();
                    clearhisAssociateList();
                  }}
                  onFocus={() => {
                    this.setState({
                      focusAddress: true,
                    });
                    this.onCommonBlurFocus(false);
                  }}
                  onBlur={() => {
                    this.setState({
                      focusAddress: false,
                    });
                    this.onCommonBlurFocus(true);
                  }}
                />
              </View>
            </FlexItem>
            <TouchableOpacity activeOpacity={0.8} onPress={() => this.onChangeCargoInfo({ address: '' })}>
              <View style={styles.iconClearBtn}>
                <Image source={Images.icon_clear} style={{ width: 16, height: 16 }} />
              </View>
            </TouchableOpacity>
          </Flex>
        ) : null}

        <Splitline type="dashed" />
        <Flex direction="row" style={styles.flexPadding}>
          <FlexItem style={styles.flexItemStyle}>
            <View style={styles.itemLableIcon}>
              <Image style={styles.itemIcon} source={{ uri: Images.companyName_icon }} />
              {companyNameRequired ? <MBText style={styles.itemRequired}>*</MBText> : null}
            </View>
            <View style={styles.contactName}>
              <InputItem
                placeholder={contactType === 1 ? moduleData.shipmentsPlaceHolder : moduleData.receivingPlaceHolder}
                inputStyle={styles.inputStyle}
                value={user.companyName}
                maxLength={200}
                onChangeText={(value: string) => {
                  this.onChangeCargoInfo({ companyName: value });
                }}
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
            </View>
          </FlexItem>
        </Flex>
        <Splitline type="dashed" />

        <Flex direction="row" style={styles.flexPadding}>
          <FlexItem style={styles.flexItemStyle}>
            <View style={styles.itemLableIcon}>
              <Image style={styles.itemIcon} source={{ uri: Images.icon_peopleGary }} />
              {contactNameRequired ? <MBText style={styles.itemRequired}>*</MBText> : null}
            </View>

            <View style={styles.contactName}>
              <InputItem
                placeholder={contactType === 1 ? moduleData.deliveryNamePlaceholder : moduleData.consigneeNamePlaceholder}
                maxLength={100}
                inputStyle={styles.inputStyle}
                value={user.contactName}
                extraNode={<View></View>}
                onChangeText={(value: string) => {
                  this.onChangeCargoInfo({ contactName: value });
                }}
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
            </View>

            <View style={styles.linkRight}></View>

            <View style={styles.contactPhone}>
              {contactPhoneRequired ? <MBText style={styles.contactPhoneRequired}>*</MBText> : null}
              <InputItem
                placeholder={moduleData.phonePlaceholder}
                maxLength={20}
                inputStyle={styles.inputStyle}
                keyboardType={Platform.OS == 'ios' ? 'numbers-and-punctuation' : 'numeric'}
                value={user.contactPhone}
                extraNode={<View></View>}
                onChangeText={(value: string) => {
                  this.onChangeCargoInfo({ contactPhone: value });
                }}
                onFocus={() => {
                  this.onCommonBlurFocus(false);
                }}
                onBlur={() => {
                  this.onCommonBlurFocus(true);
                }}
              />
            </View>
          </FlexItem>
        </Flex>

        <Splitline type="dashed" />

        <View style={styles.deliveryConsigneeDateWrapper}>
          {deliveryConsigneeDateRequired ? <MBText style={styles.deliveryConsigneeRequired}>*</MBText> : null}
          <Cell
            style={styles.cellStyle}
            icon={<Image style={styles.itemIcon} source={{ uri: icon }} />}
            title={' '}
            fontSize={autoFix(30)}
            placeholder={contactType === 1 ? moduleData.deliveryDatePlaceholder : moduleData.consigneeDatePlaceholder}
            align="left"
            isLink={false}
            value={user.handlingTime?.displayValue}
            onPress={() => {
              this.handleDateTimePress(contactType);
            }}
          />
        </View>

        <Splitline type="dashed" />

        <View style={styles.clearBtnWrapper}>
          <TouchableThrottle activeOpacity={0.8} waitSecond={3} onPress={this.clearPageInfo}>
            <MBText style={styles.clearBtn}>清空</MBText>
          </TouchableThrottle>
        </View>
      </View>
    );
  };

  /**
   * 渲染卡片
   * @param item
   * @param onSelect
   * @returns
   */

  renderItem = (item: CustomerModel, index: number, onSelect: () => void): JSX.Element => {
    const {
      cargoAddressStore: { contactType },
    } = this.props;

    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onSelect} key={index}>
        <View style={[styles.listItem, !index ? styles.listItemIndexFirst : {}]}>
          <MBText style={[styles.listItemTitle]}>{item.customerName}</MBText>

          {contactType === 1 &&
            (item.shipper ? (
              <View style={styles.listItemSubTitle}>
                {item.shipper?.address ? (
                  <View style={{ flexDirection: 'row' }}>
                    <MBText style={styles.address} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.shipper?.address}
                    </MBText>
                  </View>
                ) : null}

                {item.shipper?.companyName ? (
                  <View style={{ flexDirection: 'row' }}>
                    <MBText style={styles.address} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.shipper?.companyName}
                    </MBText>
                  </View>
                ) : null}

                {item.shipper?.contactName || item.shipper?.contactPhone ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    {item.shipper?.contactName ? (
                      <MBText style={styles.userName} numberOfLines={1} ellipsizeMode="tail" size="xs">
                        {item.shipper?.contactName}
                      </MBText>
                    ) : null}
                    {item.shipper?.contactPhone ? (
                      <MBText size="xs" style={styles.tel}>
                        {item.shipper?.contactPhone}
                      </MBText>
                    ) : null}
                  </View>
                ) : null}
              </View>
            ) : null)}

          {contactType === 2 &&
            (item.consignee ? (
              <View style={styles.listItemSubTitle}>
                {item.consignee?.address ? (
                  <View style={{ flexDirection: 'row' }}>
                    <MBText style={styles.address} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.consignee?.address}
                    </MBText>
                  </View>
                ) : null}

                {item.consignee?.companyName ? (
                  <View style={{ flexDirection: 'row' }}>
                    <MBText style={styles.address} numberOfLines={1} ellipsizeMode="tail" size="xs">
                      {item.consignee?.companyName}
                    </MBText>
                  </View>
                ) : null}

                {item.consignee?.contactName || item.consignee?.contactPhone ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    {item.consignee?.contactName ? (
                      <MBText style={styles.userName} numberOfLines={1} ellipsizeMode="tail" size="xs">
                        {item.consignee?.contactName}
                      </MBText>
                    ) : null}
                    {item.consignee?.contactPhone ? (
                      <MBText size="xs" style={styles.tel}>
                        {item.consignee?.contactPhone}
                      </MBText>
                    ) : null}
                  </View>
                ) : null}
              </View>
            ) : null)}
        </View>
        <Splitline />
      </TouchableOpacity>
    );
  };

  /**
   * 装卸货历史渲染视图
   * @param store
   * @returns
   */
  renderShipperConsigneeView = () => {
    const {
      cargoAddressStore: { contactType, isLoading, historyRecordList, hasShipperhistory, hasConsigneehistory },
    } = this.props;

    return (
      <View style={styles.historyList}>
        {!isLoading &&
          (historyRecordList.length === 0 || (contactType === 1 && !hasShipperhistory) || (contactType === 2 && !hasConsigneehistory)) && (
            <View>
              <Whitespace vertical={14} />
              <MBText align="center" color="#ccc">
                {contactType === 1 ? '无最近装货方历史' : '无最近卸货方历史'}
              </MBText>
            </View>
          )}

        {historyRecordList.length > 0 && ((contactType === 1 && hasShipperhistory) || (contactType === 2 && hasConsigneehistory)) && (
          <View>
            <View style={styles.historyTitle}>
              <MBText color="#666">{contactType === 1 ? '最近装货' : '最近卸货'}</MBText>
            </View>
            <View style={styles.listWrapper}>
              <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
                <View>
                  {historyRecordList.map((item: any, index: number) => {
                    if ((contactType === 1 && item.shipper) || (contactType === 2 && item.consignee)) {
                      return this.renderItem(
                        {
                          customerName: item.customerName,
                          customerId: item.customerId,
                          shipper: item.shipper,
                          consignee: item.consignee,
                        },
                        index,
                        () => {
                          this.confirmSelect({
                            shipper: contactType === 1 ? item.shipper : null,
                            consignee: contactType === 2 ? item.consignee : null,
                          });
                        }
                      );
                    } else {
                      return null;
                    }
                  })}
                </View>
              </ScrollView>
            </View>
          </View>
        )}
      </View>
    );
  };

  render(): JSX.Element {
    const {
      cargoAddressStore: {
        contactType,
        contactList,
        updateDatetime,
        addressAssociateList,
        hisAssociateList,
        addressRequiredConfig,
        searchAddressLoading,
        regionData,
        provinceCityAreaSelect,
      },
    } = this.props;

    const { loadVisible, unLoadVisible, isAddressChanged, showFooterBtn } = this.state;
    const user = contactList[contactType - 1];
    let addressRequired = false;
    if (contactType === 1) {
      addressRequired = addressRequiredConfig.loadAddressConfig;
    } else {
      addressRequired = addressRequiredConfig.unloadAddressConfig;
    }

    return (
      <View style={styles.container}>
        <NavBar title={contactType === 1 ? '装货地址' : '卸货地址'} />
        <SafeAreaView style={styles.flexStyle}>
          <ScrollView scrollEnabled={!((hisAssociateList.length || addressAssociateList.length) && user.address)}>
            <View style={styles.flexStyle}>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <View style={styles.deliveryAddress}>{this.renderUserItem(user)}</View>
                <PlacePicker
                  ref={(ref: PlacePicker) => (this.placePicker = ref)}
                  placeData={regionData}
                  confirm={(res: any) => {
                    this.confirmAddress(res);
                  }}
                />
              </CellGroup>

              {this.renderShipperConsigneeView()}

              {(hisAssociateList.length || addressAssociateList.length) && user.address ? (
                <View style={[styles.addressAssociate, provinceCityAreaSelect ? styles.provinceCityAreaAddressAssociate : {}]}>
                  <AddressList
                    inputText={user.address}
                    addressList={addressAssociateList}
                    hisAddressList={hisAssociateList}
                    onSelect={this.onSelectAddressAssociate}
                  />
                </View>
              ) : addressRequired && !searchAddressLoading && isAddressChanged && user.address ? (
                <View style={[styles.addressAssociate, provinceCityAreaSelect ? styles.provinceCityAreaAddressAssociate : {}]}>
                  <Whitespace vertical={14} />
                  <MBText align="center" color="#ccc">
                    无搜索结果
                  </MBText>
                </View>
              ) : null}
            </View>
          </ScrollView>
          {showFooterBtn ? <CargoFooter onPress={this.onSubmit} /> : null}
        </SafeAreaView>

        <TimePickerModal
          key="load"
          type="loadTimeMonth"
          visible={loadVisible}
          onChange={(value: any) => {
            if (contactList[1].handlingTime?.endTimestamp && value?.endTimestamp) {
              if (contactList[1].handlingTime?.endTimestamp < value.endTimestamp) {
                MBToast.show('卸货时间不能小于装货时间');
              }
            }

            updateDatetime(0, value);
            this.setState({
              loadVisible: false,
            });
          }}
          onCancel={() => {
            this.setState({
              loadVisible: false,
            });
          }}
          defaultTime={contactList[0].handlingTime}
        />

        <TimePickerModal
          key="unload"
          type="unloadTimeMonth"
          visible={unLoadVisible}
          onChange={(value: any) => {
            if (contactList[0].handlingTime?.endTimestamp && value?.endTimestamp) {
              if (contactList[0].handlingTime?.endTimestamp > value.endTimestamp) {
                MBToast.show('卸货时间不能小于装货时间');
              }
            }

            updateDatetime(1, value);
            this.setState({
              unLoadVisible: false,
            });
          }}
          onCancel={() => {
            this.setState({
              unLoadVisible: false,
            });
          }}
          defaultTime={contactList[1].handlingTime}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  historyList: {
    padding: autoFix(20),
    marginTop: autoFix(80),
    paddingBottom: autoFix(300),
  },

  historyTitle: {
    color: '#666',
    fontSize: autoFix(28),
    paddingLeft: autoFix(10),
  },

  addressAssociateWrapper: {
    position: 'relative',
  },

  addressAssociate: {
    position: 'absolute',
    left: autoFix(90),
    top: autoFix(110),
    width: autoFix(598),
    minHeight: autoFix(132),
    maxHeight: autoFix(532),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 5, height: 5 },
    shadowRadius: autoFix(20),
    elevation: 20,
    borderRadius: autoFix(8),
  },

  provinceCityAreaAddressAssociate: {
    top: autoFix(200),
  },

  listWrapper: {
    backgroundColor: '#fff',
    marginTop: autoFix(20),
    paddingTop: autoFix(20),
    marginBottom: autoFix(220),
  },

  listItem: {
    padding: autoFix(28),
  },

  listItemIndexFirst: {
    paddingTop: 0,
  },

  listItemTitle: {
    color: '#333',
    fontSize: autoFix(30),
    fontWeight: 'bold',
  },

  listItemSubTitle: {
    marginTop: autoFix(8),
  },

  inputStyle: {
    fontSize: autoFix(30),
  },

  cellStyle: {
    paddingLeft: 0,
  },

  itemIcon: {
    width: autoFix(42),
    height: autoFix(42),
  },

  contactName: {
    flex: 1,
  },

  contactPhone: {
    position: 'relative',
    width: autoFix(260),
  },

  linkRight: {
    width: autoFix(1),
    height: autoFix(24),
    backgroundColor: '#E8E8E8',
  },

  address: {
    color: '#666',
    fontSize: autoFix(28),
    flexShrink: 1,
    marginTop: autoFix(8),
  },

  userName: {
    color: '#666',
    fontSize: autoFix(28),
    marginRight: autoFix(10),
  },

  tel: {
    color: '#666',
    fontSize: autoFix(28),
  },

  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  deliveryAddress: {
    paddingLeft: autoFix(28),
  },

  flexPadding: {
    paddingRight: autoFix(28),
  },

  flexItemStyle: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },

  companyName: {
    fontSize: autoFix(30),
    color: '#666',
    marginBottom: 10,
  },

  placeholder: {
    fontSize: autoFix(30),
    color: '#CCC',
  },

  area: {
    marginBottom: 6,
    color: '#333',
    fontWeight: 'bold',
    fontSize: autoFix(32),
  },

  userInfo: {
    fontSize: autoFix(26),
    color: '#666',
  },

  itemArrowWrapper: {
    justifyContent: 'flex-end',
    marginLeft: 8,
  },

  itemArrow: {
    width: 8,
    height: 14,
  },

  itemLableIcon: {
    position: 'relative',
  },

  itemRequired: {
    position: 'absolute',
    top: autoFix(-6),
    right: autoFix(-14),
    fontSize: 15,
    color: '#FF4040',
  },

  contactPhoneRequired: {
    position: 'absolute',
    top: autoFix(22),
    left: autoFix(8),
    fontSize: 15,
    color: '#FF4040',
  },

  deliveryConsigneeDateWrapper: {
    position: 'relative',
  },

  deliveryConsigneeRequired: {
    position: 'absolute',
    top: autoFix(22),
    left: autoFix(44),
    fontSize: 15,
    color: '#FF4040',
    zIndex: 99,
  },

  addressWarpper: {
    paddingTop: autoFix(28),
  },

  iconWrapper: {
    marginRight: autoFix(28),
  },

  addressWrapper: {
    flex: 1,
  },

  addressInputStyle: {
    fontSize: autoFix(26),
    color: '#666',
  },

  placeholderStyle: {
    fontSize: autoFix(30),
    color: '#ccc',
  },

  clearBtnWrapper: {
    alignItems: 'flex-end',
  },

  clearBtn: {
    width: autoFix(120),
    paddingTop: autoFix(24),
    paddingBottom: autoFix(24),
    textAlign: 'center',
    color: '#999999',
    fontSize: autoFix(30),
  },
  iconClearBtn: {
    paddingVertical: autoFix(24),
    paddingHorizontal: autoFix(24),
  },
});

export default inject('cargoAddressStore')(observer(CargoAddress));
