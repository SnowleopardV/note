import GoodsInfoStore from '../goods-info/store';
import DliveryAddressStore from '../delivery-address/store';
import MoreInfoStore from '../more-info/store';
import WaybillCreateStore from '../create/store';

class PageStore {
  constructor() {
    this.goodsInfoStore = new GoodsInfoStore(this);
    this.waybillCreateStore = new WaybillCreateStore(this);
    this.deliveryAddressStore = new DliveryAddressStore(this);
    this.moreInfoStore = new MoreInfoStore(this);
  }

  get stores() {
    return {
      goodsInfoStore: this.goodsInfoStore,
      waybillCreateStore: this.waybillCreateStore,
      deliveryAddressStore: this.deliveryAddressStore,
      moreInfoStore: this.moreInfoStore,
    };
  }
}
export default PageStore;
