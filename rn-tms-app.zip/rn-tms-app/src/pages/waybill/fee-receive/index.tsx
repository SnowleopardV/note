import { MBBridge, MBToast } from '@ymm/rn-lib';
import React from 'react';
import { View, StyleSheet, Platform, BackHandler, NativeEventSubscription, Keyboard } from 'react-native';
import NavBar from '~/components/common/NavBar';
import FeeReceiveContent from './components/FeeReceiveContent';
import ModalFeeCompute from './components/ModalFeeCompute';
import WaybillCreateStore from '~/pages/waybill/create/store';
import GoodsInfoStore from '~/pages/waybill/goods-info/store';
import DeliveryAddressStore from '~/pages/waybill/delivery-address/store';
import MoreInfoStore from '~/pages/waybill/more-info/store';
import RegTest from '~/utils/RegTest';
import { inject, observer } from 'mobx-react';
import { MBText } from '@ymm/rn-elements';

export interface FeeReceiveIndexProps {
  navigation: any;
  screenProps: any;
  waybillCreateStore: WaybillCreateStore;
  goodsInfoStore: GoodsInfoStore;
  deliveryAddressStore: DeliveryAddressStore;
  moreInfoStore: MoreInfoStore;
}

@inject('waybillCreateStore', 'goodsInfoStore', 'deliveryAddressStore', 'moreInfoStore')
@observer
class FeeReceiveIndex extends React.Component<FeeReceiveIndexProps, any> {
  backHandleListener?: NativeEventSubscription;
  keyboardWillShowListener: any;
  keyboardWillHideListener: any;
  refFeeReceiveContent: FeeReceiveContent | any;
  constructor(props: FeeReceiveIndexProps) {
    super(props);
    const {
      waybillCreateStore: { editEnum },
      goodsInfoStore: { stateData },
    } = props;

    this.state = {
      showFooterBtn: true,
      unsaveFeeList: [],
      keyboardHeight: 0,
      editEnum,
      copyStockValue: stateData.stockValue,
      feeComputeModalVisible: false,
      feeComputeData: {
        priceName: '',
        priceRules: [],
        computeResult: '',
        chargeData: {
          type: '',
          name: '',
        },
      },
      currentFeeCode: null,
    };
  }

  UNSAFE_componentWillMount() {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  }

  componentDidMount() {
    const {
      navigation,
      waybillCreateStore: {
        stateData: { feeList },
      },
      goodsInfoStore: { stateData },
    } = this.props;
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        stateData.stockValue = this.state.copyStockValue;
        navigation.goBack();
        return true;
      });
    } else {
      this.keyboardWillShowListener = Keyboard.addListener('keyboardDidShow', (el) => this.onKeyboardDidShow(el));
      this.keyboardWillHideListener = Keyboard.addListener('keyboardDidHide', (el) => this.onKeyboardDidHide(el));
    }

    this.setRules(feeList);
  }

  componentWillUnmount(): void {
    if (Platform.OS === 'android') {
      this.backHandleListener?.remove();
    } else {
      this.keyboardWillShowListener?.remove();
      this.keyboardWillHideListener?.remove();
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }

  onKeyboardDidShow(el: any): void {
    this.setState({ keyBoardHeight: el.endCoordinates.height });
  }

  onKeyboardDidHide(el: any): void {
    this.setState({ keyBoardHeight: 0 });
  }

  // 费用填写
  onChangeFee = (amount: string, data: any) => {
    const { unsaveFeeList } = this.state;
    const valueArr = amount.split('.')[0];
    console.log('onChangeFee amount',amount);

    if (valueArr.length > 9) return;
    if (!RegTest.twoPrecision(amount) && amount) return;
    if (RegTest.emoji(amount)) return;

    if (data.isRequired) {
      // amount可填写为0（number/string）
      data.isError = !amount && amount !== '0';
    }

    const itemChange = {
      feeCode: data.feeCode,
      amount,
      isError: data.isError,
      priceType: 0, // 0 手动填写，1 自动计算
    };

    const handleFeeList = unsaveFeeList.map((item: any) => {
      let handleItem = { ...item };
      if (item.feeCode === data.feeCode) {
        handleItem = { ...item, ...itemChange };
      }
      return handleItem;
    });

    this.setState({
      unsaveFeeList: handleFeeList,
    });
    this.onUpdateFeeList(handleFeeList)
  };

  // 费用实时合计，已更新税费
  onUpdateFeeList = (unsaveFeeList:[]) => {
    const {
      moreInfoStore
    } = this.props;
    moreInfoStore.setUnsaveFeeLisList(unsaveFeeList) 
  };

  // 底部确定
  onConfirm = () => {
    const { unsaveFeeList } = this.state;
    const {
      navigation,
      waybillCreateStore: { onConfirmFreightReceive, handleFeeListPriceSnapshot },
    } = this.props;

    // 必填校验拦截提交
    if (this.validate()) {
      onConfirmFreightReceive(unsaveFeeList);
      handleFeeListPriceSnapshot();
      navigation.goBack();
    }
  };

  // 初始化校验规则
  setRules = (feeList: any) => {
    const handleFeeList = feeList.map((item: any) => {
      item.isError = false;
      return item;
    });

    this.setState({
      unsaveFeeList: handleFeeList,
    });
    this.onUpdateFeeList(handleFeeList)
  };

  validate = () => {
    let errIndex = -1; // 未填的那一行下标
    const handleFeeList = this.state.unsaveFeeList.map((item: any, index: number) => {
      if (item.isRequired) {
        // amount可填写为0（number/string）
        if (!Number(item.amount)) {
          errIndex = errIndex > -1 ? errIndex : index;
          item.isError = true;
        } else {
          item.isError = false;
        }
      }
      return item;
    });

    this.setState({ unsaveFeeList: handleFeeList });
    if (errIndex > -1) {
      MBToast.show(handleFeeList[errIndex].feeCodeDesc + '未填');
      this.refFeeReceiveContent?.wrappedInstance.errInputScrollTo(errIndex);
    }
    // 检测数组所有元素isError均为false
    return errIndex == -1;
  };

  // 应用匹配价格弹窗
  onComputeModalVisible = () => {
    const { feeComputeModalVisible } = this.state;
    this.setState({
      feeComputeModalVisible: !feeComputeModalVisible,
    });
  };

  // 打开匹配价格弹窗并处理数据
  onModalFeeCompute = (item: any) => {
    this.setState({
      feeComputeData: item.appPriceSnapshotMap,
      currentFeeCode: item.feeCode,
      priceType: item.priceType, // 打开弹窗显示的类型：1：自动计算，2有合并计费的快照
    });
    this.onComputeModalVisible();
  };

  // 应用匹配价格
  onApplyFeeCompute = (amount: string) => {
    const { unsaveFeeList, currentFeeCode } = this.state;

    const itemChange = {
      feeCode: currentFeeCode,
      amount,
      priceType: 0, // 0 手动填写，1 自动计算
    };

    const handleFeeList = unsaveFeeList.map((item: any) => {
      let handleItem = { ...item };
      if (item.feeCode === currentFeeCode) {
        handleItem = { ...item, ...itemChange };
      }
      return handleItem;
    });

    this.setState({
      unsaveFeeList: handleFeeList,
    });
    this.onComputeModalVisible();
  };

  render() {
    const {
      navigation,
      waybillCreateStore: { isFromTms },
      deliveryAddressStore: {
        stateData: { contactList },
      },
      goodsInfoStore: { stateData },
      moreInfoStore: {
        stateData: { costMileage },
      },
    } = this.props;
    const { unsaveFeeList, feeComputeModalVisible, feeComputeData, priceType } = this.state;
    return (
      <View style={styles.container}>
        <NavBar
          title="应收费用"
          leftClick={() => {
            stateData.stockValue = this.state.copyStockValue;
            navigation.goBack();
          }}
          rightElement={
            <MBText color="primary" size="md" onPress={() => this.onConfirm()}>
              确定
            </MBText>
          }
        />
        <View style={styles.flexStyle}>
          <FeeReceiveContent
            ref={(ref) => (this.refFeeReceiveContent = ref)}
            navigation={navigation}
            feeList={unsaveFeeList}
            isFromTms={isFromTms}
            keyboardHeight={this.state.keyBoardHeight || 0}
            onChangeFee={this.onChangeFee}
            onModalFeeCompute={this.onModalFeeCompute}
          />
          <ModalFeeCompute
            visible={feeComputeModalVisible}
            feeComputeData={feeComputeData}
            contactList={contactList}
            cargoList={stateData.cargoList}
            costMileage={costMileage}
            priceType={priceType}
            onApply={this.onApplyFeeCompute}
            onCancel={this.onComputeModalVisible}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },
});

export default FeeReceiveIndex;
