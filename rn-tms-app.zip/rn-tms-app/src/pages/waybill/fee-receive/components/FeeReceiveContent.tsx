import React from 'react';
import { View, StyleSheet, ScrollView, Platform, Image } from 'react-native';
import { Flex, MBText, Splitline, RNElementsUtil, Whitespace, CellGroup, Cell } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import InputItem from '~/components/common/InputItem';
import TouchableThrottle from '~/components/TouchableThrottle';
import GoodsInfoStore from '~/pages/waybill/goods-info/store';
import WaybillCreateStore from '~/pages/waybill/create/store';
import RegTest from '~/utils/RegTest';
import { inject, observer } from 'mobx-react';
import images from '~public/static/images';
import { xyzMath } from '~/utils/xyzMath';
import MoreInfoStore from '../../more-info/store';
import ModalSettleType from '../../create/components/ModalSettleType';
import ModalIsInvoice from '../../more-info/components/ModalIsInvoice';
import ModalComputeTax from '../../more-info/components/ModalComputeTax';

export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}
interface FeeReceiveContentProps {
  navigation: any;
  feeList: any;
  isFromTms: boolean;
  keyboardHeight: number;
  onChangeFee: (amount: string, item: any) => void;
  onModalFeeCompute: (data: any) => void;
  goodsInfoStore: GoodsInfoStore;
  waybillCreateStore: WaybillCreateStore;
  moreInfoStore: MoreInfoStore
}
@inject('goodsInfoStore', 'waybillCreateStore','moreInfoStore')
@observer
export default class FeeReceiveContent extends React.Component<FeeReceiveContentProps, any> {
  scrollViewHeight: number = 0;
  refScrollView: ScrollView | null = null;
  refScrollLayout: any;
  inputLayoutList: any[] = [];
  refInput: any[] = [];
  constructor(props: FeeReceiveContentProps) {
    super(props);
  }

  onChangeStockValueData = (value: string) => {
    const {
      waybillCreateStore: { insuranceRate },
      goodsInfoStore: { onConfirmStockValueModal },
      feeList,
      onChangeFee,
    } = this.props;
    const valueArr = value.split('.')[0];
    if (valueArr.length > 9) return;
    if (!RegTest.twoPrecision(value) && value) return;
    if (RegTest.emoji(value)) return;
    const handleFeeList = feeList.filter((item: any) => item.feeCode === 8);
    const insuranceFeeItem = handleFeeList.length ? handleFeeList[0] : null;
    let handleInsuranceFee = '';
    // 保险费 = 申明价值 * 保险费率
    if (value && value !== '0') {
      const insuranceFee = insuranceRate && insuranceRate !== 0 ? xyzMath.multiply(value, insuranceRate) : '';
      const divideInsuranceFee = insuranceFee ? xyzMath.divide(insuranceFee, 1000) + '' : '';
      handleInsuranceFee = divideInsuranceFee ? xyzMath.round(divideInsuranceFee, 2) + '' : '';
    }

    if (insuranceRate && insuranceRate !== 0 && insuranceFeeItem) {
      onChangeFee(handleInsuranceFee, insuranceFeeItem);
    }

    onConfirmStockValueModal({ stockValue: value });
  };

  extraNode = (item: any) => {
    const { onModalFeeCompute } = this.props;
    
    return (
      <View style={styles.extraNode}>
        <MBText style={styles.itemUnit}>元</MBText>
        {!!item.appPriceSnapshotMap && (
          <TouchableThrottle
            activeOpacity={0.8}
            onPress={() => {
              onModalFeeCompute(item);
            }}
          > 
          {
            item.appPriceSnapshotMap.priceType == 1 ? (
              <Image style={styles.imgStyle} source={images.icon_price_chart} />
            ) : item.appPriceSnapshotMap.priceType == 2 ? (
              <Image style={styles.imgStyle} source={images.icon_combined_billing} />
            ) : null
          }
          </TouchableThrottle>
        )}
      </View>
    );
  };
  setRefInput(el: any, index: number) {
    this.refInput[index] = el;
  }
  onFocus(val: number): void {
    // 当输入框聚焦时，自动滚动到对应位置，防止被键盘遮挡
    setTimeout(() => {
      if (Platform.OS == 'ios') {
        const keyboardHeight = this.props.keyboardHeight;
        const y = this.inputLayoutList[val]?.y;
        const scrollY = this.refScrollLayout?.contentOffset?.y || 0;
        const viewHeight = this.scrollViewHeight - keyboardHeight - this.inputLayoutList[val].height - 20;
        const isScroll = y > scrollY + viewHeight;
        if (isScroll) {
          this.refScrollView?.scrollTo({ y: y - viewHeight });
        }
      }
    }, 650);
  }
  /** 滚动到对应的错误输入行 */
  errInputScrollTo = (index: number): void => {
    this.refInput[index || 0]?.focus();
  };

  // 下一步 光标到下一个输入框
  onSubmitEditing(index: number) {
    if (Platform.OS == 'ios') {
      this.refInput[index]?.blur();
    } else {
      this.refInput[index + 1]?.focus();
    }
  }

  filterTaxWay = () => {
    let handleTaxWay;
    const {
      moreInfoStore: {
        unsaveMoreInfoData: { taxWay },
      },
    } = this.props;

    switch (taxWay) {
      case 1:
        handleTaxWay = '应收合计含税';
        break;
      case 2:
        handleTaxWay = '应收合计不含税';
        break;
      default:
        handleTaxWay = '';
        break;
    }

    return handleTaxWay;
  };

  filterIsBilling = () => {
    let handleIsBilling;
    const {
      moreInfoStore: {
        unsaveMoreInfoData: { isBilling },
      },
    } = this.props;

    switch (isBilling) {
      case 1:
        handleIsBilling = '是';
        break;
      case 0:
        handleIsBilling = '否';
        break;
      default:
        handleIsBilling = '';
        break;
    }

    return handleIsBilling;
  };

  changeBillingRate = (value: string) => {
    const {
      moreInfoStore: { onChangeBillingRate },
    } = this.props;

    onChangeBillingRate && onChangeBillingRate(value);
  };

  rightElement = (extraValue: string, readonly?: boolean) => {
    return <MBText style={[styles.itemUnit, readonly ? { color: '#ccc' } : {}]}>{extraValue}</MBText>;
  };

  renderContent(): React.ReactNode {
    const { feeList, onChangeFee } = this.props;
    const {
      waybillCreateStore: { 
        stateData: { settleType },
        filterSettleType,
        editEnum,
        editNotReceivable,
        settleTypeModalVisible,
        onConfirmSettleTypeModal,
        changeSettleTypeModalVisible
       },
      goodsInfoStore: { stateData },
      moreInfoStore :{
        changeIsInvoiceModalVisible,
        changeComputeTaxModalVisible,
        onConfirmIsInvoiceModal,
        onConfirmComputeTaxModal,
        isInvoiceModalVisible,
        computeTaxModalVisible,
        taxFee,
        unsaveMoreInfoData:{
          isBilling,
          taxWay,
          billingRate,
        }
      },
    } = this.props;
    const readonlyFlag = (editEnum === 'ONE' && editNotReceivable) || editEnum === 'TWO' || editEnum === 'FOUR';

    // item?.feeCode 保险费前插入声明价值
    return (
      <View>
        <CellGroup withBottomLine style={{marginHorizontal:0}} >
          <Cell
            name="settleType"
            title="结算方式"
            align="right"
            required
            readonly={(editEnum === 'ONE' && editNotReceivable) || editEnum === 'TWO' || editEnum === 'FOUR'}
            value={filterSettleType}
            placeholder="请选择"
            onPress={changeSettleTypeModalVisible}
          />
        </CellGroup>
        <Whitespace vertical={10} />
        <View style={styles.listWrapper}>
          {feeList.map((item: any, index: number) => {
            return (
              <View key={index} onLayout={(el) => (this.inputLayoutList[index] = el.nativeEvent.layout)}>
                { item?.feeCode == 8 ? (
                  <View style={styles.stock} onLayout={(el) => (this.inputLayoutList[feeList.length] = el.nativeEvent.layout)}>
                    <InputItem
                      ref={(el) => this.setRefInput(el, feeList.length)}
                      style={[styles.inputStyle]}
                      styleItem={styles.styleItem}
                      titleStyle={styles.inputLable}
                      title="声明价值"
                      placeholder="请输入所有货物总价值"
                      keyboardType="numeric"
                      readonly={editEnum === 'TWO' || editEnum === 'FOUR'}
                      editable={editEnum !== 'TWO' && editEnum !== 'FOUR'}
                      value={stateData.stockValue ?? ''}
                      onChangeText={(value) => this.onChangeStockValueData(value)}
                      textAlign="right"
                      maxLength={9}
                      returnKeyType="done"
                      onFocus={() => this.onFocus(feeList.length)}
                      extraNode={this.rightElement('元', readonlyFlag)}
                      />
                    <Splitline />
                  </View>
                ) :<View />
                }
                <Flex direction="row">
                  <InputItem
                    ref={(el) => this.setRefInput(el, index)}
                    onSubmitEditing={() => this.onSubmitEditing(index)}
                    blurOnSubmit={false}
                    title={item.feeCodeDesc}
                    placeholder="请输入"
                    type="numeric"
                    textAlign="right"
                    maxLength={14}
                    required={item.isRequired}
                    titleStyle={styles.inputLable}
                    style={styles.inputStyle}
                    styleItem={styles.styleItem}
                    value={item.amount}
                    returnKeyType={Platform.OS == 'ios' ? 'done' : 'next'}
                    onChangeText={(value) => onChangeFee(value, item)}
                    onFocus={() => this.onFocus(index)}
                    extraNode={this.extraNode(item)}
                    extra={
                      item.isError && (
                        <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                          <MBText size="xs" color="#F54242" align="right">
                            {item.feeCodeDesc}未填
                          </MBText>
                          <Whitespace vertical={12} />
                        </View>
                      )
                    }
                  />
                </Flex>
                {index !== feeList.length - 1 ? <Splitline /> : null}
              </View>
            );
          })}
        </View>

        <Whitespace vertical={10} />
        <CellGroup withBottomLine style={{marginHorizontal:0}}>
          <Cell
            name="isBilling"
            title="是否开票"
            align="right"
            numberOfLines={1}
            readonly={readonlyFlag}
            value={this.filterIsBilling()}
            placeholder="请选择"
            onPress={changeIsInvoiceModalVisible}
          />
          {!!isBilling && (
            <Cell
              name="taxWay"
              title="计税方式"
              readonly={readonlyFlag}
              align="right"
              value={this.filterTaxWay()}
              onPress={changeComputeTaxModalVisible}
              placeholder="请选择"
            />
          )}

          {!!isBilling && (
            <InputItem
              title="税率"
              placeholder="请输入"
              keyboardType="numeric"
              readonly={readonlyFlag}
              editable={!readonlyFlag}
              value={!editNotReceivable ? billingRate : '*'}
              onChangeText={(value) => this.changeBillingRate(value)}
              textAlign="right"
              extraNode={this.rightElement('%', readonlyFlag)}
              onFocus={() => {
                // onCommonFocus && onCommonFocus();
              }}
              onBlur={() => {
                // onCommonBlur && onCommonBlur();
              }}
            />
          )}

          {(!!isBilling && (!!taxFee || taxFee === 0)) || editNotReceivable ? (
            <Cell
              name="settleType"
              title="税金"
              readonly={readonlyFlag}
              valueStyle={styles.taxValueStyle}
              align="right"
              value={!editNotReceivable ? taxFee + '' : '*'}
              rightElement={this.rightElement('元', readonlyFlag)}
            />
          ) : null}
        </CellGroup>
        
        <ModalSettleType
          visible={settleTypeModalVisible}
          settleType={settleType}
          onConfirm={onConfirmSettleTypeModal}
          onCancel={changeSettleTypeModalVisible}
        />
        <ModalIsInvoice
          visible={isInvoiceModalVisible}
          isInvoice={isBilling}
          onConfirm={onConfirmIsInvoiceModal}
          onCancel={changeIsInvoiceModalVisible}
        />
        <ModalComputeTax
          visible={computeTaxModalVisible}
          computeTax={taxWay}
          onConfirm={onConfirmComputeTaxModal}
          onCancel={changeComputeTaxModalVisible}
        />
      </View>
    );
  }
  render() {
    const { keyboardHeight } = this.props;
    return (
      <ScrollView
        style={{ flex: 1 }}
        ref={(el) => (this.refScrollView = el)}
        onScroll={(event) => (this.refScrollLayout = event.nativeEvent)}
        scrollEventThrottle={200}
        onLayout={(el) => (this.scrollViewHeight = el.nativeEvent.layout.height)}
      >
        <View style={styles.inner}>{this.renderContent()}</View>
        <Whitespace vertical={keyboardHeight + 200} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
  },

  listWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: autoFix(8),
    paddingHorizontal: autoFix(28),
  },
  stock: {
    backgroundColor: '#FFFFFF',
    borderRadius: autoFix(8),
  },
  inner: {
    flex: 1,
    paddingBottom: autoFix(20),
    paddingTop: autoFix(20),
    paddingHorizontal: autoFix(20),
  },

  inputStyle: {
    paddingLeft: 0,
    flex: 1,
  },
  styleItem: {
    paddingRight: 0,
  },
  inputLable: {
    width: autoFix(212),
  },

  itemUnit: {
    marginLeft: autoFix(12),
    color: '#666',
  },

  extraNode: {
    flexDirection: 'row',
    justifyContent: 'center',
  },

  imgStyle: {
    width: autoFix(36),
    height: autoFix(36),
    marginLeft: autoFix(16),
  },
});
