import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Modal, MBText, Splitline, Whitespace, Button } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import { xyzMath } from '~/utils/xyzMath';

const ModalFeeCompute = (props: any) => {
  const { visible, feeComputeData, contactList, cargoList, costMileage, onApply, onCancel, priceType } = props;
  const {chargeData} = feeComputeData;
  const type = chargeData?.type || {}
  const name = chargeData?.name || {}

  const priceMergeRulesHitInfo = feeComputeData?.priceMergeRulesHitInfo || {}
  let actualData = [
    {
      name: '出发区域',
      value: contactList[0].address,
    },
    {
      name: '到达区域',
      value: contactList[1].address,
    },
  ];

  const computeTota = (type: string) => {
    return cargoList.reduce((total: any, item: any) => {
      return xyzMath.add(total, item[type]);
    }, 0);
  };

  // 吨公里
  if (type === 'weightMileage') {
    const value = computeTota('weight');
    actualData.push(
      {
        name: '重量',
        value: `${value}吨`,
      },
      {
        name: '里程',
        value: `${costMileage}公里`,
      }
    );
  }

  // 里程
  if (type === 'mileage') {
    actualData.push({
      name,
      value: `${costMileage}公里`,
    });
  }

  // 重量/体积/件数
  if (type === 'weight' || type === 'volume' || type === 'quantity') {
    let handleType = type;
    if (type === 'quantity') {
      handleType = 'packageQuantity';
    }
    const value = computeTota(handleType);
    const unit = type === 'weight' ? '吨' : type === 'volume' ? '方' : '件';
    actualData.push({
      name,
      value: `${value}${unit}`,
    });
  }

  // 一口价
  if (type === 'fixedPrice') {
    actualData.push({
      name,
      value: `${feeComputeData?.computeResult}元`,
    });
  }

  // 重量体积最大值
  if (type === 'weightVolume') {
    let value = computeTota('weight');
    let unit = '吨';
    // 后端反馈重量体积最大值字段特殊，故以汉字作比较
    if (name === '体积') {
      value = computeTota('volume');
      unit = '方';
    }

    actualData.push({
      name,
      value: `${value}${unit}`,
    });
  }

  const onClose = () => {
    onCancel && onCancel();
  };
  /** 合并计费 */
  const combinedBillingElement: React.ReactNode = () => {
    // 分摊策略，1：按重量，2：按体积，3：按件数，4：按结算重量，5：按单数，6：按里程
    const allocationStrategyMap = {
      1: '按重量',
      2: '按体积',
      3: '按件数',
      4: '按结算重量',
      5: '按单数',
      6: '按里程',
    }
    // 1:重量（吨），2：体积（方），3：件，4：结算重量（吨），5：里程(千米)
    const attributeValuesMap = {
      1: '合并重量',
      2: '合并体积',
      3: '合并件数',
      4: '合并结算重量',
      5: '合并计费里程',
    }
    const valuesUnit = {
      1: '吨',
      2: '方',
      3: '件',
      4: '吨',
      5: '公里',
    }
    const combinedBillingData = [
      { name: '合并规则', value: priceMergeRulesHitInfo?.mergeRuleName || null },
      { name: '分摊策略', value: priceMergeRulesHitInfo?.allocationStrategy ? allocationStrategyMap[priceMergeRulesHitInfo?.allocationStrategy] : null },
      { name: 'attributeValues', value: priceMergeRulesHitInfo?.attributeValues || null },
      { name: '合并计费总金额', value: priceMergeRulesHitInfo?.totalMergeFee ? priceMergeRulesHitInfo?.totalMergeFee + '元' : null },
      { name: '合并单号', value: priceMergeRulesHitInfo?.mergeOrderConunt || null },
      { name: '合并运单数', value: priceMergeRulesHitInfo?.mergeOrderCount || null },
    ];
    
    return (
      <>
        <MBText style={styles.feeLable}>合并计费：</MBText>
        {combinedBillingData.map((item: any, index: number) => {
          if(item.name == 'attributeValues'){
            const list = item.value?.filter((data: any)=> {
              return data.attributeValue && data.type && data.type != 4
            }) || [];
            return list.length ? (
              <View key={index} style={styles.feeValueWrapper}>
                <MBText style={styles.feeName}>{attributeValuesMap[list[0]?.type]}：</MBText>
                <MBText style={styles.feeValue}>
                  {list.map((row: any, index: number)=>{
                    return index ? row.attributeValue ? `${attributeValuesMap[row?.type]}：${row.attributeValue} ${valuesUnit[row?.type]}；` : null : `${row.attributeValue} ${valuesUnit[row?.type]}；`;
                  })}
                </MBText>
              </View>
            ) : null;
          } else {
            return item.value ? (
              <View key={index} style={styles.feeValueWrapper}>
                <MBText style={styles.feeName}>{item.name}：</MBText>
                <MBText style={styles.feeValue}>{item.value}</MBText>
              </View>
            ) : null;
          }
        })}
      </>
    );
  };
  return (
    <Modal
      title="运费计算"
      position="bottom"
      visible={visible}
      autoAdjustPosition={true}
      contentStyle={styles.contentStyle}
      headerLine={false}
      closable={true}
      onMaskClose={onClose}
      onRequestClose={onClose}
      onClose={onClose}
    >
      <ScrollView
        style={styles.infoBox}
        keyboardShouldPersistTaps="never"
        showsVerticalScrollIndicator={false}
        alwaysBounceVertical={false}
        nestedScrollEnabled={true}
      >
        <MBText style={[styles.feeLable, styles.feeLableClearTop]}>价格名称：</MBText>
        <MBText style={styles.feeValueWrapper}>{feeComputeData.priceName}</MBText>

        <MBText style={styles.feeLable}>价格规则：</MBText>
        {feeComputeData?.priceRules?.map((item: any, index: number) => {
          return item.name || item.value ? (
            <View key={index} style={styles.feeValueWrapper}>
              {item.name && <MBText style={styles.feeName}>{item.name}：</MBText>}
              {item.value && <MBText style={styles.feeValue}>{item.value}</MBText>}
            </View>
          ) : null;
        }) || null}

        <MBText style={styles.feeLable}>实际数据：</MBText>
        {actualData.map((item: any, index: number) => {
          return (
            <View key={index} style={styles.feeValueWrapper}>
              <MBText style={styles.feeName}>{item.name}：</MBText>
              <MBText style={styles.feeValue}>{item.value}</MBText>
            </View>
          );
        })}
        {priceType == 2 && combinedBillingElement()}
      </ScrollView>
      <View style={[styles.flexRow, { width: '100%' }]}>
        <MBText style={styles.feeLable}>计算结果：</MBText>
        <MBText style={[styles.feeLable, styles.feeComputeResult]}>{feeComputeData.computeResult}元</MBText>
      </View>
      <Whitespace vertical={10} />
      <Splitline />
      <View style={styles.footer}>
        <Button
          type="primary"
          size="sm"
          radius
          style={styles.itemBtn}
          onPress={() => {
            onApply && onApply(feeComputeData.computeResult);
          }}
        >
          <MBText color="#fff">应用</MBText>
        </Button>
      </View>
      <Whitespace vertical={20} />
    </Modal>
  );
};

const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  contentStyle: {
    paddingHorizontal: autoFix(36),
    alignItems: 'flex-start',
  },
  infoBox: {
    width: '100%',
    maxHeight: autoFix(920),
  },
  feeLable: {
    fontWeight: 'bold',
    fontSize: autoFix(30),
    marginTop: autoFix(28),
  },

  feeLableClearTop: {
    marginTop: autoFix(12),
  },

  feeValueWrapper: {
    flexDirection: 'row',
    marginTop: autoFix(12),
  },

  feeName: {
    fontWeight: 'bold',
    color: '#666',
  },

  feeValue: {
    flex: 1,
    color: '#666',
  },

  feeComputeResult: {
    color: '#F54242',
    fontWeight: 'bold',
  },

  footer: {
    height: 60,
    paddingVertical: 10,
    flexDirection: 'row',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },

  itemBtn: {
    flex: 1,
  },
});

export default ModalFeeCompute;
