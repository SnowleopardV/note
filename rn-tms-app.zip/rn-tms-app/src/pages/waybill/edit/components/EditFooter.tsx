import React from 'react';
import { StyleSheet, View } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import TouchableThrottle from '~/components/TouchableThrottle';

const EditFooter = (props: any) => (
  <View style={styles.footer}>
    <TouchableThrottle
      onPress={() => {
        props.onSubmit(4);
      }}
    >
      <View style={styles.editText}>
        <MBText style={styles.btnText} color="#fff">
          确定修改
        </MBText>
      </View>
    </TouchableThrottle>
  </View>
);

const styles = StyleSheet.create<any>({
  footer: {
    paddingVertical: autoFix(20),
    paddingHorizontal: autoFix(28),
  },

  btnText: {
    fontSize: autoFix(32),
  },

  editText: {
    height: autoFix(80),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4885FF',
    borderRadius: 40,
  },
});

export default EditFooter;
