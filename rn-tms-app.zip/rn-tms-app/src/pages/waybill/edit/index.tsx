import React from 'react';
import { SafeAreaView, View, StyleSheet, ImageBackground, BackHandler, Platform, KeyboardAvoidingView } from 'react-native';
import { inject, observer } from 'mobx-react';
import Images from '../../../../public/static/images';
import NavBar from '~/components/common/NavBar';
import CreateContent from '~/pages/waybill/create/components/CreateContent';
import EditFooter from './components/EditFooter';
import TotalFreightReceive from '~/pages/waybill/create/components/TotalFreightReceive';
import WaybillCreateStore from '~/pages/waybill/create/store';
import DeliveryAddressStore from '~/pages/waybill/delivery-address/store';
import { MBBridge, MBAutoPVComponent } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export interface CreateIndexProps {
  screenProps: any;
  waybillCreateStore: WaybillCreateStore;
  deliveryAddressStore: DeliveryAddressStore;
  navigation: any;
}

class EditIndex extends MBAutoPVComponent<CreateIndexProps, any> {
  state = {
    showFooterBtn: true,
    pageTitle: '修改运单',
  };
  timerBtn: any = null;
  constructor(props: CreateIndexProps) {
    super(props);
  }

  async UNSAFE_componentWillMount() {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }

  async componentDidMount() {
    super.componentDidMount();
    const {
      waybillCreateStore: {
        getEditWaybillDetail,
        trackPageView,
        getFeeReceiveList,
        getEditOrganize,
        getSystemInit,
        getUserCreateOrderConfigs,
      },
      screenProps: { id },
    } = this.props;
    // 获取所有费用
    await getFeeReceiveList();
    // 获取组织
    getEditOrganize(id);
    // 系统配置接口（包含查询敏感词数据）
    getSystemInit();
    // 获取运单详情
    await getEditWaybillDetail(id);

    const {
      deliveryAddressStore: { getCustomerHistoryInfo },
    } = this.props;

    getCustomerHistoryInfo();

    // 用户地址、增加按钮等配置
    getUserCreateOrderConfigs();

    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', this.backAction);
    }
  }

  componentWillUnmount() {
    super.componentWillUnmount();
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener('hardwareBackPress', this.backAction);
    }
  }
  backAction = () => {
    MBBridge.app.ui.closeWindow({});
    return true;
  };

  // 失焦底部按钮显示，聚焦底部按钮隐藏
  onCommonBlurFocus = (val: boolean) => {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ showFooterBtn: val });
    }, 10);
  };

  getPageName() {
    return 'waybill_supply_edit';
  }

  render() {
    const {
      navigation,
      waybillCreateStore: {
        getTotalFeeInfo: { totalFee, detailFeeList },
        onSubmit,
        isLoading,
        editNotReceivable,
        isFromTms,
      },
    } = this.props;

    const { showFooterBtn, pageTitle } = this.state;

    return (
      <KeyboardAvoidingView behavior="padding" style={styles.container} enabled={Platform.OS == 'ios' && isFromTms}>
        <NavBar title={pageTitle} />
        {!isLoading ? (
          <ImageBackground source={{ uri: Images.icon_bg_map }} style={styles.imageBackground}>
            <View style={styles.flexStyle}>
              <CreateContent
                navigation={navigation}
                isEdit={true}
                onCommonFocus={() => this.onCommonBlurFocus(false)}
                onCommonBlur={() => this.onCommonBlurFocus(true)}
              />
              {showFooterBtn ? (
                <View style={styles.shadowStyle}>
                  {detailFeeList && detailFeeList.length ? (
                    <TotalFreightReceive detailFeeList={detailFeeList} totalFee={totalFee} editNotReceivable={editNotReceivable} />
                  ) : null}
                  <EditFooter onSubmit={(type: number) => onSubmit(type)} />
                </View>
              ) : null}
            </View>
          </ImageBackground>
        ) : null}
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create<any>({
  shadowStyle: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },

  container: {
    flex: 1,
  },

  imageBackground: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },

  supplyQuestionWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },

  supplyQuestionText: {
    marginLeft: autoFix(2),
  },

  iconQuestion: {
    width: autoFix(30),
    height: autoFix(30),
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default inject('waybillCreateStore', 'deliveryAddressStore')(observer(EditIndex));
