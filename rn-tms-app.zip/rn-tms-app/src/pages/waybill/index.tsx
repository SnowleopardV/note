import React from 'react';
import CreateIndex from '../waybill/create';

class WaybillCreate extends React.Component {
  constructor(props: any) {
    super(props);
  }

  render() {
    return <CreateIndex pageStore={this.props.screenProps} navigation={this.props.navigation} />;
  }
}

export default WaybillCreate;
