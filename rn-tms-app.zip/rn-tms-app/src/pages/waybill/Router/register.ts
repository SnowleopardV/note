import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import WaybillCreatePage from '../index';
import GoodsInfoPage from '../goods-info';
import MoreInfoPage from '../more-info';
import WaybillEditPage from '../edit';
import FeeReceivePage from '../fee-receive';
import GoodsMore from '../goods-more/GoodsMore';
import OneMoreOrderPage from '../OneMoreOrder/OneMoreOrderPage'; // 再来一单页面
/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 创建运单
   */
  WaybillCreate = 'WaybillCreate',
  /**
   * 货物信息
   */
  GoodsInfo = 'GoodsInfo',
  /**
   * 更多信息
   */
  MoreInfo = 'MoreInfo',
  /**
   * 修改运单
   */
  WaybillEdit = 'WaybillEdit',
  /**
   * 应收费用
   */
  FeeReceive = 'FeeReceive',

  /**
   * 货物更多信息
   */
  GoodsMore = 'GoodsMore',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        WaybillCreate: {
          screen: WaybillCreatePage,
          navigationOptions: () => ({
            header: null,
          }),
        },

        GoodsInfo: {
          screen: GoodsInfoPage,
          navigationOptions: () => ({
            header: null,
          }),
        },

        MoreInfo: {
          screen: MoreInfoPage,
          navigationOptions: () => ({
            header: null,
          }),
        },

        WaybillEdit: {
          screen: WaybillEditPage,
          navigationOptions: () => ({
            header: null,
          }),
        },

        FeeReceive: {
          screen: FeeReceivePage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        GoodsMore: {
          screen: GoodsMore,
          navigationOptions: () => ({
            header: null,
          }),
        },
        OneMoreOrderPage: {
          screen: OneMoreOrderPage,
          navigationOptions: () => ({ header: null }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
