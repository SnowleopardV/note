import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { LayProvider } from '@ymm/rn-elements';
import { Provider } from 'mobx-react';
import PageStore from '../store/index';
const RootStack = new RouterMap().getRouterMap(RouterPageName.WaybillEdit);

const WaybillEdit: React.FunctionComponent<any> = (props) => {
  const pageStore = new PageStore();

  return (
    <Provider {...pageStore.stores}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={{ ...props, pageStore }} />
      </LayProvider>
    </Provider>
  );
};

export default WaybillEdit;
