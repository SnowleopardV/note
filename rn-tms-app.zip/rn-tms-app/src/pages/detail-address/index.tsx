import * as React from 'react';
import {
  SafeAreaView,
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Platform,
  BackHandler,
  NativeEventSubscription,
  Keyboard,
} from 'react-native';
import { MBBridge, MBLog, App } from '@ymm/rn-lib';
import { Flex, Button, MBText, Whitespace, Input, RNElementsUtil, CellGroup, LayProvider } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import { getCountyRegion } from '~/extends/MapBridge/index';
import AddressList from './AddressList';
import Api from './api';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
export interface DetailAddressProps {
  value: string;
}

export interface StateAddressModel {
  cityName: string;
  detailAddress: string;
  latitude: string;
  longitude: string;
  areaName: string;
  poiName: string;
  provinceName: string;
  districtCode: number;
  cityCode: number;
  provinceCode: number;
}
export interface DetailAddressState {
  address: string;
  addressList: StateAddressModel[];
  focusIndex: number;
  value: AddressType;
  onlyAddress: boolean;
}
export default class DetailAddressComponent extends React.Component<DetailAddressProps, DetailAddressState> {
  timer?: any;
  backHandleListener?: NativeEventSubscription;
  municipality = new Set<number>([110100, 120100, 310100, 500100]);
  constructor(props: DetailAddressProps) {
    super(props);
    const value = JSON.parse(Platform.OS == 'ios' ? decodeURI((props.value || '') + '') : (props.value || '') + '');
    const { onlyAddress, ...otherValue } = value;
    this.state = {
      value: otherValue,
      addressList: [],
      address: value.address,
      focusIndex: 0,
      onlyAddress: onlyAddress || false, // 是否是手写地址，不用在列表中选择
    };
  }
  UNSAFE_componentWillMount = (): void => {
    if (Platform.OS === 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        //返回
        this.goBack({
          back: true,
        });
        // 阻止返回
        return true;
      });
    }
  };
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  /**
   * 输入关键字
   * @param value
   */
  changeDetailAddress = (value: string): void => {
    value = value.replace(/\n/gm, ''); // 禁止换行
    this.setState({ address: value });
    if (!this.state.onlyAddress) {
      this.prepareSearchAddress(value);
    }
  };

  prepareSearchAddress = (address: string) => {
    const _this = this;
    const { value } = this.state;
    const startInput = address;
    value.address = '';
    value.latitude = '0';
    value.longitude = '0';
    value.poiName = '';
    // 清空历史记录
    this.setState(
      {
        addressList: [],
        value,
      },
      () => {
        if (_this.timer) {
          clearTimeout(_this.timer);
          _this.timer = null;
        }
        const endInput = _this.state.address;
        if (startInput == endInput) {
          _this.timer = setTimeout(() => {
            _this.fetchAddressAssociate(address);
            // this.setState({
            //   addressList: [],
            // });
          }, 200);
        }
      }
    );
  };
  /**
   * 调用接口
   * @param address
   * @returns
   */
  fetchAddressAssociate = (address: string) => {
    if (!address) {
      return;
    }
    const { value } = this.state;
    const areaCode = this.getAreaCode();
    const params: any = {
      keyWord: address,
      districtCode: void 0,
      cityCode: void 0,
      provinceCode: void 0,
    };

    if (areaCode) {
      params.districtCode = areaCode;
    }
    if (value?.city) {
      params.cityCode = value.city;
    }
    if (value?.province) {
      params.provinceCode = value.province;
    }
    Api.fetchAddressAssociate(params)
      .then((resp: any) => {
        if (!resp || !resp.data) {
          return;
        }
        this.setState({
          addressList: resp.data.map((item: any) => {
            return {
              ...item,
              areaName: item.districtName,
              longitude: item.coordinate.longitude,
              latitude: item.coordinate.latitude,
            };
          }),
        });
        return true;
      })
      .catch((er) => {
        MBLog.log('搜索关联地址错误：', er);
      });
  };
  /**
   * 获取当前区域code
   */
  getAreaCode = () => {
    const { value } = this.state;
    if (!value) {
      return 0;
    }
    if (value?.area) {
      return +value?.area;
    }
    // if (this.municipality.has(+value?.area)) {
    //   return +value?.province;
    // }

    return 0;
  };
  /**
   * 返回
   * 如果字段里包含back：点击左上角返回
   * @param data
   */
  goBack = (data: any) => {
    MBBridge.rnruntime.handlebackResult({ data: data ? JSON.stringify(data) : '' });
    // App.sendEvent('detail-address', { data: data ? JSON.stringify(data) : '' }, { containerType: 'rn' });
    if (Platform.OS == 'ios') {
      setTimeout(() => {
        MBBridge.app.ui.closeWindow({});
      }, 300);
    }
  };
  /**
   * 选中某一条搜索结果，直接返回并返回选中的数据
   * @param data
   */
  onSelect = (addressData: StateAddressModel) => {
    const { value } = this.state;
    const data: AddressType = {
      provinceName: addressData.provinceName,
      cityName: addressData.cityName,
      province: addressData.provinceCode || value.province,
      city: addressData.cityCode || value.city,
      area: addressData.districtCode || value.area,
      areaName: addressData.areaName,
      address: addressData.detailAddress,
      poiName: addressData.poiName,
      longitude: addressData.longitude,
      latitude: addressData.latitude,
    };
    this.goBack(data);
  };
  submit() {
    this.goBack({ onlyAddress: { address: this.state.address } });
  }

  public render() {
    const { address, onlyAddress, addressList } = this.state;
    return (
      <LayProvider theme="skyblue">
        <View style={styles.container}>
          <NavBar title="输入详细地址" leftClick={() => this.goBack({ back: true })} />
          <SafeAreaView style={styles.flexStyle}>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine={false}>
              <Flex
                direction="row"
                style={{ paddingVertical: RNElementsUtil.autoFix(32), alignItems: 'flex-start', paddingHorizontal: 16 }}
              >
                <View style={{ width: RNElementsUtil.autoFix(120) }}>
                  <MBText>详细地址</MBText>
                </View>
                <Flex.Item style={{ marginLeft: 15 }}>
                  <Input
                    placeholder={'请输入详细地址'}
                    style={{
                      height: RNElementsUtil.autoFix(210),
                      paddingTop: RNElementsUtil.autoFix(2),
                      textAlignVertical: 'top',
                    }}
                    placeholderTextColor={'#999'}
                    value={address}
                    maxLength={100}
                    onChangeText={this.changeDetailAddress}
                    multiline
                    underlineColorAndroid="transparent"
                    returnKeyType="done"
                    onSubmitEditing={Keyboard.dismiss}
                    onFocus={() => {
                      this.setState({
                        focusIndex: 1,
                      });
                    }}
                    onBlur={() => {
                      this.setState({
                        focusIndex: 0,
                      });
                    }}
                  />
                </Flex.Item>
                {!onlyAddress ? (
                  <View
                    style={{ width: autoFix(100), flexDirection: 'row', position: 'absolute', right: autoFix(20), bottom: autoFix(20) }}
                  >
                    {!!address && (
                      <Button
                        style={styles.btn}
                        radius
                        interval={500}
                        onPress={() => this.changeDetailAddress('')}
                        size="xs"
                        type="bordered"
                      >
                        清空
                      </Button>
                    )}
                    {!address && (
                      <Button style={styles.btn} radius interval={500} onPress={() => this.submit()} size="xs" type="primary">
                        确定
                      </Button>
                    )}
                  </View>
                ) : (
                  <View
                    style={{
                      width: autoFix(100),
                      flexDirection: 'row',
                      position: 'absolute',
                      right: !!address ? autoFix(140) : autoFix(40),
                      bottom: autoFix(20),
                    }}
                  >
                    {!!address && (
                      <Button
                        style={styles.btn}
                        radius
                        interval={500}
                        onPress={() => this.changeDetailAddress('')}
                        size="xs"
                        type="bordered"
                      >
                        清空
                      </Button>
                    )}
                    <Whitespace horizontal={10} />
                    <Button style={styles.btn} radius interval={500} onPress={() => this.submit()} size="xs" type="primary">
                      确定
                    </Button>
                  </View>
                )}
              </Flex>
            </CellGroup>
            <Whitespace vertical={10} />
            {!!onlyAddress && (
              <ScrollView keyboardShouldPersistTaps={'handled'} keyboardDismissMode={'on-drag'} showsVerticalScrollIndicator={false}>
                <AddressList
                  inputText={address}
                  addressList={addressList}
                  // onChangeText={(text: string) => this.handleChangeText(text)}
                  onSelect={this.onSelect}
                />
              </ScrollView>
            )}
          </SafeAreaView>
        </View>
      </LayProvider>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },
  btn: {
    width: autoFix(100),
  },
});
