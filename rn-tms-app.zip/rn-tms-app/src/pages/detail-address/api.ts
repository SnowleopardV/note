import server from '~/server';
interface AssociateRequestParams {
  keyWord: string;
  areaCode?: number;
  cityCode?: number;
}
interface AssociateResponseParams {
  cityName: string;
  coordinate: {
    latitude: string;
    longitude: string;
  };
  detailAddress: string;
  districtName: string;
  poiName: string;
  provinceName: string;
  regionAddress: string;
  streetAddress: string;
  regionAddressWithSpace: string;
}
const Api = {
  fetchAddressAssociate(params: AssociateRequestParams): Promise<ResponseData<AssociateResponseParams[]>> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/address/associate',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
};

export default Api;
