export const getLabelList = (PayType: number | undefined) => {
  const list = {
    1: [{ label: '支付备注', key: 'payRemark' }],
    2: [
      { label: '开户名称', key: 'accountName' },
      { label: '开户银行', key: 'bankName' },
      { label: '银行账号', key: 'accountNumber' },
    ],
    3: [
      { label: '账号', key: 'weChatNumber' },
      { label: '支付备注', key: 'payRemark' },
    ],
    4: [
      { label: '账号', key: 'alipayNumber' },
      { label: '支付备注', key: 'payRemark' },
    ],
    6: [{ label: '支付备注', key: 'payRemark' }],
  };
  return list[PayType ?? -1] ?? [{ label: '支付备注', key: 'payRemark' }];
};
