import server from '~/server';
export interface applyDetailRequsetParams {
  applyNo: string;
}
export interface applyDetailResponseParams {
  applyNo?: string; // 单号
  orgName?: string; // 组织名称
  startPoints?: string[]; //出发地
  endPoints?: string[]; //目的地
  cargoInfos?: string[]; //货物信息
  driverInfos?: string[]; //司机信息
  applyVerifyAmount?: string; // 应付金额
  payWays?: string[]; //结算方式
  paySubjectType?: string; //收款类型
  paySubjectName?: string; // 收款方
  imageUrls?: string[] | null; // 附件
  payeeInfo?: {
    accountName: string; //开户名称
    payType?: number; //支付方式
    bankName?: string; //银行名称
    bankNumber?: string; // 银行账号
    weChatNumber?: string; //微信号
    alipayNumber?: string; //支付宝号
    accountNumber?: string; //账号
  };
  taskInfos?: any[];
  orderInfos?: any[];
}
export interface buttonSingleRequsetParams {
  businessId: string;
  businessNo: string;
}
export interface buttonSingleResponseParams {
  buttonDTO: Array<{
    code: string;
    name: string;
    enable: boolean;
  }>;
}
export interface processCompleteRequsetParams extends buttonSingleRequsetParams {
  isPass: boolean;
  remark: string;
}
export interface revokeRequsetParams extends buttonSingleRequsetParams {
  revokeComment: string;
}

export interface applyRevokeParams {
  applyId: string;
  applyNo: string;
}

const Api = {
  // 审批跟踪接口
  applyDetail(params: applyDetailRequsetParams): Promise<ResponseData<applyDetailResponseParams>> {
    return server({
      // url: '/saas-financial-app/yzgApp/payment/apply/detail',
      url: '/saas-financial-app/yzgApp/apply/detail',
      data: { ...params },
    });
  },
  //获取按钮列表
  buttonSingle(params: buttonSingleRequsetParams): Promise<ResponseData<buttonSingleResponseParams>> {
    return server({
      url: '/saas-tms-process-engine/yzgApp/process/component/button/single',
      data: { ...params },
    });
  },
  //审批
  processComplete(
    params: processCompleteRequsetParams
  ): Promise<ResponseData<{ businessCurrentStatus: string; businessCurrentProcessor: string; businessCurrentProcessorName: string }>> {
    return server({
      url: '/saas-tms-process-engine/yzgApp/process/complete',
      data: { ...params },
    });
  },
  //撤销
  instanceRevoke(params: revokeRequsetParams) {
    return server({
      url: '/saas-tms-process-engine/yzgApp/process/runtime/instance/revoke',
      data: { ...params },
    });
  },
  //撤销
  applyRevoke(params: applyRevokeParams) {
    return server({
      url: '/saas-financial-app/yzgApp/apply/revoke',
      data: { ...params },
    });
  },

  // 用户信息
  getUserInfo() {
    return server(
      {
        url: '/saas-permission-app/yzgApp/user/queryUserInfo',
        data: {},
      },
      { showLoading: false, toastError: false }
    );
  },

  // 获取任务详情
  getTaskDetail(params: any) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/detail',
        data: { ...params },
      },
      { toastError: false }
    );
  },

  // 获取运单详情
  getWaybillDetail(params: any) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/dispatch/dispatchDetail',
        data: { ...params },
      },
      { toastError: false }
    );
  },
};

export default Api;
