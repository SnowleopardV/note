import { StyleSheet, Dimensions } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';
const { autoFix } = RNElementsUtil;
const Width = Dimensions.get('window').width;
export default StyleSheet.create({
  title: {
    fontSize: autoFix(30),
    color: '#333333',
    marginTop: autoFix(36),
    marginBottom: autoFix(20),
    marginLeft: autoFix(28),
    
  },
  content: {
    backgroundColor: '#fff',
    paddingLeft: autoFix(28),
  },
  contentItem: {
    paddingVertical: autoFix(29),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#E8E8E8',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingRight: autoFix(28),
    alignItems: 'center',
  },
  alertOtherConentItem: {
    paddingVertical: autoFix(29),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#E8E8E8',
    textAlign: 'center',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'row',
    paddingHorizontal: autoFix(30),
  },
  ph30: {
    paddingHorizontal: autoFix(30),
  },
  ph20: {
    paddingHorizontal: autoFix(20),
  },
  labelLeft: {
    color: '#333333',
    fontSize: autoFix(30),
  },
  labelRight: {
    color: '#666666',
    fontSize: autoFix(30),
    marginLeft: autoFix(60),
    flex: 1,
    textAlign: 'right',
  },
  ml0: {
    marginLeft: 0,
  },
  sortArrow: {
    width: autoFix(13),
    height: autoFix(26),
    marginLeft: autoFix(20),
  },
  longArrow: {
    width: autoFix(36),
    height: autoFix(26),
    marginHorizontal: autoFix(19),
    marginTop: autoFix(10),
  },
  address: {
    width: '100%',
    marginTop: autoFix(20),
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },
  alertConent: {
    paddingBottom: autoFix(30),
    width: Width,
    maxHeight: autoFix(600),
  },
  itemText: {
    fontSize: autoFix(30),
  },
  applyVerifyAmount: {
    color: '#F54242',
  },
  accessory: {
    marginBottom: autoFix(36),
  },
  imageContent: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingTop: autoFix(15),
    borderRadius: 5,
  },
  smallImage: {
    width: autoFix(100),
    height: autoFix(100),
    marginBottom: autoFix(20),
    marginRight: autoFix(30),
  },
  noFile: {
    fontSize: autoFix(30),
    paddingBottom: autoFix(20),
  },
  buttonGroup: {
    backgroundColor: '#fff',
    paddingHorizontal: autoFix(30),
    height: autoFix(120),
    paddingVertical: autoFix(20),
    display: 'flex',
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  tailAfter: {
    flex: 1,
    borderWidth: autoFix(1),
    borderColor: '#4885FF',
    borderRadius: autoFix(40),
    height: '100%',
    marginRight: autoFix(20),
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tailAfterText: {
    color: '#4885FF',
    fontSize: autoFix(32),
  },
  appovalsBtton: {
    flex: 1,
    borderWidth: autoFix(1),
    backgroundColor: '#4885FF',
    borderColor: '#4885FF',
    borderRadius: autoFix(40),
    height: '100%',
    marginRight: autoFix(20),
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  appovalsText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: autoFix(32),
  },
  appovalsIcon: {
    width: autoFix(80),
    height: autoFix(80),
    borderWidth: autoFix(4),
    borderRadius: autoFix(40),
    borderColor: '#4885FF',
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    paddingHorizontal: autoFix(20),
  },
  dot: {
    width: autoFix(6),
    height: autoFix(6),
    backgroundColor: '#4885FF',
    borderRadius: autoFix(3),
  },
  splitLine: {
    height: autoFix(20),
    width: '100%',
    backgroundColor: '#F7F7F7',
  },
  buttonParent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: autoFix(24),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: '#E8E8E8',
  },
  h60: {
    height: autoFix(90),
  },
  modalButton: {
    height: autoFix(70),
    borderRadius: autoFix(30),
    marginTop: autoFix(10),
    textAlign: 'center',

    lineHeight: autoFix(70),
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalButtonText: {
    fontSize: autoFix(28),
  },
  checkStatus: {
    borderColor: '#4885FF',
    borderWidth: autoFix(1),
    //color: '#4885FF',
    backgroundColor: 'rgba(72, 133, 255, 0.2)',
  },
  noCheckStatus: {
    backgroundColor: '#F0F0F0',
    //color: '#999999',
  },
  mr26: {
    marginRight: autoFix(26),
  },
  modalTitle: {
    flexDirection: 'row',
    paddingVertical: autoFix(24),
    width: '100%',
  },
  TitleText: {
    fontSize: autoFix(32),
    color: '#333333',
    textAlign: 'left',
  },
  modalStyle: {
    width: '100%',
    height: autoFix(510),
  },
  star: {
    color: '#FF4040',
  },
  inputItem: {
    width: '100%',
    height: autoFix(170),
    marginBottom: autoFix(50),
    position: 'relative',
  },
  h260: {
    height: autoFix(260),
  },
  inputStyle: {
    //height: '100%',
    marginLeft: 0,
    width: '100%',
    fontSize: autoFix(32),
  },
  remarkLength: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    position: 'absolute',
    right: 0,
    bottom: 0,
  },
  scrollView: {
    maxHeight: autoFix(500),
    height: 'auto',
    
  },
});
