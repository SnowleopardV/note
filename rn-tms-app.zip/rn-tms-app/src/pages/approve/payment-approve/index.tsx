import React from 'react';
import { View, Image, ScrollView, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { MBText, Modal, Splitline, Whitespace } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import Accessory from './components/accessory';
import Api from './api';
import ButtonGroup from './components/buttonGroup';
import { MBBridge, MBJournal, MBAutoPVComponent } from '@ymm/rn-lib';
import { RNElementsUtil } from '@ymm/rn-elements';
import images from '~public/static/images';
import EmptyPage from '~/components/common/EmptyPage';
import { getLabelList } from './enum';
const { autoFix } = RNElementsUtil;
import NativeBridge from '~/extends/NativeBridge';

interface Props {
  navigation?: any;
}
/** 付款申请单 */
export default class paymentApprove extends MBAutoPVComponent<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      loading: true,
      detailData: {
        taskInfos: [],
        orderInfos: [],
        payeeInfo: [], // 收支付方式信息
        applyVerifyAmount: null, // 申请金额（元）
        paySubjectType: null, //
        paySubjectName: null, //
      },
      payeeInfoList: [{ label: '收款方式', key: 'payTypeName', value: '-' }],
      paymentApplication: 0, //是否调用页面最下面的list按钮接口
      userName: undefined,
      tenant: undefined,
      tmsRole: undefined,
    };
  }
  componentWillMount() {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  }
  componentDidMount() {
    super.componentDidMount();
    Api.getUserInfo().then((res) => {
      if (res?.success) {
        const { name, companyName, roleName } = res.data;
        this.__set_AutoPV_PageInfo('payment_application_detail', { userName: name, tenant: companyName, tmsRole: roleName });
        this.setState({ userName: name, tenant: companyName, tmsRole: roleName });
      }
    });
    const { businessNo } = this.props.navigation.state.params;
    Api.applyDetail({ applyNo: businessNo ?? '' })
      .then(({ data }) => {
        if (data) {
          data.taskInfos = data.taskInfos?.map((item: any) => {
            return { ...item, selected: false };
          });
          data.orderInfos = data.orderInfos?.map((item: any) => {
            return { ...item, selected: false };
          });
          this.setState({ detailData: data });
        }
      })
      .catch((err: any) => {
        console.log('applyDetail错误', err);
      })
      .finally(() => {
        this.setState({ loading: false });
      });
  }
  componentWillUnmount() {
    super.componentWillUnmount();
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }

  gotoDetail = (item: any, type: string) => {
    const { id, taskNo } = item;
    if (type === 'task') {
      if (taskNo) {
        // 查任务详情接口，判断是否能获取详情
        Api.getTaskDetail({ id })
          .then((res) => {
            if (res.success && res.data) {
              // 跳转任务详情
              const schemeUrl = `ymm://rn.tms/taskdetail?id=${id}`;
              NativeBridge.setOpenUrl({
                url: schemeUrl,
              });
            } else {
              this.showToastErr();
            }
          })
          .catch((err: any) => {
            this.showToastErr();
          });
      } else {
        this.showToastErr();
      }
    }

    if (type === 'order') {
      // 查任运单详情接口，判断是否能获取详情
      Api.getWaybillDetail({ id })
        .then((res) => {
          if (res.success && res.data) {
            // 跳转运单详情
            const schemeUrl = `ymm://rn.tms/waybilldetail?id=${id}`;
            NativeBridge.setOpenUrl({
              url: schemeUrl,
            });
          } else {
            this.showToastErr();
          }
        })
        .catch((err: any) => {
          this.showToastErr();
        });
    }
  };

  showToastErr = () => {
    NativeBridge.toast('暂不支持查看');
  };

  changItem(index: number, type: string) {
    const { detailData } = this.state;
    const { taskInfos, orderInfos } = detailData;
    const TypeMap = {
      task: taskInfos,
      order: orderInfos,
    };
    TypeMap[type][index].selected = !TypeMap[type][index].selected;
    this.setState({ detailData: detailData });
  }
  // 运输明细
  OrderTaskNoElement = (item: any, index: number, type: string) => {
    const titleText = {
      task: () => <MBText>{item?.taskNo ? '任务号：' : '业务单号：'}</MBText>,
      order: () => <MBText>运单号：</MBText>,
    };

    const numberText = {
      task: () => <MBText color="#4885FF">{item?.taskNo || item?.mybOrderId || ''}</MBText>,
      order: () => <MBText color="#4885FF">{item?.transOrderNo || ''}</MBText>,
    };

    const detailList = { task: item.taskNoDetailList, order: item.orderDetailList };
    return (
      <View style={{ marginBottom: autoFix(20), backgroundColor: '#FFFFFF', margin: autoFix(20), borderRadius: autoFix(10) }}>
        <View style={[styles.cellGroup, styles.cellItem, { paddingHorizontal: 0 }]}>
          <TouchableOpacity onPress={() => this.gotoDetail(item, type)}>
            <MBText>
              {titleText[type]()} {numberText[type]()}
            </MBText>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => this.changItem(index, type)}>
            {item.selected ? <MBText>收起</MBText> : <MBText>展开</MBText>}
          </TouchableOpacity>
        </View>
        {item.selected && <Splitline color="#E8E8E8" type="solid" />}
        {item.selected && (
          <View style={[styles.cellItem, { paddingHorizontal: autoFix(29), paddingTop: autoFix(28) }]}>
            <MBText style={{ flex: 1, textAlign: 'left' }} color="#666666">
              {item.startPoint}
            </MBText>
            <View style={{ paddingHorizontal: autoFix(20) }}>
              <Image style={styles.longArrow} source={{ uri: images.longArrows }}></Image>
            </View>
            <MBText style={{ flex: 1, textAlign: 'left' }} color="#666666">
              {item.endPoint}
            </MBText>
          </View>
        )}
        {item.selected &&
          detailList[type].map((row: any, index: number) => {
            return (
              <View style={[styles.cellItem, { paddingTop: autoFix(28), paddingHorizontal: autoFix(28) }]}>
                <MBText color="#333333" style={{ paddingRight: autoFix(20) }}>
                  {row.label}
                </MBText>
                {row.type === 'money' ? (
                  <MBText>
                    <MBText bold style={{ fontSize: autoFix(25) }} color={row.color || '#666666'}>
                      ¥
                    </MBText>
                    <MBText
                      bold
                      color={row.color || '#666666'}
                      style={[styles.cellValue, { fontSize: autoFix(row.size || 28), textAlign: 'right' }]}
                    >
                      {item[row.key] || row.value}
                    </MBText>
                  </MBText>
                ) : (
                  <MBText
                    color={row.color || '#666666'}
                    style={[styles.cellValue, { fontSize: autoFix(row.size || 28), textAlign: 'right' }]}
                  >
                    {item[row.key] || row.value}
                  </MBText>
                )}
              </View>
            );
          })}
        {item.selected && <Whitespace vertical={10} />}
      </View>
    );
  };
  render() {
    const { detailData, payeeInfoList, loading, userName, tenant, tmsRole } = this.state;
    const { applyVerifyAmount, paySubjectType, paySubjectName, taskInfos, orderInfos, payeeInfo } = detailData;
    const payeeInfoListData = [...payeeInfoList, ...getLabelList(payeeInfo.payType)];
    return (
      <View style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <NavBar title="付款申请单" leftClick={() => this.props.navigation?.goBack()} />
        <ScrollView style={{ flex: 1 }}>
          <View style={styles.cellGroup}>
            <View style={styles.cellItem}>
              <MBText color="#999999">申请金额（元）</MBText>
              <MBText color="#666666">{paySubjectType}</MBText>
            </View>
            <View style={styles.cellItem}>
              <MBText color="#FF6969" bold style={{ fontSize: autoFix(42) }}>
                {applyVerifyAmount || '-'}
              </MBText>
              <MBText
                color="#666666"
                style={{ flex: 1, paddingLeft: autoFix(40), textAlign: 'right', marginTop: autoFix(10) }}
                numberOfLines={2}
              >
                {paySubjectName}
              </MBText>
            </View>
            <Splitline color="#CFD6E6" dashWidth={10} type="dashed" style={{ marginBottom: autoFix(12) }} />
            {payeeInfoListData?.map((item: any) => {
              const value = payeeInfo[item.key] || '';
              return (
                <View style={styles.cellItem}>
                  <MBText color="#999999">{item.label}</MBText>
                  <MBText color="#666666" style={styles.cellValue}>
                    {value}
                  </MBText>
                </View>
              );
            })}
          </View>
          <View style={{ paddingHorizontal: autoFix(48), paddingVertical: autoFix(20) }}>
            <MBText color="#333333" bold>
              运输明细
            </MBText>
          </View>
          {taskInfos?.length || orderInfos?.length ? (
            (() => {
              return [
                ...taskInfos?.map((item: any, index: number) => this.OrderTaskNoElement(item, index, 'task')),
                ...orderInfos?.map((item: any, index: number) => this.OrderTaskNoElement(item, index, 'order')),
              ];
            })()
          ) : !loading ? (
            <View style={{ margin: autoFix(28) }}>
              <EmptyPage
                errorData={{ image: images.icon_grey_no_data.uri, msg: '暂无数据' }}
                style={{ backgroundColor: '#FFFFFF', paddingTop: autoFix(80), paddingBottom: autoFix(80), borderRadius: 10 }}
                imgStyle={{ width: autoFix(256), height: autoFix(175) }}
                tipText={{ color: '#C9CED9' }}
              />
            </View>
          ) : null}
          {/* 附件信息 */}
          <View style={{ padding: autoFix(28) }}>
            <Accessory detail={detailData} loading={loading} />
          </View>
          <Whitespace vertical={20} />
        </ScrollView>
        <ButtonGroup navigation={this.props.navigation} detail={detailData} userName={userName} tenant={tenant} tmsRole={tmsRole} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  cellGroup: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    margin: autoFix(20),
    paddingHorizontal: autoFix(32),
    paddingVertical: autoFix(20),
  },
  cellItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: autoFix(12),
  },
  cellValue: {
    flex: 1,
    textAlign: 'right',
  },
  sortArrow: {
    width: autoFix(13),
    height: autoFix(26),
    marginLeft: autoFix(20),
  },
  openListItem: {
    transform: [{ rotateZ: '90deg' }, { translateX: autoFix(5) }], // 详情箭头旋转朝下
  },
  longArrow: {
    width: autoFix(36),
    height: autoFix(26),
  },
});
