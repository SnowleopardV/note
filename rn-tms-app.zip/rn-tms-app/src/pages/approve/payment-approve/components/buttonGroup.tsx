import React, { useEffect, useState, useRef } from 'react';
import { View, Text, TouchableOpacity, TextInput, SafeAreaView } from 'react-native';
import { MBText, Modal } from '@ymm/rn-elements';
import Styles from '../style';
import Api, { processCompleteRequsetParams, revokeRequsetParams } from '../api';
import { MBToast, MBLoading, MBBridge } from '@ymm/rn-lib';
import { NavigationScreenProp } from 'react-navigation';
import RegTest from '~/utils/RegTest';

enum ModalTile {
  approval = '审批',
  revoke = '撤销',
}
const approvalRequset = async (
  params: processCompleteRequsetParams,
  onCancel: () => void,
  navigation: NavigationScreenProp<{}, { businessId: string; businessNo: string; refresh?: () => void }>
) => {
  await MBLoading.load(Api.processComplete(params));
  MBToast.show('审批成功');
  onCancel && onCancel();
  navigation.goBack();
  navigation.state.params?.refresh?.();
};
const revokeRequset = async (
  params: revokeRequsetParams,
  onCancel: () => void,
  navigation: NavigationScreenProp<{}, { businessId: string; businessNo: string; refresh?: () => void }>,
  interfaceFlag: Boolean
) => {
  // interfaceFlag为1时撤销调用接口：yzgApp/apply/revoke
  if (!!interfaceFlag) {
    const { businessId, businessNo } = params;
    await MBLoading.load(
      Api.applyRevoke({
        applyId: businessId,
        applyNo: businessNo,
      })
    );
  } else {
    await MBLoading.load(Api.instanceRevoke(params));
  }

  MBToast.show('撤销成功');
  onCancel && onCancel();
  navigation.goBack();
  navigation.state.params?.refresh?.();
};

const ApprovalModal = ({
  approvalVisible,
  onCancel,
  type,
  businessId,
  businessNo,
  navigation,
  detail,
}: {
  approvalVisible: boolean;
  onCancel: () => void;
  type: string;
  businessId: string;
  businessNo: string;
  navigation: NavigationScreenProp<{}, { businessId: string; businessNo: string }>;
  detail: any;
}) => {
  const [remark, setRemark] = useState<string>('');
  const inputRef = useRef(null) as React.MutableRefObject<any>;
  const [isPass, setIsPass] = useState<boolean>(true);
  const { interfaceFlag, payAuth } = detail;

  const onChangeText = (val: string) => {
    if (RegTest.emoji(val)) return;
    setRemark(val);
  };

  // 驳回
  const onRefuse = () => {
    // payAuth: 0无权限，1有权限，无权限时则驳回按钮置灰，点击提示暂无权限...
    if (!!payAuth) {
      setIsPass(false);
    } else {
      MBToast.show('暂无权限，请至公司管理-财务权限中开通"拒绝支付"的权限！');
    }
  };

  return (
    <Modal
      position="bottom"
      title={ModalTile[type]}
      visible={approvalVisible}
      headerLine={false}
      headerLeft="取消"
      headerRight="确定"
      onCancel={onCancel}
      onMaskClose={onCancel}
      onRequestClose={onCancel}
      style={Styles.modalStyle}
      autoAdjustPosition={true}
      onConfirm={() => {
        //当审批为驳回或者撤销需要校验审批意见是否必填
        if ((!isPass || (type === 'revoke' && !interfaceFlag)) && !remark.length) {
          MBToast.show(ModalTile[type] + '意见为必填项');
          return;
        }
        if (type === 'approval') approvalRequset({ businessId, businessNo, isPass: isPass, remark: remark }, onCancel, navigation);
        if (type === 'revoke') revokeRequset({ businessId, businessNo, revokeComment: remark }, onCancel, navigation, interfaceFlag);
      }}
    >
      {type === 'approval' && (
        <View style={Styles.buttonParent}>
          <TouchableOpacity
            onPress={() => {
              setIsPass(true);
            }}
            style={[{ flex: 1 }, Styles.h60]}
          >
            <View style={[Styles.modalButton, isPass ? Styles.checkStatus : Styles.noCheckStatus, Styles.mr26]}>
              <Text style={[Styles.modalButtonText, { color: isPass ? '#4885FF' : '#999999' }]}>通过</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={onRefuse} style={[{ flex: 1 }, Styles.h60]}>
            <View style={[Styles.modalButton, isPass ? Styles.noCheckStatus : Styles.checkStatus]}>
              <Text style={[Styles.modalButtonText, { color: isPass ? '#999999' : '#4885FF' }]}>驳回</Text>
            </View>
          </TouchableOpacity>
        </View>
      )}
      <View style={Styles.modalTitle}>
        <Text style={Styles.TitleText}>{ModalTile[type]}意见</Text>
        {(!isPass || (type === 'revoke' && !interfaceFlag)) && <Text style={[Styles.TitleText, Styles.star]}>*</Text>}
      </View>
      <TouchableOpacity
        onPress={() => {
          inputRef.current.focus();
        }}
        style={{ width: '100%' }}
      >
        <View style={[Styles.inputItem, type === 'revoke' && !interfaceFlag ? Styles.h260 : {}]}>
          <TextInput
            ref={inputRef}
            style={Styles.inputStyle}
            value={remark}
            placeholder={
              type === 'revoke' && !interfaceFlag ? '请输入撤销意见（必填）' : isPass ? '请输入审批意见' : '请输入审批意见（必填）'
            }
            onChangeText={(val) => onChangeText(val)}
            maxLength={100}
            multiline={true}
          ></TextInput>
          <View style={Styles.remarkLength}>
            <Text>
              <Text style={{ color: '#666666' }}>{remark.length}</Text>/100
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    </Modal>
  );
};
interface buttonProps {
  userName: string;
  tenant: string;
  tmsRole: string;
  detail: any;
  navigation: NavigationScreenProp<
    any,
    {
      businessId: string;
      businessNo: string;
      businessCurrentStatus: number;
      refresh?: () => void;
    }
  >;
}
export default ({ navigation, detail, userName, tenant, tmsRole }: buttonProps) => {
  const [buttonGroup, setButtonGroup] = useState<
    Array<{
      code: string;
      name: string;
      enable: boolean;
    }>
  >([]);
  const { businessId, businessNo, businessCurrentStatus } = navigation.state.params ?? {
    businessId: '',
    businessNo: '',
  };
  const [visible, setVisible] = useState<boolean>(false);
  const [btnType, setBtnType] = useState<string>('');
  const [approvalVisible, setApprovalVisible] = useState<boolean>(false);
  const { applyAuditStatus, verifyStatus, payAuth } = detail;
  useEffect(() => {
    if (detail.applyNo) {
      // 审批状态：5: 无需审批
      if (detail.applyAuditStatus === 5) {
        return;
      }
      Api.buttonSingle({
        businessId,
        businessNo,
      })
        .then(({ data }) => {
          const buttonDTO = data.buttonDTO || [];
          const revokeButtonList = buttonDTO.filter((item) => item.code === 'revoke');
          // 审批流未返回撤销按钮且审批通过且未结算时，增加撤销按钮
          if (!revokeButtonList.length && applyAuditStatus === 2 && verifyStatus === 0 && payAuth !== 0) {
            buttonDTO.push({
              code: 'revoke',
              name: '撤销',
              enable: true,
            });
          }

          const buttonList = buttonDTO.filter((item) => {
            let isShow = item.enable;
            // 撤销按钮，1：审批通过且（已结算或部分结算）时不展示；2：payAuth: 0无权限时不展示；3：审批中、审批跟踪根据enable字段控制展示
            if (item.code === 'revoke') {
              if ((applyAuditStatus === 2 && (verifyStatus === 1 || verifyStatus === 2)) || payAuth === 0) {
                isShow = false;
              }
            }

            return isShow;
          });

          setButtonGroup(buttonList);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [detail]);
  if (!buttonGroup.length) {
    return null;
  }
  return (
    <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}>
      <View style={Styles.buttonGroup}>
        {buttonGroup.length >= 1 && (
          <TouchableOpacity
            onPress={() => {
              if (buttonGroup[0].code === 'tracking') {
                navigation.navigate('PaymentRequset', {
                  businessId,
                  businessNo,
                  userName,
                  tenant,
                  tmsRole,
                });
                return;
              }
              setBtnType(buttonGroup[0].code);
              setApprovalVisible(true);
            }}
            style={Styles.tailAfter}
          >
            <View>
              <MBText style={Styles.tailAfterText}>{buttonGroup?.[0]?.name}</MBText>
            </View>
          </TouchableOpacity>
        )}
        {buttonGroup.length >= 2 && (
          <TouchableOpacity
            onPress={() => {
              if (buttonGroup[1].code === 'tracking') {
                navigation.navigate('PaymentRequset', {
                  businessId,
                  businessNo,
                  userName,
                  tenant,
                  tmsRole,
                });
                return;
              }
              setBtnType(buttonGroup[1].code);
              setApprovalVisible(true);
            }}
            style={Styles.appovalsBtton}
          >
            <View>
              <MBText style={Styles.appovalsText}>{buttonGroup?.[1]?.name}</MBText>
            </View>
          </TouchableOpacity>
        )}
        {buttonGroup.length >= 3 && (
          <>
            <TouchableOpacity
              onPress={() => {
                setVisible(true);
              }}
            >
              <View style={Styles.appovalsIcon}>
                <View style={Styles.dot}></View>
                <View style={Styles.dot}></View>
                <View style={Styles.dot}></View>
              </View>
            </TouchableOpacity>
            <Modal visible={visible} position="bottom" headerLine={false} onMaskClose={() => setVisible(false)}>
              <View style={Styles.alertConent}>
                {buttonGroup.slice(2, buttonGroup.length).map((item) => (
                  <TouchableOpacity
                    onPress={() => {
                      setBtnType(item.code);
                      setApprovalVisible(true);
                      setVisible(false);
                    }}
                  >
                    <View style={Styles.alertOtherConentItem}>
                      <MBText style={Styles.itemText}>{item.name}</MBText>
                    </View>
                  </TouchableOpacity>
                ))}
                <View style={Styles.splitLine}></View>
                <TouchableOpacity onPress={() => setVisible(false)}>
                  <View style={Styles.alertOtherConentItem}>
                    <MBText style={Styles.itemText}>取消</MBText>
                  </View>
                </TouchableOpacity>
              </View>
            </Modal>
          </>
        )}
        {!!approvalVisible && (
          <ApprovalModal
            approvalVisible={approvalVisible}
            onCancel={() => setApprovalVisible(false)}
            type={btnType}
            businessId={businessId}
            businessNo={businessNo}
            navigation={navigation}
            detail={detail}
          />
        )}
      </View>
    </SafeAreaView>
  );
};
