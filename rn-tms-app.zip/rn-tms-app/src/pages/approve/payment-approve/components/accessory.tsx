import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Image, ScrollView, TouchableOpacity } from 'react-native';
import { applyDetailResponseParams } from '../api';
import ImageView from '~/components/common/ImageView';
import playStyles from '../style';
import { MBText } from '@ymm/rn-elements';
import EmptyPage from '~/components/common/EmptyPage';
import images from '~public/static/images';
import { RNElementsUtil } from '@ymm/rn-elements';
const { autoFix } = RNElementsUtil;
export default ({ detail, loading }: { detail: applyDetailResponseParams; loading: boolean }) => {
  const [visible, setVisible] = useState<boolean>(false);
  const [index, setIndex] = useState<number>(0);
  return (
    <View style={playStyles.accessory}>
      <MBText bold color="#333333" style={{ paddingBottom: autoFix(40), paddingHorizontal: autoFix(20) }}>
        附件信息
      </MBText>
      {detail.imageUrls?.length ? (
        <View style={[playStyles.content, playStyles.imageContent]}>
          {detail.imageUrls.map((item, index) => (
            <TouchableOpacity
              onPress={() => {
                setIndex(index);
                setVisible(true);
              }}
            >
              <Image style={playStyles.smallImage} source={{ uri: item }}></Image>
            </TouchableOpacity>
          ))}
        </View>
      ) : !loading ? (
        <EmptyPage
          errorData={{ image: images.icon_grey_no_data.uri, msg: '暂无数据' }}
          style={{ backgroundColor: '#FFFFFF', paddingTop: autoFix(80), paddingBottom: autoFix(80), borderRadius: 10 }}
          imgStyle={{ width: autoFix(256), height: autoFix(175) }}
          tipText={{ color: '#C9CED9' }}
        />
      ) : null}
      <ImageView
        visible={visible}
        onCancel={() => setVisible(false)}
        imageUrls={
          detail.imageUrls?.reduce((total: { url: string }[], current: string) => {
            const item: { url: string } = {
              url: current,
            };
            total.push(item);
            return total;
          }, []) ?? []
        }
        index={index}
      />
    </View>
  );
};
