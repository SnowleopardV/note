import React, { Component } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import ApproveContent from './components/ApproveContent';
import ApproveSearch from './components/ApproveSearch';
import MBSearchInput from '~/components/common/MBSearchInput';
import EmptyPage from '~/components/common/EmptyPage';
import TouchableThrottle from '~/components/TouchableThrottle';
import ApproveStore from './store';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import RegTest from '~/utils/RegTest';
import { MBAutoPVComponent } from '@ymm/rn-lib';

export interface ApproveIndexProps {
  navigation: any;
  approveStore?: ApproveStore;
}

export interface ApproveIndexState {
  title: string;
  keyword: string;
  currentIndex: number;
  searchParams: any;
}

@inject('approveStore')
@observer
class ApproveIndex extends MBAutoPVComponent<ApproveIndexProps, ApproveIndexState> {
  store: any;
  timer: any;
  constructor(props: ApproveIndexProps) {
    super(props);
    this.store = this.props.approveStore;
    this.timer = null;
    this.state = {
      title: '审批列表',
      keyword: '',
      currentIndex: 0,
      searchParams: {
        channel: 1,
        pageNo: 0,
        pageSize: 20,
        tab: 1,
        filterCondition: '',
      },
    };
  }

  async componentDidMount() {
    const { getshowPermissionVisible, getApproveListTab, getUserInfo, trackPageView } = this.store;
    await getshowPermissionVisible();
    getApproveListTab();
    await getUserInfo();
    // 记录PV埋点
    const { name, companyName, roleName } = this.store.userInfo;
    this.__set_AutoPV_PageInfo('approval_list', { userName: name, tenant: companyName, tmsRole: roleName });
  }
  componentWillUnmount() {
    super.componentWillUnmount();
  }
  /**
   * 搜索框渲染视图
   * @param keyword
   * @returns
   */
  renderSearchInputView(keyword: string) {
    return (
      <View style={styles.searchBar}>
        <MBSearchInput
          returnKeyType="search"
          initialText={keyword}
          onSearch={this.onSearch}
          onBlur={this.onSearch}
          onChangeText={this.onChangeText}
          placeholder="请输入发起人、单号"
        />
      </View>
    );
  }
  onSearch = () => {
    clearTimeout(this.timer);
    if (Platform.OS === 'android') {
      this.prepareSearch(this.state.keyword);
    }
  };
  onChangeText = (text: string) => {
    this.setState({ keyword: text }, () => {
      if (Platform.OS === 'ios') {
        if (this.timer) {
          clearTimeout(this.timer);
        }
        this.timer = setTimeout(() => {
          this.prepareSearch(text);
        }, 1000);
      }
    });
  };
  prepareSearch = (text: string) => {
    const _this = this;
    const { currentIndex } = this.state;
    if (RegTest.emoji(text)) return;

    this.store?.beforeGetSearchApproveList();

    const params = {
      channel: 1,
      pageNo: 1,
      pageSize: 20,
      tab: currentIndex + 1,
      filterCondition: text,
    };
    this.setState({ searchParams: params }, () => {
      _this.store.isSearchLoaded = false;
      _this.store?.getSearchApproveList(params);
      _this.store?.trackTap('approval_list', 'approval_search');
    });
  };

  onTabChange = (position: number, name: string) => {
    const { trackTap } = this.store;
    this.setState({ currentIndex: position });
    // 待办，切换到不同tab埋点
    if (name === '1') {
      trackTap('approval_list', 'approval_list_backlog');
    }
    //已办
    if (name === '2') {
      trackTap('approval_list', 'approval_list_finished');
    }
    // 我发起的
    if (name === '3') {
      trackTap('approval_list', 'approval_list_created');
    }
  };

  onRefresh = (index: number) => {
    const { currentIndex } = this.state;
    const { getApproveList, approveList } = this.store;
    index = index > -1 ? index : currentIndex;
    if (approveList[index].loading) return Promise.resolve();
    approveList[index].loading = true;
    approveList[index].params.pageNo = 1;
    const params = approveList[index].params;
    return new Promise((resolve) => getApproveList(params, 'refresh').finally(() => resolve()));
  };

  onLoadMore = () => {
    const { currentIndex } = this.state;
    const { getApproveList, approveList } = this.store;
    if (approveList[currentIndex].loading) return Promise.resolve();
    approveList[currentIndex].loading = true;
    approveList[currentIndex].params.pageNo++;
    const params = approveList[currentIndex].params;
    return new Promise((resolve) => getApproveList(params, 'loadMore').finally(() => resolve()));
  };

  gotoDetail = (item: any) => {
    const { currentIndex } = this.state;
    const { navigation } = this.props;
    const {
      pathParams: { businessId, businessNo },
      businessCurrentStatus,
    } = item;

    navigation.navigate('PaymentApprove', {
      businessId,
      businessNo,
      businessCurrentStatus,
      refresh: () => this.onRefresh(currentIndex),
    });
  };

  onSearchLoadMore = () => {
    const { keyword, currentIndex, searchParams } = this.state;
    const { getSearchApproveList } = this.store;
    this.store.isSearchLoading = true;

    if (!this.store.isSearchLoaded) {
      this.store.isSearchLoaded = true;
      return Promise.resolve();
    }

    const params = {
      channel: 1,
      pageNo: searchParams.pageNo + 1,
      pageSize: 20,
      tab: currentIndex + 1,
      filterCondition: keyword,
    };

    this.setState({
      searchParams: params,
    });

    return new Promise((resolve) => getSearchApproveList(params).finally(() => resolve()));
  };

  renderElement = () => {
    const { navigation } = this.props;
    const { trackTap } = this.store;
    return (
      <View style={styles.subTipWrapper}>
        <MBText style={styles.subTipText}>去了解</MBText>
        <TouchableThrottle
          activeOpacity={0.8}
          onPress={() => {
            trackTap('approval_list', 'approval_getinfo');
            navigation.navigate('ApproveIntro');
          }}
        >
          <MBText style={styles.approveText}>审批功能</MBText>
        </TouchableThrottle>
      </View>
    );
  };

  render() {
    const { title, keyword, currentIndex } = this.state;
    const { isPermissionLoading, showPermissionVisible, errorData, approveList, searchApproveList, isSearchEnd, isSearchLoading } =
      this.store;

    return (
      <View style={styles.flexStyle}>
        <NavBar title={title} />
        {!isPermissionLoading ? (
          showPermissionVisible ? (
            <EmptyPage errorData={errorData} renderElement={this.renderElement()} />
          ) : (
            <View style={styles.flexStyle}>
              {this.renderSearchInputView(keyword)}

              <ApproveContent
                keyword={keyword}
                defaultIndex={currentIndex}
                list={approveList}
                onTabChange={this.onTabChange}
                onRefresh={this.onRefresh}
                onLoadMore={this.onLoadMore}
                gotoDetail={this.gotoDetail}
              />

              <ApproveSearch
                keyword={keyword}
                isSearchEnd={isSearchEnd}
                isSearchLoading={isSearchLoading}
                list={searchApproveList}
                onLoadMore={this.onSearchLoadMore}
                gotoDetail={this.gotoDetail}
              />
            </View>
          )
        ) : null}
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  flexStyle: {
    flex: 1,
  },

  searchBar: {
    backgroundColor: '#fff',
    paddingHorizontal: autoFix(28),
    paddingBottom: autoFix(28),
  },

  subTipWrapper: {
    flex: 1,
    flexDirection: 'row',
  },

  subTipText: {
    marginTop: autoFix(8),
    fontSize: autoFix(28),
    color: '#A2ADC7',
  },

  approveText: {
    marginTop: autoFix(8),
    fontSize: autoFix(28),
    color: '#4885FF',
  },
});

export default ApproveIndex;
