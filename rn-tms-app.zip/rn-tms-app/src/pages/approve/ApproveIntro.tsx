import React from 'react';
import { View, StyleSheet, ScrollView, ImageBackground } from 'react-native';
import NavBar from '~/components/common/NavBar';
import Images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export interface ApproveIntroProps {
  navigation?: any;
}

class ApproveIntro extends React.Component<ApproveIntroProps, any> {
  constructor(props: ApproveIntroProps) {
    super(props);
  }

  leftClick = () => {
    const { navigation } = this.props;
    navigation.goBack();
  };

  render() {
    return (
      <View style={styles.approveIntro}>
        <NavBar title="审批功能" leftClick={this.leftClick} />
        <ScrollView style={styles.scrollBox} keyboardShouldPersistTaps="handled" showsHorizontalScrollIndicator={false}>
          <ImageBackground source={{ uri: Images.bg_approve }} style={styles.imageBackground}></ImageBackground>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  approveIntro: {
    flex: 1,
  },

  scrollBox: {
    flex: 1,
  },

  imageBackground: {
    height: autoFix(2101),
    resizeMode: 'cover',
    justifyContent: 'center',
  },
});

export default ApproveIntro;
