import React from 'react';
import { View, StyleSheet, ScrollView, Image } from 'react-native';
import { MBText, Tabs, RefreshList } from '@ymm/rn-elements';
import TouchableThrottle from '~/components/TouchableThrottle';
import EmptyPage from '~/components/common/EmptyPage';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}
interface ApproveSearchProps {
  keyword: string;
  list: any;
  isSearchEnd: boolean;
  isSearchLoading: boolean;
  onLoadMore: () => void;
  gotoDetail: (item: any) => void;
}

class ApproveSearch extends React.Component<ApproveSearchProps, any> {
  constructor(props: ApproveSearchProps) {
    super(props);
  }

  renderEmpty = () => {
    return (
      <EmptyPage
        errorData={{ image: 'https://image.ymm56.com/ymmfile/operation-biz/43215d82-c71b-4e84-938d-7c9bb2cf5dca.png.png', msg: `暂无数据` }}
      />
    );
  };

  renderItem = (item: any, index: number) => {
    const { keyword, gotoDetail } = this.props;
    return (
      <TouchableThrottle
        style={styles.itemWrapper}
        activeOpacity={0.8}
        onPress={() => {
          gotoDetail(item);
        }}
        key={index}
      >
        {!!keyword && item.searchSummary?.indexOf(keyword) >= 0 ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            <MBText style={styles.searchSummary}>{item.searchSummary.substring(0, item.searchSummary.indexOf(keyword))}</MBText>
            <MBText style={[styles.searchSummary, { color: '#4885FF' }]}>
              {item.searchSummary.substring(item.searchSummary.indexOf(keyword), item.searchSummary.indexOf(keyword) + keyword.length)}
            </MBText>
            <MBText style={styles.searchSummary}>
              {item.searchSummary?.substring(item.searchSummary.indexOf(keyword) + keyword.length)}
            </MBText>
          </View>
        ) : (
          <MBText style={styles.searchSummary}>{item.searchSummary}</MBText>
        )}
      </TouchableThrottle>
    );
  };

  render() {
    const { keyword, isSearchEnd, list, onLoadMore } = this.props;

    return (
      <View style={[styles.listWrapper, { display: !!keyword ? 'flex' : 'none' }]}>
        {list.map((item: any) => {
          return (
            <RefreshList
              isEnd={isSearchEnd}
              data={item.list}
              renderItem={(e: any, index: number) => this.renderItem(e, index)}
              emptyRender={this.renderEmpty}
              onLoadMore={onLoadMore}
              pullRefresh={false}
              getLayoutTypeForIndex={() => 215}
            />
          );
        })}
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  listWrapper: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  emptyText: {
    fontSize: autoFix(32),
    fontWeight: 'bold',
    color: '#666',
  },

  searchSummary: {
    fontSize: autoFix(30),
    color: '#333',
  },

  itemWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingLeft: autoFix(52),
    paddingRight: autoFix(28),
    paddingVertical: autoFix(20),
  },
});

export default ApproveSearch;
