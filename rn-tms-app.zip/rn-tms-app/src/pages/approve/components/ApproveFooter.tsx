import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, MBText } from '@ymm/rn-elements';

interface ApproveFooterProps {
  onConfirm?: () => void;
}

class ApproveFooter extends React.Component<ApproveFooterProps, any> {
  constructor(props: ApproveFooterProps) {
    super(props);
  }

  render() {
    return (
      <View style={styles.footer}>
        <Button
          type="primary"
          size="sm"
          radius
          style={styles.itemBtn}
          onPress={() => {
            const { onConfirm } = this.props;
            onConfirm && onConfirm();
          }}
        >
          <MBText color="#fff">确定</MBText>
        </Button>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  footer: {
    height: 60,
    paddingVertical: 10,
    paddingHorizontal: 14,
    flexDirection: 'row',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },

  itemBtn: {
    flex: 1,
  },
});

export default ApproveFooter;
