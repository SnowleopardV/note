import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { MBText, Tabs, RefreshList } from '@ymm/rn-elements';
import TouchableThrottle from '~/components/TouchableThrottle';
import EmptyPage from '~/components/common/EmptyPage';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import images from '~public/static/images';
import { Splitline, Whitespace } from '@ymm/rn-elements';
import { xyzMath } from '~/utils/xyzMath';
export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}
interface ApproveContentProps {
  keyword: string;
  defaultIndex: number;
  list: any;
  onTabChange: (position: number, name: string) => void;
  onRefresh: (index: number) => void;
  onLoadMore: () => void;
  gotoDetail: (item: any) => void;
}
const InvoiceTypeMap = {
  0: '', // 默认值， 无任何业务含义
  1: '', // 不开票
  2: { img: images.logo_mybqy, width: autoFix(115), height: autoFix(25) }, // 企业增值税专票
  3: { img: images.icon_myb, width: autoFix(70), height: autoFix(25) }, // 企业增值税普票
};

class ApproveContent extends React.Component<ApproveContentProps, any> {
  constructor(props: ApproveContentProps) {
    super(props);
  }

  renderEmpty = (typeName: string) => {
    return (
      <EmptyPage
        errorData={{
          image: images.icon_no_data,
          msg: `暂无${typeName}数据`,
        }}
      />
    );
  };

  renderItem = (item: any, index: number) => {
    const { gotoDetail } = this.props;
    const totalAmount = xyzMath.divide(Number(item?.extension?.totalAmount) || 0, 100).toFixed(2);
    const payeeInfo = item?.extension?.payeeInfo?.split('/');
    const invoiceType = item.extension?.invoiceType ? InvoiceTypeMap[item.extension.invoiceType] || null : null;
    return (
      <TouchableThrottle style={styles.itemWrapper} activeOpacity={0.8} onPress={() => gotoDetail(item)} key={index}>
        <View style={styles.itemInfo}>
          <View style={styles.statusWrapper}>
            <MBText style={styles.statusName}>{item?.businessUnitTypeLabel || '-'}</MBText>
            <View style={[styles.statusTagWrapper, styles[`statusTagWrapper${item.businessCurrentStatus}`]]}>
              <MBText style={[styles.statusTag, styles[`statusTag${item.businessCurrentStatus}`]]}>
                {item?.businessCurrentStatusLabel || '-'}
              </MBText>
            </View>
          </View>
          <View style={[styles.otherInfoWrapper, { marginTop: autoFix(16) }]}>
            <View style={styles.otherInfo}>
              <MBText color="#999999" style={styles.otherInfo}>
                申请信息
              </MBText>
              <View style={styles.otherInfo}>
                <MBText color="#333" numberOfLines={1} style={[styles.otherInfo, { flex: 1 }]}>
                  {item.initiatorName || '-'}
                </MBText>
                <MBText color="#333" numberOfLines={1} style={[styles.otherInfo, { flex: 1 }]}>
                  {item.initiatorDepartment || '-'}
                </MBText>
              </View>
              <MBText color="#999999" style={[styles.otherInfo, { marginTop: autoFix(26) }]}>
                {item?.businessNo || '-'}
              </MBText>
            </View>
            <View style={{ backgroundColor: '#E8E8E8', width: 1, marginHorizontal: autoFix(20), height: autoFix(90) }} />
            <View style={styles.otherInfo}>
              <MBText color="#999999" style={styles.otherInfo}>
                收款信息
              </MBText>
              <View style={styles.otherInfo}>
                <MBText color="#333" style={[styles.otherInfo, { flex: 1 }]} numberOfLines={1}>
                  {payeeInfo && payeeInfo[0] ? payeeInfo[0] : '-'}
                </MBText>
                <View style={[styles.otherInfoWrapper, { justifyContent: 'flex-start', marginTop: 0 }]}>
                  <MBText color="#333" numberOfLines={1} style={[styles.otherInfo]}>
                    {payeeInfo && payeeInfo[1] ? payeeInfo[1] : '-'}
                  </MBText>
                  {!!invoiceType && (
                    <Image
                      style={{ width: invoiceType.width, height: invoiceType.height, marginLeft: autoFix(7), marginTop: autoFix(7) }}
                      source={{ uri: invoiceType.img }}
                    />
                  )}
                </View>
              </View>
              <MBText color="#999999" style={[styles.otherInfo, { marginTop: autoFix(26) }]}>
                {item?.createTime || '-'}
              </MBText>
            </View>
          </View>
          {!!item?.extension?.totalAmount && (
            <View>
              <Whitespace vertical={20} />
              <Splitline color="#D9DEE8" dashWidth={8} type="dashed" />
              <View style={{ flexDirection: 'row', marginTop: autoFix(26), alignItems: 'center' }}>
                <MBText color="#666666" size="sm">
                  应付金额
                </MBText>
                <MBText color="#333333" style={styles.footAmount} numberOfLines={1}>
                  ¥{totalAmount}
                </MBText>
              </View>
            </View>
          )}
        </View>
      </TouchableThrottle>
    );
  };

  render() {
    const { keyword, defaultIndex, list, onTabChange, onRefresh, onLoadMore } = this.props;

    return (
      <View style={[styles.listWrapper, { display: !keyword ? 'flex' : 'none' }]}>
        <Tabs
          defaultIndex={defaultIndex}
          onChange={(position, name) => {
            onTabChange && onTabChange(position, name);
          }}
        >
          {list.map((item: any, index: number) => {
            // 只显示待办数量，为0时不显示
            const title = item.total && item.total !== '0' && item.type === '1' ? `${item.typeName}(${item.total})` : item.typeName;
            return (
              <Tabs.TabPane title={title} position={index} name={item.type}>
                <View style={[styles.listContentWrapper]}>
                  <RefreshList
                    isEnd={item.isEnd}
                    data={item.list}
                    renderItem={(e: any, index: number) => this.renderItem(e, index)}
                    emptyRender={() => this.renderEmpty(item.typeName)}
                    onRefresh={onRefresh}
                    onLoadMore={onLoadMore}
                    getLayoutTypeForIndex={() => 215}
                  />
                </View>
              </Tabs.TabPane>
            );
          })}
        </Tabs>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  listWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  listContentWrapper: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  itemWrapper: {
    flex: 1,
    flexDirection: 'column',
    marginTop: autoFix(20),
    paddingHorizontal: autoFix(20),
  },

  statusName: {
    fontSize: autoFix(32),
    fontWeight: 'bold',
    color: '#333333',
  },

  itemInfo: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingLeft: autoFix(40),
    paddingRight: autoFix(28),
    paddingTop: autoFix(40),
    paddingBottom: autoFix(20),
  },

  statusWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  statusTagWrapper: {
    backgroundColor: 'rgba(250, 173, 20, 0.12)',
    padding: autoFix(6),
    borderRadius: autoFix(6),
  },

  statusTagWrapper2: {
    backgroundColor: 'rgba(250, 173, 20, 0.12)',
  },

  statusTagWrapper3: {
    backgroundColor: 'rgba(98, 186, 70, 0.12)',
  },

  statusTagWrapper4: {
    backgroundColor: 'rgba(162, 173, 199, 0.12)',
  },

  statusTagWrapper5: {
    backgroundColor: 'rgba(255, 105, 105, 0.12)',
  },

  statusTagWrapper10: {
    backgroundColor: 'rgba(98, 186, 70, 0.12)',
  },

  statusTag: {
    fontSize: autoFix(26),
    color: '#FAAD14',
  },

  statusTag2: {
    color: '#FAAD14',
  },

  statusTag3: {
    color: '#62BA46',
  },

  statusTag4: {
    color: '#9DA1B0',
  },

  statusTag5: {
    color: '#FF6969',
  },

  statusTag10: {
    color: '#62BA46',
  },

  otherInfoWrapper: {
    flexDirection: 'row',
    marginTop: autoFix(10),
    alignItems: 'center',
  },

  otherInfo: {
    marginTop: autoFix(10),
    fontSize: autoFix(24),
    flex: 1,
  },
  footAmount: {
    flex: 1,
    fontFamily: 'DINAlternate-Bold',
    marginLeft: autoFix(20),
    fontSize: autoFix(42),
  },
});

export default ApproveContent;
