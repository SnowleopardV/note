import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { LayProvider } from '@ymm/rn-elements';
import { Provider } from 'mobx-react';
import Store from '../store';

const RootStack = new RouterMap().getRouterMap(RouterPageName.ApproveIndex);

const WaybillCreate: React.FunctionComponent<any> = (props) => {
  const store = new Store(props);
  return (
    <Provider approveStore={store}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
      </LayProvider>
    </Provider>
  );
};

export default WaybillCreate;
