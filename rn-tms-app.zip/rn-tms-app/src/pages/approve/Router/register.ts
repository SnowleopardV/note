import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import ApproveIndexPage from '../index';
import ApproveIntroPage from '../ApproveIntro';
import PaymentRequsetPage from '../payment-requset';
import PaymentApprovePage from '../payment-approve';

/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 审批列表页
   */
  ApproveIndex = 'ApproveIndex',
  /**
   * 审批流
   */
  PaymentRequset = 'PaymentRequset',
  /**
   * 审批详情页
   */
  PaymentApprove = 'PaymentApprove',
  /**
   * 审批功能介绍页
   */
  ApproveIntro = 'ApproveIntro',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        ApproveIndex: {
          screen: ApproveIndexPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        PaymentRequset: {
          screen: PaymentRequsetPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        PaymentApprove: {
          screen: PaymentApprovePage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        ApproveIntro: {
          screen: ApproveIntroPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
