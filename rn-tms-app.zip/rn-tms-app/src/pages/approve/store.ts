import { observable, action } from 'mobx';
import BaseStore from '~/extends/BaseStore';
import server from '~/server';
import { MBLog, MBJournal } from '@ymm/rn-lib';

interface ApproveStateData {
  customerId: string;
}
interface ApproveModuleData {
  shipperPlaceholder: string;
}

interface ApproveListType {
  type: string;
  typeName: string;
  count: number;
  list: any;
  loading: boolean;
  isEnd: boolean;
  total: string;
  params: any;
}
interface SearchApproveListType {
  list: ApproveListType[];
}

class ApproveStore extends BaseStore<ApproveModuleData, ApproveStateData> {
  constructor(props: any) {
    super(props);
    this.init();
  }
  init = () => {
    this.saveStateData({
      customerId: '',
    });
    this.saveModuleData({
      shipperPlaceholder: '必填，请输入装货地址',
    });
  };

  @observable userInfo: any = {};
  @observable isPermissionLoading: boolean = true;
  @observable showPermissionVisible: boolean = true;
  @observable errorData: any = {};
  @observable approveList: ApproveListType[] = [];
  @observable isSearchLoading: boolean = false;
  @observable isSearchEnd: boolean = false;
  @observable isSearchLoaded: boolean = false;
  @observable searchApproveList: SearchApproveListType[] = [];

  // 获取用户信息
  @action
  getUserInfo = async () => {
    try {
      const res = await server(
        {
          url: '/saas-permission-app/yzgApp/user/queryUserInfo',
          data: {},
        },
        { showLoading: false }
      );

      if (res.success) {
        this.userInfo = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '获取用户信息失败',
        error: error,
      });
    }
  };

  // 获取审批tab
  @action
  getApproveListTab = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-process-engine/yzgApp/task/tab',
          data: { channel: 1 },
        },
        { showLoading: false }
      );

      if (res.success) {
        const data = res.data.map((item: any, index: number) => {
          item.list = [];
          item.loading = false;
          item.params = {
            channel: 1,
            pageNo: 0,
            pageSize: 10,
            tab: index + 1,
            filterCondition: '',
          };
          return item;
        });
        this.approveList = data;
      }
    } catch (error) {
      MBLog.log({
        message: '获取审批tab失败',
        error: error,
      });
    } finally {
      this.isPermissionLoading = false;
    }
  };

  // 获取审批权限
  @action
  getshowPermissionVisible = async () => {
    try {
      const res = await server({
        url: '/saas-tms-process-engine/yzgApp/process/usable',
        data: {},
      });

      if (res.success) {
        this.showPermissionVisible = !res.data;
        this.errorData = {
          image: 'https://image.ymm56.com/ymmfile/operation-biz/43215d82-c71b-4e84-938d-7c9bb2cf5dca.png',
          msg: '暂未开通审批功能',
        };
      }
    } catch (error) {
      MBLog.log({
        message: '获取审批权限失败',
        error: error,
      });
    }
  };

  // 获取审批列表
  @action
  getApproveList = async (params: any, type: string) => {
    const { tab } = params;
    try {
      const res = await server(
        {
          url: '/saas-tms-process-engine/yzgApp/task/tab/list',
          data: { ...params },
        },
        { showLoading: false }
      );

      if (res.success) {
        const data = this.approveList;
        data[tab - 1].loading = false;
        data[tab - 1].isEnd = !res.data?.hasNextPage;
        data[tab - 1].total = res.data?.total;
        if (type === 'refresh') {
          data[tab - 1].list = res.data?.list;
        }

        if (type === 'loadMore') {
          data[tab - 1].list = data[tab - 1].list.concat(res.data?.list);
        }

        this.approveList = [...data];
      }
    } catch (error) {
      MBLog.log({
        message: '获取审批列表失败',
        error: error,
      });
    }
  };

  // 搜索前清空上一次数据
  @action
  beforeGetSearchApproveList = () => {
    this.searchApproveList = [];
  };

  // 获取搜索审批数据
  @action
  getSearchApproveList = async (params: any) => {
    try {
      const res = await server({
        url: '/saas-tms-process-engine/yzgApp/task/tab/list',
        data: { ...params },
      });

      if (res.success) {
        const lastList = this.searchApproveList[0]?.list || [];
        let data = res.data?.list;
        this.isSearchEnd = !res.data?.hasNextPage;
        this.isSearchLoading = false;

        data = lastList.concat(res.data?.list);
        this.searchApproveList = [{ list: [...data] }];
      }
    } catch (error) {
      MBLog.log({
        message: '获取审批列表失败',
        error: error,
      });
    }
  };

  // 点击埋点
  @action
  trackTap = (pageName: string, elementId: string) => {
    const { name, companyName, roleName } = this.userInfo;
    MBJournal.tapJournal({
      elementId: elementId,
      pageName: pageName,
      referPageName: '',
      extraDict: {
        userName: name,
        tenant: companyName,
        tmsRole: roleName,
      },
    });
  };
}

export default ApproveStore;
