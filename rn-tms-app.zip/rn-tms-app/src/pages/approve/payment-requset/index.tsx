import React, { useEffect, useState } from 'react';
import { Modal } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import { SafeAreaView, View, Image, ScrollView, TouchableOpacity, Text } from 'react-native';
import PayRequsetFlow from './pay-flow';
import { flowStyle, headStyle } from './styles';
import Api, { processHistResponseParams } from './api';
import { NavigationScreenConfigProps, NavigationScreenProp } from 'react-navigation';
import images from '~public/static/images';
import { MBJournal, useAutoPv } from '@ymm/rn-lib';

// 申请单状态对应图片地址
enum businessCurrentStatus {
  icon_startAudit = 1, // 开始审批
  icon_auditing, // 审批中
  icon_audit_end, // 审批通过
  icon_audit_catch, // 审批取消
  icon_audit_reject, // 审批驳回
}
const HeadContent = (props: { detail: processHistResponseParams }) => {
  const { detail } = props;
  return (
    <View style={headStyle.headContent}>
      <View style={[headStyle.line, headStyle.flex, headStyle.spaceBetween, headStyle.mb23, headStyle.pd20]}>
        <View style={headStyle.flex}>
          <View style={headStyle.headphoto}>
            <Text style={headStyle.headphotoTitle}>{detail?.creatorName?.slice(-2)}</Text>
          </View>
          <View>
            <Text style={headStyle.title}>{detail.creatorName}的申请单</Text>
            <Text style={headStyle.code}>{detail.businessNo}</Text>
          </View>
        </View>
        <Image style={headStyle.statusLogo} source={{ uri: images[businessCurrentStatus[Number(detail.businessCurrentStatus)]] }}></Image>
      </View>
      <View style={headStyle.mt28}>
        <View style={[headStyle.flex, headStyle.spaceBetween, headStyle.mb40]}>
          <Text style={headStyle.labelLeft}>业务类型</Text>
          <Text style={headStyle.labelRight}>{detail.businessUnitTypeLabel}</Text>
        </View>
        <View style={[headStyle.flex, headStyle.spaceBetween, headStyle.mb40]}>
          <Text style={headStyle.labelLeft}>所属组织</Text>
          <Text style={headStyle.labelRight}>{detail.creatorOrgName}</Text>
        </View>
      </View>
    </View>
  );
};

const PersonModal = ({ visible, setVisible, approvers }: { visible: boolean; approvers: string[]; setVisible: (val: boolean) => void }) => {
  return (
    <Modal autoAdjustPosition position="bottom" visible={visible} style={{ padding: 0, margin: 0 }}>
      <View style={flowStyle.modalContent}>
        {approvers.map((item) => (
          <View style={flowStyle.contentItem}>
            <View style={[flowStyle.headPortrait, flowStyle.modalPoseron]}>
              <Text style={[flowStyle.personName]}>{item?.slice(-2) ?? ''}</Text>
            </View>
            <Text numberOfLines={1} ellipsizeMode={'tail'}>
              {item}
            </Text>
          </View>
        ))}
      </View>
      <View style={flowStyle.cutOffRule}></View>
      <TouchableOpacity onPress={() => setVisible?.(false)}>
        <View style={flowStyle.ModalButton}>
          <Text style={flowStyle.ButtonText}>取消</Text>
        </View>
      </TouchableOpacity>
    </Modal>
  );
};
type paramsType = {
  businessId: string;
  businessNo: string;
  userName: string;
  tenant: string;
  tmsRole: string;
};
export default (props: NavigationScreenConfigProps<NavigationScreenProp<any, paramsType>>) => {
  const { businessId = '', businessNo = '', userName, tenant, tmsRole } = props?.navigation?.state?.params ?? {};
  const [detail, setDetail] = useState<processHistResponseParams>();
  const [visible, setVisible] = useState<boolean>(false);
  const [approvers, setapprovers] = useState<string[]>([]);
  const onTriggerPop = (val: boolean, approvers: string[]) => {
    setVisible(val);
    setapprovers(approvers);
  };
  // 获取用户信息
  useAutoPv(props, 'approval_process', { userName, tenant, tmsRole });
  useEffect(() => {
    const init = async () => {
      const { data }: { data: processHistResponseParams } = await Api.processHist({ businessId, businessNo });
      setDetail(data);
    };
    init();
  }, []);
  return (
    <View style={{ flex: 1 }}>
      <NavBar
        title="审批进度"
        leftClick={() => {
          props.navigation.goBack();
        }}
      />
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ minHeight: '100%' }}>
          <View style={headStyle.SafeAreaView}>
            {detail && (
              <>
                {/* 申请单头部 */}
                <HeadContent detail={detail} />
                {/* 流程组件 */}
                <PayRequsetFlow detail={detail} onTriggerPop={(val, approvers) => onTriggerPop(val, approvers)} />
                {/**多人审批弹窗 */}
                <PersonModal visible={visible} approvers={approvers} setVisible={(val) => setVisible(val)} />
              </>
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
};
