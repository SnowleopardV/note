import { StyleSheet, Dimensions } from 'react-native';
import { RNElementsUtil } from '@ymm/rn-elements';
const { autoFix } = RNElementsUtil;
export const headStyle = StyleSheet.create({
  SafeAreaView: {
    flex: 1,
    paddingLeft: autoFix(20),
    paddingRight: autoFix(20),
    height: '100%',

    // backgroundColor: '#fff',
  },
  headContent: {
    padding: autoFix(28),
    marginTop: autoFix(20),
    backgroundColor: '#fff',
  },
  pd20: {
    paddingVertical: autoFix(25),
  },
  line: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#F9F9F9',
  },
  flex: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },
  spaceBetween: { justifyContent: 'space-between' },
  headphoto: {
    width: autoFix(120),
    height: autoFix(120),
    marginRight: autoFix(30),
    borderRadius: autoFix(60),
    backgroundColor: '#4985ff',
  },
  headphotoTitle: {
    color: '#fff',
    textAlign: 'center',
    lineHeight: autoFix(115),
    fontSize: autoFix(40),
  },
  title: {
    fontSize: autoFix(32),
    color: '#525866',
    marginBottom: autoFix(12),
    width: autoFix(320),
  },
  code: {
    fontSize: autoFix(24),
    color: '#525866',
  },
  statusLogo: {
    width: autoFix(160),
    height: autoFix(125),
  },
  labelLeft: {
    fontSize: autoFix(30),
    color: '#999999',
  },
  labelRight: {
    fontSize: autoFix(30),
    color: '#333',
    flex: 1,
    textAlign: 'right',
  },
  mb23: {
    marginBottom: autoFix(23),
  },
  mb40: {
    marginBottom: autoFix(40),
  },
  mb20: {
    marginBottom: autoFix(20),
  },
  mt28: {
    marginTop: autoFix(28),
  },
  br15: {
    borderRadius: autoFix(15),
  },
});

export const flowStyle = StyleSheet.create({
  flow: {
    flex: 1,
  },
  title: {
    fontSize: autoFix(32),
    color: '#333',
    marginBottom: autoFix(28),
  },
  wh30: {
    width: autoFix(30),
    height: autoFix(30),
  },
  br15: {
    borderRadius: autoFix(15),
  },
  mb12: {
    marginBottom: autoFix(12),
  },
  wh60: {
    width: autoFix(60),
    height: autoFix(60),
  },
  br30: {
    borderRadius: autoFix(30),
  },
  statusIcon: {
    position: 'absolute',
    bottom: 0,
    right: autoFix(0),
  },
  being: {
    display: 'flex',
    flexDirection: 'row',
    backgroundColor: '#FAAD14',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingLeft: autoFix(5),
    paddingRight: autoFix(5),
  },
  beingBig: {
    backgroundColor: '#ddd',
    paddingLeft: autoFix(10),
    paddingRight: autoFix(10),
  },
  dot: {
    backgroundColor: '#fff',
    width: autoFix(4),
    height: autoFix(4),
    borderRadius: autoFix(2),
  },
  dotBig: {
    backgroundColor: '#fff',
    width: autoFix(8),
    height: autoFix(8),
    borderRadius: autoFix(4),
  },
  headPortrait: {
    width: autoFix(100),
    height: autoFix(100),
    borderRadius: autoFix(50),
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    backgroundColor: '#4985ff',
  },
  leftTitle: {
    display: 'flex',
    flexDirection: 'column',
    marginLeft: autoFix(20),
  },
  applyTitle: {
    marginBottom: autoFix(12),
    color: '#333',
    fontSize: autoFix(30),
  },
  statusTitle: {
    fontSize: autoFix(28),
  },
  time: {
    color: '#999999',
    fontSize: autoFix(26),
    marginTop: autoFix(4),
  },
  line: {
    width: autoFix(2),
    height: '100%',
    backgroundColor: '#ddd',
    position: 'absolute',
    top: 0,
    left: autoFix(49),
  },
  mtb10: {
    marginTop: autoFix(10),
    marginBottom: autoFix(10),
  },
  bottom: {
    paddingTop: autoFix(18),
    paddingBottom: autoFix(18),
    paddingRight: autoFix(16),
    backgroundColor: '#fff',
    marginLeft: autoFix(100),
  },
  bottomInfo: {
    backgroundColor: '#F9F9F9',
    paddingBottom: autoFix(10),
    paddingTop: autoFix(10),
    paddingLeft: autoFix(20),
    paddingRight: autoFix(20),
  },
  lh55: {
    lineHeight: autoFix(45),
  },
  mh53: {
    minHeight: autoFix(53),
  },
  ml18: {
    marginLeft: autoFix(20),
  },
  fz30: {
    fontSize: autoFix(30),
  },
  lineEnd: {
    width: autoFix(2),
    marginLeft: autoFix(29),
    backgroundColor: '#ddd',
    marginTop: autoFix(10),
    height: autoFix(53),
  },
  bubble: {
    backgroundColor: '#FF4D4F',
    paddingHorizontal: autoFix(8),
    borderRadius: autoFix(18),
    position: 'absolute',
    right: autoFix(-10),
    top: 0,
    color: '#fff',
    fontSize: autoFix(18),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#fff',
  },
  fs18: {
    fontSize: autoFix(18),
  },
  modalContent: {
    width: '100%',
    paddingHorizontal: autoFix(5),
    paddingTop: autoFix(36),
    backgroundColor: '#fff',
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
  },
  contentItem: {
    marginHorizontal: autoFix(20),
    marginBottom: autoFix(20),
    width: autoFix(120),
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    //height: autoFix(120),
  },
  modalPoseron: {
    width: autoFix(120),
    height: autoFix(120),
    borderRadius: autoFix(60),
    marginBottom: autoFix(10),
  },
  ModalButton: {
    width: '100%',
    height: autoFix(100),
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cutOffRule: {
    width: Dimensions.get('window').width,
    height: autoFix(20),
    backgroundColor: '#F7F7F7',
  },
  personName: {
    color: '#fff',
  },
  ButtonText: {
    fontSize: autoFix(34),
    color: '#333333',
    paddingHorizontal: autoFix(40),
    paddingVertical: autoFix(20),
  },
});

export const bottomBtnStyle = StyleSheet.create({
  bottomBtn: {
    height: autoFix(120),
  },
});
