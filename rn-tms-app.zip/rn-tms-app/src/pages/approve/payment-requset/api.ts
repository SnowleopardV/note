import server from '~/server';
// 文档 https://yapi.1111.com/#/project/2907/interface/api/241766
interface processHistRequsetParams {
  businessId: string;
  businessNo: string;
}
export interface taskInstances {
  assignee: string; // 处理人
  createTime: string; // 创建时间
  endTime: string; //结束时间
  deleteReason: string; //审批意见
  businessProcessingStatus: string; //处理状态  待处理，处理中，已处理
  nodeName: string; //节点名称
  comment?: string; // 备注
  nodeType: string; //节点类型
  optionType: string; //操作
  resType: string; // 审批结果
  flowAssignee?: {
    assigneeName: string; // 分配人/组织/角色 名称
  };
}
export interface processHistResponseParams {
  businessUnitTypeLabel: string; //业务类型
  creatorOrgName: string; // 组织名
  creatorName: string; // 创建人
  createTime: string; // 创建时间
  businessNo: string; //单号
  processInstanceStatus: number; //使用这个字段判断流程是否结束： 1:已撤销,2:已驳回, 3:发起审批,  4:审批中,5:审批通过
  businessCurrentStatus: string; // 发起审批1  审批中2 审批通过3 审批撤销4 审批驳回5
  taskInstances: [taskInstances];
}
const Api = {
  // 审批跟踪接口
  processHist(params: processHistRequsetParams): Promise<ResponseData<processHistResponseParams>> {
    return server({
      url: '/saas-tms-process-engine/yzgApp/process/hist',
      data: { ...params },
    });
  },
  // 用户信息
  getUserInfo() {
    return server({
      url: '/saas-permission-app/yzgApp/user/queryUserInfo',
      data: {},
    });
  },
};

export default Api;
