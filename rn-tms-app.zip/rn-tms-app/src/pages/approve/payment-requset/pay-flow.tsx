import React from 'react';
import { Text } from '@ymm/rn-elements';
import { flowStyle, headStyle } from './styles';
import { Image, View, TouchableOpacity } from 'react-native';
import images from '~public/static/images';
import { processHistResponseParams, taskInstances } from './api';
enum BeingType {
  small,
  big,
}
/**
 * 审批中状态标志
 */
const Being = (props: { type: BeingType; isGray?: boolean }): JSX.Element => {
  const { type, isGray } = props;
  var style: [object] = [{ ...flowStyle.wh30, ...flowStyle.being, ...flowStyle.br15 }];
  var dotKey = 'dot';
  if (type) {
    style = [{ ...flowStyle.wh60, ...flowStyle.being, ...flowStyle.br30, ...flowStyle.beingBig }];
    dotKey = 'dotBig';
  }
  if (isGray) {
    style.push({ backgroundColor: '#C4C4C4' });
  }
  return (
    <View style={style}>
      {Array.from({ length: 3 }).map((item) => (
        <View style={flowStyle[dotKey]}></View>
      ))}
    </View>
  );
};

enum businessProcessingStatus {
  '待处理' = 'pending',
  '处理中' = 'ing',
  '已处理' = 'processed',
  '发起申请' = 'processed',
  '已驳回' = 'processed',
  '已撤销' = 'processed',
}
enum textColor {
  '处理中' = '#FAAD14',
  '已撤销' = '#fa8414',
  '已驳回' = '#FF6969',
}
enum hiddenIcon {
  '已撤销' = '1',
  '已驳回' = '2',
}
/**
 * 生成流程状态图标
 * @param status 当前节点的状态 发起申请 待处理，处理中，已处理
 * @returns element
 */
const StatusIcon = (props: { status: string }): JSX.Element => {
  const { status } = props;
  return (
    <View style={flowStyle.statusIcon}>
      {status === 'processed' ? (
        <Image source={{ uri: images.icon_success_small }} style={flowStyle.wh30}></Image>
      ) : (
        <Being type={BeingType.small} isGray={status === 'pending' ? true : undefined} />
      )}
    </View>
  );
};
/**
 * 流程节点组件
 */
const FlowNodeItem = ({
  nodeItem,
  isNoneLine,
  onTriggerPop,
}: {
  nodeItem: taskInstances;
  isNoneLine: boolean;
  onTriggerPop?: (val: boolean, approvers: string[]) => void;
}) => {
  /* 开始节点 和结束节点 处理中不显示 */
  const { nodeType, businessProcessingStatus: buStatus } = nodeItem;
  const isNoneInfo = nodeType === 'StartEvent' || nodeType === 'EndEvent' || buStatus === '处理中';
  // 审批人数量
  const approvePerson: string[] = nodeItem?.assignee?.split(',') ?? [];
  const approvePersonNumber: number = approvePerson.length ?? 0;
  return (
    <View>
      <View style={[headStyle.flex, headStyle.spaceBetween, { alignItems: 'flex-start' }]}>
        <View style={headStyle.flex}>
          <TouchableOpacity
            activeOpacity={approvePerson.length > 1 ? 0.2 : 1}
            onPress={() => {
              if (approvePerson.length > 1) onTriggerPop?.(true, approvePerson);
            }}
          >
            <View style={flowStyle.headPortrait}>
              <Text style={[{ color: '#fff' }, flowStyle.fz30]}>{nodeItem?.assignee?.slice(-2) ?? ''}</Text>
              {!hiddenIcon[nodeItem.businessProcessingStatus] && (
                <StatusIcon status={businessProcessingStatus[nodeItem.businessProcessingStatus ?? '已处理']} />
              )}
              {approvePersonNumber > 1 && (
                <View style={flowStyle.bubble}>
                  <Text style={[{ color: '#fff' },flowStyle.fs18]}>等{approvePersonNumber}人</Text>
                </View>
              )}
            </View>
          </TouchableOpacity>
          <View style={flowStyle.leftTitle}>
            <Text style={flowStyle.applyTitle}>{nodeItem.nodeName}</Text>
            {nodeItem.nodeType !== 'EndEvent' && (
              <Text style={[flowStyle.statusTitle, { color: textColor[nodeItem.businessProcessingStatus] ?? '#52C41A' }]}>
                {nodeItem.businessProcessingStatus}
              </Text>
            )}
          </View>
        </View>
        {/* 正则截取日期 */}
        <Text style={flowStyle.time}>{/\d{4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2}/g.exec(nodeItem.endTime ?? '')?.[0] ?? ''}</Text>
      </View>
      <View style={[{ position: 'relative' }, flowStyle.mtb10, flowStyle.mh53]}>
        {!isNoneLine && <View style={flowStyle.line}></View>}
        {!isNoneInfo && (
          <View style={flowStyle.bottom}>
            <View style={flowStyle.bottomInfo}>
              <Text style={[flowStyle.lh55, { color: '#333' }]}>操作：{nodeItem.optionType + nodeItem.resType}</Text>
              {/* <Text style={[flowStyle.lh55, { color: '#333' }]}>审批结果：{nodeItem.resType}</Text> */}
              <Text style={[flowStyle.lh55, { color: '#333' }]}>审批意见：{nodeItem.comment}</Text>
            </View>
          </View>
        )}
      </View>
    </View>
  );
};
export default ({
  detail,
  onTriggerPop,
}: {
  detail: processHistResponseParams;
  onTriggerPop: (val: boolean, approvers: string[]) => void;
}) => {
  const { taskInstances, processInstanceStatus } = detail;
  return (
    <View style={[headStyle.headContent, flowStyle.flow]}>
      <Text style={flowStyle.title}>流程</Text>
      {taskInstances.map((item: taskInstances, index: number) => (
        <FlowNodeItem
          nodeItem={item}
          isNoneLine={index === taskInstances.length - 1 && processInstanceStatus !== 4}
          onTriggerPop={(val: boolean, approvers: string[]) => onTriggerPop(val, approvers)}
        />
      ))}
      {processInstanceStatus === 4 && (
        <View>
          <View>
            <View style={flowStyle.ml18}>
              <Being type={BeingType.big} />
              <View style={[flowStyle.lineEnd]}></View>
            </View>
          </View>
          <View style={[flowStyle.headPortrait, { backgroundColor: '#A2ADC7' }]}>
            <Text style={[{ color: '#fff' }, flowStyle.fz30]}>结束</Text>
          </View>
        </View>
      )}
    </View>
  );
};
