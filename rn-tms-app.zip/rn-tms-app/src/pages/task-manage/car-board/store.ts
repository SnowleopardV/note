import { observable, action } from 'mobx';
import BaseStore from '~/extends/BaseStore';
import server from '~/server';
import { MBLog, MBToast } from '@ymm/rn-lib';
import dayjs from 'dayjs';

interface CarBoardStateData {
  id: string;
}
interface CarBoardModuleData {
  emptyPageData: string;
}

interface CarBoardListType {
  id: number;
  taskId: string;
  taskNo: string;
  refindCarStatus: any;
  orgId: string;
  refindCarList: any;
}
interface getCarBoardListParamsType {
  taskNo?: string;
  orderNo?: string;
}

class CarBoardStore extends BaseStore<CarBoardModuleData, CarBoardStateData> {
  constructor(props: any) {
    super(props);
    this.init();
  }

  init = () => {
    this.saveModuleData({ emptyPageData: '暂无找车信息' });
  };

  @observable loading: boolean = true;
  @observable carBoardList: CarBoardListType[] = [];
  @observable getCarBoardListParams: getCarBoardListParamsType = {};

  // 获取找车看板列表
  @action
  getCarBoardList = async (params: any) => {
    this.getCarBoardListParams = { ...params };
    try {
      this.loading = true;
      const res = await server({
        url: '/saas-tms-trans/yzgApp/order/refindCarList',
        data: { ...params },
      });

      if (res.success) {
        console.log(res.data, 'res.data');
        this.carBoardList = res.data?.refindCarList ? res.data.refindCarList : [];
      }
    } catch (error) {
      MBLog.log({
        message: '获取找车看板列表失败',
        error: error,
      });
    } finally {
      this.loading = false;
    }
  };

  // 删除找车货源
  @action
  deleteCarBoard = async (params: any) => {
    try {
      const res = await server({
        url: '/saas-tms-trans/yzgApp/task/deleteTaskCargoRelation',
        data: { ...params },
      });

      if (res.success) {
        MBToast.show('删除成功');
      }
    } catch (error) {
      MBLog.log({
        message: '删除找车货源失败',
        error: error,
      });
    } finally {
      this.getCarBoardList({ ...this.getCarBoardListParams });
    }
  };

  @action
  reset = () => {
    this.carBoardList = [];
  };
}

export default CarBoardStore;
