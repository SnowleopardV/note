import React from 'react';
import { inject, observer } from 'mobx-react';
import { View, StyleSheet } from 'react-native';
import EmptyPage from '~/components/common/EmptyPage';
import { Modal } from '@ymm/rn-elements';
import CollapseItem from './CollapseItem';
import ModalCarBoardDetail from './ModalCarBoardDetail';

const Confirm = Modal.Confirm;

interface CarBoardContentProps {
  carBoardStore?: any;
}

@inject('carBoardStore')
@observer
class CarBoardContent extends React.Component<CarBoardContentProps, any> {
  constructor(props: CarBoardContentProps) {
    super(props);
  }

  state = {
    visible: false,
    detailData: {},
  };

  onActions = (e: any, item: any) => {
    switch (e.code) {
      case '1': // 删除
        Confirm({
          closable: false,
          headerLine: false,
          title: '删除货源',
          content: e.confirmContent,
          cancelText: '取消',
          confirmText: '确定',
          onConfirm: () => {
            this.onDeleteItem(item);
          },
        });
        break;
      default:
        break;
    }
  };

  onDeleteItem = (item: any) => {
    const {
      carBoardStore: { deleteCarBoard },
    } = this.props;
    deleteCarBoard({ id: item.id });
  };

  onClickDetailModal = (item: any) => {
    this.setState({ detailData: item });
    this.changeModalVisible();
  };

  changeModalVisible = () => {
    const { visible } = this.state;
    this.setState({ visible: !visible });
  };

  render() {
    const { visible, detailData } = this.state;
    const {
      carBoardStore: {
        carBoardList,
        moduleData: { emptyPageData, carBoardDetailList },
      },
    } = this.props;

    return (
      <View style={styles.listWrapper}>
        {!carBoardList.length && <EmptyPage errorData={{ msg: emptyPageData }} />}

        {carBoardList.map((item: any, index: number) => {
          return (
            <CollapseItem
              collapseItem={item}
              index={index}
              defaultCollapseActive={carBoardList.length === 1}
              onActions={this.onActions}
              onClickDetailModal={this.onClickDetailModal}
            />
          );
        })}

        <ModalCarBoardDetail
          visible={visible}
          onCancel={this.changeModalVisible}
          detailData={detailData}
          carBoardDetailList={carBoardDetailList}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  listWrapper: {
    flex: 1,
  },
});

export default CarBoardContent;
