import React from 'react';
import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { MBText, Splitline, Button } from '@ymm/rn-elements';
import TouchableThrottle from '~/components/TouchableThrottle';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Images from '~/../public/static/images';
import { debounce } from 'lodash';

interface CollapseItemProps {
  collapseItem: any;
  index: number;
  defaultCollapseActive: boolean;
  onActions: (e: any, item: any) => void;
  onClickDetailModal: (item: any) => void;
}

class CollapseItem extends React.Component<CollapseItemProps, any> {
  constructor(props: CollapseItemProps) {
    super(props);
  }

  state = {
    collapseActive: false,
  };

  componentDidMount() {
    this.setState({
      collapseActive: this.props.defaultCollapseActive,
    });
  }

  onCollapse = () => {
    const { collapseActive } = this.state;
    this.setState({
      collapseActive: !collapseActive,
    });
  };

  onDetail = (item: any) => {
    const { onClickDetailModal } = this.props;
    onClickDetailModal && onClickDetailModal(item);
  };

  debouncedOnDetail = debounce(this.onDetail, 200);

  render() {
    const { collapseActive } = this.state;
    const { collapseItem, index, onActions } = this.props;

    return (
      <View style={styles.itemCollapse} key={index}>
        <TouchableOpacity style={styles.itemCollapseHeader} activeOpacity={0.8} onPress={this.onCollapse}>
          <MBText>
            {collapseItem.taskNoDesc}:{collapseItem.taskNo}
          </MBText>
          <Image style={[styles.iconArrowUp, collapseActive ? styles.iconTransform : {}]} source={{ uri: Images.icon_arrow_up }}></Image>
        </TouchableOpacity>

        {collapseActive && (
          <View style={styles.itemCollapseContent}>
            {collapseItem.refindCarList.map((item: any, index: number) => {
              // carNo、driverName、driverPhone 均为空
              const carInfoNone = !item.carNo && !item.driverName && !item.driverPhone;
              // 正在找车
              const carFindingStatus = item.cargoStatus === 'PUBLISHING';

              return (
                <TouchableOpacity
                  key={index}
                  style={styles.touchableThrottle}
                  activeOpacity={0.8}
                  onPress={() => this.debouncedOnDetail(item)}
                >
                  <View style={[styles.itemInfoHeader, carFindingStatus ? styles.itemInfoHeaderDiff : {}]}>
                    <MBText style={styles.dispatcherName}>{item.dispatcherName}</MBText>
                    <View style={styles.itemStatusWrapper}>
                      {carFindingStatus && (
                        <View style={styles.findCarStatusWrapper}>
                          <Image style={styles.iconCarOrange} source={{ uri: Images.icon_car_orange }}></Image>
                          <MBText style={styles.findCarStatus}>正在找车</MBText>
                        </View>
                      )}
                      {!!item.refindCarStatus && <MBText style={styles.itemStatus}>{item.refindCarStatus}</MBText>}
                      {!!item.agreementStatusForList && <MBText style={styles.itemStatus}>{item.agreementStatusForList}</MBText>}
                    </View>
                  </View>
                  {!!item.mainCargo && (
                    <View style={styles.iconSelectedWrapper}>
                      <Image style={styles.iconSelected} source={Images.icon_selected_circle}></Image>
                    </View>
                  )}
                  <View style={styles.itemInfoContent}>
                    {!carInfoNone && (
                      <>
                        <MBText style={styles.itemCarDriverInfo}>{item.carNo}</MBText>
                        {!!item.driverName && <View style={styles.lineVertical}></View>}
                        <MBText style={styles.itemCarDriverInfo}>{item.driverName}</MBText>
                        {!!item.driverPhone && <View style={styles.lineVertical}></View>}
                        <MBText style={styles.itemCarDriverInfo}>{item.driverPhone}</MBText>
                      </>
                    )}
                  </View>
                  <Splitline />
                  <View style={styles.itemInfoFooter}>
                    <View style={styles.expectFreightWrapper}>
                      <MBText style={styles.expectFreightLable}>预计运费¥</MBText>
                      <MBText style={styles.expectFreight}>{item.expectFreight}</MBText>
                    </View>

                    <View style={styles.flexRow}>
                      {item.buttonList?.map((e: any, i: number) => (
                        <Button
                          key={i}
                          radius
                          style={styles.btnStyle}
                          size="sm"
                          onPress={() => {
                            onActions(e, item);
                          }}
                        >
                          <MBText style={styles.btnTextStyle}>{e.name}</MBText>
                        </Button>
                      ))}
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  itemCollapse: {
    marginTop: autoFix(20),
  },

  itemCollapseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: autoFix(32),
    paddingVertical: autoFix(28),
    borderRadius: autoFix(4),
    backgroundColor: '#FFFFFF',
  },

  itemCollapseContent: {
    position: 'relative',
    paddingHorizontal: autoFix(16),
    paddingBottom: autoFix(16),
    borderBottomLeftRadius: autoFix(4),
    borderBottomRightRadius: autoFix(4),
    backgroundColor: '#EBEBEB',
  },

  touchableThrottle: {
    backgroundColor: '#fff',
    marginTop: autoFix(16),
    borderRadius: autoFix(4),
  },

  itemInfoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: autoFix(34),
    paddingRight: autoFix(16),
    paddingBottom: autoFix(16),
    paddingLeft: autoFix(32),
    borderTopLeftRadius: autoFix(4),
    borderTopRightRadius: autoFix(4),
  },

  itemInfoHeaderDiff: {
    paddingBottom: autoFix(34),
  },

  dispatcherName: {
    fontSize: autoFix(32),
    fontWeight: 'bold',
  },

  itemStatusWrapper: {
    flexDirection: 'row',
  },

  itemStatus: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: autoFix(6),
    paddingVertical: autoFix(4),
    borderRadius: autoFix(6),
    backgroundColor: 'rgba(72, 133, 255, .15)',
    color: '#4885FF',
    fontSize: autoFix(22),
    marginLeft: autoFix(10),
  },

  iconCarOrange: {
    width: autoFix(28),
    height: autoFix(28),
  },

  findCarStatusWrapper: {
    paddingHorizontal: autoFix(6),
    paddingVertical: autoFix(4),
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF8EC',
    borderRadius: autoFix(6),
    marginLeft: autoFix(10),
  },

  findCarStatus: {
    backgroundColor: '#FFF8EC',
    color: '#F76A19',
    fontSize: autoFix(22),
    marginLeft: autoFix(2),
  },

  itemInfoContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    paddingTop: autoFix(16),
    paddingRight: autoFix(16),
    paddingBottom: autoFix(30),
    paddingLeft: autoFix(32),
  },

  itemCarDriverInfo: {
    color: '#999999',
    fontSize: autoFix(28),
  },

  lineVertical: {
    width: autoFix(1),
    height: autoFix(24),
    backgroundColor: '#E8E8E8',
    marginHorizontal: autoFix(8),
  },

  itemInfoFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingVertical: autoFix(22),
    paddingRight: autoFix(16),
    paddingLeft: autoFix(32),
    borderBottomLeftRadius: autoFix(4),
    borderBottomRightRadius: autoFix(4),
  },

  expectFreightWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },

  expectFreightLable: {
    color: '#666666',
    fontSize: autoFix(28),
    paddingBottom: autoFix(6),
  },

  expectFreight: {
    color: '#333333',
    fontSize: autoFix(48),
    fontWeight: 'bold',
  },

  iconSelectedWrapper: {
    position: 'absolute',
    top: 0,
    right: autoFix(6),
  },

  iconSelected: {
    width: autoFix(192),
    height: autoFix(150),
  },

  iconArrowUp: {
    width: autoFix(26),
    height: autoFix(16),
  },

  iconTransform: {
    transform: [{ rotate: '180deg' }],
  },

  btnStyle: {
    height: autoFix(60),
    paddingHorizontal: autoFix(32),
    paddingVertical: autoFix(10),
    borderColor: '#4885FF',
    marginLeft: autoFix(10),
  },

  btnTextStyle: {
    fontSize: autoFix(28),
    color: '#4885FF',
  },

  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default CollapseItem;
