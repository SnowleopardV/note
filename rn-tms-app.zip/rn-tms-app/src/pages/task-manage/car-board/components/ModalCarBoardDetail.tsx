import React from 'react';
import { ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { Modal, MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Cell from '~/components/common/Cell';
import EmptyPage from '~/components/common/EmptyPage';

const ModalCarBoardDetail = (props: any) => {
  const { visible, onCancel, detailData } = props;
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onCancel()}>
        <View style={styles.confirmText}>
          <MBText color="primary" size="md">
            完成
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  const contentList = detailData?.contentList?.sort((a: any, b: any) => a.seq - b.seq);
  return (
    <Modal
      headerRight={rightElement()}
      title="车辆详情"
      position="bottom"
      visible={visible}
      autoAdjustPosition={true}
      headerLine={false}
      onCancel={onCancel}
      onMaskClose={onCancel}
      onRequestClose={onCancel}
      contentStyle={styles.modalContentStyle}
    >
      <ScrollView alwaysBounceVertical={false} style={{ maxHeight: autoFix(900), width: '100%' }} contentContainerStyle={styles.container}>
        {contentList?.map((item: any, index: number) => {
          return (
            <Cell
              key={index}
              title={item.label}
              align="right"
              value={item.value || '-'}
              isLink={false}
              style={styles.cellStyle}
              contentStyle={styles.itemStyle}
              titleStyle={styles.itemLable}
              valueStyle={styles.itemValue}
            />
          );
        }) || (
          <EmptyPage
            style={{ paddingTop: autoFix(50), paddingBottom: autoFix(50), backgroundColor: '#fff' }}
            errorData={{ msg: '暂无数据' }}
          />
        )}
      </ScrollView>
    </Modal>
  );
};

const styles = StyleSheet.create<any>({
  modalContentStyle: {
    paddingHorizontal: 0,
  },

  container: {
    width: '100%',
    paddingBottom: autoFix(32),
  },

  cellStyle: {
    paddingLeft: autoFix(36),
  },

  itemStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: autoFix(11),
  },

  itemLable: {
    color: '#666666',
    fontWeight: 'bold',
    fontSize: autoFix(30),
  },

  itemValue: {
    flex: 1,
    color: '#666666',
    fontSize: autoFix(30),
  },
});

export default ModalCarBoardDetail;
