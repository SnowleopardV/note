import * as React from 'react';
import { View, StyleSheet, ScrollView, SafeAreaView, TouchableOpacity, Image, Platform, BackHandler } from 'react-native';
import { LayProvider, MBText, Modal, RNElementsUtil } from '@ymm/rn-elements';
import { inject, observer, Provider } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import CarBoardContent from './components/CarBoardContent';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import CarBoardStore from './store';
import images from '~public/static/images';

interface CarBoardIndexProps {
  navigation: any;
}

interface CarBoardIndexState {
  title: string;
}

@observer
class CarBoard extends React.Component<CarBoardIndexProps, CarBoardIndexState> {
  carBoardStore: CarBoardStore;
  backHandleListener: any;
  constructor(props: CarBoardIndexProps) {
    super(props);
    this.carBoardStore = new CarBoardStore(props);
    this.state = {
      title: '找车看板',
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  componentDidMount() {
    const { getCarBoardList } = this.carBoardStore;
    const { taskNo, orderNo, id, type } = this.props.navigation?.state?.params ?? {};
    // 获取找车看板列表
    if (taskNo || orderNo) {
      getCarBoardList({ taskNo: taskNo || null, orderNo: orderNo || null });
    } else {
      getCarBoardList({ id: id, type: type }); // type: 1 运单 2任务单
    }
  }

  onLeftClick = () => {
    const { navigation } = this.props;
    const { reset } = this.carBoardStore;
    reset();
    navigation.goBack();
  };

  render(): JSX.Element {
    const { title } = this.state;
    const { loading, carBoardList } = this.carBoardStore;

    return (
      <Provider carBoardStore={this.carBoardStore}>
        <View style={{ flex: 1 }}>
          <NavBar title={title} leftClick={this.onLeftClick} />
          {carBoardList.length > 1 && (
            <View style={{ backgroundColor: '#FFFBE6', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', height: 26 }}>
              <Image
                style={{ height: RNElementsUtil.autoFix(30), width: RNElementsUtil.autoFix(30), paddingHorizontal: 5 }}
                source={images.icon_warning_yellow}
              />
              <MBText size="xs" color="#FFBB44" style={{ marginLeft: 5 }}>
                如需修改关联的平台订单请前往运掌柜PC端操作
              </MBText>
            </View>
          )}
          {!loading ? (
            <View style={styles.container}>
              <SafeAreaView>
                <ScrollView
                  keyboardShouldPersistTaps="handled"
                  showsHorizontalScrollIndicator={false}
                  showsVerticalScrollIndicator={false}
                  alwaysBounceVertical={false}
                >
                  <CarBoardContent />
                </ScrollView>
              </SafeAreaView>
            </View>
          ) : null}
        </View>
      </Provider>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F7F7F7',
    paddingHorizontal: autoFix(20),
    paddingBottom: autoFix(20),
  },
});

export default CarBoard;
