import taskManageStore from '../store';
import carBoardStore from '../car-board/store';

const stores = {
  taskManageStore,
  carBoardStore,
};

export default stores;
