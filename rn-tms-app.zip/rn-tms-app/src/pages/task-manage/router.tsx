import React, { Component } from 'react';
import { Provider } from 'mobx-react';
import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import TaskList from './list';
import TaskDetail from './detail';
import CarBoardPage from './car-board';
import PaymentApplication from './payment-application';
import SuccessPaymentApplication from './payment-application/components/SuccessPaymentApplication';
import PaymentApprove from '../approve/payment-approve';
import PaymentRequset from '../approve/payment-requset';
import stores from './stores';
import { LayProvider } from '@ymm/rn-elements';

export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        TaskList: {
          screen: TaskList,
          navigationOptions: () => ({
            header: null,
          }),
        },
        TaskDetail: {
          screen: TaskDetail,
          navigationOptions: () => ({
            header: null,
          }),
        },
        CarBoard: {
          screen: CarBoardPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        PaymentApplication: {
          screen: PaymentApplication,
          navigationOptions: () => ({
            header: null,
          }),
        },
        SuccessPaymentApplication: {
          screen: SuccessPaymentApplication,
          navigationOptions: () => ({
            header: null,
          }),
        },
        PaymentApprove: {
          screen: PaymentApprove,
          navigationOptions: () => ({
            header: null,
          }),
        },
        PaymentRequset: {
          screen: PaymentRequset,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: string) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}

// const RootStack = createStackNavigatorCompat({
//   TaskList: {
//     screen: TaskList,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   TaskDetail: {
//     screen: TaskDetail,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   CarBoard: {
//     screen: CarBoardPage,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   PaymentApplication: {
//     screen: PaymentApplication,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   SuccessPaymentApplication: {
//     screen: SuccessPaymentApplication,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   PaymentApprove: {
//     screen: PaymentApprove,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   PaymentRequset: {
//     screen: PaymentRequset,
//     navigationOptions: () => ({
//       header: null,
//     }),
//   },
//   // initialRouteName: { screen: 'TaskList' },
//   initialRouteName: initialRouteName,
// });

/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 列表
   */
  TASK_LIST = 'TaskList',

  /**
   * 详情
   */
  TASK_DETAIL = 'TaskDetail',
}

// export default class StickerPageRouter extends Component<any, any> {
//   constructor(props: any) {
//     super(props);
//   }

//   render() {
//     const App = createAppContainerCompat(RootStack);
//     return (
//       <Provider {...stores}>
//         <App screenProps={this.props} />
//       </Provider>
//     );
//   }
// }
