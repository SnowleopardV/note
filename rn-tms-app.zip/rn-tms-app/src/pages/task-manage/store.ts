import { observable, action, computed } from 'mobx';
import BaseStore from '~/extends/BaseStore';
import NativeBridge from '~/extends/NativeBridge';
import server from '~/server';
import keyMap from '~/pages/dispatch/keyMap';
import threeTimeformat from '~/extends/threeTimeformat';
import dayjs from 'dayjs';
import { MBToast } from '@ymm/rn-lib';
import { NavigationScreenProp } from 'react-navigation';
export interface cargoParamsProps {
  customerName: string;
  shipperContactAddress: string;
  consigneeContactAddress: string;
}

interface TaskManageStoreModuleData {
  selectPlaceholder: string;
  inputPlaceholder: string;
}
interface TaskManageStoreStateData {
  carrierId: number | null;
  carrierName: string;
  carId: string;
  carNo: string;
  carType: number | null;
  carLength: number | null;
  driverId: number | null;
  driverName: string;
  driverPhone: string;
}

class TaskManageStore extends BaseStore<TaskManageStoreModuleData, TaskManageStoreStateData> {
  now = dayjs();
  constructor(props: any) {
    super(props);
    this.init();
  }

  init = () => {
    this.saveStateData({
      carrierId: null,
      carrierName: '',
      carId: '',
      carNo: '',
      carType: null,
      carLength: null,
      driverId: null,
      driverName: '',
      driverPhone: '',
    });

    this.saveModuleData({
      selectPlaceholder: '请选择',
      inputPlaceholder: '请输入',
    });
  };

  @observable loaded = false; // 加载中
  @observable detail = {};
  @observable defaultEstimateOutsetTime = {};
  @observable defaultEstimateArrivedTime = {};
  @observable defaultCarrierItem = {};
  @observable defaultVehicleItem = {};
  @observable defaultDriverItem = {};
  @observable carrierList = [];
  @observable truckList = [];
  @observable driverList = [];
  @observable isDepartureError = false;
  @observable isArriveError = false;
  @observable departureVisible = false; // 发车
  @observable arriveVisible = false; // 到达
  @observable departureListVisible = false; // 发车（列表）
  @observable arriveListVisible = false; // 到达（列表）
  @observable truckSourceArr = [null, 1, 5, 4]; // 车辆来源 1：自有 4：外调 5：承运商
  @observable driverTypeArr = [null, 11, 13, 12]; // 司机类型 11：自有 12：外调 13：承运商
  @observable isAddCarrier = false; // 是否可以添加承运商
  @observable isAddVehicle = false; // 是否可以添加车辆
  @observable isAddDrive = false; // 是否可以添加司机
  @observable unsaveDefaultVehicleItem = {}; // 选择承运商后的一个月内最近的车辆
  @observable unsaveDefaultDriverItem = {}; // 选择承运商后的一个月内最近的司机
  @observable refreshTabList = [false, false, false, false, false]; // 切换tab 后需要单独刷新的tab
  @observable applyNoList = [];

  // 获取任务详情
  getTaskDetail = async (data: any, navigation: NavigationScreenProp<{ refresh: () => void }>) => {
    try {
      const res = await server({
        url: '/saas-tms-trans/yzgApp/task/detail',
        data,
      });
      this.loaded = true;
      if (res.success && res.data) {
        this.detail = res.data;
        const {
          outsetTime,
          arrivedTime,
          carrierId,
          carrierName,
          carId,
          carNo,
          carType,
          carLength,
          majorityDriverId,
          majorityDriverName,
          majorityDriverPhone,
          driverId,
          driverName,
          driverPhone,
          carDisplayValue,
          driverDisplayValue,
          dispatcherMode,
          invoiceFlag,
          payApplyList,
          dispatcherListInfo,
        } = res.data;
        this.applyNoList = payApplyList;
        let handleOutsetTime = null;
        let handleArrivedTime = null;

        // 外调车开票或平台车日期7天范围，否则一个月
        if ((dispatcherMode === '3' && invoiceFlag === '1') || dispatcherMode === '4') {
          // 发车时间：接口获得发车时间在（当前-未来7天）之内，取接口发车时间值，否则取当前时间
          if (
            outsetTime &&
            this.now.hour(0).valueOf() <= outsetTime.endTimestamp &&
            outsetTime.endTimestamp <= this.now.add(7, 'day').hour(0).valueOf()
          ) {
            handleOutsetTime = outsetTime;
          } else {
            handleOutsetTime = threeTimeformat(null);
          }
          // 到达时间：接口获得到达时间在（当前-未来14天）之内，取接口到达时间值，否则取当前时间
          if (
            arrivedTime &&
            this.now.hour(0).valueOf() <= arrivedTime.endTimestamp &&
            arrivedTime.endTimestamp <= this.now.add(14, 'day').hour(0).valueOf()
          ) {
            handleArrivedTime = arrivedTime;
          } else {
            handleArrivedTime = threeTimeformat(null);
          }
        } else {
          // 发车时间：接口获得发车时间在（过去30天-未来30天）之内，取接口发车时间值，否则取当前时间
          if (
            outsetTime &&
            this.now.subtract(30, 'day').hour(0).valueOf() <= outsetTime.endTimestamp &&
            outsetTime.endTimestamp <= this.now.add(30, 'day').hour(0).valueOf()
          ) {
            handleOutsetTime = outsetTime;
          } else {
            handleOutsetTime = threeTimeformat(null);
          }
          // 到达时间：接口获得到达时间在（过去30天-未来37天）之内，取接口到达时间值，否则取当前时间
          if (
            arrivedTime &&
            this.now.subtract(30, 'day').hour(0).valueOf() <= arrivedTime.endTimestamp &&
            arrivedTime.endTimestamp <= this.now.add(37, 'day').hour(0).valueOf()
          ) {
            handleArrivedTime = arrivedTime;
          } else {
            handleArrivedTime = threeTimeformat(null);
          }
        }

        this.defaultEstimateOutsetTime = handleOutsetTime;
        this.defaultEstimateArrivedTime = handleArrivedTime;

        this.defaultCarrierItem = {
          carrierId,
          carrierName,
        };

        this.defaultVehicleItem = {
          carId,
          carNo,
          carType,
          carLength,
          displayValue: carDisplayValue,
          majorityDriverId,
          majorityDriverName,
          majorityDriverPhone,
        };

        this.defaultDriverItem = {
          driverId,
          driverName,
          driverPhone,
          displayValue: driverDisplayValue,
        };
      }
    } catch (error) {
      console.log(error, '----------errr----');
      const code = (error as { code: string }).code;
      if (code === '900003') {
        navigation.goBack();
        navigation.state?.params?.refresh();
      }
    }
  };

  // 承运商
  getCarrierList = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/capacity/queryCarrierList',
          data: {},
        },
        { toastError: false, showLoading: false }
      );

      if (res.success) {
        this.isAddCarrier = res.data?.enableCreation;
        if (res.data?.carrierList) {
          this.carrierList = res.data.carrierList;
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 承运车辆
  getTruckList = async (params: any) => {
    try {
      const {
        truckSourceArr,
        detail: { dispatcherMode, carrierId, carrierName },
      } = this;

      let handleDispatcherMode = dispatcherMode;
      let handleCarrierId = carrierId;
      let handleCarrierName = carrierName;

      if (params) {
        handleDispatcherMode = params.dispatcherMode;
        handleCarrierId = params.carrierId;
        handleCarrierName = params.carrierName;
      }

      const data = {
        truckSource: handleDispatcherMode ? truckSourceArr[handleDispatcherMode] : null,
        carrierId: handleCarrierId,
        carrierName: handleCarrierName,
      };

      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/capacity/queryTruckList',
          data,
        },
        { toastError: false, showLoading: false }
      );
      if (res.success) {
        this.isAddVehicle = res.data?.enableCreation;
        if (res.data?.truckList) {
          this.truckList = res.data.truckList;
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 承运司机
  getDriverlist = async (params: any) => {
    try {
      const {
        driverTypeArr,
        detail: { dispatcherMode, carrierId, carrierName },
      } = this;

      let handleDispatcherMode = dispatcherMode;
      let handleCarrierId = carrierId;
      let handleCarrierName = carrierName;

      if (params) {
        handleDispatcherMode = params.dispatcherMode;
        handleCarrierId = params.carrierId;
        handleCarrierName = params.carrierName;
      }

      const data = {
        driverType: handleDispatcherMode ? driverTypeArr[handleDispatcherMode] : null,
        carrierId: handleCarrierId,
        carrierName: handleCarrierName,
      };

      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/capacity/queryDriverList',
          data,
        },
        { toastError: false, showLoading: false }
      );
      if (res.success) {
        this.isAddDrive = res.data?.enableCreation;
        if (res.data?.driverList) {
          this.driverList = res.data.driverList;
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 获取车长
  @action
  getTruckLengthList = async (data: any) => {
    try {
      const url = '/saas-tms-trans/yzgApp/capacity/getTruckLengths';
      const res = await server({ url, data: data }, { showLoading: false });

      if (res.success && res.data) {
        const carLength: any = {};
        for (const item of res.data) {
          carLength[item.lengthId] = item.lengthName;
        }
        keyMap.carLengthList = res.data; // 暂存一份列表， 用于新增车辆时使用
        keyMap.carLength = carLength;
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 获取车型
  @action
  getTruckTypeList = async (data: any) => {
    try {
      const url = '/saas-tms-trans/yzgApp/capacity/getTruckTypes';
      const res = await server({ url, data }, { showLoading: false });

      if (res.success && res.data) {
        const carType: any = {};
        for (const item of res.data) {
          carType[item.typeId] = item.typeName;
        }
        keyMap.carTypeList = res.data; // 暂存一份列表， 用于新增车辆时使用
        keyMap.carType = carType;
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 最近一次指派承运商的信息
  @action
  getLastCarrierTaskInfo = async (params: any) => {
    try {
      const url = '/saas-tms-trans/yzgApp/task/lastCarrierTaskInfo';
      const res = await server({ url, data: params }, { showLoading: false });

      if (res.success && res.data) {
        const { truckInfo, driverInfo } = res.data;
        if (truckInfo) {
          const { carId, carNo, displayValue, majorityDriverId, majorityDriverName, majorityDriverPhone } = truckInfo;
          this.unsaveDefaultVehicleItem = {
            carId,
            carNo,
            displayValue: displayValue || carNo,
            majorityDriverId,
            majorityDriverName,
            majorityDriverPhone,
          };
        }

        if (driverInfo) {
          const { driverId, driverName, driverPhone, displayValue } = driverInfo;
          this.unsaveDefaultDriverItem = {
            driverId,
            driverName,
            driverPhone,
            displayValue: displayValue || `${driverName ? driverName + '-' : ''}${driverPhone ? driverPhone : ''}`,
          };
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 发车
  @action
  postTaskOutset = async (params: any, callback: () => void) => {
    if (this.validateDeparture(params)) {
      const { dispatcherMode, ...restParams } = params;
      try {
        const url = '/saas-tms-trans/yzgApp/task/outset';
        const res = await server({ url, data: restParams });
        if (res.success) {
          NativeBridge.toast('发车成功');
          callback && callback();
        }
      } catch (error) {
        console.log(error);
      }
      this.setDepartureError(false);
    } else {
      this.setDepartureError(true);
    }
  };

  // 到达
  @action
  postTaskArrive = async (params: any, callback: () => void) => {
    if (this.validateArrive(params)) {
      try {
        const url = '/saas-tms-trans/yzgApp/task/arrived';
        const res = await server({ url, data: params });
        if (res.success) {
          NativeBridge.toast('到达成功');
          callback && callback();
        }
      } catch (error) {
        console.log(error);
      }
      this.setArriveError(false);
    } else {
      this.setArriveError(true);
    }
  };

  // 取消发车
  @action
  postRevokeOutset = async (params: any, callback: () => void) => {
    try {
      const url = '/saas-tms-trans/yzgApp/task/revokeOutset';
      const res = await server({ url, data: params });
      if (res.success && res.code === '10000') {
        NativeBridge.toast('取消发车成功');
        callback && callback();
        this.refreshTabList[0] = true;
        this.refreshTabList[2] = true;
        this.refreshTabList[3] = true;
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 取消到达
  @action
  postRevokeArrived = async (params: any, callback: () => void) => {
    try {
      const url = '/saas-tms-trans/yzgApp/task/revokeArrived';
      const res = await server({ url, data: params });
      if (res.success && res.code === '10000') {
        NativeBridge.toast('取消到达成功');
        callback && callback();
        this.refreshTabList[0] = true;
        this.refreshTabList[3] = true;
        this.refreshTabList[4] = true;
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 删除
  @action
  postTaskDelete = async (params: any, callback: () => void) => {
    try {
      const url = '/saas-tms-trans/yzgApp/task/revoke';
      const res = await server({ url, data: params });
      if (res.success) {
        NativeBridge.toast('删除成功');
        callback && callback();
      }
    } catch (error) {
      console.log(error);
    }
  };

  // 发车弹窗确认/取消
  @action
  changeDepartureModalVisible = (type: string) => {
    if (type && type === 'list') {
      this.departureListVisible = !this.departureListVisible;
    } else {
      this.departureVisible = !this.departureVisible;
    }

    this.setDepartureError(false);
  };

  // 到达弹窗确认/取消
  changeArriveModalVisible = (type: string) => {
    if (type && type === 'list') {
      this.arriveListVisible = !this.arriveListVisible;
    } else {
      this.arriveVisible = !this.arriveVisible;
    }
    this.setArriveError(false);
  };

  // 设置初始校验值
  @action
  setDepartureError = (value: boolean) => {
    this.isDepartureError = value;
  };

  @action
  setArriveError = (value: boolean) => {
    this.isArriveError = value;
  };

  /**
   * 校验规则 发车时间，承运商，承运车辆，承运司机必填
   * @returns
   */
  validateDeparture = (params: any) => {
    const { estimateOutsetTime, carrierName, driverName, carNo, dispatcherMode } = params;

    const flag = dispatcherMode === '2' ? !!estimateOutsetTime && !!carrierName : !!estimateOutsetTime && !!carNo && !!driverName;

    if (flag) {
      return true;
    }

    return false;
  };

  /**
   * 校验规则 发车时间，承运司机必填
   * @returns
   */
  validateArrive = (params: any) => {
    if (params.estimateArrivedTime) {
      return true;
    }
    return false;
  };
}

const taskManageStore = new TaskManageStore();

export default taskManageStore;
