// 对应的状态码枚举
export const STATUS_MAP = {
  LOOKING_CAR: '找车中',
  WAIT_FOR_DEPART: '待发车',
  DEPARTED: '在途中',
  ARRIVED: '已到达',
};

// 时间选择弹窗title枚举
export const MODAL_TITLE_MAP = {
  DEPARTURE: '请选择发车时间',
  ARRIVAL: '请选择到达时间',
};

// 操作类型文案枚举
export const ACTION_MAP = {
  delete: { title: '删除该任务单？', content: '删除后可在运单里重新调度', toast: '删除成功' },
  unbind: { title: '解绑平台订单', content: '解绑平台订单后，将自动为您删除该运输任务，平台订单请前往满帮平台发起取消', toast: '解绑成功' },
};

export const MODAL_LEVEL1_TITLE_MAP = {
  1: '发车',
  2: '到达',
  3: '取消发车',
  4: '取消到达',
  5: '修改',
  6: '删除',
};

export const MODAL_LEVEL2_TITLE_MAP = {
  1: '请选择发车时间',
  2: '请选择到达时间',
  3: '请选择取消发车时间',
  4: '请选择取消到达时间',
  5: '请选择修改时间',
  6: '请选择删除时间',
};
