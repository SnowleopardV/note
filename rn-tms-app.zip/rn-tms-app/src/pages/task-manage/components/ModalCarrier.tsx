import React, { useState, useEffect } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { Flex, Modal, Selector, MBText, Button } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

const FlexItem = Flex.Item;

const ModalCarrier = (props: any) => {
  const { visible, onConfirm, onCancel, carrierList, defaultCarrierItem, dispatcherMode, isAddCarrier, onCancelModalDeparture } = props;

  const [carrierItem, setCarrierItem] = useState(defaultCarrierItem);
  const [lastItemIndex, setLastItemIndex] = useState(0);

  useEffect(() => {
    const carrierId = defaultCarrierItem.carrierId;
    const carrierName = defaultCarrierItem.carrierName;

    setCarrierItem(() => {
      const lastVehicleItemArr = carrierList.filter((item: any) => item.carrierId === defaultCarrierItem.carrierId);
      return lastVehicleItemArr.length ? lastVehicleItemArr[0] : carrierList.length ? carrierList[0] : {};
    });

    carrierList.forEach((item: any, index: number) => {
      if (item.carrierId === carrierId || item.carrierName === carrierName) {
        setLastItemIndex(index);
      }
    });
  }, [carrierList, defaultCarrierItem.carrierId, defaultCarrierItem.carrierName]);

  const onModalConfirm = () => {
    onConfirm && onConfirm(carrierItem);
  };

  const onItemChange = (value: any) => {
    setCarrierItem(value);
  };

  const addCarrier = () => {
    if (!isAddCarrier) return NativeBridge.toast('您还没有#新增承运商权限#，请联系管理员开通');

    // 关闭当前弹窗
    onCancel && onCancel();
    // 关闭发车弹窗
    onCancelModalDeparture && onCancelModalDeparture();

    MBBridge.app.base.openSchemeForResult({ schemeUrl: 'ymm://rn.tms/newcarrier' }).then((res: any) => {
      if (res.data) {
        let handleData;
        try {
          handleData = JSON.parse(res.data);
        } catch (error) {
          handleData = res.data;
        }

        const { carrierId, carrierName } = handleData;
        const data = {
          carrierId,
          carrierName,
        };
        // 新增并使用等同于选择承运商
        onConfirm && onConfirm(data, 'addCarrier');
      }
    });
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <View>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请选择承运商"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onCancel}
        onMaskClose={onCancel}
        onRequestClose={onCancel}
        contentStyle={[styles.modalContentStyle, dispatcherMode === '2' && { height: autoFix(630) }]}
      >
        <Flex direction="row" justify="center" flex={1}>
          {carrierList.length ? (
            <FlexItem>
              <Selector
                scaleFont={true}
                value={lastItemIndex}
                rowTitle="carrierName"
                list={carrierList}
                onChange={(position, value) => {
                  onItemChange(value);
                }}
              />
            </FlexItem>
          ) : (
            <MBText color="#999999">无承运商信息，请新增</MBText>
          )}
        </Flex>
        <Button type="bordered" size="xs" style={[styles.btn, !isAddCarrier && { opacity: 0.3 }]} onPress={addCarrier}>
          新增承运商
        </Button>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  modalContentStyle: {
    height: autoFix(580),
    paddingTop: autoFix(40),
  },

  btn: {
    marginBottom: autoFix(60),
    width: autoFix(358),
    height: autoFix(80),
    borderRadius: autoFix(50),
  },
});

export default ModalCarrier;
