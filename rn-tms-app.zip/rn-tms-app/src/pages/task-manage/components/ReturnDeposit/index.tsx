import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity, TouchableHighlight, ScrollView, Platform } from 'react-native';
import { Modal, Whitespace, MBText } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import verification from '~/extends/verification';
import TipsText from '~/components/TipsText';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import images from '~public/static/images';
import Api from '../../api';
import filterFormat from '~/extends/filterFormat';
import { MBToast } from '@ymm/rn-lib';

// 退还订金
interface Props {
  visible?: boolean;
  data: any;
  onCancel: () => void;
  onConfirm?: () => void;
}
type apiReasonData = {
  refundDepositReasons: any[]; // 原因列表
  fullDeposit: number; // 要么区间，要么全额
  minDeposit: number;
  maxDeposit: number;
};
type dataForm = {
  refundReasonKey: number;
  refundReasonValue: string;
  refundAmount: number;
  mybOrderId: string;
};

const depositTips = {
  '10': '订金此时在平台监管账户中，提交成功后，订金将会从平台监管账户中退还给司机',
  '1': '订金此时在您的钱包余额里，提交成功后，订金将会从您的钱包账户退还给司机',
  '15': '订金此时在您的钱包余额里，提交成功后，订金将会从您的钱包账户退还给司机',
};
export const api_depositRefundReason = async (mybOrderId: string) => {
  const res = await Api.depositRefundReason({ mybOrderId: mybOrderId });
  if (res.data) {
    const data: apiReasonData = res.data;
    return data;
  } else {
    return null;
  }
};

export default class ReturnDeposit extends React.Component<Props, any> {
  showhandleConfirm: any;
  constructor(props: any) {
    super(props);
    this.state = {
      isRulesTips: false, // 是否开启验证提醒
      refundAmount: '', // 退还金额
      refundReasonValue: '', //
      refundReasonKey: '', //
      mybOrderId: null,
      showReasonModal: false, // 显示退还订金原因列表弹窗
      refundReasonList: [],
      reasonListError: '暂无数据，请稍后再试',
      fullDeposit: null, // 要么区间，要么全额
      minDeposit: null,
      maxDeposit: null,
      depositStatus: null,
    };
  }
  componentDidMount() {
    const { refundDepositReasons, mybOrderId, fullDeposit, minDeposit, maxDeposit, depositStatus } = this.props.data || {};
    this.setState({
      refundReasonList: refundDepositReasons || [],
      refundAmount: filterFormat.moneyDecFormat(fullDeposit),
      mybOrderId: mybOrderId,
      fullDeposit: fullDeposit,
      minDeposit: filterFormat.moneyDecFormat(minDeposit),
      maxDeposit: filterFormat.moneyDecFormat(maxDeposit),
      depositStatus,
    });
  }
  handleConfirm = () => {
    console.log('点击确定');
    if (this.showhandleConfirm) {
      return;
    }
    this.showhandleConfirm = true;
    this.setState({ isRulesTips: true });
    const { refundReasonValue, minDeposit, maxDeposit, refundAmount, fullDeposit } = this.state;
    if (!refundAmount) {
      MBToast.show(`退款金额需要在${minDeposit}-${maxDeposit}元之间`);
      this.showhandleConfirm = false;
      return;
    } else if (!!minDeposit && !!maxDeposit && (Number(refundAmount) < Number(minDeposit) || Number(refundAmount) > Number(maxDeposit))) {
      MBToast.show(`退款金额需要在${minDeposit}-${maxDeposit}元之间`);
      this.showhandleConfirm = false;
      return;
    } else if (!refundReasonValue) {
      this.showhandleConfirm = false;
      MBToast.show('请选择退款原因');
      this.showhandleConfirm = false;
      return;
    }
    Modal.Confirm({
      closable: true,
      headerLine: false,
      title: '提示',
      content: '请确认是否退还订金',
      cancelText: '取消',
      confirmText: '确定退还',
      onCancel: () => {
        this.showhandleConfirm = false;
      },
      onConfirm: () => {
        this.showhandleConfirm = false;
        setTimeout(() => this.api_depositRefund(), 650);
      },
    });
  };
  api_depositRefund() {
    const { refundReasonKey, refundReasonValue, refundAmount, mybOrderId } = this.state;
    const data: dataForm = {
      refundReasonKey,
      refundReasonValue,
      refundAmount: filterFormat.moneyFormat(refundAmount),
      mybOrderId,
    };
    Api.depositRefund(data)
      .then((res) => {
        console.log('----------------api_depositRefund-------------------');
        console.log(res);
        if (res.success) {
          MBToast.show(res.msg);
          const { onConfirm } = this.props;
          !!onConfirm && setTimeout(() => onConfirm(), 1000);
        }
      })
      .catch((err: any) => {
        console.log('api_depositRefund:', err);
      });
  }
  handleCancel = () => {
    console.log('点击取消');
    const { onCancel } = this.props;
    !!onCancel && onCancel();
  };
  changeAmount = (val: string) => {
    if (verification.number(val) || val === '') {
      this.setState({ refundAmount: val });
    }
  };
  openReasonModal(val: boolean) {
    this.setState({ showReasonModal: val });
  }
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: autoFix(80), width: autoFix(100), justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  rulesTipsElement(tips: string) {
    return (
      <View style={{ paddingRight: autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {tips}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }
  indexElement() {
    const { visible } = this.props;
    const { refundAmount, refundReasonValue, fullDeposit, minDeposit, maxDeposit, depositStatus } = this.state;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="退还订金"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          // autoAdjustPosition={true}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
          contentStyle={{ paddingHorizontal: 0 }}
        >
          <View style={[styles.groupItem, { height: autoFix(479) }]}>
            <Whitespace vertical={20} />
            {!!depositTips[depositStatus] && <TipsText text={depositTips[depositStatus]} />}
            <InputItem
              titleStyle={{ color: '#333333' }}
              styleItem={styles.item}
              inputStyle={!!fullDeposit ? { marginRight: autoFix(10), color: '#333333' } : styles.input}
              value={refundAmount}
              readonly={!!fullDeposit}
              title="退还金额"
              textAlign="right"
              extraNode={<MBText>元</MBText>}
              onChangeText={this.changeAmount}
              placeholder={`请输入${minDeposit}-${maxDeposit}`}
              keyboardType="numeric"
              extra={this.state.isRulesTips && !refundAmount && this.rulesTipsElement(`退款金额需要在${minDeposit}-${maxDeposit}元之间`)}
            />
            <InputItem
              titleStyle={{ color: '#333333' }}
              inputStyle={{ color: '#333333', paddingLeft: autoFix(20) }}
              styleItem={[styles.item, { alignItems: 'flex-start' }]}
              linkIconStyle={{ marginTop: Platform.OS === 'ios' ? autoFix(2) : autoFix(4) }}
              value={refundReasonValue}
              title="退还原因"
              textAlign="right"
              isLink
              readonly
              placeholder="请输入"
              onReadOnlyPress={() => this.openReasonModal(true)}
              extra={this.state.isRulesTips && !refundReasonValue && this.rulesTipsElement('请选择退款原因')}
            />
          </View>
        </Modal>
      </View>
    );
  }
  ReasonModal() {
    const { refundReasonList, refundReasonKey, reasonListError } = this.state;
    const changeReason = (item: any) => {
      this.setState({ refundReasonValue: item.dictValue, refundReasonKey: item.dictKey, showReasonModal: false });
    };
    return (
      <View>
        <Modal
          title="退还订金"
          position="bottom"
          visible
          headerLine={false}
          onCancel={() => this.openReasonModal(false)}
          autoAdjustPosition={true}
          onMaskClose={() => this.openReasonModal(false)}
          onRequestClose={() => this.openReasonModal(false)}
          contentStyle={{ paddingHorizontal: 0 }}
        >
          <ScrollView style={{ minHeight: autoFix(479), maxHeight: autoFix(892), width: '100%' }}>
            <View style={styles.groupItem}>
              {refundReasonList?.length > 0 ? (
                refundReasonList.map((item: any) => {
                  return (
                    <TouchableHighlight
                      key={item.dictKey}
                      style={{ width: '100%' }}
                      underlayColor="#eeeeee"
                      onPress={() => changeReason(item)}
                    >
                      <View style={styles.listRow}>
                        <MBText size="xs" style={{ flex: 1, paddingRight: autoFix(20) }}>
                          {item.dictValue}
                        </MBText>
                        <Image
                          style={{ height: autoFix(30), width: autoFix(30), marginRight: autoFix(6) }}
                          source={item.dictKey === refundReasonKey ? images.icon_selected_point : images.icon_circleSelect}
                        />
                      </View>
                    </TouchableHighlight>
                  );
                })
              ) : (
                <View style={{ height: autoFix(479), justifyContent: 'center' }}>
                  <MBText size="xs" color="#ccc">
                    {reasonListError}
                  </MBText>
                </View>
              )}
              <Whitespace vertical={30} />
            </View>
          </ScrollView>
        </Modal>
      </View>
    );
  }
  render() {
    const { visible } = this.props;
    const { showReasonModal } = this.state;
    if (visible) {
      if (!showReasonModal) {
        return this.indexElement();
      } else {
        return this.ReasonModal();
      }
    }
  }
}

const styles = StyleSheet.create({
  groupItem: {
    width: '100%',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  item: {
    paddingHorizontal: autoFix(10),
    width: '100%',
  },
  input: {
    ...Platform.select({
      ios: {
        paddingBottom: autoFix(8),
      },
    }),
    flexDirection: 'row',
    paddingRight: autoFix(10),
    alignItems: 'center',
  },
  listRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: autoFix(28),
    paddingVertical: autoFix(32),
    borderBottomWidth: autoFix(1),
    borderBottomColor: '#E8E8E8',
  },
});
