import { MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import * as React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import Cell from '~/components/common/Cell';
import filterFormat from '~/extends/filterFormat';
import images from '~public/static/images';

// 详情里退还订金信息
interface Props {
  depositDetail: {
    deposit: string; // 订金
    refundDeposit: string; // 已退订金
    receivedDeposit: string; // 已收订金
    refundDepositTime: string; // 订金退还时间
    depositStatus: string; // 订金状态
    canDepositRefund: boolean; // 订金是否可退
    depositDetailRule: string; // 订金详细规则
    showReceipt: number; // 0：不展示  1：展示
    showRefundDepositButton: string; // showReceipt = true:展示
    depositStatusDesc: string; // 订金状态文本
  };
}

export default class CellDepositDetail extends React.Component<Props, any> {
  static defaultProps = {
    depositDetail: {},
  };
  constructor(props: any) {
    super(props);
    this.state = {};
  }
  extraElement() {
    const { refundDeposit, receivedDeposit, refundDepositTime, depositDetailRule } = this.props.depositDetail || {};
    if (depositDetailRule) {
      return (
        <View style={{ paddingBottom: autoFix(20) }}>
          <MBText color="#999999" size="xs">
            {depositDetailRule}
          </MBText>
        </View>
      );
    } else {
      const timeLineData = [];
      if (refundDeposit) {
        timeLineData.push({ label: `已退还订金${filterFormat.moneyDecFormat(refundDeposit)}元`, time: refundDepositTime || '' });
      }
      if (receivedDeposit) {
        timeLineData.push({ label: `已收订金${filterFormat.moneyDecFormat(receivedDeposit)}元`, time: '' });
      }
      if (timeLineData.length) {
        return (
          <View
            style={{
              backgroundColor: '#F9F9F9',
              paddingHorizontal: autoFix(12),
              paddingVertical: autoFix(18),
              marginBottom: autoFix(20),
              marginRight: autoFix(28),
            }}
          >
            {timeLineData.map((item: any, index: number) => {
              return (
                <View key={index} style={[styles.flexRowBetween, { position: 'relative', paddingVertical: autoFix(10) }]}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View style={styles.point}></View>
                    <MBText color="#666666" size="xs">
                      {item.label}
                    </MBText>
                  </View>
                  <View>
                    <MBText color="#666666" style={{ fontSize: autoFix(22) }}>
                      {item.time}
                    </MBText>
                  </View>
                  {!!index && <Image fadeDuration={0} style={[styles.timeLine, { top: autoFix(0) }]} source={images.line_vertical} />}
                  <Image fadeDuration={0} style={styles.timeLine} source={images.line_vertical} />
                </View>
              );
            })}
          </View>
        );
      } else {
        return null;
      }
    }
  }
  tagElement() {
    const { canDepositRefund } = this.props.depositDetail || {};
    const color = canDepositRefund ? '#51D27E' : '#FF9700';
    const text = canDepositRefund ? '退还' : '不退还';
    return (
      <View>
        <MBText style={[styles.tag, { borderColor: color }]} color={color}>
          {text}
        </MBText>
      </View>
    );
  }
  valueElement() {
    const { deposit, depositStatus, depositStatusDesc } = this.props.depositDetail || {};
    return (
      <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }}>
        <MBText color="#FF6969" bold size="xs">
          {filterFormat.moneyDecFormat(deposit)}元
        </MBText>
        {!!depositStatusDesc && (
          <MBText color="#666666" bold size="xs">
            ({depositStatusDesc})
          </MBText>
        )}
      </View>
    );
  }
  render() {
    const { deposit } = this.props.depositDetail || {};
    if (!!deposit) {
      return (
        <Cell
          key="depositDetail"
          title="订金"
          titleStyle={{ fontSize: autoFix(24) }}
          tag={this.tagElement()}
          align="right"
          rightTag={this.valueElement()}
          bottomLine
          isLink={false}
          contentStyle={styles.contentStyle}
          extra={this.extraElement()}
        />
      );
    } else {
      return null;
    }
  }
}

const styles = StyleSheet.create({
  contentStyle: {},
  flexRowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  tag: {
    borderWidth: autoFix(1),
    paddingHorizontal: autoFix(6),
    paddingVertical: autoFix(2),
    fontSize: autoFix(24),
  },
  point: {
    backgroundColor: '#CBCED6',
    borderRadius: 100,
    height: autoFix(14),
    width: autoFix(14),
    marginLeft: autoFix(10),
    marginRight: autoFix(16),
  },
  timeLine: {
    position: 'absolute',
    top: autoFix(20),
    left: autoFix(17),
    width: autoFix(2),
    height: autoFix(30),
  },
});
