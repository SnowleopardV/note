import React from 'react';
import {Image, StyleSheet, TouchableOpacity, View, ScrollView} from 'react-native';
import { observer} from "mobx-react";
import {Modal, MBText, Checkbox} from '@ymm/rn-elements';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import InputItem from '~/components/common/InputItem';
import { MBBridge } from '@ymm/rn-lib';

// 任务删除弹窗
interface Props {
  visible?: boolean;
  removeMsg?: string;
  bottomMsg?: any;
  cancelReasonList?: any;
  refundDeposit?: number;
  refundDepositRes?: number;
  launchResponsibility?: any;
  launchResponsibilityNote?: string;
  currentCheckedReason?: any;
  onConfirm?: any;
  onCancel?: any;
  onSelect?: any;
  onChange?: any;
  checkboxChanged?: any;
  setNote?: any;
}

@observer
export default class ModalRemove extends React.Component<Props, any> {
  refInput: React.RefObject<any>;
  constructor(props: Props) {
    super(props);
    this.refInput = React.createRef();
    this.state = {
      otherReasonList: [
        { title: '自己原因', value: '0' },
        { title: '司机原因', value: '1' }
      ]
    };
  }

  componentWillReceiveProps(nextProps: Readonly<Props>, nextContext: any) {
    MBBridge.rnruntime.IQKeyboard({ enable: !nextProps.visible });
  }
  // 弹窗确定
  onModalConfirm = () => {
    const { onConfirm } = this.props;
    onConfirm && onConfirm();
  };
  // 弹窗取消
  onModalCancel = () => {
    const { onCancel } = this.props;
    onCancel && onCancel();
  };
  // 原因勾选
  onReasonSelect = (item: any) => {
    const { onSelect } = this.props;
    onSelect && onSelect(item);
  }
  rightElement = () => {
    return (
      <TouchableOpacity onPress={() => this.onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">确定</MBText>
        </View>
      </TouchableOpacity>
    );
  };
  render() {
    const { otherReasonList } = this.state;
    const {
      visible,
      removeMsg,
      bottomMsg,
      cancelReasonList,
      refundDeposit,
      refundDepositRes,
      launchResponsibility,
      launchResponsibilityNote,
      currentCheckedReason,
      onChange,
      checkboxChanged,
      setNote
    } = this.props;
    const CheckboxGroup = Checkbox.CheckboxGroup;
    const textNum = launchResponsibilityNote?.length || 0;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="删除任务单"
          position="bottom"
          visible={visible}
          autoAdjustPosition={true}
          headerLine={false}
          onConfirm={this.onModalConfirm}
          onCancel={this.onModalCancel}
          onMaskClose={this.onModalCancel}
          onRequestClose={this.onModalCancel}
          contentStyle={styles.modalContentStyle}
        >
          <ScrollView style={styles.container}>
            {cancelReasonList?.map((item: any, index: any) => {
              return (
                <View>
                  <View style={styles.flexRow}>
                    <MBText style={styles.leftTextBox}>
                      {item.cancelReasonDesc}
                    </MBText>
                    <TouchableOpacity onPress={() => this.onReasonSelect(item)}>
                      {
                        currentCheckedReason.cancelReasonCode === null ?
                          <Image style={styles.imageIcon} source={images.icon_circleSelect} /> :
                          currentCheckedReason.cancelReasonCode === item.cancelReasonCode ?
                            <Image style={styles.imageIcon} source={images.icon_circleSelectCheck} /> :
                            <Image style={styles.imageIcon} source={images.icon_circleSelect} />
                      }
                    </TouchableOpacity>
                  </View>
                  {index === 0 ? (<MBText style={styles.noteArea}>{removeMsg}</MBText>) : null}
                </View>
              );
            })}

            {currentCheckedReason.cancelReasonCode === 0 ? (
              <View style={styles.inputReasonArea}>
                <CheckboxGroup
                  multiple={false}
                  data={otherReasonList}
                  value={launchResponsibility}
                  onChange={checkboxChanged}
                />
                <View style={styles.editBox}>
                  <InputItem
                    value={launchResponsibilityNote}
                    placeholder='取消原因需经过司机确认，为避免交易纷争，请如实填写'
                    onChangeText={setNote}
                    style={styles.inputItem}
                    maxLength={100}
                    multiline={true}
                    blurOnSubmit
                    extraNode={<MBText></MBText>}
                  />
                  <View style={styles.fontNum}>
                    <MBText color="#CCCCCC">{textNum}/100</MBText>
                  </View>
                </View>
              </View>) : null}
          </ScrollView>

          {
            (bottomMsg && bottomMsg.length > 0) || (refundDepositRes === 1 && currentCheckedReason.cancelReasonCode !== -1) ?
              (<View style={styles.bottomArea}>
                {
                  refundDepositRes === 1 && currentCheckedReason.cancelReasonCode !== -1 ?
                    (<Checkbox type="primary" size="sm" checked={refundDeposit === 1} onChange={onChange}>
                      <MBText style={styles.bottomText1}>同时退订金给司机</MBText>
                    </Checkbox>) : null
                }
                {
                  bottomMsg && bottomMsg.length > 0 ?
                    (<MBText style={styles.bottomText2}>{bottomMsg}</MBText>) : null
                }
              </View>) : null
          }
        </Modal>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  modalContentStyle: {
    paddingHorizontal: 0
  },
  container: {
    width: '100%',
    maxHeight: autoFix(600)
  },
  flexRow: {
    display: 'flex',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: autoFix(32),
    paddingBottom: autoFix(32),
    paddingLeft: autoFix(28),
    paddingRight: autoFix(42)
  },
  leftTextBox: {
    flex: 1,
    fontSize: autoFix(28),
    paddingRight: autoFix(20)
  },
  imageIcon: {
    width: autoFix(40),
    height: autoFix(40)
  },
  noteArea: {
    color: '#999999',
    backgroundColor: '#F5F5F5',
    fontSize: autoFix(24),
    paddingTop: autoFix(20),
    paddingBottom: autoFix(20),
    paddingLeft: autoFix(28),
    paddingRight: autoFix(28)
  },
  inputReasonArea: {
    paddingTop: autoFix(32),
    paddingBottom: autoFix(28),
    paddingLeft: autoFix(28),
    paddingRight: autoFix(28)
  },
  editBox: {
    width: autoFix(694),
    height: autoFix(238),
    backgroundColor: '#F6F6F6',
    marginTop: autoFix(28),
    borderRadius: autoFix(8)
  },
  inputItem: {
    flex: 1
  },
  fontNum: {
    position: 'absolute',
    bottom: autoFix(20),
    right: autoFix(20),
  },
  bottomArea: {
    width: '100%',
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 5, height: 5 },
    shadowRadius: autoFix(20),
    elevation: 20,
    borderRadius: autoFix(8),
    paddingTop: autoFix(32),
    paddingBottom: autoFix(48),
    paddingLeft: autoFix(28),
    paddingRight: autoFix(28)
  },
  bottomText1: {
    color: '#666666',
    fontSize: autoFix(26)
  },
  bottomText2: {
    color: '#999999',
    fontSize: autoFix(22),
    marginTop: autoFix(20)
  }
});
