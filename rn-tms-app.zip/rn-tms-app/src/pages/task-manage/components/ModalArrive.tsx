import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { Modal, Whitespace, CellGroup, MBText, RNElementsUtil } from '@ymm/rn-elements';
import { MBToast } from '@ymm/rn-lib';
import InputItem from '~/components/common/InputItem';
import NativeBridge from '~/extends/NativeBridge';
import MBDatetimePicker from '~/components/common/MBDatetimePicker';
import RegTest from '~/utils/RegTest';

const ModalArrive = (props: any) => {
  const {
    visible,
    onConfirm,
    onCancel,
    defaultEstimateOutsetTime,
    defaultEstimateArrivedTime,
    remark,
    isArriveError,
    dispatcherMode,
    invoiceFlag,
  } = props;

  const [unsaveDateTime, setUnsaveDateTime] = useState(defaultEstimateArrivedTime);
  const [unsaveRemark, setUnsaveRemark] = useState(remark);
  const dateTimeRef = useRef(null);

  useEffect(() => {
    setUnsaveDateTime({ ...defaultEstimateArrivedTime });
  }, [defaultEstimateArrivedTime]);

  useEffect(() => {
    setUnsaveRemark(remark);
  }, [remark]);

  const onModalConfirm = () => {
    if (defaultEstimateOutsetTime?.endTimestamp && unsaveDateTime?.endTimestamp) {
      if (defaultEstimateOutsetTime.endTimestamp > unsaveDateTime.endTimestamp) {
        return MBToast.show('到达时间不能小于发车时间');
      }
    }

    const params = {
      estimateArrivedTime: unsaveDateTime,
      remark: unsaveRemark,
    };

    onConfirm && onConfirm(params);
  };

  // 弹窗取消
  const onModalCancel = () => {
    // 设置带入默认值
    setUnsaveDateTime({ ...defaultEstimateArrivedTime });
    setUnsaveRemark(remark);
    onCancel && onCancel();
  };

  // 时间
  const onChangeDateTime = (value: any) => {
    console.log(defaultEstimateOutsetTime?.endTimestamp, 'defaultEstimateOutsetTime?.endTimestamp');
    console.log(unsaveDateTime?.endTimestamp, 'unsaveDateTime?.endTimestamp');
    if (defaultEstimateOutsetTime?.endTimestamp && value?.endTimestamp) {
      if (defaultEstimateOutsetTime.endTimestamp > value.endTimestamp) {
        MBToast.show('到达时间不能小于发车时间');
      }
    }

    setUnsaveDateTime(value);
  };

  // 备注
  const onChangeRemark = (value: string) => {
    if (RegTest.emoji(value)) return;
    if (value && value.length > 100) {
      return NativeBridge.toast('已达到输入上限100个字符');
    }
    setUnsaveRemark(value);
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <View>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="到达"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
        contentStyle={styles.modalContentStyle}
      >
        <View style={styles.container}>
          <Whitespace vertical={10} />

          <CellGroup withBottomLine style={{ marginHorizontal: 0 }}>
            <MBDatetimePicker
              ref={dateTimeRef}
              value={unsaveDateTime}
              title="到达时间"
              modalTitle="请选择到达时间"
              type={(dispatcherMode === '3' && invoiceFlag === '1') || dispatcherMode === '4' ? 'loadTime' : 'loadTimeMonth'}
              placeholder="请选择"
              align="right"
              required
              onChange={onChangeDateTime}
              extra={
                isArriveError &&
                !unsaveDateTime && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      到达时间为空
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />

            <InputItem
              title="到达备注"
              placeholder="请输入"
              maxLength={101}
              textAlign="right"
              value={unsaveRemark}
              onChangeText={onChangeRemark}
            />
          </CellGroup>

          <Whitespace vertical={40} />
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    width: '100%',
  },

  modalContentStyle: {
    paddingHorizontal: 0,
  },
});

export default ModalArrive;
