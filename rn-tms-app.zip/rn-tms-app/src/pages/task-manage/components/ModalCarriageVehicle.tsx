import React, { useState, useEffect } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { Flex, Modal, Selector, MBText, Button } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

const FlexItem = Flex.Item;

const ModalCarriageVehicle = (props: any) => {
  const {
    visible,
    onConfirm,
    onCancel,
    truckList,
    defaultCarrierItem,
    defaultVehicleItem,
    dispatcherMode,
    isAddVehicle,
    onCancelModalDeparture,
    onaddCallback,
  } = props;
  const [vehicleItem, setVehicleItem] = useState(defaultVehicleItem);
  const [lastItemIndex, setLastItemIndex] = useState(0);
  const [truckSourceArr, setTruckSourceArr] = useState([null, 1, 5, 4]); // 车辆来源 1：自有 4：外调 5：承运商

  useEffect(() => {
    const carNo = defaultVehicleItem.carNo;

    setVehicleItem(() => {
      const lastVehicleItemArr = truckList.filter((item: any) => item.carNo === defaultVehicleItem.carNo);
      return lastVehicleItemArr.length ? lastVehicleItemArr[0] : truckList.length ? truckList[0] : {};
    });

    truckList.forEach((item: any, index: number) => {
      if (item.carNo === carNo) {
        setLastItemIndex(index);
      }
    });
  }, [truckList, defaultVehicleItem.carNo]);

  useEffect(() => {
    const carNo = defaultVehicleItem.carNo;

    truckList.forEach((item: any, index: number) => {
      if (item.carNo === carNo) {
        setLastItemIndex(index);
      }
    });
  }, [defaultVehicleItem.carNo]);

  const onModalConfirm = () => {
    const { carType, carLength, ...restParams } = vehicleItem;
    onConfirm && onConfirm(restParams);
  };

  const onItemChange = (value: any) => {
    setVehicleItem(value);
  };

  const addVehicle = () => {
    if (!isAddVehicle) return NativeBridge.toast('您还没有#新增车辆权限#，请联系管理员开通');
    const { carrierId } = defaultCarrierItem;
    const params = {
      truckSource: dispatcherMode ? truckSourceArr[dispatcherMode] : null,
      carrierId,
    };

    // 关闭当前弹窗
    onCancel && onCancel();
    // 关闭发车弹窗
    onCancelModalDeparture && onCancelModalDeparture();

    MBBridge.app.base
      .openSchemeForResult({ schemeUrl: 'ymm://rn.tms/newcars?item=' + encodeURIComponent(JSON.stringify(params)) })
      .then((res) => {
        if (res.data) {
          let handleData;
          try {
            handleData = JSON.parse(res.data);
          } catch (error) {
            handleData = res.data;
          }

          const { truckNo, truckLengthText, truckTypeText, carId } = handleData;
          const displayValue = `${truckNo ? truckNo + '-' : ''}${truckTypeText ? truckTypeText + '-' : ''}${
            truckLengthText ? truckLengthText + '米' : ''
          }`;
          const data = {
            carId,
            carNo: truckNo,
            displayValue,
          };

          onConfirm && onConfirm(data);
          onaddCallback && onaddCallback('addVehicle');
        }
      });
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <View>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="请选择承运车辆"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onCancel}
        onMaskClose={onCancel}
        onRequestClose={onCancel}
        contentStyle={[styles.modalContentStyle, dispatcherMode === '2' && { height: autoFix(630) }]}
      >
        <Flex direction="row" justify="center" flex={1}>
          {truckList.length ? (
            <FlexItem>
              <Selector
                scaleFont={true}
                value={lastItemIndex}
                rowTitle="displayValue"
                list={truckList}
                onChange={(position, value) => {
                  onItemChange(value);
                }}
              />
            </FlexItem>
          ) : (
            <MBText color="#999999">无车辆信息，请新增</MBText>
          )}
        </Flex>
        <Button type="bordered" size="xs" style={[styles.btn, !isAddVehicle && { opacity: 0.3 }]} onPress={addVehicle}>
          新增车辆
        </Button>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create<any>({
  modalContentStyle: {
    height: autoFix(580),
    paddingTop: autoFix(40),
  },

  btn: {
    marginBottom: autoFix(60),
    width: autoFix(358),
    height: autoFix(80),
    borderRadius: autoFix(50),
  },
});

export default ModalCarriageVehicle;
