import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { Modal, Whitespace, CellGroup, MBText, RNElementsUtil } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import InputItem from '~/components/common/InputItem';
import Cell from '~/components/common/Cell';
import NativeBridge from '~/extends/NativeBridge';
import MBDatetimePicker from '~/components/common/MBDatetimePicker';
import ModalCarrier from './ModalCarrier';
import ModalCarriageVehicle from './ModalCarriageVehicle';
import ModalCarrierDriver from './ModalCarrierDriver';
import RegTest from '~/utils/RegTest';

const ModalDeparture = (props: any) => {
  const {
    visible,
    onConfirm,
    onCancel,
    carrierList,
    truckList,
    driverList,
    defaultEstimateOutsetTime,
    defaultCarrierItem,
    defaultVehicleItem,
    defaultDriverItem,
    remark,
    invoiceFlag,
    dispatcherMode,
    isDepartureError,
    isAddCarrier,
    isAddVehicle,
    isAddDrive,
    sendCarFlag,
    onaddCallbackDeparture,
    selectedCarrierCallback,
    unsaveDefaultVehicleItem,
    unsaveDefaultDriverItem,
  } = props;

  const [carrierVisible, setCarrierVisible] = useState(false);
  const [carriageVehicleVisible, setCarriageVehicleVisible] = useState(false);
  const [carrierDriverVisible, setCarrierDriverVisible] = useState(false);
  const [unsaveDateTime, setUnsaveDateTime] = useState(defaultEstimateOutsetTime);
  const [unsaveSelectedCarrierItem, setUnsaveSelectedCarrierItem] = useState(defaultCarrierItem);
  const [unsaveSelectedVehicleItem, setUnsaveSelectedVehicleItem] = useState(defaultVehicleItem);
  const [unsaveSelectedDriverItem, setUnsaveSelectedDriverItem] = useState(defaultDriverItem);
  const [unsaveRemark, setUnsaveRemark] = useState(remark);
  const dateTimeRef = useRef(null);

  useEffect(() => {
    setUnsaveDateTime({ ...defaultEstimateOutsetTime });
  }, [defaultEstimateOutsetTime.dateCode]);

  useEffect(() => {
    setUnsaveSelectedCarrierItem({ ...defaultCarrierItem });
  }, [defaultCarrierItem]);

  useEffect(() => {
    setUnsaveSelectedVehicleItem({ ...defaultVehicleItem, ...unsaveDefaultVehicleItem });
  }, [defaultVehicleItem, unsaveDefaultVehicleItem]);

  useEffect(() => {
    setUnsaveSelectedDriverItem({ ...defaultDriverItem, ...unsaveDefaultDriverItem });
  }, [defaultDriverItem, unsaveDefaultDriverItem]);

  useEffect(() => {
    setUnsaveRemark(remark);
  }, [remark]);

  // 弹窗确认
  const onModalConfirm = () => {
    const params = {
      ...unsaveSelectedCarrierItem,
      ...unsaveSelectedVehicleItem,
      ...unsaveSelectedDriverItem,
      estimateOutsetTime: unsaveDateTime,
      remark: unsaveRemark,
      dispatcherMode,
    };

    onConfirm && onConfirm(params);
  };

  // 弹窗取消
  const onModalCancel = () => {
    // 设置带入默认值
    setUnsaveDateTime({ ...defaultEstimateOutsetTime });
    setUnsaveSelectedCarrierItem({ ...defaultCarrierItem });
    setUnsaveSelectedVehicleItem({ ...defaultVehicleItem });
    setUnsaveSelectedDriverItem({ ...defaultDriverItem });
    setUnsaveRemark(remark);
    onCancel && onCancel();
  };

  const onItemClick = (value: string) => {
    if (value === 'carrier') {
      setCarrierVisible(true);
    } else if (value === 'carriageVehicle') {
      setCarriageVehicleVisible(true);
    } else {
      setCarrierDriverVisible(true);
    }
  };

  // 时间
  const onChangeDateTime = (value: any) => {
    setUnsaveDateTime(value);
  };

  /**
   * 承运商弹窗确认
   * @param addType 新增承运商: addCarrier
   * @param value 承运商Id: carrierId, 承运商名称: carrierName
   *
   */
  const onModalCarrierConfirm = (value: any, addType: string) => {
    if (addType && addType === 'addCarrier') {
      // 新增承运商后回到原页面打开发车弹窗
      onCancel && onCancel();
    }
    setUnsaveSelectedCarrierItem(value);
    selectedCarrierCallback && selectedCarrierCallback(value);
    changeCarrierVisible();
  };

  const changeCarrierVisible = () => {
    setCarrierVisible(!carrierVisible);
  };

  // 承运车辆弹窗确认
  const onModalCarriageVehicleConfirm = (value: any) => {
    // 指派外调车-不开票 选择车辆不回显司机
    if (!(dispatcherMode === '3' && invoiceFlag !== '1')) {
      const { majorityDriverId, majorityDriverName, majorityDriverPhone } = value;
      const displayValue = `${majorityDriverName ? majorityDriverName + '-' : ''}${majorityDriverPhone ? majorityDriverPhone : ''}`;
      const driverData = {
        driverId: majorityDriverId,
        driverPhone: majorityDriverPhone,
        driverName: majorityDriverName,
        displayValue,
      };
      setUnsaveSelectedDriverItem(driverData);
    }
    setUnsaveSelectedVehicleItem(value);
    changeCarriageVehicleVisible();
  };

  const changeCarriageVehicleVisible = () => {
    setCarriageVehicleVisible(!carriageVehicleVisible);
  };

  // 承运司机弹窗确认
  const onModalCarriageDriverConfirm = (value: any) => {
    setUnsaveSelectedDriverItem(value);
    changeCarrierDriverVisible();
  };

  const changeCarrierDriverVisible = () => {
    setCarrierDriverVisible(!carrierDriverVisible);
  };

  // 备注
  const onChangeRemark = (value: string) => {
    if (RegTest.emoji(value)) return;
    if (value && value.length > 100) {
      return NativeBridge.toast('已达到输入上限100个字符');
    }
    setUnsaveRemark(value);
  };

  /**
   * 新增承运商、车辆、司机的回调
   * @param addType 新增承运商: addCarrier，新增承车辆: addVehicle，新增司机: addDriver,
   * @param carrierData 承运商Id: carrierId, 承运商名称: carrierName
   *
   */
  const onaddCallback = (addType: string) => {
    // 打开发车弹窗
    onCancel && onCancel();
    // 回调父组件请求车辆、司机接口
    onaddCallbackDeparture && onaddCallbackDeparture(addType, unsaveSelectedCarrierItem);
  };

  // 关闭发车弹窗
  const onCancelModalDeparture = () => {
    onCancel && onCancel();
  };
  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <View>
      <Modal
        headerLeft="取消"
        headerRight={rightElement()}
        title="发车"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={onModalCancel}
        onMaskClose={onModalCancel}
        onRequestClose={onModalCancel}
        contentStyle={[styles.modalContentStyle, dispatcherMode === '2' && { height: autoFix(630) }]}
      >
        <View style={styles.container}>
          <Whitespace vertical={10} />

          <CellGroup withBottomLine style={{ marginHorizontal: 0 }}>
            <MBDatetimePicker
              ref={dateTimeRef}
              value={unsaveDateTime}
              title="发车时间"
              modalTitle="请选择发车时间"
              type={(dispatcherMode === '3' && invoiceFlag === '1') || dispatcherMode === '4' ? 'loadTime' : 'loadTimeMonth'}
              placeholder="请选择"
              align="right"
              required
              onChange={onChangeDateTime}
              contentStyle={[styles.modalDatetimeContentStyle, dispatcherMode === '2' && { height: autoFix(616) }]}
              extra={
                isDepartureError &&
                !unsaveDateTime && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      发车时间为空
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
            {dispatcherMode === '2' ? (
              <Cell
                name="carrier"
                title="承运商"
                align="right"
                required
                readonly={sendCarFlag}
                value={unsaveSelectedCarrierItem.carrierName}
                numberOfLines={1}
                placeholder="请选择"
                onPress={() => {
                  onItemClick('carrier');
                }}
                onReadOnlyPress={() => {
                  NativeBridge.toast('已生成财务数据，不支持修改');
                }}
                extra={
                  isDepartureError &&
                  dispatcherMode !== '2' &&
                  !unsaveSelectedCarrierItem.carrierName && (
                    <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                      <MBText size="xs" color="#F54242" align="right">
                        承运商为空
                      </MBText>
                      <Whitespace vertical={14} />
                    </View>
                  )
                }
              />
            ) : null}
            <Cell
              name="carriageVehicle"
              title="承运车辆"
              align="right"
              required={dispatcherMode !== '2'}
              readonly={(dispatcherMode === '3' && invoiceFlag === '1') || dispatcherMode === '4'}
              value={unsaveSelectedVehicleItem.displayValue}
              numberOfLines={1}
              placeholder="请选择"
              onPress={() => {
                onItemClick('carriageVehicle');
              }}
              onReadOnlyPress={() => {
                NativeBridge.toast('平台任务单，不支持修改');
              }}
              extra={
                isDepartureError &&
                !unsaveSelectedVehicleItem.carNo && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      承运车辆为空
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
            <Cell
              name="carrierDriver"
              title="承运司机"
              align="right"
              required={dispatcherMode !== '2'}
              value={unsaveSelectedDriverItem.displayValue}
              numberOfLines={1}
              placeholder="请选择"
              readonly={
                dispatcherMode === '4' ||
                (dispatcherMode === '3' && invoiceFlag === '1') ||
                (dispatcherMode === '3' && invoiceFlag !== '1' && sendCarFlag)
              }
              onPress={() => {
                onItemClick('carrierDriver');
              }}
              onReadOnlyPress={() => {
                if (dispatcherMode === '3' && invoiceFlag !== '1' && sendCarFlag) {
                  NativeBridge.toast('已生成财务数据，不支持修改');
                } else {
                  NativeBridge.toast('平台任务单，不支持修改');
                }
              }}
              extra={
                isDepartureError &&
                dispatcherMode !== '2' &&
                !unsaveSelectedDriverItem.driverName && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      承运司机为空
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
            <InputItem
              title="发车备注"
              placeholder="请输入"
              maxLength={101}
              textAlign="right"
              value={unsaveRemark}
              onChangeText={onChangeRemark}
            />
          </CellGroup>

          <Whitespace vertical={40} />
        </View>
      </Modal>

      <ModalCarrier
        visible={carrierVisible}
        carrierList={carrierList}
        dispatcherMode={dispatcherMode}
        defaultCarrierItem={unsaveSelectedCarrierItem}
        isAddCarrier={isAddCarrier}
        onConfirm={onModalCarrierConfirm}
        onCancel={changeCarrierVisible}
        onCancelModalDeparture={onCancelModalDeparture}
        onaddCallback={onaddCallback}
      />

      <ModalCarriageVehicle
        visible={carriageVehicleVisible}
        truckList={truckList}
        dispatcherMode={dispatcherMode}
        defaultCarrierItem={unsaveSelectedCarrierItem}
        defaultVehicleItem={unsaveSelectedVehicleItem}
        isAddVehicle={isAddVehicle}
        onConfirm={onModalCarriageVehicleConfirm}
        onCancel={changeCarriageVehicleVisible}
        onCancelModalDeparture={onCancelModalDeparture}
        onaddCallback={onaddCallback}
      />

      <ModalCarrierDriver
        visible={carrierDriverVisible}
        driverList={driverList}
        dispatcherMode={dispatcherMode}
        isAddDrive={isAddDrive}
        defaultCarrierItem={unsaveSelectedCarrierItem}
        defaultDriverItem={unsaveSelectedDriverItem}
        onConfirm={onModalCarriageDriverConfirm}
        onCancel={changeCarrierDriverVisible}
        onCancelModalDeparture={onCancelModalDeparture}
        onaddCallback={onaddCallback}
      />
    </View>
  );
};

const styles = StyleSheet.create<any>({
  container: {
    width: '100%',
  },

  modalContentStyle: {
    paddingHorizontal: 0,
    height: autoFix(580),
  },

  modalDatetimeContentStyle: {
    height: autoFix(566),
  },
});

export default ModalDeparture;
