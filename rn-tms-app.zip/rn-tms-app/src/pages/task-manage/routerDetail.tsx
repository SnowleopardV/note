import React, { Component } from 'react';
import RouterRigister, { RouterPageName } from './router';
import { Provider } from 'mobx-react';
import { LayProvider } from '@ymm/rn-elements';
import stores from './stores';

/**
 * 路由申明
 */
const RootStack = new RouterRigister().getRouterMap(RouterPageName.TASK_DETAIL.toString());

/**
 * 路由组件
 */
export default class TaskDetail extends Component<any, any> {
  constructor(props: any) {
    super(props);
  }

  render() {
    return (
      <Provider {...stores}>
        <LayProvider theme="skyblue">
          <RootStack screenProps={this.props} />
        </LayProvider>
      </Provider>
    );
  }
}
