import { StyleSheet, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  flexing: {
    flex: 1,
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bgImg: {
    position: 'absolute',
  },
  footer: {
    paddingHorizontal: 13,
    paddingVertical: 10,
    backgroundColor: '#fff',
    justifyContent: 'flex-end',
    flexWrap: 'wrap',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  btn: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    minWidth: 65,
    textAlign: 'center',
    borderRadius: 20,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 10,
    marginTop: 10,
  },
  btnTxt: {
    fontSize: 16,
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
    color: '#4885FF',
    textAlign: 'center',
  },
  //新增的付款申请单号
  paymentOrderBox: {
    marginLeft: autoFix(20),
    marginRight: autoFix(20),
    marginBottom: autoFix(20),
    padding: autoFix(28),
    backgroundColor: '#fff',
  },
  paymentOrderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  paymentOrderTitle: {
    fontSize: autoFix(26),
    fontWeight: '400',
    color: '#999',
  },
  paymentOrderMore: {
    fontSize: autoFix(26),
    fontWeight: '400',
    color: '#666',
  },
  paymentOrderMoreImg: {
    height: autoFix(23),
    width: autoFix(23),
    marginLeft: autoFix(6),
    marginRight: autoFix(-10),
  },
  paymentOrderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: autoFix(20),
  },
  paymentOrderItemLable: {
    fontSize: autoFix(28),
    fontWeight: '400',
    color: '#333',
  },
  paymentOderItemOrderNo: {
    fontSize: autoFix(28),
    fontWeight: '400',
    color: '#666',
  },
  paymentOrderGoImg: {
    height: autoFix(23),
    width: autoFix(23),
    marginLeft: autoFix(6),
    marginRight: autoFix(-10),
  },
});
