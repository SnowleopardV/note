import * as React from 'react';
import { View, ScrollView, SafeAreaView, TouchableOpacity, Image, StyleSheet } from 'react-native';
import {LayProvider, MBText, Modal, TagContent} from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import {PlatformKit, MBBridge, MBToast, MBAutoPVComponent, HandleOnceUtil} from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import StatusBar from '~/components/orderDetail/StatusBar'; // 状态栏
import DriverInfo from '~/components/orderDetail/DriverInfo'; // 承运信息
import WaybillInfo from '~/components/orderDetail/WaybillInfo'; // 装车清单
import LoadInfo from '~/components/orderDetail/LoadInfo'; // 装卸信息
import CargoInfo from '~/components/orderDetail/CargoInfo'; // 货物信息
import FeeInfo from '~/components/orderDetail/FeeInfo'; // 费用信息
import InsuranceInfo from '~/components/orderDetail/InsuranceInfo'; // 保险信息
import SettlementInfo from '~/components/orderDetail/SettlementInfo'; // 结算方式
import TransDealInfo from '~/components/orderDetail/TransDealInfo'; // 运输协议
import OtherInfo from '~/components/orderDetail/OtherInfo'; // 其他信息
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import NativeBridge from '~/extends/NativeBridge';
import ModalDeparture from '../components/ModalDeparture';
import ModalArrive from '../components/ModalArrive';
import ModalRemove from '../components/ModalRemove';
import Api from '../api';
import { STATUS_MAP, MODAL_TITLE_MAP, ACTION_MAP } from '../status';
import styles from './styles';
import TaskManageStore from '../store';
import { toJS } from 'mobx';
import images from '../../../../public/static/images/index';
import commonData, { goNetworkProtocol } from '~/pages/commonData';
import OpenDispatchResultModal from '~/components/OpenDispatchResultModal';
import FootButtonList from '~/components/FootButtonList';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import ReturnDeposit, { api_depositRefundReason } from '../components/ReturnDeposit';
const Confirm = Modal.Confirm;
const Alert = Modal.Alert;

interface TaskManageStore {
  taskManageStore: TaskManageStore;
}

@inject('taskManageStore')
@observer
class TaskDetail extends MBAutoPVComponent<TaskManageStore, any> {
  refOpenDispatchResult: any;
  constructor(props: TaskManageStore) {
    super(props);
    this.state = {
      title: '',
      showTimePicker: false,
      showAllPaymentApplicationOrder: false,
      returnDepositData: null, // 显示退还订金弹窗 需要的字段
      removeListVisible: false, // 删除弹窗的显隐
      removeMsg: '', // 删除弹框显示的msg
      bottomMsg: '', // 删除弹框，底部显示的msg
      cancelReasonList: [], // 删除弹框内取消原因列表
      refundDeposit: 2, // 删除弹框内，是否退订金: 1-退订金, 2-不退订金
      refundDepositRes: 2, // 删除弹框内，是否退订金 - response
      launchResponsibility: ['0'], // 删除弹框内，勾选其他后的原因类型: 0-自己原因，1-司机原因
      launchResponsibilityNote: '', // 删除弹框内，勾选其他后的原因内容
      currentCheckedReason: { // 删除弹框内，当前勾选的原因
        cancelReasonCode: null,
        cancelReasonDesc: '',
        responsibility: null,
        reasonType: null
      },
      primaryKeyId: null // 任务主键id
    };
  }

  async componentDidMount() {
    super.componentDidMount();
    const id = this.props.screenProps?.id || this.props.navigation.state?.params?.id;
    const {
      taskManageStore: { getTaskDetail, getTruckLengthList, getTruckTypeList },
    } = this.props;

    await getTaskDetail({ id }, this.props.navigation);
    const {
      taskManageStore: {
        detail: { dispatcherMode, taskState, taskNo },
      },
    } = this.props;

    // 待发车&调度方式为非平台找车下：车型、车长
    if (dispatcherMode !== '4' && taskState === 'WAIT_FOR_DEPART') {
      getTruckLengthList({
        toPlatform: false,
        queryType: 0,
      });
      getTruckTypeList({
        toPlatform: false,
        queryType: 0,
      });
    }
    // 是否显示满帮找车发货结果
    if (commonData.cargoRespList?.length) {
      this.refOpenDispatchResult?.openModal(taskNo);
    }
  }

  getPageName() {
    return 'dispatch_manage_detail';
  }

  // 获取状态栏
  get statusBarInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;

    if (JSON.stringify(detail) == '{}') return {};
    const { taskState, transOrderNo, taskNo, mybOrderId, mybOrderStatus, mybCorpIcon, orgName } = detail;
    return {
      status: STATUS_MAP[taskState],
      transOrderNo,
      taskNo,
      mybOrderId,
      showMybCancel: mybOrderStatus == 3,
      mybCorpIcon,
      orgName,
    };
  }

  // 获取承运信息
  get driverInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.schedulingInfo || null;
  }

  // 获取装车清单
  get waybillInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.transOrderList || [];
  }

  // 获取装货信息
  get loadInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.loadList || [];
  }

  // 获取卸货信息
  get unLoadInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.unloadList || [];
  }

  // 获取货物信息
  get cargoInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.cargoList || [];
  }

  // 获取应收信息
  get feeInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    let data = detail.feeDetailList || [];
    data = data.map((item) => ({
      name: item.feeCodeDesc,
      value: item.amountDesc,
    }));
    // 拼上额外字段
    data = data.concat(toJS(detail?.feeDetailExtList) || []);
    return data;
  }

  // 获取保险信息
  get insuranceInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.insuranceList || [];
  }

  // 获取结算信息
  get settlementInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.settlementList || [];
  }

  // 获取协议信息
  get agreement() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.agreement || null;
  }

  // 获取其他信息
  get otherInfo() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return { otherList: detail.otherList || [], dispatcherListInfo: detail.dispatcherListInfo || [] };
  }

  // 获取按钮信息
  get buttonList() {
    const {
      taskManageStore: { detail },
    } = this.props;
    return detail.buttonList || [];
  }
  openReturnDeposit = (val: any) => {
    this.setState({ returnDepositData: val });
  };

  goBack = async () => {
    // 来自付款申请单
    if (this.props.screenProps?.id) {
      MBBridge.app.ui.closeWindow({});
    } else {
      this.props.navigation?.goBack();
    }
  };

  jump = (item) => {
    this.props.navigation.navigate('TaskDetail', item);
  };
  // 跳转找车看板页面
  gotoCarBoardPage = (taskNo: string) => {
    this.props.navigation.navigate('CarBoard', { taskNo });
  };

  // 重新调度
  onDispatchAgain = (confirmContent: string) => {
    if (confirmContent) {
      MBToast.show(confirmContent);
      return;
    }
  };

  onActions = (item: any) => {
    console.log('----------详情按钮---------');
    console.log(item.code);

    const {
      taskManageStore: { detail, changeArriveModalVisible },
    } = this.props;
    // console.log(detail,'---------------detail---------');
    this.setState({
      actionType: item.code,
      primaryKeyId: detail.id,
    });
    switch (item.code) {
      case '1': // 发车
        this.onConfirmDeparture();
        break;
      case '2': // 到达
        changeArriveModalVisible();
        break;
      case '3': // 取消发车
        this.onCancelDeparture();
        break;
      case '4': // 取消到达
        this.onCancelArrive();
        break;
      case '5': // 修改
        !!detail.id &&
          MBBridge.app.base.openSchemeForResult({ schemeUrl: 'ymm://rn.tms/dispatchedit?id=' + detail.id }).then(() => {
            this.handleGetTaskDetail();
          });
        break;
      case '6': // 删除
        this.changeRemoveModalVisible('needCheck', detail.id);
        break;
      case '9': // 找车看板
        this.gotoCarBoardPage(detail.taskNo);
      case '10': // 重新调度
        this.onDispatchAgain(item.confirmContent);
        break;
      case '14': // 协议
        goNetworkProtocol(detail);
        break;
      case '15': // 北斗轨迹
        NativeBridge.getTmsMoblieUrl().then((res: string) => {
          if (res) {
            const toViewInfo = { taskPkId: detail.id, defaultQueryFlag: false };
            const url = res + 'trackSharing/index?toViewInfo=' + encodeURIComponent(JSON.stringify(toViewInfo));
            NativeBridge.openWebViewPage(url);
          }
        });
        break;
      case '20': //付款申请
        this.goPaymentApplicationPage(detail);
        break;
      case '22': // 退订金
        api_depositRefundReason(detail.mybOrderId).then((res: any) => {
          console.log('================退订金====================');
          if (res) {
            this.openReturnDeposit({ ...res, ...detail, depositStatus: detail?.depositDetail?.depositStatus });
          }
        });
        break;
      default:
        break;
    }
  };
  goPaymentApplicationPage = (item) => {
    // console.log('准备跳转付款申请页面方法', item.invoiceFlag, item.taskId, item.mybOrderId);
    this.props.navigation.navigate('PaymentApplication', {
      invoiceFlag: item.invoiceFlag, //0:不开票 1:专票
      taskId: item.taskId,
      refresh: () => {
        // 刷新列表和任务详情
        this.handleGetTaskDetail();
        this.props.navigation.state.params?.refresh?.();
      },
    });
  };

  // 修改了时间
  changeDateTime(val) {
    this.setState({
      showTimePicker: false,
    });
    const { actionType } = this.state;
    switch (actionType) {
      case 'DEPARTURE':
        this.doDeparture(val);
        break;
      case 'ARRIVAL':
        this.doArrival(val);
        break;
      default:
        break;
    }
  }

  handleClose = () => {
    this.setState({
      showTimePicker: false,
    });
  };

  // 发车
  doDeparture = async (estimateOutsetTime) => {
    try {
      const { detail } = this.state;
      const params = {
        taskId: detail.taskId,
        estimateOutsetTime,
      };
      await Api.doDeparture(params);
      this.handleGetTaskDetail();
      // 刷新列表
      this.props.navigation.state.params?.refresh?.();
    } catch (error) {
      console.log(error);
    }
  };

  // 到达
  doArrival = async (estimateArrivedTime) => {
    try {
      const { detail } = this.state;
      const params = {
        taskId: detail.taskId,
        estimateArrivedTime,
      };
      await Api.doArrival(params);
      this.handleGetTaskDetail();
      // 刷新列表
      this.props.navigation.state.params?.refresh?.();
    } catch (error) {
      console.log(error);
    }
  };

  // 删除&&解绑
  doDelete = (type) => {
    const { detail } = this.state;
    Confirm({
      headerLine: false, // 隐藏头部分割线
      title: ACTION_MAP[type].title,
      content: <MBText>{ACTION_MAP[type].content}</MBText>,
      cancelText: '取消',
      confirmText: '确定',
      onConfirm: async () => {
        try {
          await Api.doRemove({ taskId: detail.taskId });
          NativeBridge.toast(ACTION_MAP[type].toast);
          // 刷新列表
          await this.props.navigation.state.params?.refresh?.();
          this.goBack();
        } catch (error) {
          console.log(error);
        }
      },
    });
  };

  handleScroll = (event) => {
    const { y = 0 } = event.nativeEvent.contentOffset;
    if (y > 60) {
      this.setState({
        title: this.statusBarInfo.status,
      });
    } else {
      this.setState({
        title: '',
      });
    }
  };

  formatCustName = (data) => {
    let str = `${data?.[0]?.customerName || ''}`;
    if (data && data.length > 1) {
      str = `${data[0].customerName}...等${data.length}家`;
    }
    return str;
  };

  // 二期调整的方法

  handleGetTaskDetail = () => {
    const id = this.props.screenProps?.id || this.props.navigation.state.params?.id;
    const {
      taskManageStore: { getTaskDetail },
    } = this.props;

    getTaskDetail({ id }, this.props.navigation);
  };

  // 发车弹窗确认
  onDepartureModalConfirm = (data: any) => {
    const {
      taskManageStore: {
        detail: { taskId },
        postTaskOutset,
        changeDepartureModalVisible,
      },
    } = this.props;

    const params = {
      taskId,
      ...data,
    };

    postTaskOutset(params, () => {
      changeDepartureModalVisible();
      this.handleGetTaskDetail();
      // 刷新列表
      this.props.navigation.state.params?.refresh?.();
    });
  };

  // 到达弹窗确认
  onArriveModalConfirm = (data: any) => {
    const {
      taskManageStore: {
        detail: { taskId },
        postTaskArrive,
        changeArriveModalVisible,
      },
    } = this.props;

    const params = {
      taskId,
      ...data,
    };

    postTaskArrive(params, () => {
      changeArriveModalVisible();
      this.handleGetTaskDetail();
      // 刷新列表
      this.props.navigation.state.params?.refresh?.();
    });
  };

  // 发车
  onConfirmDeparture = () => {
    const {
      taskManageStore: {
        detail: { dispatcherMode, taskState, carrierId, carrierName },
        changeDepartureModalVisible,
        getCarrierList,
        getTruckList,
        getDriverlist,
      },
    } = this.props;

    // 待发车&调度方式为非平台找车下：才需要获取车辆、司机列表、车型、车长
    if (dispatcherMode !== '4' && taskState === 'WAIT_FOR_DEPART') {
      //调度方式为承运商下 才需要获取承运商列表
      if (dispatcherMode === '2') {
        getCarrierList();
      }
      getTruckList({ dispatcherMode, carrierId, carrierName });
      getDriverlist({ dispatcherMode, carrierId, carrierName });
    }

    changeDepartureModalVisible();
  };

  // 取消发车
  onCancelDeparture = () => {
    const {
      taskManageStore: {
        postRevokeOutset,
        detail: { id },
      },
    } = this.props;

    Confirm({
      closable: true,
      headerLine: false,
      title: '取消发车',
      content: '取消发车后该任务单将变成待发车状态',
      cancelText: '取消',
      confirmText: '取消发车',
      // onCancel: () => {},
      onConfirm: () => {
        postRevokeOutset({ ids: [id] }, () => {
          this.handleGetTaskDetail();
          // 刷新列表
          this.props.navigation.state.params?.refresh?.();
        });
      },
    });
  };

  // 取消到达
  onCancelArrive = () => {
    const {
      taskManageStore: {
        postRevokeArrived,
        detail: { id },
      },
    } = this.props;

    Confirm({
      closable: true,
      headerLine: false,
      title: '取消到达',
      content: '取消到达后该任务单将变成待到达状态',
      cancelText: '取消',
      confirmText: '取消到达',
      // onCancel: () => {},
      onConfirm: () => {
        postRevokeArrived({ ids: [id] }, () => {
          this.handleGetTaskDetail();
          // 刷新列表
          this.props.navigation.state.params?.refresh?.();
        });
      },
    });
  };

  // 删除
  async changeRemoveModalVisible(type: string, id: any) {
    // 根据type判断是否需要校验
    if (type === 'needCheck') {
      const data:any = await Api.checkRemoveEnable({ids: [id]});
      if (!!data.data) {
        // 有删除原因的逻辑, 显示原因勾选弹框
        this.setState({
          removeListVisible: true,
          removeMsg: data.msg,
          bottomMsg: data.data.bottomMsg,
          cancelReasonList: [].concat(data.data.cancelReasonList),
          refundDepositRes: data.data.refundDeposit
        });
      } else {
        // 没有删除原因的逻辑, 显示确认删除弹框
        this.setState({ removeListVisible: false });
        Confirm({
          closable: true,
          headerLine: false,
          title: '删除任务单',
          content: <TagContent textAttribute={true} size={autoFix(28)} content={data.msg} />,
          cancelText: '取消',
          confirmText: '删除',
          onConfirm: async () => {
            await Api.doRemove({ids: [id]});
            // 刷新列表
            await this.props.navigation.state.params?.refresh?.();
            this.goBack();
          }
        });
      }
    } else {
      this.setState({
        removeListVisible: false,
        removeMsg: '',
        bottomMsg: '',
        cancelReasonList: [],
        currentCheckedReason: {
          cancelReasonCode: null,
          cancelReasonDesc: '',
          responsibility: null,
          reasonType: null
        },
        refundDeposit: 2
      });
    }
  }
  handleReasonCheck(item: any) {
    const { currentCheckedReason } = this.state;
    if (currentCheckedReason.cancelReasonCode !== null && item.cancelReasonCode === currentCheckedReason.cancelReasonCode) {
      this.setState({
        currentCheckedReason: {
          cancelReasonCode: null,
          cancelReasonDesc: '',
          responsibility: null,
          reasonType: null
        }
      });
    } else {
      this.setState({
        currentCheckedReason: {
          cancelReasonCode: item.cancelReasonCode,
          cancelReasonDesc: item.cancelReasonDesc,
          responsibility: item.responsibility,
          reasonType: item.reasonType
        }
      });
      if (item.cancelReasonCode === -1) {
        this.setState({ refundDeposit: 2 });
      }
    }
  };
  refundDepositChanged(data: any) {
    this.setState({ refundDeposit: data ? 1 : 2 });
  }
  checkboxChanged(data: any) {
    this.setState({ launchResponsibility: data });
  }
  setNote(data: any) {
    this.setState({ launchResponsibilityNote: data });
  }
  // 删除弹框确认
  onRemoveModalConfirm = async () => {
    const {primaryKeyId, launchResponsibility, launchResponsibilityNote, currentCheckedReason, refundDeposit} = this.state;
    let param:any = {
      ids: [primaryKeyId],
      cancelReasonCode: currentCheckedReason.cancelReasonCode,
      refundDeposit: refundDeposit
    };
    // 只删除任务不取消订单时，肯定是不退订金
    if (param.cancelReasonCode === -1 ) {
      param.refundDeposit = 2;
    }
    // 当原因为其他时，添加这两个字段
    if (param.cancelReasonCode === 0) {
      param.launchResponsibility = parseFloat(launchResponsibility[0]);
      param.note = launchResponsibilityNote;
    }
    const data:any = await Api.doRemove(param);
    if (data.success) {
      NativeBridge.toast(data.msg);
      this.changeRemoveModalVisible('noCheck', null);
      // 刷新列表
      await this.props.navigation.state.params?.refresh?.();
      this.goBack();
    }
  };

  /**
   *
   * 新增承运商、车辆、司机回调更新列表
   * @param addType 新增承运商: addCarrier，新增承车辆: addVehicle，新增司机: addDriver,
   * @param carrierData 承运商Id: carrierId, 承运商名称: carrierName
   *
   */
  onaddCallbackDeparture = (addType: string, carrierData: any) => {
    const {
      taskManageStore: {
        detail: { dispatcherMode },
        getLastCarrierTaskInfo,
        getCarrierList,
        getTruckList,
        getDriverlist,
      },
    } = this.props;

    const { carrierId, carrierName } = carrierData;
    const params = { dispatcherMode, carrierId, carrierName };

    console.log(addType, carrierData, '---------');

    if (addType === 'addCarrier') {
      getCarrierList();
      getLastCarrierTaskInfo({ carrierId });
      getTruckList(params);
      getDriverlist(params);
    }

    if (addType === 'addVehicle') {
      getTruckList(params);
    }

    if (addType === 'addDriver') {
      getDriverlist(params);
    }
  };

  // 选择承运商后回调
  selectedCarrierCallback = (value: any) => {
    const {
      taskManageStore: {
        detail: { dispatcherMode },
        getLastCarrierTaskInfo,
        getTruckList,
        getDriverlist,
      },
    } = this.props;

    const { carrierId, carrierName } = value;
    getLastCarrierTaskInfo({ carrierId });
    getTruckList({ dispatcherMode, carrierId, carrierName });
    getDriverlist({ dispatcherMode, carrierId, carrierName });
  };
  goApplyDetail = (item: any) => {
    this.props.navigation.navigate('PaymentApprove', {
      businessNo: item.orderNo,
      businessId: item.orderId,
      refresh: () => null,
      businessCurrentStatus: 0,
    });
  };
  //付款申请单号
  paymentApplicationOrder = (applyNoList: any) => {
    const morePaymentApplicationOrder = () => {
      this.setState({
        showAllPaymentApplicationOrder: !this.state.showAllPaymentApplicationOrder,
      });
    };
    applyNoList = applyNoList || [];
    const paymentApplicationOrder = applyNoList.map((item: any, index: number) => {
      return {
        lable: '付款申请' + (index + 1),
        orderNo: item.applyNo,
        orderId: item.applyId,
      };
    });
    const showOderList = [];
    if (paymentApplicationOrder.length !== 0) showOderList.push(paymentApplicationOrder[0]);
    return (
      <>
        {showOderList.length !== 0 ? (
          <View style={styles.paymentOrderBox}>
            <View style={styles.paymentOrderRow}>
              <MBText style={styles.paymentOrderTitle}>付款申请单号</MBText>
              {paymentApplicationOrder.length !== 1 ? (
                <View style={{ flexDirection: 'row' }}>
                  <MBText onPress={morePaymentApplicationOrder} style={styles.paymentOrderMore}>
                    更多申请单
                  </MBText>
                  <Image style={styles.paymentOrderMoreImg} source={{ uri: images.icon_arrow_gray }}></Image>
                </View>
              ) : null}
            </View>
            {this.state.showAllPaymentApplicationOrder
              ? paymentApplicationOrder.map((item) => {
                  return (
                    <View style={styles.paymentOrderItem}>
                      <MBText style={styles.paymentOrderItemLable}>{item.lable}</MBText>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <MBText onPress={() => this.goApplyDetail(item)} style={styles.paymentOderItemOrderNo}>
                          {item.orderNo}
                        </MBText>
                        <Image style={styles.paymentOrderGoImg} source={{ uri: images.icon_arrow_gray }}></Image>
                      </View>
                    </View>
                  );
                })
              : showOderList.map((item) => {
                  return (
                    <View style={styles.paymentOrderItem}>
                      <MBText style={styles.paymentOrderItemLable}>{item.lable}</MBText>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <MBText onPress={() => this.goApplyDetail(item)} style={styles.paymentOderItemOrderNo}>
                          {item.orderNo}
                        </MBText>
                        <Image style={styles.paymentOrderGoImg} source={{ uri: images.icon_arrow_gray }}></Image>
                      </View>
                    </View>
                  );
                })}
          </View>
        ) : null}
      </>
    );
  };
  // 点击了运输协议
  clickTransDeal() {
    const { invoiceFlag, agreement } = this.props.taskManageStore?.detail || {};
    // 开票才跳转
    if (invoiceFlag == 1) {
      this.onActions({ code: '14' });
    } else if (agreement?.agreementOperationText) {
      MBToast.show(agreement.agreementOperationText);
    }
  }

  render() {
    const {
      title,
      showTimePicker,
      actionType,
      returnDepositData,
      removeListVisible,
      removeMsg,
      bottomMsg,
      cancelReasonList,
      refundDeposit,
      refundDepositRes,
      launchResponsibility,
      launchResponsibilityNote,
      currentCheckedReason
    } = this.state;

    const {
      taskManageStore: {
        loaded,
        detail,
        isDepartureError,
        isArriveError,
        departureVisible,
        arriveVisible,
        carrierList,
        truckList,
        driverList,
        defaultEstimateOutsetTime,
        defaultEstimateArrivedTime,
        defaultCarrierItem,
        defaultVehicleItem,
        defaultDriverItem,
        changeDepartureModalVisible,
        changeArriveModalVisible,
        isAddCarrier,
        isAddVehicle,
        isAddDrive,
        unsaveDefaultVehicleItem,
        unsaveDefaultDriverItem,
        applyNoList,
      },
    } = this.props;
    return (
      loaded && (
        <View style={{ flex: 1 }}>
          <NavBar
            title={title}
            titleStyle={{ color: '#fff' }}
            leftClick={this.goBack}
            bgColor="#4885FF"
            leftElementImagUri={images.icon_goBack}
          />
          <View style={styles.flexing}>
            <ScrollView style={styles.flexing} onScroll={this.handleScroll} scrollEventThrottle={16}>
              <View style={styles.bgImg}>
                <Image fadeDuration={0} resizeMode="stretch" style={{ width: PlatformKit.Width, height: 343 }} source={images.detail_bg} />
              </View>
              <StatusBar info={this.statusBarInfo} />
              <DriverInfo info={this.driverInfo} status={detail.taskState} lookingCarText={detail.lookingCarText} />
              <WaybillInfo info={this.waybillInfo} />
              <LoadInfo loads={this.loadInfo} unLoads={this.unLoadInfo} custName={this.formatCustName(detail.transOrderList)} />
              <CargoInfo info={this.cargoInfo} />
              <FeeInfo info={this.feeInfo} dispatcherMode={detail.dispatcherMode} depositDetail={detail.depositDetail} />
              <InsuranceInfo info={this.insuranceInfo} />
              <SettlementInfo info={this.settlementInfo} />
              <TransDealInfo info={this.agreement} onPress={() => this.clickTransDeal()} />
              <OtherInfo info={this.otherInfo} />
              {this.paymentApplicationOrder(applyNoList)}
            </ScrollView>
            {this.buttonList.length ? (
              <View>
                <View style={[styles.footer, styles.flexRow]}>
                  <FootButtonList maxShowNum={4} buttonList={this.buttonList} onConfirm={(item: any) => this.onActions(item)} />
                </View>
                <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
              </View>
            ) : null}
            <TimePickerModal
              key="start"
              visible={showTimePicker}
              modalTitle={MODAL_TITLE_MAP[actionType]}
              onCancel={this.handleClose}
              onChange={(val: any) => {
                this.changeDateTime(val);
              }}
            />

            <ModalDeparture
              visible={departureVisible}
              carrierList={carrierList}
              truckList={truckList}
              driverList={driverList}
              defaultEstimateOutsetTime={defaultEstimateOutsetTime}
              defaultCarrierItem={defaultCarrierItem}
              defaultVehicleItem={defaultVehicleItem}
              defaultDriverItem={defaultDriverItem}
              unsaveDefaultVehicleItem={unsaveDefaultVehicleItem}
              unsaveDefaultDriverItem={unsaveDefaultDriverItem}
              remark={detail.departRemark}
              sendCarFlag={detail.sendCarFlag}
              invoiceFlag={detail.invoiceFlag}
              dispatcherMode={detail.dispatcherMode}
              isDepartureError={isDepartureError}
              isAddCarrier={isAddCarrier}
              isAddVehicle={isAddVehicle}
              isAddDrive={isAddDrive}
              onConfirm={this.onDepartureModalConfirm}
              onCancel={changeDepartureModalVisible}
              onaddCallbackDeparture={this.onaddCallbackDeparture}
              selectedCarrierCallback={this.selectedCarrierCallback}
            />

            <ModalArrive
              visible={arriveVisible}
              defaultEstimateOutsetTime={defaultEstimateOutsetTime}
              defaultEstimateArrivedTime={defaultEstimateArrivedTime}
              remark={detail.arriveRemark}
              dispatcherMode={detail.dispatcherMode}
              invoiceFlag={detail.invoiceFlag}
              isArriveError={isArriveError}
              onConfirm={this.onArriveModalConfirm}
              onCancel={changeArriveModalVisible}
            />
            <ModalRemove
              visible={removeListVisible}
              removeMsg={removeMsg}
              bottomMsg={bottomMsg}
              cancelReasonList={cancelReasonList}
              refundDeposit={refundDeposit}
              refundDepositRes={refundDepositRes}
              launchResponsibility={launchResponsibility}
              launchResponsibilityNote={launchResponsibilityNote}
              currentCheckedReason={currentCheckedReason}
              onConfirm={() => {
                HandleOnceUtil.callOnceInInterval(() => {
                  this.onRemoveModalConfirm();
                }, 1000);
              }}
              onCancel={() => this.changeRemoveModalVisible('noCheck', null)}
              onSelect={(item: any) => this.handleReasonCheck(item)}
              onChange={(data: any) => this.refundDepositChanged(data)}
              checkboxChanged={(data: any) => this.checkboxChanged(data)}
              setNote={(data: any) => this.setNote(data)}
            />
          </View>
          <OpenDispatchResultModal navigation={this.props.navigation} ref={(el) => (this.refOpenDispatchResult = el)} />
          {!!returnDepositData && (
            <ReturnDeposit
              visible={true}
              onCancel={() => this.openReturnDeposit(null)}
              data={returnDepositData}
              onConfirm={() => {
                this.openReturnDeposit(null);
                this.handleGetTaskDetail();
                for (const index of [0, 1, 2, 3, 4]) {
                  this.props.taskManageStore.refreshTabList[index] = true; // 切换tab 后刷新列表
                }
              }}
            />
          )}
        </View>
      )
    );
  }
}
export default TaskDetail;
