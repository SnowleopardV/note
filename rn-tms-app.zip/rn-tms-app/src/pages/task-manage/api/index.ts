import server from '~/server';
const Api = {
  // 获取任务管理列表
  getTaskList(data, isLoading: boolean = true) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/list',
        data,
      },
      { showLoading: isLoading }
    );
  },
  // 获取任务管理列表数量
  getTaskNum(data) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/count',
        data,
      },
      { showLoading: false }
    );
  },
  // 获取任务管理详情
  getTaskDetail(data) {
    return server({
      url: '/saas-tms-trans/yzgApp/task/detail',
      data,
    });
  },
  // 任务管理-发车
  doDeparture(data) {
    return server({
      url: '/saas-tms-trans/yzgApp/task/outset',
      data,
    });
  },
  // 任务管理-到达
  doArrival(data) {
    return server({
      url: '/saas-tms-trans/yzgApp/task/arrived',
      data,
    });
  },
  // 任务管理-校验任务能否删除
  checkRemoveEnable(data: any) {
    return server({
      url: '/saas-tms-trans/yzgApp/task/mainline/delete/check',
      data
    });
  },
  // 任务管理-删除-new
  doRemove(data: any) {
    return server({
      url: '/saas-tms-trans/yzgApp/task/mainline/delete',
      data
    });
  },

  // 承运商列表
  getCarrierList(data) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/queryCarrierList',
        data,
      },
      { toastError: false }
    );
  },

  // 承运车辆列表
  getTruckList(data) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/queryTruckList',
        data,
      },
      { toastError: false }
    );
  },

  // 承运司机列表
  getDriverlist(data) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/queryDriverList',
        data,
      },
      { toastError: false }
    );
  },
  // 点击付款申请按钮校验接口
  goPaymentApplication(data) {
    return server({
      url: '/saas-financial-app/yzgApp/apply/check',
      data,
    });
  },
  //点击付款申请按钮提交申请按钮接口
  paymentApplySubmit(data) {
    return server({
      url: '/saas-financial-app/yzgApp/apply/submit',
      data,
    });
  },
  //app申请单渲染页面
  paymentApplyInfo(data) {
    return server({
      url: '/saas-financial-app/yzgApp/apply/prepare',
      data,
    });
  },

  // 退订金
  depositRefund(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/deposit/refund',
      data: { ...params },
    });
  },
  // 退还原因查询
  depositRefundReason(params: { mybOrderId: string } | any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/deposit/refundReason',
      data: { ...params },
    });
  },
  // 查询字典--- 收款方式
  payTypeList(params = { dictionaryKey: 'paymentType' }): Promise<any> {
    return server({
      url: '/saas-financial-app/yzgApp/common/dataDictionary/query',
      data: { ...params },
    });
  },
};

export default Api;
