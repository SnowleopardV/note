import { StyleSheet, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import { fixDependencies } from 'mathjs';

export default StyleSheet.create({
  flexing: {
    flex: 1,
  },
  task_list: {
    paddingHorizontal: 10,
    paddingBottom: 10,
  },
  card: {
    width: '100%',
    backgroundColor: '#ffffff',
    marginTop: 10,
    borderRadius: 2,
  },
  actions: {
    paddingVertical: autoFix(20),
    paddingLeft: autoFix(28),
    paddingRight: autoFix(28),
    borderTopWidth: autoFix(1),
    borderTopColor: '#E8E8E8',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  labelFee: {
    fontSize: 14,
    color: '#666',
    paddingTop: 5,
  },
  valueFee: {
    fontSize: 22,
    fontWeight: 'bold',
    // fontFamily: 'DINAlternate-Bold, DINAlternate;',
  },
  driverInfo: {
    marginLeft: 8,
  },
  driverName: {
    fontSize: 14,
    width: 163,
  },
  driverType: {
    paddingHorizontal: 3,
    borderWidth: 0.5,
    fontSize: 10,
    borderRadius: 4,
    borderBottomLeftRadius: 0,
  },
  truckInfo: {
    fontSize: 12,
    color: '#999',
  },
  btn: {
    paddingVertical: 5,
    paddingHorizontal: 16,
    borderRadius: 15,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 6,
  },
  btnTxt: {
    fontSize: 14,
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
    color: '#4885FF',
  },
  empty: {
    height: 600,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
  },
  //侧面搜索Drawer
  titleRightSearch: {
    fontSize: autoFix(30),
    color: '#4885FF',
  },
  drawerTitle: {
    marginTop: autoFix(38),
    marginLeft: autoFix(52),
    fontSize: autoFix(32),
    fontWeight: '600',
  },
  drawLine: {
    marginTop: autoFix(28),
    height: autoFix(1),
    backgroundColor: '#E8E8E8',
  },
  drawInputArea: {
    paddingLeft: autoFix(30),
    paddingRight: autoFix(32),
    paddingTop: autoFix(10),
  },
  drawLable: {
    fontSize: autoFix(28),
    color: '#333333',
    fontWeight: '500',
    marginTop: autoFix(32),
  },
  drawInput: {
    marginTop: autoFix(20),
    backgroundColor: '#F6F6F6',
    height: autoFix(80),
    paddingLeft: autoFix(20),
  },
  bottom: {
    paddingVertical: autoFix(20),
    paddingHorizontal: autoFix(32),
    // display: 'flex',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  clear: {
    borderTopLeftRadius: autoFix(40),
    borderBottomLeftRadius: autoFix(40),
    width: autoFix(145),
    height: autoFix(80),
    borderRightWidth: 0,
  },
  clearBorder: {
    borderColor: '#CCD2DE',
    borderWidth: autoFix(2.67),
  },
  clearText: {
    color: '#4885FF',
    fontSize: autoFix(32),
    lineHeight: autoFix(75),
    textAlign: 'center',
  },
  check: {
    borderTopRightRadius: autoFix(40),
    borderBottomRightRadius: autoFix(40),
    width: autoFix(234),
    height: autoFix(80),
    backgroundColor: '#4885FF',
  },
  checkText: {
    color: '#fff',
    fontSize: autoFix(32),
    lineHeight: autoFix(75),
    textAlign: 'center',
  },
  //
  goPaymentApplicationBtn: {
    paddingVertical: 5,
    paddingHorizontal: 16,
    borderRadius: 15,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 6,
    position: 'relative',
  },
  goPaymentBtnText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4885FF',
  },
});
