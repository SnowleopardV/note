/* eslint-disable max-lines */
import * as React from 'react';
import { View, TouchableOpacity, TouchableWithoutFeedback, Image, Text } from 'react-native';
import { inject, observer } from 'mobx-react';
import { LayProvider, MBText, RefreshList, Drawer, Button, Flex, Field, Modal, TagContent } from '@ymm/rn-elements';
import { PlatformKit, MBJournal, HandleOnceUtil, MBLog, App, AppStateCompat, MBAutoPVComponent } from '@ymm/rn-lib';
import MBTabs from '~/components/common/MBTabs';
import NavBar from '~/components/common/NavBar';
import BaseInfo from '~/components/common/BaseInfo';
import DriverInfo from '~/components/orderDetail/DriverInfo'; // 承运信息
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import Api from '../api';
import { MODAL_TITLE_MAP } from '../status';
import styles from './styles';
import ModalDeparture from '../components/ModalDeparture';
import ModalArrive from '../components/ModalArrive';
import ModalRemove from '../components/ModalRemove';
import threeTimeformat from '~/extends/threeTimeformat';
import dayjs from 'dayjs';
import server from '~/server';
import EmptyPage from '~/components/common/EmptyPage';
import OpenDispatchResultModal from '~/components/OpenDispatchResultModal';
import commonData, { goNetworkProtocol } from '~/pages/commonData';
import FootButtonList from '~/components/FootButtonList';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import images from '~public/static/images';
import NativeBridge from '~/extends/NativeBridge';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import { SafeAreaView } from 'react-native-safe-area-context';
import Confirm from '@ymm/rn-elements/lib/components/Modal/components/Confirm';
import ReturnDeposit, { api_depositRefundReason } from '~/pages/task-manage/components/ReturnDeposit';
import filterFormat from '~/extends/filterFormat';
const FlexItem = Flex.Item;
export interface DawerDemoState {
  visible: boolean;
}
@inject('taskManageStore')
@observer
class TaskList extends MBAutoPVComponent<any, any> {
  now = dayjs();
  search = { list: [], isEnd: false, loading: false, loaded: false };
  refOpenDispatchResult: any;
  pageListener: any;
  constructor(props: any) {
    super(props);
    if (this.props?.screenProps?.source === 'dispatch') {
      this.jump({ id: this.props?.screenProps?.id });
    }
    this.state = {
      tabs: [
        { name: 'ALL', title: '全部', search: { pageNo: 0, pageSize: 20, taskState: 'ALL' }, ...this.search },
        { name: 'LOOKING_CAR', title: '找车中', search: { pageNo: 0, pageSize: 20, taskState: 'LOOKING_CAR' }, ...this.search },
        { name: 'WAIT_FOR_DEPART', title: '待发车', search: { pageNo: 0, pageSize: 20, taskState: 'WAIT_FOR_DEPART' }, ...this.search },
        { name: 'DEPARTED', title: '在途中', search: { pageNo: 0, pageSize: 20, taskState: 'DEPARTED' }, ...this.search },
        { name: 'ARRIVED', title: '已到达', search: { pageNo: 0, pageSize: 20, taskState: 'ARRIVED' }, ...this.search },
      ],
      currentIndex: 0,
      showTimePicker: false,
      actionType: '',
      actionId: '',
      taskItem: {},
      defaultEstimateOutsetTime: {},
      defaultEstimateArrivedTime: {},
      defaultCarrierItem: {},
      defaultVehicleItem: {},
      defaultDriverItem: {},
      isLoading: false,
      errorData: {},
      showPermissionVisible: false,
      MBTabsKey: 'taskManage',
      visible: false, //是否显示侧面弹出搜索框
      searchFormData: {
        driverName: null,
        carNo: null,
        taskNo: null,
        mybOrderId: null,
        dispatcherName: null,
      },
      pageDetailType: 0, //点击申请付款按钮，如果申请付款失败，跳转哪个协议页面 1:创建 2：签署 3：增补
      returnDepositData: null, // 显示退还订金弹窗 需要的字段
      removeListVisible: false, // 删除弹窗的显隐
      removeMsg: '', // 删除弹框显示的msg
      bottomMsg: '', // 删除弹框，底部显示的msg
      cancelReasonList: [], // 删除弹框内取消原因列表
      refundDeposit: 2, // 删除弹框内，是否退订金: 1-退订金, 2-不退订金
      refundDepositRes: 2, // 删除弹框内，是否退订金 - response
      launchResponsibility: ['0'], // 删除弹框内，勾选其他后的原因类型: 0-自己原因，1-司机原因
      launchResponsibilityNote: '', // 删除弹框内，勾选其他后的原因内容
      currentCheckedReason: { // 删除弹框内，当前勾选的原因
        cancelReasonCode: null,
        cancelReasonDesc: '',
        responsibility: null,
        reasonType: null
      },
      primaryKeyId: null // 任务主键id
    };
  }
  openReturnDeposit = (val: any) => {
    this.setState({ returnDepositData: val });
  };
  // 侧面弹出搜索框打开
  open = () => {
    this.setState({
      visible: true,
    });
  };
  //侧面弹出搜索框关闭
  close = () => {
    this.setState({
      visible: false,
    });
  };
  // 侧面弹出搜索框change
  onChange = (isOpen: boolean) => {
    this.setState({
      visible: isOpen,
    });
  };
  async componentDidMount() {
    super.componentDidMount();
    // 是否显示满帮找车发货结果
    if (commonData.cargoRespList?.length) {
      this.refOpenDispatchResult?.openModal();
    }
    await this.getAuthentication({ permissionCode: '120100' });
    // 重新显示该页面需要刷新下tabs,否则会和上一页的tabs显示重合
    this.pageListener = AppStateCompat.addPageActiveListener((active: boolean, willUnMount: boolean) => {
      if (active) {
        this.getTaskList(false, this.state.currentIndex, true); // 刷新当前列表
        //用于解决 运单管理点击修改进入客户名称界面 在返回运单管理导致运单管理的tabs 被覆盖问题
        this.forceUpdate();
      }
    }, this.props);
  }
  componentWillUnmount() {
    super.componentWillUnmount();
    this.pageListener?.remove();
  }

  getPageName() {
    return 'task_manage_list';
  }

  // 鉴权
  getAuthentication = async (parmas: any) => {
    try {
      this.setState({
        isLoading: true,
      });
      const res = await server({
        url: '/saas-tms-trans/yzgApp/tenant/config/authentication',
        data: parmas,
      });
      if (res.success) {
        this.setState({
          errorData: res.data,
          showPermissionVisible: !res.data?.hasPermission,
        });
      }
      // 系统鉴权，单独处理
      if (res.code === '710012' || res.code === '710013') {
        this.setState({
          errorData: {
            image: 'https://image.ymm56.com/ymmfile/saas-tms-pub/detail.png',
            msg: res.msg,
          },
          showPermissionVisible: true,
        });
      }
    } catch (error) {
      MBLog.log({
        message: '获取鉴权失败',
        error: error,
      });
    } finally {
      this.setState({
        isLoading: false,
      });
    }
  };

  getTaskList = async (bool = false, index = 0, showLoading = false) => {
    const { tabs, searchFormData } = this.state;
    let tabItem = tabs[index];
    return Api.getTaskList({ ...tabItem.search, ...searchFormData }, showLoading)
      .then((res: any) => {
        let list = res.data?.list || [];
        list = bool ? tabItem.list.concat(list) : list;
        tabItem = {
          ...tabItem,
          list,
          loading: false,
          isEnd: !res.data?.hasNextPage,
        };
        tabs[index] = tabItem;
        this.setState({ tabs });
        this.props.taskManageStore.refreshTabList[index] = false; // 刷新标记去除
      })
      .catch((err: any) => {
        tabs[index].loading = false;
        this.setState({ tabs });
      });
  };

  // 下拉刷新
  onRefresh(index: number = -1): Promise<any> {
    console.log('----------------下拉刷新-------------');
    //清空搜索框中的内容
    this.setState({
      searchFormData: {
        driverName: '',
        carNo: '',
        taskNo: '',
        mybOrderId: '',
        dispatcherName: '',
      },
    });
    const { tabs, currentIndex } = this.state;
    index = index >= 0 ? index : currentIndex;
    if (tabs[index].loading) return Promise.resolve();
    tabs[index].loading = true;
    tabs[index].search.pageNo = 1;
    this.setState({ tabs });
    return new Promise((resolve) => this.getTaskList(false, index).finally(() => resolve()));
  }

  // 上拉加载
  onLoadMore(): Promise<any> {
    console.log('------------------上拉加载----------------');
    const { tabs, currentIndex } = this.state;
    if (tabs[currentIndex].loading) return Promise.resolve();
    tabs[currentIndex].loading = true;
    tabs[currentIndex].loaded = true;
    ++tabs[currentIndex].search.pageNo;
    this.setState({ tabs });
    return new Promise((resolve) => this.getTaskList(true, currentIndex).finally(() => resolve()));
  }

  changeTab = (index: number, name: string) => {
    const { refreshTabList } = this.props.taskManageStore;
    //清空搜索框中的内容
    this.setState({
      searchFormData: {
        driverName: '',
        carNo: '',
        taskNo: '',
        mybOrderId: '',
        dispatcherName: '',
      },
    });
    this.setState({ currentIndex: index });
    const item = this.state.tabs[index];
    // 如果当前列表已经加载过页面，重新请求下数据
    if (item.loaded && !item.loading) {
      if (!item.list.length || refreshTabList[index]) {
        this.getTaskList(false, index, true); // 刷新当前列表
      }
    }
  };

  jump = (item) => {
    this.props.navigation.navigate('TaskDetail', {
      id: item.id,
      refresh: () => this.onRefresh(),
    });
  };

  handleActions = (btnItem: any, item: any) => {
    const actionType = btnItem.code;
    console.log('------------actionType-----------------', actionType);
    const {
      taskManageStore: { changeArriveModalVisible },
    } = this.props;

    const {
      outsetTime,
      arrivedTime,
      carrierId,
      carrierName,
      carId,
      carNo,
      carType,
      carLength,
      driverId,
      driverName,
      driverPhone,
      carDisplayValue,
      driverDisplayValue,
      dispatcherMode,
      invoiceFlag,
    } = item;

    let handleOutsetTime = null;
    let handleArrivedTime = null;

    // 外调车开票或平台车日期7天范围，否则一个月
    if ((dispatcherMode === '3' && invoiceFlag === '1') || dispatcherMode === '4') {
      // 发车时间：接口获得发车时间在（当前-未来7天）之内，取接口发车时间值，否则取当前时间
      if (
        outsetTime &&
        this.now.hour(0).valueOf() <= outsetTime.endTimestamp &&
        outsetTime.endTimestamp <= this.now.add(7, 'day').hour(0).valueOf()
      ) {
        handleOutsetTime = outsetTime;
      } else {
        handleOutsetTime = threeTimeformat(null);
      }
      // 到达时间：接口获得到达时间在（当前-未来14天）之内，取接口到达时间值，否则取当前时间
      if (
        arrivedTime &&
        this.now.hour(0).valueOf() <= arrivedTime.endTimestamp &&
        arrivedTime.endTimestamp <= this.now.add(14, 'day').hour(0).valueOf()
      ) {
        handleArrivedTime = arrivedTime;
      } else {
        handleArrivedTime = threeTimeformat(null);
      }
    } else {
      // 发车时间：接口获得发车时间在（过去30天-未来30天）之内，取接口发车时间值，否则取当前时间
      if (
        outsetTime &&
        this.now.subtract(30, 'day').hour(0).valueOf() <= outsetTime.endTimestamp &&
        outsetTime.endTimestamp <= this.now.add(30, 'day').hour(0).valueOf()
      ) {
        handleOutsetTime = outsetTime;
      } else {
        handleOutsetTime = threeTimeformat(null);
      }
      // 到达时间：接口获得到达时间在（过去30天-未来37天）之内，取接口到达时间值，否则取当前时间
      if (
        arrivedTime &&
        this.now.subtract(30, 'day').hour(0).valueOf() <= arrivedTime.endTimestamp &&
        arrivedTime.endTimestamp <= this.now.add(37, 'day').hour(0).valueOf()
      ) {
        handleArrivedTime = arrivedTime;
      } else {
        handleArrivedTime = threeTimeformat(null);
      }
    }

    this.setState(
      {
        actionType,
        actionId: item.taskId,
        primaryKeyId: item.id,
        taskItem: item,
        defaultEstimateOutsetTime: handleOutsetTime,
        defaultEstimateArrivedTime: handleArrivedTime,
        defaultCarrierItem: {
          carrierId,
          carrierName,
        },
        defaultVehicleItem: {
          carId,
          carNo,
          carType,
          carLength,
          displayValue: carDisplayValue,
        },
        defaultDriverItem: {
          driverId,
          driverName,
          driverPhone,
          displayValue: driverDisplayValue,
        },
      },
      () => {
        switch (actionType) {
          case '1': // 发车
            this.onConfirmDeparture();
            break;
          case '2': // 到达
            changeArriveModalVisible('list');
            break;
          case '6': // 删除
            this.changeRemoveModalVisible('needCheck', item.id);
            break;
          case '9': // 找车看板
            this.gotoCarBoardPage(item.taskNo);
            break;
          case '14': // 协议
            goNetworkProtocol(item);
            break;
          case '20': //付款申请
            this.goPaymentApplicationPage(item);
            break;
          case '15': // 北斗轨迹
            NativeBridge.getTmsMoblieUrl().then((res: string) => {
              console.log('------------------', res);
              if (res) {
                const toViewInfo = { taskPkId: item.id, defaultQueryFlag: false };
                const url = res + 'trackSharing/index?toViewInfo=' + encodeURIComponent(JSON.stringify(toViewInfo));
                NativeBridge.openWebViewPage(url);
              }
            });
            break;
          case '22': // 退订金
            api_depositRefundReason(item.mybOrderId).then((res: any) => {
              console.log('================退订金====================', res);
              if (res) {
                this.openReturnDeposit({ ...res, ...item });
              }
            });
            break;
          default:
            break;
        }
      }
    );
  };
  //跳转付款申请页面
  goPaymentApplicationPage = (item) => {
    this.props.navigation.navigate('PaymentApplication', {
      invoiceFlag: item.invoiceFlag, //0:不开票 1:专票
      taskId: item.taskId,
      id: item.id,
      refresh: () => this.onRefresh(),
    });
  };
  // 发车
  doDeparture = async (estimateOutsetTime) => {
    try {
      const { actionId, currentIndex } = this.state;
      const params = {
        taskId: actionId,
        estimateOutsetTime,
      };
      await Api.doDeparture(params);
      this.getTaskList(false, currentIndex, true); // 刷新当前列表
      this.props.taskManageStore.refreshTabList[0] = true;
      this.props.taskManageStore.refreshTabList[3] = true; // 切换tab 后刷新 tab = 3 列表
    } catch (error) {
      console.log(error);
    }
  };

  // 到达
  doArrival = async (estimateArrivedTime) => {
    try {
      const { actionId, currentIndex } = this.state;
      const params = {
        taskId: actionId,
        estimateArrivedTime,
      };
      await Api.doArrival(params);
      this.getTaskList(false, currentIndex, true); // 刷新当前列表
      this.props.taskManageStore.refreshTabList[0] = true;
      this.props.taskManageStore.refreshTabList[4] = true;
    } catch (error) {
      console.log(error);
    }
  };

  // 修改了时间
  changeDateTime(val) {
    this.setState({
      showTimePicker: false,
    });
    const { actionType } = this.state;
    switch (actionType) {
      case 'DEPARTURE':
        this.doDeparture(val);
        break;
      case 'ARRIVAL':
        this.doArrival(val);
        break;
      default:
        break;
    }
  }

  handleClose = () => {
    this.setState({
      showTimePicker: false,
    });
  };

  formatCustName = (data) => {
    let str = `${data?.[0]?.customerName || ''}`;
    if (data && data.length > 1) {
      str = `${data[0].customerName}...等${data.length}家`;
    }
    return str;
  };

  // 二期新增方法

  // 发车
  onConfirmDeparture = () => {
    const {
      taskManageStore: { getCarrierList, getTruckList, getDriverlist, getTruckLengthList, getTruckTypeList, changeDepartureModalVisible },
    } = this.props;

    const {
      taskItem: { taskState, dispatcherMode, carrierId, carrierName },
    } = this.state;

    // 待发车&调度方式为非平台找车下：才需要获取车辆、司机列表、车型、车长
    if (dispatcherMode !== '4' && taskState === 'WAIT_FOR_DEPART') {
      //调度方式为承运商下 才需要获取承运商列表
      if (dispatcherMode === '2') {
        getCarrierList();
      }
      getTruckList({ dispatcherMode, carrierId, carrierName });
      getDriverlist({ dispatcherMode, carrierId, carrierName });
      getTruckLengthList({
        toPlatform: false,
        queryType: 0,
      });
      getTruckTypeList({
        toPlatform: false,
        queryType: 0,
      });
    }

    changeDepartureModalVisible('list');
  };

  /**
   *
   * 新增车辆、司机回调更新列表
   * @param addType 新增承车辆: addVehicle，新增司机: addDriver,
   * @param carrierData 承运商Id: carrierId, 承运商名称: carrierName
   *
   */

  onaddCallbackDeparture = (addType: string, carrierData: any) => {
    const {
      taskManageStore: { getTruckList, getDriverlist },
    } = this.props;

    const {
      taskItem: { dispatcherMode },
    } = this.state;

    const { carrierId, carrierName } = carrierData;
    const params = { dispatcherMode, carrierId, carrierName };

    console.log(addType, carrierData, '---------');

    if (addType === 'addVehicle') {
      getTruckList(params);
    }

    if (addType === 'addDriver') {
      getDriverlist(params);
    }
  };

  // 新增&&选择承运商回调
  selectedCarrierCallback = (value: any) => {
    const {
      taskManageStore: { getLastCarrierTaskInfo, getTruckList, getDriverlist },
    } = this.props;

    const { carrierId, carrierName } = value;

    const {
      taskItem: { dispatcherMode },
    } = this.state;

    getLastCarrierTaskInfo({ carrierId, carrierName });
    getTruckList({ dispatcherMode, carrierId, carrierName });
    getDriverlist({ dispatcherMode, carrierId, carrierName });
  };

  // 跳转找车看板页面
  gotoCarBoardPage = (taskNo: string) => {
    this.props.navigation.navigate('CarBoard', { taskNo });
  };
  onCall = (telephone: string) => {
    NativeBridge.dial({ telephone });
  };
  // 点击付款申请按钮，校验失败的弹窗
  defeatGoPaymentApplicationPageConfirm = () => {
    Confirm({
      closable: false, // 1.0.91新增属性，显示差差按钮
      headerLine: false, // 隐藏头部分割线
      hideHeader: false, // 可以隐藏头部: true
      title: '',
      content: (
        <View>
          {/* 点击申请付款按钮，如果申请付款失败，跳转哪个协议页面 1:创建 2：签署 3：增补 */}
          {this.state.pageDetailType === 1 ? (
            <MBText>您选择的订单协议为空，是否签署协议？</MBText>
          ) : this.state.pageDetailType === 2 ? (
            <MBText>您选择的订单主协议货主未签署，是否签署协议？</MBText>
          ) : this.state.pageDetailType === 3 ? (
            <MBText>您选择的订单主协议货主未签署，是否签署协议？</MBText>
          ) : null}
        </View>
      ),
      cancelText: '我知道了',
      confirmText: '签署协议',
      onValid: () => {
        // 可选，confirm之前回调，返回Promise<boolean>，如果不通过弹窗不关闭
        return Promise.resolve(true);
      },
      onConfirm: () => {
        this.state.pageDetailType === 1
          ? // 去创建协议页面
            this.props.navigation.navigate('SuccessPaymentApplication', {})
          : this.state.pageDetailType === 2
          ? // 去协议签署详情页面
            this.props.navigation.navigate('SuccessPaymentApplication', {})
          : // 去增补协议页面
          this.state.pageDetailType === 3
          ? this.props.navigation.navigate('SuccessPaymentApplication', {})
          : null;
      },
      onCancel: () => {
        // todo
      },
    });
  };
  // 付款申请按钮  测试
  goPaymentApplication = (item: any) => {
    this.props.navigation.navigate('PaymentApplication', {
      invoiceFlag: item.invoiceFlag, //0:不开票 1:专票
      taskId: item.taskId,
    });
  };
  renderItem(item: any) {
    const info = {
      orderNo: item.taskNo,
      cargoInfoForDisplay: item.cargoInfoForDisplay,
      loadAddress: item.loadAddress,
      unloadAddress: item.unloadAddress,
      custName: this.formatCustName(item.transOrderList),
      dispatchStatus: item.dispatchStatus,
      loadMessage: item.loadMessage,
      unloadMessage: item.unloadMessage,
      invoiceFlag: item.invoiceFlag,
    };
    // 是否显示司机净得
    const showDriverFee = Boolean(item.taskState === 'LOOKING_CAR' && item.driverFee);
    // 是否显示承运商信息
    const showDriverInfo = item.taskState !== 'LOOKING_CAR' && item.schedulingInfo;
    // 是否显示列表底部部分
    const showBottom = showDriverFee || showDriverInfo || item.buttonList?.length;
    return (
      <TouchableWithoutFeedback key={item.id} onPress={() => this.jump(item)}>
        <View style={styles.card}>
          <BaseInfo info={info}>
            {showDriverInfo ? (
              <View style={[styles.actions, styles.flexRow, { padding: autoFix(20) }]}>
                <DriverInfo info={item.schedulingInfo || null} source="list" />
                {item?.schedulingInfo?.driverPhone ? (
                  <TouchableOpacity activeOpacity={0.3} onPress={() => this.onCall(item.schedulingInfo.driverPhone)}>
                    <View style={{ marginLeft: 5 }}>
                      <Image style={{ width: 32, height: 32 }} source={images.icon_telephone} />
                    </View>
                  </TouchableOpacity>
                ) : null}
              </View>
            ) : null}
            {!!showBottom && (
              <TouchableWithoutFeedback onPress={() => null}>
                <View style={styles.actions}>
                  <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginBottom: autoFix(12) }}>
                    {!!item.contractStatusDoc && (
                      <MBText color="#999999" size="xs">
                        {item.contractStatusDoc}
                      </MBText>
                    )}
                    {!!item.deposit && (
                      <View style={[styles.flexRow, { marginLeft: autoFix(20) }]}>
                        <MBText color="#999999" size="xs">
                          订金
                        </MBText>
                        <MBText color="#FF6969" size="xs">
                          ¥{filterFormat.moneyDecFormat(item.deposit)}
                        </MBText>
                        {!!item.depositStatusDesc && (
                          <MBText color="#999999" size="xs">
                            ({item.depositStatusDesc})
                          </MBText>
                        )}
                      </View>
                    )}
                  </View>
                  <View style={[styles.flexRow, { justifyContent: 'flex-end' }]}>
                    {item.buttonList?.length ? (
                      <FootButtonList maxShowNum={4} buttonList={item.buttonList} onConfirm={(btn: any) => this.handleActions(btn, item)} />
                    ) : null}
                  </View>
                </View>
              </TouchableWithoutFeedback>
            )}
          </BaseInfo>
        </View>
      </TouchableWithoutFeedback>
    );
  }

  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <MBText style={styles.emptyText}>暂无数据</MBText>
      </View>
    );
  };

  // 发车弹窗确认
  onDepartureModalConfirm = (data: any) => {
    const { actionId, currentIndex } = this.state;
    const {
      taskManageStore: { postTaskOutset, changeDepartureModalVisible },
    } = this.props;

    const params = {
      taskId: actionId,
      ...data,
    };

    postTaskOutset(params, () => {
      changeDepartureModalVisible('list');
      this.getTaskList(false, currentIndex, true); // 刷新当前列表
      this.props.taskManageStore.refreshTabList[0] = true;
      this.props.taskManageStore.refreshTabList[3] = true;
    });
  };

  // 到达弹窗确认
  onArriveModalConfirm = (data: any) => {
    const { actionId, currentIndex } = this.state;
    const {
      taskManageStore: { postTaskArrive, changeArriveModalVisible },
    } = this.props;

    const params = {
      taskId: actionId,
      ...data,
    };

    postTaskArrive(params, () => {
      changeArriveModalVisible('list');
      this.getTaskList(false, currentIndex, true); // 刷新当前列表
      this.props.taskManageStore.refreshTabList[0] = true;
      this.props.taskManageStore.refreshTabList[4] = true;
    });
  };

  async changeRemoveModalVisible(type: string, id: any) {
    const { currentIndex } = this.state;
    // 根据type判断是否需要校验
    if (type === 'needCheck') {
      const data:any = await Api.checkRemoveEnable({ids: [id]});
      if (!!data.data) {
        // 有删除原因的逻辑, 显示原因勾选弹框
        this.setState({
          removeListVisible: true,
          removeMsg: data.msg,
          bottomMsg: data.data.bottomMsg,
          cancelReasonList: [].concat(data.data.cancelReasonList),
          refundDepositRes: data.data.refundDeposit
        });
      } else {
        // 没有删除原因的逻辑, 显示确认删除弹框
        this.setState({ removeListVisible: false });
        Modal.Confirm({
          closable: true,
          headerLine: false,
          title: '删除任务单',
          content: <TagContent textAttribute={true} size={autoFix(28)} content={data.msg} />,
          cancelText: '取消',
          confirmText: '删除',
          onConfirm: async () => {
            await Api.doRemove({ids: [id]});
            // 刷新列表
            setTimeout(() => {
              this.getTaskList(false, currentIndex, true); // 刷新当前列表
            }, 1500);
            for (const i in [0, 1, 2, 3, 4]) {
              if (i !== currentIndex) {
                this.props.taskManageStore.refreshTabList[i] = true;
              }
            }
          }
        });
      }
    } else {
      this.setState({
        removeListVisible: false,
        removeMsg: '',
        bottomMsg: '',
        cancelReasonList: [],
        currentCheckedReason: {
          cancelReasonCode: null,
          cancelReasonDesc: '',
          responsibility: null,
          reasonType: null
        },
        refundDeposit: 2
      });
    }
  }

  handleReasonCheck(item: any) {
    const { currentCheckedReason } = this.state;
    if (currentCheckedReason.cancelReasonCode !== null && item.cancelReasonCode === currentCheckedReason.cancelReasonCode) {
      this.setState({
        currentCheckedReason: {
          cancelReasonCode: null,
          cancelReasonDesc: '',
          responsibility: null,
          reasonType: null
        }
      });
    } else {
      this.setState({
        currentCheckedReason: {
          cancelReasonCode: item.cancelReasonCode,
          cancelReasonDesc: item.cancelReasonDesc,
          responsibility: item.responsibility,
          reasonType: item.reasonType
        }
      });
      if (item.cancelReasonCode === -1) {
        this.setState({ refundDeposit: 2 });
      }
    }
  };

  refundDepositChanged(data: any) {
    this.setState({ refundDeposit: data ? 1 : 2 });
  }

  checkboxChanged(data: any) {
    this.setState({ launchResponsibility: data });
  }

  setNote(data: any) {
    this.setState({ launchResponsibilityNote: data });
  }

  // 删除弹框确认
  onRemoveModalConfirm = async () => {
    const {currentIndex, primaryKeyId, launchResponsibility, launchResponsibilityNote, currentCheckedReason, refundDeposit} = this.state;
    let param:any = {
      ids: [primaryKeyId],
      cancelReasonCode: currentCheckedReason.cancelReasonCode,
      refundDeposit: refundDeposit
    };
    // 只删除任务不取消订单时，肯定是不退订金
    if (param.cancelReasonCode === -1 ) {
      param.refundDeposit = 2;
    }
    // 当原因为其他时，添加这两个字段
    if (param.cancelReasonCode === 0) {
      param.launchResponsibility = parseFloat(launchResponsibility[0]);
      param.note = launchResponsibilityNote;
    }
    const data:any = await Api.doRemove(param);
    if (data.success) {
      NativeBridge.toast(data.msg);
      this.changeRemoveModalVisible('noCheck', null);
      // 刷新列表
      setTimeout(() => {
        this.getTaskList(false, currentIndex, true); // 刷新当前列表
      }, 1500);
      for (const i in [0, 1, 2, 3, 4]) {
        if (i !== currentIndex) {
          this.props.taskManageStore.refreshTabList[i] = true;
        }
      }
    }
  };

  renderListContent = (index: number) => {
    const { tabs, currentIndex } = this.state;
    return (
      <View style={[styles.flexing, styles.task_list]}>
        <RefreshList
          isEnd={tabs[index]?.isEnd}
          data={tabs[index]?.list}
          showsVerticalScrollIndicator={false}
          renderItem={(item: any) => this.renderItem(item)}
          emptyRender={this.renderEmpty}
          onRefresh={this.onRefresh.bind(this)}
          onLoadMore={this.onLoadMore.bind(this)}
        />
      </View>
    );
  };
  // 侧面搜索抽屉的内容
  renderSearchList = () => {
    const searchList = [
      { label: '司机姓名', placeholder: '请输入司机姓名', value: 'driverName' },
      { label: '车牌号', placeholder: '请输入车牌号,支持三位及以上模糊查询', value: 'carNo' },
      { label: '任务单号', placeholder: '请输入任务单号,支持三位及以上模糊查询', value: 'taskNo' },
      { label: '平台订单号', placeholder: '请输入平台订单号,支持三位及以上模糊查询', value: 'mybOrderId' },
      { label: '调度员', placeholder: '请输入调度员', value: 'dispatcherName' },
    ];
    return (
      <>
        {searchList.map((item) => {
          return (
            <Flex direction="row">
              <FlexItem>
                <View>
                  <MBText style={styles.drawLable}>{item.label}</MBText>
                  <TextInput
                    style={styles.drawInput}
                    placeholder={item.placeholder}
                    value={this.state.searchFormData[item.value]}
                    onChangeText={(value) => {
                      if (value === '') {
                        value = null;
                      }
                      this.setState({
                        searchFormData: {
                          ...this.state.searchFormData,
                          [item.value]: value,
                        },
                      });
                    }}
                  ></TextInput>
                </View>
              </FlexItem>
            </Flex>
          );
        })}
      </>
    );
  };
  // 侧面抽屉搜索
  searchList = (bool = false, index = 0, showLoading = true) => {
    const { tabs } = this.state;
    let tabItem = tabs[this.state.currentIndex];
    const params = {
      ...tabItem.search,
      ...this.state.searchFormData,
    };
    console.log(params, '---------params-----');
    return Api.getTaskList(params, showLoading)
      .then((res: any) => {
        this.close();
        console.log(res.data.list[1], '---------params-----');
        let list = res.data?.list || [];
        list = bool ? tabItem.list.concat(list) : list;
        tabItem = {
          ...tabItem,
          list,
          loading: false,
          isEnd: !res.data?.hasNextPage,
        };
        tabs[index] = tabItem;
        this.setState({ tabs });
        this.props.taskManageStore.refreshTabList[index] = false; // 刷新标记去除
      })
      .catch((err: any) => {
        tabs[index].loading = false;
        this.setState({ tabs });
      });
  };
  render() {
    const {
      currentIndex,
      tabs,
      showTimePicker,
      actionType,
      taskItem,
      defaultCarrierItem,
      defaultVehicleItem,
      defaultDriverItem,
      defaultEstimateOutsetTime,
      defaultEstimateArrivedTime,
      isLoading,
      showPermissionVisible,
      errorData,
      returnDepositData,
      removeListVisible,
      removeMsg,
      bottomMsg,
      cancelReasonList,
      refundDeposit,
      refundDepositRes,
      launchResponsibility,
      launchResponsibilityNote,
      currentCheckedReason
    } = this.state;

    const {
      taskManageStore: {
        isDepartureError,
        isArriveError,
        departureListVisible,
        arriveListVisible,
        carrierList,
        truckList,
        driverList,
        changeDepartureModalVisible,
        changeArriveModalVisible,
        isAddCarrier,
        isAddVehicle,
        isAddDrive,
        unsaveDefaultVehicleItem,
        unsaveDefaultDriverItem,
      },
    } = this.props;
    // 右边弹窗
    const navigationView = (
      <SafeAreaView style={{ flex: 1 }}>
        <Flex direction="row">
          <FlexItem>
            <MBText style={styles.drawerTitle}>在【{tabs[currentIndex].title}】下搜索</MBText>
            <View style={styles.drawLine}></View>
          </FlexItem>
        </Flex>
        <ScrollView style={{ flex: 1 }}>
          <View style={styles.drawInputArea}>{this.renderSearchList()}</View>
        </ScrollView>
        <View>
          <View style={styles.drawLine}></View>
          <View style={styles.bottom}>
            <TouchableOpacity
              style={styles.clear}
              onPress={() => {
                // TODO clear
                this.setState({
                  searchFormData: {
                    driverName: '',
                    carNo: '',
                    taskNo: '',
                    mybOrderId: '',
                    dispatcherName: '',
                  },
                });
              }}
            >
              <View style={[styles.clear, styles.clearBorder]}>
                <MBText style={styles.clearText}>清空</MBText>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.check]}
              onPress={() => {
                this.searchList(false, currentIndex);
              }}
            >
              <View style={[styles.check]}>
                <MBText style={[styles.checkText]}>查询</MBText>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
    return (
      <View style={{ flex: 1 }}>
        <Drawer visible={this.state.visible} position="right" navigationView={navigationView} onChange={this.onChange}>
          <View style={styles.flexing}>
            <NavBar
              title="任务管理"
              rightElement={
                <View style={{ display: 'flex', flexDirection: 'row' }}>
                  <MBText style={styles.titleRightSearch} onPress={this.open}>
                    筛选
                  </MBText>
                </View>
              }
            />
            {!isLoading ? (
              showPermissionVisible ? (
                <EmptyPage errorData={errorData} />
              ) : (
                <View style={styles.flexing}>
                  <MBTabs
                    tabs={[...tabs]}
                    defaultIndex={currentIndex}
                    renderTitle={(isActive: boolean, name: string) => (
                      <MBText style={{ color: isActive ? '#4885FF' : '#000' }}>{name}</MBText>
                    )}
                    onTabChange={this.changeTab}
                    renderList={this.renderListContent}
                  />
                  <TimePickerModal
                    key="start"
                    modalTitle={MODAL_TITLE_MAP[actionType]}
                    visible={showTimePicker}
                    onCancel={this.handleClose}
                    onChange={(data: any) => {
                      HandleOnceUtil.callOnceInInterval(() => {
                        this.changeDateTime(data);
                      }, 1000);
                    }}
                  />
                  <ModalDeparture
                    visible={departureListVisible}
                    carrierList={carrierList}
                    truckList={truckList}
                    driverList={driverList}
                    defaultEstimateOutsetTime={defaultEstimateOutsetTime}
                    defaultEstimateArrivedTime={defaultEstimateArrivedTime}
                    defaultCarrierItem={defaultCarrierItem}
                    defaultVehicleItem={defaultVehicleItem}
                    defaultDriverItem={defaultDriverItem}
                    unsaveDefaultVehicleItem={unsaveDefaultVehicleItem}
                    unsaveDefaultDriverItem={unsaveDefaultDriverItem}
                    remark={taskItem.departRemark}
                    sendCarFlag={taskItem.sendCarFlag}
                    invoiceFlag={taskItem.invoiceFlag}
                    dispatcherMode={taskItem.dispatcherMode}
                    isDepartureError={isDepartureError}
                    isAddCarrier={isAddCarrier}
                    isAddVehicle={isAddVehicle}
                    isAddDrive={isAddDrive}
                    onConfirm={(data: any) => {
                      HandleOnceUtil.callOnceInInterval(() => {
                        this.onDepartureModalConfirm(data);
                      }, 1000);
                    }}
                    onCancel={() => changeDepartureModalVisible('list')}
                    onaddCallbackDeparture={this.onaddCallbackDeparture}
                    selectedCarrierCallback={this.selectedCarrierCallback}
                  />
                  <ModalArrive
                    visible={arriveListVisible}
                    defaultEstimateOutsetTime={defaultEstimateOutsetTime}
                    defaultEstimateArrivedTime={defaultEstimateArrivedTime}
                    remark={taskItem.arriveRemark}
                    dispatcherMode={taskItem.dispatcherMode}
                    invoiceFlag={taskItem.invoiceFlag}
                    isArriveError={isArriveError}
                    onConfirm={(data: any) => {
                      HandleOnceUtil.callOnceInInterval(() => {
                        this.onArriveModalConfirm(data);
                      }, 1000);
                    }}
                    onCancel={() => changeArriveModalVisible('list')}
                  />
                  <ModalRemove
                    visible={removeListVisible}
                    removeMsg={removeMsg}
                    bottomMsg={bottomMsg}
                    cancelReasonList={cancelReasonList}
                    refundDeposit={refundDeposit}
                    refundDepositRes={refundDepositRes}
                    launchResponsibility={launchResponsibility}
                    launchResponsibilityNote={launchResponsibilityNote}
                    currentCheckedReason={currentCheckedReason}
                    onConfirm={() => {
                      HandleOnceUtil.callOnceInInterval(() => {
                        this.onRemoveModalConfirm();
                      }, 1000);
                    }}
                    onCancel={() => this.changeRemoveModalVisible('noCheck', null)}
                    onSelect={(item: any) => this.handleReasonCheck(item)}
                    onChange={(data: any) => this.refundDepositChanged(data)}
                    checkboxChanged={(data: any) => this.checkboxChanged(data)}
                    setNote={(data: any) => this.setNote(data)}
                  />
                </View>
              )
            ) : null}
          </View>
          <OpenDispatchResultModal navigation={this.props.navigation} ref={(el) => (this.refOpenDispatchResult = el)} />
          {!!returnDepositData && (
            <ReturnDeposit
              visible={true}
              onCancel={() => this.openReturnDeposit(null)}
              onConfirm={() => {
                this.openReturnDeposit(null);
                this.getTaskList(false, currentIndex, true); // 刷新当前列表
                for (const index of [0, 1, 2, 3, 4]) {
                  if (index != currentIndex) {
                    this.props.taskManageStore.refreshTabList[index] = true; // 切换tab 后刷新列表
                  }
                }
              }}
              data={returnDepositData}
            />
          )}
        </Drawer>
      </View>
    );
  }
}

export default TaskList;
