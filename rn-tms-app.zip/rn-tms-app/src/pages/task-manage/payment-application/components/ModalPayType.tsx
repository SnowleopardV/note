import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, MBText, Whitespace, RNElementsUtil, CellGroup, Switch } from '@ymm/rn-elements';

// 收款方式

interface Props {
  visible?: boolean;
  onChange?: any;
  default?: string;
  list?: any[];
}
export default class ModalPayType extends React.Component<Props, any> {
  static defaultProps = {
    default: null,
  };
  constructor(props: any) {
    super(props);
    this.state = {
      position: 0,
      list: [],
    };
  }
  componentDidMount() {
    const position = this.listData.findIndex((item: any) => item.optionValue === this.props.default);
    this.setState({ position: position == -1 ? 0 : position });
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { position } = this.state;
    const item = this.listData[position];
    onChange && onChange(item?.optionValue || -1);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleChange = (position: number) => {
    this.setState({ position: position });
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  get listData(): any[] {
    const data = [
      {
        optionValue: '',
        content(selected: boolean) {
          return (
            <Flex direction="row" justify="center" align="center">
              <MBText bold={selected} size="md" color={selected ? 'primary' : 'base'} numberOfLines={1}>
                无
              </MBText>
            </Flex>
          );
        },
      },
    ];
    const data1 = this.props.list?.map((item: any) => {
      return {
        text: item.optionText,
        optionValue: item.optionValue,
        content(selected: boolean) {
          return (
            <Flex direction="row" justify="center" align="center">
              <MBText bold={selected} size="md" color={selected ? 'primary' : 'base'} numberOfLines={1}>
                {item.optionText || ''}
              </MBText>
            </Flex>
          );
        },
      };
    });
    return data.concat(data1 || []);
  }

  get isChecked() {
    const { defaultPhone, position } = this.state;
    const item: { text: string | undefined; content: JSX.Element } = this.listData[position];
    return defaultPhone === item.text;
  }
  render() {
    const { visible } = this.props;
    const { position } = this.state;
    return (
      <Modal
        headerLeft="取消"
        headerRight={this.rightElement()}
        title="请选择收款方式"
        position="bottom"
        visible={visible}
        headerLine={false}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        {this.listData?.length ? (
          <View style={styles.content}>
            <Selector type={2} value={position} rowTitle="content" list={this.listData} onChange={this.handleChange} />
          </View>
        ) : (
          <MBText style={{ marginVertical: 50 }} color="#999999">
            暂无数据
          </MBText>
        )}
        <Whitespace vertical={34} />
      </Modal>
    );
  }
}
const styles = StyleSheet.create({
  content: {
    width: '100%',
    zIndex: -1,
    marginHorizontal: RNElementsUtil.autoFix(-34),
    flexDirection: 'column',
  },
  cellTitle: {
    color: '#333333',
    fontSize: RNElementsUtil.autoFix(32),
    fontWeight: '400',
  },
});
