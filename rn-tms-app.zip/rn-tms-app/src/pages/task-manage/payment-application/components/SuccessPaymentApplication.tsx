import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';
import { LayProvider, MBText } from '@ymm/rn-elements';
import React, { useEffect } from 'react';
import NavBar from '~/components/common/NavBar';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import images from '~public/static/images';
import { inject, observer } from 'mobx-react';
import { MBBridge } from '@ymm/rn-lib';

const SuccessPaymentApplication = (props: any) => {
  const { applyId, applyNo } = props.navigation.state.params?.dataList[0] || {};
  const onLeftClick = () => {
    props.navigation.goBack();
  };
  const goDetail = () => {
    props.navigation.navigate('PaymentApprove', {
      businessNo: applyNo,
      businessId: applyId,
      refresh: () => null,
      businessCurrentStatus: 0,
    });
  };
  const goList = () => {
    props.navigation.navigate('TaskList', {}); // 到任务列表页
  };
  return (
    <LayProvider theme="skyblue">
      <View>
        <NavBar title="付款申请" leftClick={onLeftClick} />
        <View style={styles.container}>
          <Image style={styles.icon_success} source={images.icon_success}></Image>
          <MBText style={styles.success_text}>付款申请单提交成功</MBText>
          <TouchableOpacity onPress={goDetail}>
            <View style={styles.detailBtn}>
              <MBText style={styles.detailBtnText}>查看详情</MBText>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={goList}>
            <View style={styles.returnBtn}>
              <MBText style={styles.returnBtnText}>返回首页</MBText>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </LayProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    marginTop: autoFix(20),
    marginLeft: autoFix(28),
    marginRight: autoFix(28),
    paddingBottom: autoFix(60),
    alignItems: 'center',
  },
  icon_success: {
    marginTop: autoFix(80),
    height: autoFix(140),
    width: autoFix(174),
  },
  success_text: {
    marginTop: autoFix(55),
    fontSize: autoFix(40),
    fontWeight: '500',
    color: '#333333',
  },
  detailBtn: {
    width: autoFix(332),
    height: autoFix(80),
    backgroundColor: '#4885FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: autoFix(40),
  },
  detailBtnText: {
    fontSize: autoFix(34),
    fontWeight: '400',
    color: '#fff',
  },
  returnBtn: {
    marginTop: autoFix(40),
    width: autoFix(332),
    height: autoFix(80),
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#DDDDDD',
    borderWidth: autoFix(2),
  },
  returnBtnText: {
    fontSize: autoFix(34),
    fontWeight: '400',
    color: '#333333',
  },
});

export default inject('taskManageStore')(observer(SuccessPaymentApplication));
