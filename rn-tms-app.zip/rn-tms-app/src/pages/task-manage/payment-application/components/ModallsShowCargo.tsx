import { SafeAreaView, TouchableOpacity, View } from 'react-native';
import { Flex, MBText, Modal, Whitespace } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import React from 'react';
const FlexItem = Flex.Item;

const ModalShowCargo = (props: any) => {
  const { visible, onConfirm, onCancel, cargoList } = props;
  const onModalConfirm = () => {
    onConfirm && onConfirm();
  };
  // const allCargo = cargoList.map((item) => {
  //   let str = '';
  //   if (item.split('|')[0].length > 5) {
  //     str = item.split('|')[0].slice(0, 3) + '...';
  //   }
  //   return {
  //     cargoName: str || item.split('|')[0],
  //     restCargo: item.split('|').slice(1).join('|'),
  //   };
  // });

  const rightElement = () => {
    return (
      <TouchableOpacity onPress={() => onModalConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            关闭
          </MBText>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Modal
        headerRight={rightElement()}
        title="货物信息"
        position="bottom"
        visible={visible}
        autoAdjustPosition={true}
        headerLine={false}
        onConfirm={onModalConfirm}
        onCancel={() => {
          onCancel && onCancel();
        }}
        onMaskClose={() => {
          onCancel && onCancel();
        }}
        onRequestClose={() => {
          onCancel && onCancel();
        }}
      >
        <View style={{ alignItems: 'center', paddingBottom: autoFix(50) }}>
          {cargoList.map((item: any, index: number) => {
            return (
              <Flex direction="row" justify="space-between" style={{ marginTop: autoFix(20) }}>
                <FlexItem style={{ alignSelf: 'flex-start' }}>
                  <View>
                    <MBText style={{ fontSize: autoFix(24) }}>货物{index + 1}</MBText>
                  </View>
                </FlexItem>
                <FlexItem>
                  <View style={{ alignSelf: 'flex-end' }}>
                    <MBText style={{ fontWeight: '500', color: '#666666', fontSize: autoFix(24) }}>{item}</MBText>
                  </View>
                </FlexItem>
              </Flex>
            );
          })}
        </View>
        <Whitespace vertical={40} />
      </Modal>
    </SafeAreaView>
  );
};

export default ModalShowCargo;
