import { Flex, MBText, Whitespace, Checkbox, Modal } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity, ImageBackground, SafeAreaView } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import NavBar from '~/components/common/NavBar';
import images from '~public/static/images';
import ModalIsInvoice from './components/ModallsShowCargo';
import Images from '../../../../public/static/images';
import API from '../api/index';
import Api from '../api/index';

import { goNetworkProtocol } from '../../commonData';
import { xyzMath } from '~/utils/xyzMath';
import InputItem from '~/components/common/InputItem';
import { MBBridge } from '@ymm/rn-lib';
import ModalPayType from './components/ModalPayType';
const FlexItem = Flex.Item;

class PaymentApplication extends React.Component<any, any> {
  addresLayoutHeight: number = 0;
  unAddressHeight: number = 0;
  constructor(props: any) {
    super(props);
    this.state = {
      taskNo: '',
      visiable: false,
      driverPhoto: { uri: 'https://imagecdn.ymm56.com/ymmfile/tms-uc/app/transtask/driver_default_photo.png' },
      driverName: '',
      truckNum: '',
      loadAddress: '',
      unloadAddress: '',
      // 不开票
      checkList1: [],
      // 专票
      checkList2: [],
      // 普票
      checkList3: [],
      cargoList: [],
      settleMethod: '', //结算方式
      invoiceFlag: Number(props.navigation.state.params.invoiceFlag), //申请详情页的类型 0:不开票，1:专票
      totalPrice: 0, //申请金额预计
      serviceAmount: 0, //附加运费
      dditionalFreight: 0, //附加运费
      taskId: props.navigation.state.params.taskId,
      mbOrderId: '',
      driverPhone: '',
      invoiceType: '', // 财务域的类型 1不开票 2专票 3普票
      subjectType: '',
      id: 0,
      line_height: 0,
      collectMoneyList: [
        { type: 'select', key: 'payType', title: '收款方式', placeholder: '请选择', value: null },
        { type: 'input', key: 'accountName', title: '收款账户', placeholder: '请输入', value: '' },
        { type: 'number', key: 'accountNumber', title: '收款账号', placeholder: '请输入', value: '' },
        { type: 'input', key: 'bankName', title: '收款银行', placeholder: '请输入', value: '' },
        { type: 'number', key: 'bankNumber', title: '收款联行号', placeholder: '请输入', value: '' },
        { type: 'input', key: 'payRemark', title: '收款备注', placeholder: '请输入', value: '' },
      ],
      payTypeList: [], // 付款方式
      showModalPayType: false, // 显示付款方式选择弹窗
      noInvoiceMap: {
        '1': { payWay: 1, label: '', title: '现付款' },
        '2': { payWay: 2, label: '', title: '到付款' },
        '3': { payWay: 3, label: '', title: '回单款' },
        '4': { payWay: 4, label: '', title: '月结' },
        '5': { payWay: 5, label: '', title: '油卡' },
        '6': { payWay: 6, label: '', title: '费用调整' },
      },
    };
  }

  componentDidMount() {
    MBBridge.rnruntime.IQKeyboard({ enable: true });
    this.setState({
      invoiceFlag: Number(this.props.navigation.state.params.invoiceFlag), //申请详情页的类型 0:不开票，1:专票
      id: this.props.navigation.state.params.id,
    });

    const params = {
      taskId: this.state.taskId,
    };
    API.paymentApplyInfo(params)
      .then((res) => {
        const data = res.data;
        if (res.code === '10000') {
          data.invoiceType = data.invoiceType || 1;
          this.setState({
            mbOrderId: data.mbOrderId || '',
            driverPhone: data.driverPhone || '',
            invoiceType: data.invoiceType,
            subjectType: data.subjectType || '',
          });
          if (data.invoiceType === 1) {
            // 不开票
            this.api_payTypeList(); // 获取收款方式列表
            const filterAppApplyFeeInfoList: { payWay: number; applicableAmount: any; serviceAmount: any }[] = [];
            const paywayList = [1, 2, 3, 4, 5, 6];
            data.appApplyFeeInfoList.forEach((item: any) => {
              if (!paywayList.includes(item.payWay)) return;
              filterAppApplyFeeInfoList.push(item);
            });
            const initAppApplyFeeInfoList = filterAppApplyFeeInfoList.map(
              (item: { payWay: number; applicableAmount: any; serviceAmount: any }) => {
                const { noInvoiceMap } = this.state;
                return {
                  title: noInvoiceMap[item.payWay].title,
                  price: xyzMath.divide(Number(item.applicableAmount), 100),
                  id: item.payWay,
                  checked: false,
                  disabled: false,
                  label: noInvoiceMap[item.payWay].label,
                  serviceAmount: Number(item.serviceAmount) === 0 ? 0 : xyzMath.divide(Number(item.serviceAmount), 100),
                };
              }
            );
            this.setState(
              {
                truckNum: data.carNo || '',
                cargoList: data.cargoInfoList || [],
                loadAddress: data.loadAddress || '',
                unloadAddress: data.unloadAddress || '',
                taskNo: data.taskNo || '',
                driverName: data.subjectName || '',
                checkList1: initAppApplyFeeInfoList || [],
              },
              () => {
                this.getTotalApply();
              }
            );
          } else if (data.invoiceType === 2) {
            //专票
            const paywayMap = {};
            data.appApplyFeeInfoList.forEach((item: any) => {
              paywayMap[item.payWay] = item;
            });
            const initList = [
              { payWay: 1, label: '', title: '现付款', checked: false, disabled: false },
              { payWay: 2, label: '同时支付到付款', title: '到付款', checked: false, disabled: false },
              { payWay: 3, label: '同时支付回单款', title: '回单款', checked: false, disabled: false },
              // { payWay: 4, label: '', title: '月结', checked: false, disabled: false },
              { payWay: 5, label: '同时支付油卡', title: '油卡', checked: false, disabled: false },
            ];
            const initAppApplyFeeInfoList = initList
              .map((item: any) => {
                const paywayData = paywayMap[item.payWay];
                if (paywayData) {
                  return {
                    ...item,
                    id: item.payWay,
                    price: xyzMath.divide(Number(paywayData.applicableAmount), 100),
                    serviceAmount: Number(paywayData.serviceAmount) ? xyzMath.divide(Number(paywayData.serviceAmount), 100) : 0,
                  };
                } else {
                  return null;
                }
              })
              .filter((item) => !!item);
            // 置灰以及默认勾选第一分段 (现付-油卡)、(到付款)、(回单款)，谁在第一个就默认勾选上，无法取消
            if (initAppApplyFeeInfoList[0].payWay == 1 || initAppApplyFeeInfoList[0].payWay == 5) {
              initAppApplyFeeInfoList.forEach((item: any) => {
                if (item.payWay == 1 || item.payWay == 5) {
                  item.disabled = true;
                  item.checked = true;
                }
              });
            } else {
              initAppApplyFeeInfoList[0].disabled = true;
              initAppApplyFeeInfoList[0].checked = true;
            }

            this.setState(
              {
                truckNum: data.carNo || '',
                cargoList: data.cargoInfoList || [],
                loadAddress: data.loadAddress || '',
                unloadAddress: data.unloadAddress || '',
                taskNo: data.taskNo || '',
                driverName: data.subjectName || '',
                checkList2: initAppApplyFeeInfoList || [],
              },
              () => {
                this.getServiceAmount();
              }
            );
          } else if (data.invoiceType === 3) {
            // 普票
            const initList = [
              { payWay: 2, label: '', title: '到付款', checked: true },
              { payWay: 11, label: '需要一起申请', title: '技术服务费', checked: true },
              { payWay: 13, label: '需要一起申请', title: '电子协议费', checked: true },
              { payWay: 12, label: '需要一起申请', title: '轨迹校验费', checked: true },
            ];
            const paywayMap = {};
            data.appApplyFeeInfoList.forEach((item: any) => {
              paywayMap[item.payWay] = item;
            });
            const initAppApplyFeeInfoList = initList.map((item: any) => {
              const paywayData = paywayMap[item.payWay];
              return {
                ...item,
                id: item.payWay,
                price: xyzMath.divide(Number(paywayData.applicableAmount), 100),
                serviceAmount: Number(paywayData.serviceAmount) ? xyzMath.divide(Number(paywayData.serviceAmount), 100) : 0,
              };
            });
            this.setState(
              {
                truckNum: data.carNo || '',
                cargoList: data.cargoInfoList || [],
                loadAddress: data.loadAddress || '',
                unloadAddress: data.unloadAddress || '',
                taskNo: data.taskNo || '',
                driverName: data.subjectName || '',
                checkList3: initAppApplyFeeInfoList || [],
              },
              () => {
                this.getServiceAmount();
              }
            );
          }
        }
      })
      .catch((err) => {
        console.log(err);
        if (err.code === 'HAVE_NO_FEE_CAN_APPLY_ERROR') {
          this.goBack(err.msg);
        }
      });
  }
  //返回错误信息，跳转至列表
  goBack = (msg: boolean | React.ReactChild | React.ReactFragment | React.ReactPortal | null | undefined) => {
    Modal.Alert({
      title: '提示', // 可以传null隐藏头部
      content: (
        <View>
          <MBText>{msg}</MBText>
        </View>
      ),
      buttonText: '我知道了',
      onConfirm: () => {
        // todo
        this.props.navigation.goBack();
      },
    });
  };
  addresLayout(el: any, index: number) {
    const height = el?.nativeEvent?.layout?.height;
    if (index === 1) {
      this.addresLayoutHeight = height;
      if (this.unAddressHeight) {
        this.setState({ line_height: this.addresLayoutHeight - this.unAddressHeight - autoFix(26) });
      }
    } else {
      this.unAddressHeight = height;
      if (this.addresLayoutHeight) {
        this.setState({ line_height: this.addresLayoutHeight - this.unAddressHeight - autoFix(26) });
      }
    }
  }
  // 信息部分
  infoCard = () => {
    const cargoList = this.state.cargoList[0] || [];
    const { loadAddress, unloadAddress, line_height } = this.state;
    return (
      <View style={styles.infoCardContain}>
        <Flex direction="row">
          {this.state.driverPhoto && this.state.driverName ? (
            <FlexItem>
              <Flex direction="column">
                <Image style={styles.infoCardLeftImg} source={this.state.driverPhoto} />
                <MBText style={styles.infoCardLeftName}>{this.state.driverName}</MBText>
                <MBText style={styles.infoCardLeftTruckNo}>{this.state.truckNum}</MBText>
              </Flex>
            </FlexItem>
          ) : null}
          <FlexItem flex={4}>
            <View style={[styles.infoCardRightBox, { position: 'relative' }]}>
              <Flex direction="column" align="flex-start">
                {(!!loadAddress || !!unloadAddress) && (
                  <View onLayout={(el: any) => this.addresLayout(el, 1)}>
                    <View style={styles.address}>
                      <View style={[styles.point, styles.load]}></View>
                      <MBText style={styles.addressText} numberOfLines={2}>
                        {loadAddress}
                      </MBText>
                    </View>
                    <Whitespace vertical={10} />
                    <View style={styles.addressUnload} onLayout={(el: any) => this.addresLayout(el, 2)}>
                      <View style={[styles.point, styles.unload]}></View>
                      <MBText style={styles.addressText} numberOfLines={2}>
                        {unloadAddress}
                      </MBText>
                    </View>
                  </View>
                )}
                {!!line_height && (
                  <View style={[styles.stepLine, { height: line_height }]}>
                    <Image
                      fadeDuration={0}
                      resizeMode="repeat"
                      style={{ height: '100%', width: autoFix(0.8) }}
                      source={images.line_vertical}
                    />
                  </View>
                )}
                <View style={{ width: '100%' }}>
                  <Flex direction="row" justify="space-between">
                    <MBText
                      style={[styles.infoCardRightCargoText, this.state.cargoList.length > 1 ? styles.maxLength : null]}
                      numberOfLines={1}
                    >
                      {cargoList}
                    </MBText>
                    {this.state.cargoList.length > 1 ? (
                      <TouchableOpacity onPress={() => this.setState({ visiable: true })}>
                        <MBText style={styles.infoCardRightCargoText}>
                          更多货物
                          <Image style={{ height: autoFix(18), width: autoFix(18) }} source={images.sortArrowsApplicetion}></Image>
                        </MBText>
                      </TouchableOpacity>
                    ) : null}
                  </Flex>
                </View>
              </Flex>
            </View>
          </FlexItem>
        </Flex>
      </View>
    );
  };
  // 计算附加运费和总运费
  getServiceAmount = () => {
    const { invoiceType } = this.state;
    const serviceAmount = this.state['checkList' + invoiceType].reduce((amount: number, item: any) => {
      const { serviceAmount, checked } = item;
      return checked ? xyzMath.add(amount, Number(serviceAmount)) : amount;
    }, 0);
    this.setState({ serviceAmount }, () => this.getTotalApply());
  };
  //计算申请金额
  getTotalApply = () => {
    const { invoiceType } = this.state;
    const totalApply = this.state['checkList' + invoiceType].reduce((amount: number, item: any) => {
      const { price, checked } = item;
      return checked ? xyzMath.add(amount, Number(price)) : amount;
    }, 0);
    console.log('=========================计算申请金额==========================');
    console.log(totalApply, this.state['checkList' + invoiceType]);

    this.setState({ totalPrice: invoiceType == 1 || invoiceType == 3 ? totalApply : xyzMath.add(totalApply, this.state.serviceAmount) });
  };
  // 选择申请金额时
  checkedApplication = (index: number, value: boolean, price: string, current: any): void => {
    const { invoiceType } = this.state;
    console.log(index, value, price, current);

    if (invoiceType === 1) {
      // 不开票
      this.state.checkList1[index].checked = !current.checked;
      this.setState({ checkList1: this.state.checkList1 }, () => this.getTotalApply());
    } else if (invoiceType === 2) {
      // 专票
      const checkList2 = JSON.parse(JSON.stringify(this.state.checkList2));
      checkList2.forEach((item: any, idx: number) => {
        if (current.payWay == 1) {
          // 现付1; 油卡5 需要绑定一起发起，需要做这个限制，勾选了现付，则油卡自动勾选上，勾选了油卡，则现付自动勾选上；
          if (item.payWay == 5 || item.payWay == 1) {
            item.checked = !current.checked;
          }
        } else if (current.payWay == 2) {
          if (!current.checked && item.payWay <= 2) {
            // 选中
            item.checked = true;
          } else if (current.checked && item.payWay >= 2 && item.payWay < 5) {
            // 取消
            item.checked = false;
          }
        } else if (current.payWay == 3) {
          if (!current.checked && item.payWay <= 3) {
            // 选中
            item.checked = true;
          } else if (current.checked && item.payWay >= 3 && item.payWay < 5) {
            // 取消
            item.checked = false;
          }
        } else if (current.payWay == 5) {
          // 现付1; 油卡5 需要绑定一起发起，需要做这个限制，勾选了现付，则油卡自动勾选上，勾选了油卡，则现付自动勾选上；
          if (item.payWay == 5 || item.payWay == 1) {
            item.checked = !current.checked;
          }
        }
        console.log('---------------item.payWay-----------------');
        console.log(item.payWay, item.checked);
      });
      this.setState({ checkList2: checkList2 }, () => this.getServiceAmount());
    }
  };
  // 申请金额部分
  applicationMoney = () => {
    const { invoiceType } = this.state;
    return (
      <View style={styles.infoCardContain}>
        <MBText style={styles.applicationMoneyTitle}>申请金额</MBText>
        {invoiceType === 1 &&
          this.state.checkList1.map((item: any, index: number) => {
            return (
              <View style={styles.applicationMoneyItem} key={index}>
                <Flex direction="row">
                  <FlexItem>
                    <View>
                      <Checkbox
                        type="primary"
                        checked={item.checked}
                        disabled={item.disabled}
                        onChange={() => this.checkedApplication(index, item.checked, item.price, item)}
                        textStyle={{ color: 'red' }}
                      >
                        <MBText style={[styles.applicationMoneyItemTitle, item.disabled ? { opacity: 0.5 } : {}]}>
                          {item.title} <MBText style={styles.applicationMoneyItemLabel}>{item.label}</MBText>
                        </MBText>
                      </Checkbox>
                    </View>
                  </FlexItem>
                  <View>
                    <MBText style={styles.applicationMoneyItemValue}>{item.price}元</MBText>
                  </View>
                </Flex>
              </View>
            );
          })}
        {invoiceType === 2 &&
          this.state.checkList2.map((item: any, index: number) => {
            return (
              <View style={styles.applicationMoneyItem}>
                <Flex direction="row">
                  <FlexItem>
                    <View>
                      <Checkbox
                        type="primary"
                        checked={item.checked}
                        disabled={item.disabled}
                        onChange={() => this.checkedApplication(index, item.checked, item.price, item)}
                      >
                        <MBText style={styles.applicationMoneyItemTitle}>
                          {item.title} <MBText style={styles.applicationMoneyItemLabel}>{item.label}</MBText>
                        </MBText>
                      </Checkbox>
                    </View>
                  </FlexItem>
                  <View>
                    <MBText style={styles.applicationMoneyItemValue}>{item.price}元</MBText>
                  </View>
                </Flex>
              </View>
            );
          })}
        {invoiceType === 2 && (
          <View style={[styles.applicationMoneyItem, { display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }]}>
            <View style={{ display: 'flex', flexDirection: 'row' }}>
              <Image
                style={{ height: autoFix(32), width: autoFix(32), marginRight: autoFix(14) }}
                source={images.icon_checkoub_disabled}
              ></Image>
              <MBText style={[styles.applicationMoneyItemTitle, { opacity: 0.5 }]}>附加运费</MBText>
            </View>
            <MBText style={styles.applicationMoneyItemValue}>{this.state.serviceAmount}元</MBText>
          </View>
        )}
        {invoiceType === 3 &&
          this.state.checkList3.map((item: any, index: number) => {
            return (
              <View style={styles.applicationMoneyItem}>
                <Flex direction="row">
                  <FlexItem>
                    <View style={{ flexDirection: 'row' }}>
                      <Image
                        style={{ height: autoFix(32), width: autoFix(32), marginRight: autoFix(14) }}
                        source={images.icon_checkoub_disabled}
                      ></Image>
                      <MBText style={styles.applicationMoneyItemTitle}>
                        {item.title} <MBText style={styles.applicationMoneyItemLabel}>{item.label}</MBText>
                      </MBText>
                    </View>
                  </FlexItem>
                  <View>
                    <MBText style={styles.applicationMoneyItemValue}>{item.price}元</MBText>
                  </View>
                </Flex>
              </View>
            );
          })}
        <View style={styles.applicationMoneyLast}>
          <Flex direction="row">
            <FlexItem>
              <View>
                <MBText style={styles.applicationMoneyLastItemTitle}>申请金额合计:</MBText>
              </View>
            </FlexItem>
            <View>
              <MBText style={styles.applicationMoneyItemAllValue}>
                {this.state.totalPrice}
                <MBText style={{ color: '#666666' }}>元</MBText>
              </MBText>
            </View>
          </Flex>
        </View>
      </View>
    );
  };
  // 结算方式部分
  settlementMethod = () => {
    return (
      <View style={styles.infoCardContainLast}>
        <MBText style={styles.settlementTitle}>结算方式</MBText>
        <View style={styles.settlementItem}>
          <Checkbox checked={this.state.settleMethod === 1} onChange={(value) => this.setState({ settleMethod: value ? 1 : '' })}>
            <MBText>支付成功后，立即结算给司机</MBText>
          </Checkbox>
        </View>
        <View style={[styles.settlementItem, styles.settlementItemLast]}>
          <Checkbox checked={this.state.settleMethod === 2} onChange={(value) => this.setState({ settleMethod: value ? 2 : '' })}>
            <MBText>支付成功后，点击确认再结算</MBText>
          </Checkbox>
        </View>
      </View>
    );
  };
  // 点击底部的付款申请按钮;
  confirm = () => {
    const { invoiceType, settleMethod, totalPrice, collectMoneyList } = this.state;
    if ((invoiceType === 2 && settleMethod === '') || totalPrice === 0) return;
    //存放申请金额
    const applyPayWays: number[] = [];
    //存放结算方式
    const applySettleType = this.state.settleMethod;
    const bizId = this.state.taskId || this.state.mbOrderId;
    let offlinePayAccountInfo = undefined;
    if (invoiceType == 1) {
      offlinePayAccountInfo = {};
      collectMoneyList.forEach((item: any) => {
        if (item.key === 'payType') {
          if (typeof item.value === 'string' && item.value !== '') {
            offlinePayAccountInfo[item.key] = Number(item.value);
          } else if (typeof item.value === 'number') {
            offlinePayAccountInfo[item.key] = item.value;
          } else {
            offlinePayAccountInfo[item.key] = null;
          }
        } else {
          offlinePayAccountInfo[item.key] = item.value || null;
        }
      });
    }
    console.log('=======================点击底部的付款申请按钮=======================', offlinePayAccountInfo);

    const params = {
      offlinePayAccountInfo, // 不开票 -- 收款信息
      applySettleType,
      bizId,
      applyPayWays,
      contactPhone: this.state.driverPhone,
      subjectType: this.state.subjectType,
      subjectName: this.state.driverName,
      applyAmount: String(this.state.totalPrice * 100),
    };
    const alerInfo: string[] = [];
    this.state['checkList' + invoiceType].forEach((item: any) => {
      if (item.checked === true) {
        if (invoiceType === 2 && this.state.settleMethod === 1) {
          alerInfo.push(item.title);
        }
        if (item.id) {
          applyPayWays.push(Number(item.id));
        }
      }
    });
    this.confirmBox(alerInfo, params);
  };
  //跳转不同的协议页面
  goDifferentApplicationPage = (contractPageType: string) => {
    const content = {
      '1': '您选择的订单协议为空，是否签署协议？',
      '2': '您选择的订单主协议货主未签署，是否签署协议？',
      '3': '您选择的订单增补协议待确认，是否签署协议？',
    };
    Modal.Confirm({
      closable: false, // 1.0.91新增属性，显示差差按钮
      headerLine: false, // 隐藏头部分割线
      hideHeader: false, // 可以隐藏头部: true
      title: '提示',
      content: content[contractPageType],
      cancelText: '我知道了',
      confirmText: '签署协议',
      onValid: () => {
        // 可选，confirm之前回调，返回Promise<boolean>，如果不通过弹窗不关闭
        return Promise.resolve(true);
      },
      onConfirm: () => {
        goNetworkProtocol({ mybOrderId: this.state.mbOrderId, invoiceFlag: this.state.invoiceFlag });
      },
      onCancel: () => {
        // todo
        this.props.navigation.goBack();
      },
    });
  };
  confirmBox = (alerInfo: any, submitParams: any) => {
    Modal.Confirm({
      closable: false, // 1.0.91新增属性，显示差差按钮
      headerLine: false, // 隐藏头部分割线
      hideHeader: false, // 可以隐藏头部: true
      title: '生成付款申请单',
      content: (
        <View>
          {alerInfo.length ? (
            <MBText>
              确认申请支付后将会确认收货、确认回单，提交财务审核，财务审核通过后，
              {alerInfo.reduce((pre: string, cur: string) => {
                return pre + '、' + cur;
              })}
              共{this.state.totalPrice}
              元直接支付至司机账户。
            </MBText>
          ) : (
            <MBText>确认申请后将成功提交支付申请，请联系贵司相关人员审批及支付。</MBText>
          )}
        </View>
      ),
      cancelText: '我再想想',
      confirmText: '确认申请',
      onValid: () => {
        // 可选，confirm之前回调，返回Promise<boolean>，如果不通过弹窗不关闭
        return Promise.resolve(true);
      },
      onConfirm: async () => {
        const paramsMap = {
          '1': { bizNo: this.state.taskNo },
          '2': { platformOrderNo: this.state.mbOrderId },
          '3': { generalInvoiceOrderNo: this.state.mbOrderId },
        };
        const res: any = await Api.goPaymentApplication(paramsMap[this.state.invoiceType]);
        console.log('===================点击付款申请按钮校验接口======================');
        console.log(res);
        const reason = res.data?.reason || '';
        const contractPageType = res.data?.contractPageType || 0;
        if (contractPageType === '1' || contractPageType === '2' || contractPageType === '3') {
          this.goDifferentApplicationPage(contractPageType);
          return;
        }
        if (reason) {
          console.log(reason);
          Modal.Alert({
            title: '提示', // 可以传null隐藏头部
            content: reason,
            buttonText: '我知道了',
            onConfirm: () => this.props.navigation.goBack(),
          });
          return;
        }
        const res2: any = await API.paymentApplySubmit(submitParams);
        if (res2.code === '10000') {
          if (res2.dataList[0]?.errorMsg) {
            this.goBack(res2.dataList[0]?.errorMsg);
            return;
          }
          this.props.navigation?.state?.params?.refresh?.();
          this.props.navigation.replace('SuccessPaymentApplication', {
            dataList: res2.dataList,
          });
        }
      },
      onCancel: () => {
        // todo
      },
    });
  };
  checkComfirm = (reason: any) => {
    Modal.Alert({
      title: '提示', // 可以传null隐藏头部
      content: reason,
      buttonText: '我知道了',
      onConfirm: () => {
        // todo
        this.props.navigation.goBack();
      },
    });
  };
  // 底部提交部分
  footer = () => {
    return (
      <Flex direction="row" justify="center" style={[styles.footer, styles.shadow]}>
        <FlexItem>
          <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
            <View style={[styles.bntCommonStyle, styles.createText]}>
              <MBText style={styles.btnText} color="#4885FF">
                取消
              </MBText>
            </View>
          </TouchableOpacity>
        </FlexItem>
        <Whitespace type="horizontal" horizontal={5} />

        <FlexItem flex={2}>
          <TouchableOpacity
            onPress={this.confirm}
            disabled={(this.state.settleMethod === '' && this.state.invoiceType === 2) || this.state.totalPrice === 0}
          >
            <View
              style={[
                styles.bntCommonStyle,
                styles.createDispathText,
                (this.state.settleMethod === '' && this.state.invoiceType === 2) || this.state.totalPrice === 0
                  ? { backgroundColor: 'hsla(220, 100%, 64%, 0.2)' }
                  : null,
              ]}
            >
              <MBText style={styles.btnText} color="#fff">
                付款申请
              </MBText>
            </View>
          </TouchableOpacity>
        </FlexItem>
      </Flex>
    );
  };
  // 付款方式
  api_payTypeList() {
    Api.payTypeList()
      .then((res: any) => {
        console.log('=================付款方式====================');
        console.log(res);
        if (res?.data?.dictionaryOptionList?.length) {
          this.setState({ payTypeList: res.data.dictionaryOptionList.filter((item: any) => item.isValid === 1) });
        }
      })
      .catch((err: any) => {
        console.log('付款方式', err);
      });
  }
  changeInput(el: string, index: number) {
    console.log(el, index);
    const { collectMoneyList } = this.state;
    collectMoneyList[index].value = el;
    this.setState({ collectMoneyList });
  }
  /** 收款信息 */
  collectMoneyInfo = () => {
    const { collectMoneyList, showModalPayType, payTypeList } = this.state;
    const onChangePayType = (val: any) => {
      this.setState({ showModalPayType: false });
      if (val) {
        console.log('收款信息选择了', val);
        this.changeInput(val == -1 ? null : val, 0);
      }
    };
    return (
      <View style={[styles.infoCardContain, { paddingRight: 0, paddingBottom: 0, marginBottom: autoFix(28) }]}>
        <MBText style={styles.applicationMoneyTitle}>收款信息</MBText>
        {collectMoneyList.map((item: any, index: number) => {
          return (
            <View style={{ borderBottomWidth: collectMoneyList.length - 1 > index ? 1 : 0, borderColor: '#E8E8E8' }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ height: autoFix(95), flexDirection: 'row', alignItems: 'center' }}>
                  <MBText style={{ fontSize: autoFix(29) }}>{item.title}</MBText>
                </View>
                <View style={{ flex: 1 }}>
                  {(item.type === 'input' || item.type === 'number') && (
                    <InputItem
                      style={{ paddingRight: 0, marginRight: 0 }}
                      styleItem={{ paddingRight: autoFix(20) }}
                      inputStyle={{ textAlign: 'right', color: '#666666', fontSize: autoFix(27) }}
                      value={item.value}
                      multiline={false}
                      maxLength={150}
                      onChangeText={(el) => this.changeInput(el, index)}
                      placeholder={item.placeholder}
                      keyboardType={item.type === 'number' ? 'numeric' : 'default'}
                    />
                  )}
                  {item.key === 'payType' && (
                    <View style={{ paddingVertical: autoFix(28) }}>
                      <TouchableOpacity
                        onPress={() => this.setState({ showModalPayType: true })}
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          justifyContent: 'flex-end',
                          paddingRight: autoFix(18),
                        }}
                      >
                        <MBText style={{ color: !!item.value ? '#666666' : '#ccc', fontSize: autoFix(27) }}>
                          {item.value ? payTypeList.find((val: any) => val.optionValue == item.value).optionText : item.placeholder}
                        </MBText>
                        <Image
                          style={{ height: autoFix(22), width: autoFix(22), marginLeft: autoFix(10) }}
                          source={{ uri: images.icon_arrow_gray }}
                        />
                      </TouchableOpacity>
                      {!collectMoneyList[0].value && !!collectMoneyList.find((item: any) => !!item.value && item.key != 'payType') && (
                        <View style={{ alignItems: 'flex-end', paddingRight: autoFix(28), paddingTop: autoFix(20) }}>
                          <MBText color="#FF6969" size="xs">
                            请选择收款方式
                          </MBText>
                        </View>
                      )}
                      <ModalPayType visible={showModalPayType} list={payTypeList} onChange={onChangePayType} />
                    </View>
                  )}
                </View>
              </View>
            </View>
          );
        })}
      </View>
    );
  };

  onLeftClick = () => {
    this.props.navigation.goBack();
  };
  render(): React.ReactNode {
    return (
      <View style={{ flex: 1 }}>
        <ImageBackground source={{ uri: Images.icon_bg_map }} style={{ flex: 1 }}>
          <View style={styles.contain}>
            <NavBar title="付款申请" leftClick={this.onLeftClick} />
            <ScrollView>
              <MBText style={styles.transNoLabel}>
                运输单号：
                <MBText
                  onPress={() => {
                    this.props.navigation.navigate('TaskDetail', { id: this.state.id });
                  }}
                  style={styles.transNo}
                >
                  {this.state.taskNo}
                </MBText>
              </MBText>

              {this.infoCard()}
              {this.applicationMoney()}
              {this.state.invoiceType === 1 ? this.collectMoneyInfo() : null}
              {this.state.invoiceType === 2 ? this.settlementMethod() : null}
              <ModalIsInvoice
                visible={this.state.visiable}
                cargoList={this.state.cargoList}
                onConfirm={() => {
                  this.setState({
                    visiable: false,
                  });
                }}
                onCancel={() => {
                  this.setState({
                    visiable: false,
                  });
                }}
              />
            </ScrollView>
          </View>
        </ImageBackground>
        {this.footer()}
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  contain: {
    flex: 1,
  },
  transNoLabel: {
    marginLeft: autoFix(48),
    marginTop: autoFix(36),
    fontSize: autoFix(30),
    fontWeight: '500',
  },
  transNo: {
    fontSize: autoFix(30),
    fontWeight: '400',
    color: '#4885FF',
  },
  infoCardContain: {
    backgroundColor: '#FFF',
    marginLeft: autoFix(20),
    marginRight: autoFix(20),
    marginTop: autoFix(20),
    marginBottom: autoFix(10),
    paddingTop: autoFix(36),
    paddingBottom: autoFix(28),
    paddingRight: autoFix(28),
    paddingLeft: autoFix(28),
  },
  infoCardContainLast: {
    backgroundColor: '#FFF',
    marginLeft: autoFix(20),
    marginRight: autoFix(20),
    marginTop: autoFix(20),
    marginBottom: autoFix(30),
    paddingTop: autoFix(36),
    paddingBottom: autoFix(28),
    paddingRight: autoFix(28),
    paddingLeft: autoFix(28),
  },
  infoCardLeftImg: {
    height: autoFix(117),
    width: autoFix(117),
    borderRadius: autoFix(60),
  },
  infoCardLeftName: {
    textAlign: 'center',
    marginTop: autoFix(16),
    fontSize: autoFix(27),
    color: '#333',
  },
  infoCardLeftTruckNo: {
    marginTop: autoFix(16),
    fontSize: autoFix(23),
    color: '#666',
  },
  footer: {
    paddingVertical: autoFix(20),
    paddingHorizontal: autoFix(28),
    backgroundColor: '#fff',
  },

  bntCommonStyle: {
    height: autoFix(80),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 40,
  },

  btnText: {
    fontSize: autoFix(32),
  },

  createText: {
    borderWidth: autoFix(1),
    borderColor: '#4885FF',
  },

  createDispathText: {
    backgroundColor: '#4885FF',
  },
  infoCardRightBox: {
    // width: autoFix(470),
    marginLeft: autoFix(16),
  },
  address: {
    flexDirection: 'row',
  },
  addressUnload: {
    flexDirection: 'row',
    marginBottom: autoFix(16),
  },
  point: {
    width: autoFix(14),
    height: autoFix(14),
    borderRadius: autoFix(7),
    marginRight: autoFix(8),
    marginTop: autoFix(13),
  },
  load: {
    backgroundColor: '#4885FF',
  },
  unload: {
    backgroundColor: '#333333',
  },
  addressText: {
    lineHeight: autoFix(40),
    fontSize: autoFix(28),
  },
  stepLine: {
    position: 'absolute',
    top: autoFix(26),
    left: autoFix(6),
    height: autoFix(8),
  },
  maxLength: {
    width: autoFix(300),
    marginLeft: autoFix(22),
    marginTop: autoFix(10),
    fontSize: autoFix(24),
    color: '#666666',
    textAlign: 'right',
  },
  infoCardRightCargoText: {
    marginLeft: autoFix(22),
    marginTop: autoFix(10),
    fontSize: autoFix(23),
    color: '#666666',
    textAlign: 'right',
    // alignSelf: 'flex-end',
  },
  //申请金额部分
  applicationMoneyTitle: {
    fontSize: autoFix(26),
    color: '#999999',
  },
  applicationMoneyItem: {
    paddingTop: autoFix(32),
    paddingBottom: autoFix(32),
    borderBottomWidth: autoFix(1),
    borderBottomColor: '#E9E9E9',
  },
  applicationMoneyItemTitle: {
    fontSize: autoFix(28),
    color: '#333333',
  },
  applicationMoneyItemLabel: {
    fontSize: autoFix(22),
    color: '#999999',
  },
  applicationMoneyItemValue: {
    fontSize: autoFix(28),
    color: '#666666',
  },
  applicationMoneyLast: {
    paddingTop: autoFix(32),
  },
  applicationMoneyLastItemTitle: {
    fontSize: autoFix(30),
    fontWeight: '500',
    color: '#333333',
  },
  applicationMoneyItemAllValue: {
    fontSize: autoFix(36),
    fontWeight: '600',
    color: '#FF6969',
  },
  //结算方式部分
  settlementTitle: {
    fontSize: autoFix(26),
    color: '#999999',
  },
  settlementItem: {
    paddingTop: autoFix(25),
    paddingBottom: autoFix(25),
    borderBottomColor: '#EAEAEA',
    borderBottomWidth: autoFix(1),
  },
  settlementItemLast: {
    borderBottomWidth: autoFix(0),
    paddingBottom: autoFix(0),
  },
});
export default PaymentApplication;
