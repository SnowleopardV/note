import server from '~/server';
const API = {
  // 组织列表
  orgList(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/org/create/order/list',
      data,
    });
  },
  // 调度员列表
  dispatchList(data = {}) {
    return server({
      url: '/saas-permission-app/yzgApp/companyAuth/dispatchList',
      data,
    });
  },

  /** APP-通话记录共 (5) 个: https://yapi.1111.com/#/project/2532/interface/api/cat_88618 */

  // 按货源通话记录搜索
  callPageShipper(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/call/log/pageShipper',
      data,
    });
  },
  // 按司机通话记录搜索
  callPageDriver(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/call/log/pageDriver',
      data,
    });
  },
  // 通话弹窗
  callInfo(data = {}) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/call/log/callInfo',
        data,
      },
      { toastError: false }
    );
  },
  // 隐私号绑定
  callBind(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/call/log/bind',
      data,
    });
  },
  // 真实号码通话记录上报
  uploadShipperCallLog(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/call/log/uploadShipperCallLog',
      data,
    });
  },
};

export default API;
