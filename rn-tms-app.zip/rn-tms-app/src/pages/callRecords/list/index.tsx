import * as React from 'react';
import { View, Platform, Image, TouchableOpacity, ImageBackground } from 'react-native';
import { LayProvider, MBText, Modal, RefreshList } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import { pageProps, listStateProps } from '~/pages/callRecords/propTypes';
import styles from '~/pages/callRecords/styles';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import ListRenderItem from '../components/ListRenderItem';
import DealNumberModal from '../components/DealNumberModal';
import UnDealNumberModal from '../components/UnDealNumberModal';
import OrgDispatchListModal from '../components/OrgDispatchListModal';
import API from '~/pages/callRecords/api';
import { MBToast } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';

export default class DetailAddressComponent extends React.Component<pageProps, listStateProps> {
  constructor(props: pageProps) {
    super(props);
    this.state = {
      showPupop: 0,
      headerFilterList: [
        {
          showTitleVal: 0,
          listMap: [
            { label: '按货源展示', value: 0 },
            { label: '按司机展示', value: 1 },
          ],
        },
        {
          showTitleVal: 4,
          listMap: [
            { label: '全部货源', value: 4 },
            { label: '找车中', value: 1 },
            { label: '已成交', value: 2 },
            { label: '已取消', value: 3 },
          ],
        },
        {
          showTitleVal: 2,
          listMap: [
            { label: '全部通话', value: 2 },
            { label: '已接通', value: 0 },
            { label: '未接通', value: 1 },
          ],
        },
      ],
      list: [],
      visible: -1, // 0 未成交拨号弹窗 1 成交拨号弹窗 2 组织调度员弹窗
      dispatcherItem: null, // 选择的调度员
      isEnd: false,
      pageForm: {
        pageNo: 1,
        pageSize: 10,
      },
      hasRequest: false,
      callInfoData: null, // 用于拨打电话弹窗信息显示
    };
  }
  async componentWillMount() {
    const data = await NativeBridge.tmsUserGet('headerFilterList');
    console.log('======================headerFilterList tmsUserGet=====================');
    console.log(data);
    if (data) {
      this.setState({ headerFilterList: data });
    }
  }
  onNavRight() {
    console.log('onNavRight');
    this.openModal({ showModal: 2 });
  }
  async onRefresh() {
    this.state.pageForm.pageNo = 1;
    return this.api_list();
  }
  async onLoadMore() {
    const { hasRequest } = this.state;
    return hasRequest ? this.api_list() : Promise.resolve();
  }
  /** 按 货源/司机 通话记录搜索 */
  async api_list() {
    const { pageForm, headerFilterList, dispatcherItem } = this.state;
    if (!dispatcherItem?.mybConsignorId) {
      this.setState({ list: [], isEnd: true });
      return Promise.resolve();
    }
    NativeBridge.tmsUserSet('headerFilterList', headerFilterList); // 记录下用户每次请求的的入参，下次再进入该页面自动带出
    const apiMap = {
      0: 'callPageShipper',
      1: 'callPageDriver',
    };
    const listType = apiMap[headerFilterList[0].showTitleVal];
    if (pageForm.pageNo === 1) {
      this.state.pageForm.requestId = new Date().getTime().toString();
    }
    const dataForm = {
      ...pageForm,
      cargoStatus: headerFilterList[1].showTitleVal, // 货源状态  1.找车中  2.已成交  3.已取消  4.全部
      callLogStatus: headerFilterList[2].showTitleVal, // 通话状态 0.已接通  1.未接通  2.全部
      dispatcherId: dispatcherItem?.mybConsignorId || null, // 调度员ID
    };
    try {
      const res = await API[listType](dataForm);
      if (res.data?.list) {
        if (!this.state.hasRequest) {
          this.setState({ hasRequest: true });
        }
        const list = this.state.pageForm.pageNo === 1 ? [] : this.state.list;
        const dataList = res.data.list.map((item: any) => ({ ...item, selected: false }));
        this.state.pageForm.pageNo = this.state.pageForm.pageNo + 1;
        this.setState({ list: list.concat(dataList), isEnd: !res.data.hasNext });
      } else {
        this.setState({ list: [], isEnd: true });
      }
    } catch (error) {
      this.setState({ list: [], isEnd: true });
    }
  }
  // 打开、关闭 弹窗
  openModal(item: any) {
    const { showModal } = item;
    if (showModal) {
      this.setState({ visible: showModal });
    } else if (item.callLogCargoStatus) {
      this.api_callInfo(item);
    }
  }
  /** 获取拨打弹窗信息 */
  api_callInfo(item: any) {
    const data = {
      shipperId: item.dispatcherId, // 平台货主ID --- 调度员 id
      driverId: item.driverId, // 平台司机ID
      shipperLoginPhone: item.dispatcherPhone, // 货主注册号码 调度员 号码
      driverLoginPhone: item.driverPhone, // 司机注册号码
    };
    API.callInfo(data)
      .then((res: any) => {
        console.log('====================api_callInfo=========================');
        console.log(res);
        if (res.data) {
          const callInfoData = {
            ...res.data,
            ...data,
            cargoId: item.cargoId,
            cargoStatus: item.cargoStatus,
          };
          if (item.callLogCargoStatus === '找车中') {
            this.setState({ callInfoData: callInfoData, visible: 0 });
          } else if (item.callLogCargoStatus === '已成交') {
            this.setState({ callInfoData: callInfoData, visible: 1 });
          }
        }
      })
      .catch((err: any) => {
        if (err.code == '800001') {
          Modal.Alert({
            title: '未开启安全号保护授权', // 可以传null隐藏头部
            content: (
              <View>
                <MBText>请使用运满满/货车帮货主APP开启安全号保护授权，方可使用安全号拨打、接听功能</MBText>
              </View>
            ),
            buttonText: '知道了',
            onConfirm: () => {
              // todo
            },
            enableCareMode: true, // 支持关怀模式
          });
        } else if (err.code !== -111033 || err.code !== 410) {
          MBToast.show(err.message || err.msg || err.reason || JSON.stringify(err));
        }
      });
  }
  changeDispatcher(item: any) {
    if (item) {
      this.state.pageForm.pageNo = 1;
      this.setState({ dispatcherItem: item }, () => this.api_list());
    }
    this.openModal({ showModal: -1 });
  }
  /** 头部筛选框 */
  filtrateHeaderElement() {
    const { headerFilterList, showPupop } = this.state;
    const openPupop = (index: number) => {
      const i = index + 1;
      this.setState({ showPupop: showPupop === i ? 0 : i });
    };
    const changeValue = (item: any) => {
      headerFilterList[showPupop - 1].showTitleVal = item.value;
      this.state.pageForm.pageNo = 1;
      this.setState({ headerFilterList: headerFilterList, showPupop: 0, list: [] }, () => this.api_list());
    };
    return (
      <View>
        <View style={[styles.headerFilter, styles.flexRow]}>
          {headerFilterList.map((item: any, index: number) => {
            const title = item.listMap.find((row: any) => row.value === item.showTitleVal).label || '';
            const showIndex = index + 1;
            return (
              <TouchableOpacity style={[styles.flexRow, { flex: 1, justifyContent: 'center' }]} onPress={() => openPupop(index)}>
                <MBText color={showPupop === showIndex ? '#333333' : '#999999'}>{title}</MBText>
                <Image style={[styles.icon, showPupop === showIndex && styles.upturned]} source={images.icon_pull_down} />
              </TouchableOpacity>
            );
          })}
        </View>
        {!!showPupop && (
          <View style={{ backgroundColor: '#fff', borderBottomColor: '#EEEEEE', borderBottomWidth: 1 }}>
            {headerFilterList[showPupop - 1].listMap.map((item: any) => {
              const listItem = headerFilterList[showPupop - 1];
              const showTitleVal = listItem.showTitleVal;
              const selected = item.value === showTitleVal;
              return (
                <TouchableOpacity onPress={() => changeValue(item)}>
                  <View
                    style={[
                      styles.flexColumn,
                      { width: '100%', height: autoFix(96), borderBottomColor: '#EEEEEE', borderBottomWidth: autoFix(0.5) },
                    ]}
                  >
                    <MBText color={selected ? '#4885FF' : '#999999'} style={{ fontWeight: selected ? '500' : '400' }}>
                      {item.label}
                    </MBText>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </View>
    );
  }
  renderEmpty() {
    return (
      <View style={[{ marginTop: autoFix(332) }, styles.flexColumn]}>
        <Image style={{ height: autoFix(287), width: autoFix(272) }} source={{ uri: images.icon_no_data }} />
        <MBText color="#A2ADC7" bold>
          暂无消息
        </MBText>
        <MBText color="#A2ADC7" size="xs" style={{ marginTop: autoFix(20) }}>
          我们将为您保留24小时内的通话记录
        </MBText>
      </View>
    );
  }
  render(): JSX.Element {
    const { list, isEnd, headerFilterList, visible, callInfoData } = this.state;
    const { navigation } = this.props;
    const listData = list.map((item: any) => {
      item.type = headerFilterList[0].showTitleVal;
      return item;
    });
    return (
      <LayProvider theme="skyblue">
        <View style={{ flex: 1 }}>
          <NavBar title="通话记录" rightElement={<MBText>调度员筛选</MBText>} onRight={() => this.onNavRight()} />
          {this.filtrateHeaderElement()}
          <View style={{ flex: 1 }}>
            <RefreshList
              footerNoMoreDataText={
                <MBText size="xs" color="#999999" style={{ textAlign: 'center', paddingVertical: autoFix(40) }}>
                  我们将为您保留24小时内的通话记录
                </MBText>
              }
              isEnd={isEnd}
              data={listData}
              showsVerticalScrollIndicator={false}
              renderItem={(item: any) => {
                return (
                  <ListRenderItem
                    navigation={navigation}
                    key={item.id}
                    item={item}
                    openModal={(el: any) => this.openModal(el)}
                  ></ListRenderItem>
                );
              }}
              emptyRender={this.renderEmpty}
              onRefresh={this.onRefresh.bind(this)}
              onLoadMore={this.onLoadMore.bind(this)}
              getLayoutTypeForIndex={() => 215}
            />
          </View>
          {visible === 0 && <UnDealNumberModal visible data={callInfoData} onColse={() => this.openModal({ showModal: -1 })} />}
          {visible === 1 && <DealNumberModal visible data={callInfoData} onColse={() => this.openModal({ showModal: -1 })} />}
          <OrgDispatchListModal visible={visible === 2} data={undefined} onColse={(item: any) => this.changeDispatcher(item)} />
        </View>
      </LayProvider>
    );
  }
}
