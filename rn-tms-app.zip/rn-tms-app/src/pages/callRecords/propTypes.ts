export interface pageProps {
  navigation?: any;
  screenProps?: any; // 路由地址参数
  store?: any;
}

export interface listStateProps {
  list: Array<any>;
  showPupop: number;
  headerFilterList: Array<any>;
  isEnd: boolean;
  visible: number; // 显示 未成交/已成交 拨打号码 弹窗 0 未成交 1已成交 -1 不显示
  dispatcherItem: any;
  pageForm: pageForm;
  hasRequest: boolean; // 进入页面先得到调度员id 再请求
  callInfoData: {
    callerPhones: string[];
    calledPhones: string[];
  } | null; // 用于拨打电话弹窗信息显示
}

export interface pageForm {
  cargoStatus?: string; // 货源状态  1.找车中  2.已成交  3.已取消  4.全部
  callLogStatus?: string; // 通话状态 1.已接通  2.未接通  3.全部
  dispatcherId?: string; // 调度员ID
  pageNo: number;
  pageSize: number;
  requestId?: string; // 请求id，首页请求是生成唯一
}
export interface listRenderItemProps {
  navigation: any;
  item: {
    selected: boolean;
    type: 0 | 1; // 1按司机展示， 0按货源展示
    loadAddress?: string;
    unloadAddress?: string;
    dispatcherName?: string;
    dispatcherPhone?: string;
    truckLengthList?: string[];
    truckTypeList?: string[];
    cargoWeight?: string;
    cargoCapacity?: string;
    cargoName?: string;
    driverCallRecordResponses?: any[];
    driverName?: string;
    carNo?: string;
    contactNum?: string;
    callerRole?: string; // 主动发起者 1.司机  2.货主
    hangUp?: string; // 是否挂断  0.否 1.是
    lastCallingTime?: string; // 最后一次通话时间
    yesterday?: string; // 最后一次通话时间是否昨天 0.否  1.是
    callDuration?: string; // 通话时长 HH:mm:ss
    carType?: string; //
    carLength?: string; //
    favRate?: string; // 司机好评率
    callLogCargoStatus?: string; // 状态
  };
  openModal: (item: any) => void;
}

export interface modalProps {
  visible: boolean;
  data: any;
  onColse: (arg0?: any) => void;
}
