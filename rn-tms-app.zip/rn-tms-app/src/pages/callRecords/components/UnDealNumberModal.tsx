import { Button, MBText, Modal, Whitespace } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import * as React from 'react';
import { Image, ScrollView, StyleSheet, TouchableWithoutFeedback, View } from 'react-native';
import NativeBridge from '~/extends/NativeBridge';
import { modalProps } from '~/pages/callRecords/propTypes';
import images from '~public/static/images';
import API from '~/pages/callRecords/api';

/** 未成交 拨打号码 模态窗 真实号/虚拟号 */
export default class UnDealNumberModal extends React.Component<modalProps, any> {
  constructor(props: any) {
    super(props);
    this.state = {};
  }
  colseModal() {
    const { onColse } = this.props;
    !!onColse && onColse();
  }
  changeNumberType(val: number) {
    this.setState({ numberType: val });
  }
  submit = () => {
    console.log('立即拨打');
    this.api_callBind();
  };
  // 获取被叫号码
  api_callBind() {
    const { data } = this.props;
    const formData = {
      shipperId: data.shipperId, // 货主ID
      driverId: data.driverId, // 司机ID
      shipperLoginPhone: data.shipperLoginPhone, // 货主注册号码
      callerPhones: data.callerPhones, // 货主主叫号码
      calledPhones: data.calledPhones, // 司机被叫号码
      cargoId: data.cargoId, // 货源id
    };
    API.callBind(formData).then((res: any) => {
      if (res.data?.calledPhone) {
        // 隐私号是否降级 0.否  1.是
        if (res.data?.isDegraded) {
          this.api_uploadShipperCallLog(1);
          NativeBridge.dial({ telephone: res.data.calledPhone }); // 司机注册号码
        } else {
          NativeBridge.dial({ telephone: res.data.calledPhone }); // 拨打号码
        }
      }
    });
  }
  /** 真实号码通话记录上报 */
  api_uploadShipperCallLog(isDownGrade: 0 | 1) {
    const { data } = this.props;
    const formData = {
      shipperId: data.shipperId, // 货主ID
      driverId: data.driverId, // 司机ID
      cargoId: data.cargoId, // 货源ID
      cargoStatus: data.cargoStatus, // 平台货源状态
      isDownGrade: isDownGrade, // 否隐私号降级真实号码场景 0.否  1.是
    };
    API.uploadShipperCallLog(formData);
  }
  render(): JSX.Element {
    const { visible, data } = this.props;
    return (
      <Modal
        modalType="View"
        closable
        position="center"
        visible={visible}
        onCancel={() => this.colseModal()}
        onMaskClose={() => this.colseModal()}
        onClose={() => this.colseModal()}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        <View style={{ width: '100%' }}>
          <View style={styles.title}>
            <MBText color="#67A4FF" size="lg" bold>
              满帮安全号
            </MBText>
            <Image style={styles.icon_safe} source={images.icon_safe} />
          </View>
          <View style={styles.flexRowItem}>
            <MBText size="sm" color="#666666">
              仅限使用以下号码呼出，否则无法呼出
            </MBText>
          </View>
          <ScrollView style={{ maxHeight: autoFix(400), marginVertical: autoFix(14) }} contentContainerStyle={[styles.flexColumnItem]}>
            {data?.callerPhones.map((phone: string) => {
              return (
                <MBText style={{ fontSize: autoFix(48), fontWeight: '600' }} color="#333333">
                  {phone}
                </MBText>
              );
            })}
          </ScrollView>
          <View style={[styles.flexRowItem, { marginBottom: autoFix(24) }]}>
            <MBText style={{ fontSize: autoFix(22), width: autoFix(438), textAlign: 'center' }} color="#999999">
              {/* 如果需要添加或者修改拨出号，请前往运满满/货车帮APP进行维护 */}
              {data.phoneChangeTip || ''}
            </MBText>
          </View>
          <Whitespace vertical={5} />
          <View style={{ paddingHorizontal: autoFix(44) }}>
            <Button radius style={styles.btn} interval={500} onPress={this.submit} size="sm" type="primary">
              <Image resizeMode="stretch" style={styles.btnBg} source={images.btn_buleBg} />
              <MBText color="#FFFFFF" size="lg" bold>
                立即拨打
              </MBText>
            </Button>
          </View>
          <View style={[styles.flexRowItem, { marginTop: autoFix(24) }]}>
            <MBText style={{ fontSize: autoFix(22), width: autoFix(482), textAlign: 'center' }} color="#999999">
              满帮为您提供号码保护，成交后可查看真实号码
            </MBText>
          </View>
          <Whitespace vertical={20} />
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  icon_safe: {
    width: autoFix(40),
    height: autoFix(41),
    marginLeft: autoFix(2),
  },
  headerBg: {
    height: autoFix(231),
    width: autoFix(591),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  flexRowItem: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  flexColumnItem: {
    width: '100%',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    height: autoFix(104),
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btn: {
    backgroundColor: '#4885FF',
    width: autoFix(498),
    height: autoFix(73),
  },
  btnBg: {
    position: 'absolute',
    top: autoFix(-2),
    right: autoFix(-2),
    bottom: autoFix(-2),
    left: autoFix(-2),
    width: autoFix(506),
    height: autoFix(73),
  },
});
