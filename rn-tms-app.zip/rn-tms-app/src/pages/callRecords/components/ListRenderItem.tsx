import { MBText } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import * as React from 'react';
import { Image, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native';
import { listRenderItemProps } from '~/pages/callRecords/propTypes';
import styles from '../styles';
import images from '~public/static/images';
/** 主动发起者 1.司机  2.货主 + 是否挂断  0.否 1.是*/
const iconConnectMap = {
  10: images.connect_in,
  11: images.not_connect_in,
  20: images.connect_out,
  21: images.not_connect_out,
};
const cargoStatusColorMap = {
  找车中: '#4885FF',
  已成交: '#52C41A',
  已取消: '#C4C4C4',
};
const cargoStatusAbleMap = {
  找车中: true,
  已成交: true,
};
export default class ListRenderItem extends React.Component<listRenderItemProps, any> {
  constructor(props: any) {
    super(props);
    this.state = {};
  }
  openPopup(item: any) {
    item.selected = !item.selected;
    this.forceUpdate();
  }
  openModal(item: any) {
    !!this.props.openModal && this.props.openModal(item);
  }
  goTaskDetail = (item: any) => {
    this.props.navigation.navigate('TaskDetail', { id: item.id });
  };
  typeDriverElement() {
    const { item } = this.props;
    const callerRole = item.callerRole; // 主动发起者 1.司机  2.货主
    const hangUp = item.hangUp; // 是否挂断  0.否 1.是
    const type = String(callerRole) + String(hangUp);
    const tagList: any[] = [];
    !!item.carNo && tagList.push(item.carNo);
    !!item.carLength && tagList.push(item.carLength + '米');
    !!item.carType && tagList.push(item.carType);
    !!item.favRate && tagList.push('好评率' + item.favRate);
    return (
      <TouchableWithoutFeedback onPress={() => this.goTaskDetail(item)}>
        <View style={[styles.itemCard, { flexDirection: 'row' }]}>
          <View style={{ marginRight: autoFix(24) }}>
            <Image style={styles.avatar} source={images.default_avatar} />
          </View>
          <View style={{ flex: 1 }}>
            <View style={[styles.flexRow, styles.flexRowBetween]}>
              <View style={{ flex: 1 }}>
                <View>
                  <MBText size="md" bold>
                    {item.driverName}
                  </MBText>
                </View>
                <View style={[styles.flexRow, { flex: 1, flexWrap: 'wrap' }]}>
                  {tagList.map((text: any) => {
                    return <MBText style={[styles.tagText, { marginTop: autoFix(10), marginRight: autoFix(10) }]}>{text}</MBText>;
                  })}
                </View>
              </View>
              <View style={styles.flexColumn}>
                {!!cargoStatusAbleMap[item.callLogCargoStatus || 0] && (
                  <TouchableWithoutFeedback onPress={() => this.openModal(item)}>
                    <Image style={styles.icon_telephone} source={images.icon_telephone2} />
                  </TouchableWithoutFeedback>
                )}
                <MBText
                  style={{ fontSize: autoFix(22), marginTop: autoFix(12), fontWeight: '500' }}
                  color={cargoStatusColorMap[item.callLogCargoStatus || 2]}
                >
                  {item.callLogCargoStatus || '-'}
                </MBText>
              </View>
            </View>
            <View style={[styles.flexRowBetween, { marginTop: autoFix(20) }]}>
              <MBText size="xs" color="#333333" style={{ flex: 1 }}>
                满帮安全号({item.contactNum || 0})
              </MBText>
              <MBText style={{ fontSize: autoFix(20) }} color="#999999">
                {item.yesterday ? '昨天' : ''} {item.lastCallingTime}
              </MBText>
            </View>
            <View style={[styles.flexRowBetween, { marginTop: autoFix(12) }]}>
              <MBText size="xs" color="#666666" style={{ flex: 1 }}>
                {item.loadAddress} → {item.unloadAddress}
              </MBText>
              <View style={[styles.flexRow, { alignItems: 'flex-start' }]}>
                <Image style={styles.icon_connect} source={iconConnectMap[type]} />
                <MBText style={{ fontSize: autoFix(20) }} color={hangUp ? '#FF3A3A' : '#999999'}>
                  {hangUp ? (callerRole == 1 ? '来电未接通' : '去电未接通') : '最近通话时间' + (item.callDuration || '-')}
                </MBText>
              </View>
            </View>
            <View style={[styles.flexRowBetween, { marginTop: autoFix(12) }]}>
              <MBText size="xs" color="#666666">
                {item.dispatcherName}/{item.dispatcherPhone}
              </MBText>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    );
  }
  typeGoodsElement() {
    const { item } = this.props;
    const goodsInfoList = [];
    const truckLength = item?.truckLengthList?.map((item) => item + '米').join('/');
    !!truckLength && goodsInfoList.push(truckLength);
    const truckType = item?.truckTypeList?.join('/');
    !!truckType && goodsInfoList.push(truckType);
    const cargoInfo = [];
    !!item.cargoWeight && cargoInfo.push(item.cargoWeight + '吨');
    !!item.cargoCapacity && cargoInfo.push(item.cargoCapacity + '方');
    !!item.cargoName && cargoInfo.push(item.cargoName);
    !!cargoInfo.length && goodsInfoList.push(cargoInfo?.join('|'));
    const goodsInfo = goodsInfoList.join('   ');
    return (
      <View>
        <TouchableWithoutFeedback onPress={() => this.goTaskDetail(item)}>
          <View style={styles.itemCard}>
            <View style={styles.flexRowBetween}>
              <View style={{ flex: 1, flexDirection: 'row' }}>
                <MBText size="md" bold style={{ fontFamily: 'PingFangSC-Semibold', flexShrink: 1 }}>
                  {item.loadAddress}
                </MBText>
                <MBText size="md" bold style={{ fontFamily: 'PingFangSC-Semibold', marginHorizontal: autoFix(5) }}>
                  →
                </MBText>
                <MBText size="md" bold style={{ fontFamily: 'PingFangSC-Semibold', flexShrink: 1 }}>
                  {item.unloadAddress}
                </MBText>
              </View>
              <MBText
                style={{ fontSize: autoFix(22), marginTop: autoFix(10) }}
                color={cargoStatusColorMap[item.callLogCargoStatus || 2]}
                bold
              >
                {item.callLogCargoStatus}
              </MBText>
            </View>
            <View style={[{ flexDirection: 'row', marginTop: autoFix(20) }]}>
              <MBText color="#999999" size="xs" style={{ width: autoFix(116) }}>
                货源信息
              </MBText>
              <MBText color="#666666" size="xs" style={{ flex: 1 }}>
                {goodsInfo}
              </MBText>
            </View>
            <View style={[styles.flexRow, { marginTop: autoFix(20) }]}>
              <MBText color="#999999" size="xs" style={{ width: autoFix(116) }}>
                调度员
              </MBText>
              <MBText color="#666666" size="xs">
                {item.dispatcherName}/{item.dispatcherPhone}
              </MBText>
            </View>
          </View>
        </TouchableWithoutFeedback>
        {!!item.selected && this.goodsPupopElement(item)}
        <TouchableOpacity
          style={[
            styles.flexRow,
            {
              height: autoFix(72),
              justifyContent: 'center',
              backgroundColor: '#FFF',
              marginHorizontal: autoFix(20),
              borderTopColor: '#E8E8E8',
              borderTopWidth: autoFix(1),
            },
          ]}
          onPress={() => this.openPopup(item)}
        >
          <MBText color="#999999" size="xs">
            {item.driverCallRecordResponses?.length || '0'}人已联系
          </MBText>
          <Image style={[{ height: autoFix(18), width: autoFix(18) }, item.selected ? styles.upturned : null]} source={images.icon_down} />
        </TouchableOpacity>
      </View>
    );
  }
  goodsPupopElement(el: any) {
    const row = el.driverCallRecordResponses;
    return (
      <View style={{ marginTop: autoFix(8) }}>
        {row.map((item: any) => {
          const callerRole = item.callerRole; // 主动发起者 1.司机  2.货主
          const hangUp = item.hangUp; // 是否挂断  0.否 1.是
          const type = String(callerRole) + String(hangUp);
          const tagList: any[] = [];
          !!item.carNo && tagList.push(item.carNo);
          !!item.carLength && tagList.push(item.carLength + '米');
          !!item.carType && tagList.push(item.carType);
          !!item.favRate && tagList.push('好评率' + item.favRate);
          item.callLogCargoStatus = el.callLogCargoStatus; // 注入货源状态
          item.dispatcherId = el.dispatcherId; // 注入
          item.dispatcherPhone = el.dispatcherPhone; // 注入
          item.cargoId = el.cargoId; // 注入 平台货源id
          item.cargoStatus = el.cargoStatus; // 注入 平台货源状态
          return (
            <View style={[styles.itemCard, { marginTop: 0, flexDirection: 'row' }]}>
              <View style={{ marginRight: autoFix(24) }}>
                <Image style={styles.avatar} source={images.default_avatar} />
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.flexRowBetween}>
                  <View style={{ flex: 1 }}>
                    <MBText size="xs" bold>
                      {item.driverName || '-'}
                    </MBText>
                    <View style={[styles.flexRow, { flex: 1, flexWrap: 'wrap' }]}>
                      {tagList.map((text: any) => {
                        return <MBText style={[styles.tagText, { marginTop: autoFix(10), marginRight: autoFix(10) }]}>{text}</MBText>;
                      })}
                    </View>
                  </View>
                  {!!cargoStatusAbleMap[item.callLogCargoStatus] && (
                    <TouchableWithoutFeedback onPress={() => this.openModal(item)}>
                      <Image style={styles.icon_telephone} source={images.icon_telephone2} />
                    </TouchableWithoutFeedback>
                  )}
                </View>
                <View style={{ marginTop: autoFix(10) }}>
                  <MBText size="xs" color="#333333">
                    满帮安全号({item.contactNum})
                  </MBText>
                </View>
                <View style={[styles.flexRowBetween, { marginTop: autoFix(8) }]}>
                  <View style={styles.flexRow}>
                    <Image style={styles.icon_connect} source={iconConnectMap[type]} />
                    <MBText style={{ fontSize: autoFix(20) }} color={hangUp ? '#FF3A3A' : '#999999'}>
                      {hangUp ? (callerRole == 1 ? '来电未接通' : '去电未接通') : '最近通话时间' + (item.callDuration || '-')}
                    </MBText>
                  </View>
                  <View>
                    <MBText style={{ fontSize: autoFix(20) }} color="#999999">
                      {item.yesterday ? '昨天' : ''} {item.lastCallingTime || ''}
                    </MBText>
                  </View>
                </View>
              </View>
            </View>
          );
        })}
      </View>
    );
  }
  render(): JSX.Element {
    const { item } = this.props;
    const renderMap = {
      0: this.typeGoodsElement(),
      1: this.typeDriverElement(),
    };
    return <View style={{ width: '100%' }}>{renderMap[item.type]}</View>;
  }
}
