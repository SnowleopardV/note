import { Button, MBText, Modal, Whitespace } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import * as React from 'react';
import { Image, ScrollView, StyleSheet, TouchableWithoutFeedback, View } from 'react-native';
import { modalProps } from '~/pages/callRecords/propTypes';
import images from '~public/static/images';
import API from '~/pages/callRecords/api';
import NativeBridge from '~/extends/NativeBridge';
import { MBBridge } from '@ymm/rn-lib';
/** 已成交 拨打号码 模态窗 真实号/虚拟号 */
export default class DealNumberModal extends React.Component<modalProps, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      numberType: 0, // 0 虚拟号 1真实号
    };
  }
  colseModal() {
    const { onColse } = this.props;
    !!onColse && onColse();
  }
  changeNumberType(val: number) {
    this.setState({ numberType: val });
  }
  submit = () => {
    console.log('立即拨打');
    const { numberType } = this.state;
    const { data } = this.props;
    if (numberType === 0) {
      this.api_callBind();
    } else {
      const telephone = data.calledPhones[0];
      NativeBridge.dial({ telephone: telephone }); // 拨打号码
      this.api_uploadShipperCallLog(0);
    }
  };
  // 获取被叫号码
  api_callBind() {
    const { data } = this.props;
    const formData = {
      shipperId: data.shipperId, // 货主ID
      driverId: data.driverId, // 司机ID
      shipperLoginPhone: data.shipperLoginPhone, // 货主注册号码
      callerPhones: data.callerPhones, // 货主主叫号码
      calledPhones: data.calledPhones, // 司机被叫号码
      cargoId: data.cargoId, // 货源id
    };
    API.callBind(formData).then((res: any) => {
      if (res.data?.calledPhone) {
        // 隐私号是否降级 0.否  1.是
        if (res.data?.isDegraded) {
          this.api_uploadShipperCallLog(1);
          NativeBridge.dial({ telephone: res.data.calledPhone }); // 司机注册号码
        } else {
          NativeBridge.dial({ telephone: res.data.calledPhone }); // 拨打号码
        }
      }
    });
  }
  /** 真实号码通话记录上报 */
  api_uploadShipperCallLog(isDownGrade: 0 | 1) {
    const { data } = this.props;
    const formData = {
      shipperId: data.shipperId, // 货主ID
      driverId: data.driverId, // 司机ID
      cargoId: data.cargoId, // 货源ID
      cargoStatus: data.cargoStatus, // 平台货源状态
      isDownGrade: isDownGrade, // 否隐私号降级真实号码场景 0.否  1.是
    };
    API.uploadShipperCallLog(formData);
  }

  render(): JSX.Element {
    const { visible, data } = this.props;
    const { numberType } = this.state;
    return (
      <Modal
        modalType="View"
        closable
        position="center"
        visible={visible}
        onCancel={() => this.colseModal()}
        onMaskClose={() => this.colseModal()}
        onClose={() => this.colseModal()}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        <View style={{ width: '100%' }}>
          <Image style={styles.headerBg} source={images.dealNumberHeaderbg} />
          <View style={[styles.flexRowItem, { marginTop: autoFix(40) }]}>
            <TouchableWithoutFeedback onPress={() => this.changeNumberType(0)}>
              <View style={[styles.selectNumberType, { borderColor: numberType === 0 ? '#4885FF' : '#CCCCCC' }]}>
                <MBText color={numberType === 0 ? '#4885FF' : '#CCCCCC'} bold={numberType === 0} size="xs">
                  虚拟号码拨打
                </MBText>
                <MBText color={numberType === 0 ? '#4885FF' : '#CCCCCC'} style={{ fontSize: autoFix(20) }}>
                  纠纷有保障
                </MBText>
                <Image style={styles.selectIcon} source={numberType === 0 ? images.icon_selected : images.icon_unselected} />
              </View>
            </TouchableWithoutFeedback>
            <TouchableWithoutFeedback onPress={() => this.changeNumberType(1)}>
              <View style={[styles.selectNumberType, { borderColor: numberType === 1 ? '#4885FF' : '#CCCCCC' }]}>
                <MBText color={numberType === 1 ? '#4885FF' : '#CCCCCC'} bold={numberType === 1} size="xs">
                  真实号码拨打
                </MBText>
                <Image style={styles.selectIcon} source={numberType === 1 ? images.icon_selected : images.icon_unselected} />
              </View>
            </TouchableWithoutFeedback>
          </View>
          {numberType === 0 ? (
            <>
              <View style={[{ marginTop: autoFix(28) }, styles.flexRowItem]}>
                <MBText style={{ fontSize: autoFix(22) }} color="#666666">
                  仅限使用以下号码呼出，否则无法呼出
                </MBText>
              </View>
              <ScrollView style={{ maxHeight: autoFix(400), marginVertical: autoFix(14) }} contentContainerStyle={[styles.flexColumnItem]}>
                {data?.callerPhones.map((text: any) => {
                  return (
                    <MBText style={{ fontSize: autoFix(48), fontWeight: '600' }} color="#333333">
                      {text}
                    </MBText>
                  );
                })}
              </ScrollView>
              <View style={[{ marginBottom: autoFix(8) }, styles.flexRowItem]}>
                <MBText style={{ fontSize: autoFix(22), textAlign: 'center', width: autoFix(438) }} color="#999999">
                  {data.phoneChangeTip || ''}
                </MBText>
              </View>
              <Whitespace vertical={14} />
              <View style={{ paddingHorizontal: autoFix(44) }}>
                <Button radius style={styles.btn} interval={500} onPress={this.submit} size="sm" type="primary">
                  <Image resizeMode="stretch" style={styles.btnBg} source={images.btn_buleBg} />
                  <MBText color="#FFFFFF" size="lg" bold>
                    立即拨打
                  </MBText>
                </Button>
              </View>
            </>
          ) : (
            <>
              <Whitespace vertical={14} />
              <View style={{ paddingHorizontal: autoFix(44) }}>
                <Button radius style={styles.btn} interval={500} onPress={this.submit} size="sm" type="primary">
                  <Image resizeMode="stretch" style={styles.btnBg} source={images.btn_buleBg} />
                  <View style={{ flexDirection: 'row', alignContent: 'center', alignItems: 'center' }}>
                    <Image style={{ height: autoFix(49), width: autoFix(48), marginRight: autoFix(13) }} source={images.icon_telephone_w} />
                    <MBText color="#FFFFFF" size="lg" bold>
                      {data.calledPhones[0]}
                    </MBText>
                  </View>
                </Button>
              </View>
            </>
          )}
          <Whitespace vertical={20} />
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  headerBg: {
    height: autoFix(231),
    width: autoFix(591),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  flexRowItem: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  flexColumnItem: {
    width: '100%',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectNumberType: {
    borderWidth: autoFix(2),
    borderColor: '#CCCCCC',
    borderRadius: autoFix(15),
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: autoFix(11),
    width: autoFix(239),
    height: autoFix(84),
    marginHorizontal: autoFix(12),
    position: 'relative',
  },
  selectIcon: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: autoFix(37),
    height: autoFix(20),
  },
  btn: {
    backgroundColor: '#4885FF',
    width: autoFix(502),
    height: autoFix(73),
  },
  btnBg: {
    position: 'absolute',
    top: autoFix(-2),
    right: autoFix(-2),
    bottom: autoFix(-2),
    left: autoFix(-2),
    width: autoFix(502),
    height: autoFix(73),
  },
});
