import { Button, CellGroup, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import * as React from 'react';
import { Image, SafeAreaView, ScrollView, StyleSheet, TouchableOpacity, TouchableWithoutFeedback, View } from 'react-native';
import Cell from '~/components/common/Cell';
import { modalProps } from '~/pages/callRecords/propTypes';
import API from '~/pages/callRecords/api';
import NativeBridge from '~/extends/NativeBridge';
/** 组织 + 调度员 列表 */
export default class OrgDispatchListModal extends React.Component<modalProps, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      orgItem: null,
      dispatcherItem: null,
      showModal: 0, // 1-组织列表 2 调度员列表
      orgList: [],
      dispatcherList: [],
      selectIndex: 0, // 选择框选择的下标
      isRulesTips: false,
      errorText: [
        '',
        '暂无数据',
        '该公司未关联满运宝企业暂无可用调度账号，请前往pc端（www.tms8.com）登陆后进行授权：公司管理-服务授权-授权',
      ],
    };
  }
  async componentDidMount() {
    await this.api_orgList();
  }
  async api_orgList() {
    try {
      const res: any = await API.orgList();
      console.log('====================orgList[0]=======================');
      console.log(res);
      if (res.data) {
        this.setState({ orgList: res.data, orgItem: res.data[0] }, async () => {
          await this.api_dispatchList(res.data[0]?.orgId);
          !!this.props.onColse && this.props.onColse(this.state.dispatcherItem || {});
        });
      } else {
        this.setState({ orgList: [], orgItem: null });
        !!this.props.onColse && this.props.onColse({});
      }
    } catch (err: any) {
      if (err?.msg) {
        this.state.errorText[1] = err.msg;
      }
      this.setState({ orgList: [], orgItem: null });
      console.log('api_orgList', err);
    }
  }
  async api_dispatchList(orgId: string | number) {
    try {
      const res: any = await API.dispatchList({ organizationId: orgId || null });
      console.log('===========dispatchList==============', res);
      if (res.data?.dispatchList) {
        const userInfo: any = await NativeBridge.getUserInfo();
        const dispatcherItem = res.data.dispatchList.find((item: any) => item.tmsUserId === userInfo.userId) || res.data.dispatchList[0];
        this.state.dispatcherItem = dispatcherItem;
        this.setState({ dispatcherList: res.data.dispatchList, dispatcherItem: dispatcherItem });
      } else {
        this.setState({ dispatcherList: [], dispatcherItem: null });
      }
    } catch (err: any) {
      if (err?.msg) {
        this.state.errorText[2] = err.msg;
      }
      this.setState({ dispatcherList: [], dispatcherItem: null });
      console.log('api_dispatchList', err);
    }
  }
  colseModal() {
    const { onColse } = this.props;
    !!onColse && onColse();
  }
  openModal(val: number) {
    const { orgItem, dispatcherItem, orgList, dispatcherList } = this.state;
    if (val === 1 && orgItem) {
      this.setState({ selectIndex: orgList.findIndex((item: any) => item.orgId === orgItem.orgId) });
    } else if (val === 2 && dispatcherItem) {
      this.setState({ selectIndex: dispatcherList.findIndex((item: any) => item.mybConsignorId === dispatcherItem.mybConsignorId) });
    }
    this.setState({ showModal: val });
  }
  reset = () => {
    console.log('reset');
    const { orgList } = this.state;
    this.setState({ orgItem: orgList[0] }, () => this.api_dispatchList(orgList[0]?.orgId));
  };
  submit = () => {
    console.log('提交');
    const { dispatcherItem } = this.state;
    const { onColse } = this.props;
    if (dispatcherItem) {
      !!onColse && onColse(dispatcherItem);
    } else {
      this.setState({ isRulesTips: true });
    }
  };
  handleChange = (index: number) => {
    console.log('改变', index);
    this.setState({ selectIndex: index });
  };
  handleConfirm = () => {
    console.log('确定');
    const { showModal, orgList, dispatcherList, selectIndex } = this.state;
    if (showModal === 1) {
      const orgItem = orgList[selectIndex];
      this.setState({ orgItem: orgItem, selectIndex: 0, showModal: 0, dispatcherList: [], dispatherItem: null });
      this.api_dispatchList(orgItem.orgId);
    } else {
      this.setState({ dispatcherItem: dispatcherList[selectIndex], selectIndex: 0, showModal: 0 });
    }
  };

  mainListElement() {
    const { visible } = this.props;
    const { orgItem, dispatcherItem, isRulesTips } = this.state;
    return (
      <Modal
        modalType="View"
        title="筛选条件"
        position="bottom"
        visible={visible}
        onCancel={() => this.colseModal()}
        onMaskClose={() => this.colseModal()}
        contentStyle={{ paddingHorizontal: 0 }}
        headerLine={false}
        autoAdjustPosition={true}
      >
        <View style={{ width: '100%' }}>
          <CellGroup withBottomLine>
            <Cell
              title="组织"
              value={orgItem?.orgName}
              align="right"
              placeholder="请选择"
              numberOfLines={1}
              onPress={() => this.openModal(1)}
            />
            <Cell
              title="调度员"
              value={dispatcherItem?.dispatcherName}
              align="right"
              placeholder="请选择"
              numberOfLines={1}
              onPress={() => this.openModal(2)}
              extra={
                isRulesTips &&
                !dispatcherItem && (
                  <View style={{ paddingRight: autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      调度员未填
                    </MBText>
                    <Whitespace vertical={12} />
                  </View>
                )
              }
            />
          </CellGroup>
          <View style={styles.bottomBtn}>
            <TouchableOpacity style={[styles.btn]} onPress={() => this.reset()}>
              <MBText style={{ fontSize: autoFix(34) }}>重置</MBText>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.btn, { backgroundColor: '#4885FF' }]} onPress={() => this.submit()}>
              <MBText style={{ fontSize: autoFix(34), color: '#FFFFFF' }}>确定</MBText>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  }

  listElement() {
    const { showModal, orgList, dispatcherList, selectIndex, errorText } = this.state;
    const listMap = {
      1: orgList.map((item: any) => ({
        ...item,
        content(selected: boolean) {
          return (
            <MBText bold={selected} size={selected ? 'md' : 'sm'} color={selected ? 'primary' : 'base'} numberOfLines={1}>
              {item?.orgName}
            </MBText>
          );
        },
      })),
      2: dispatcherList.map((item: any) => ({
        ...item,
        content(selected: boolean) {
          return (
            <MBText bold={selected} size={selected ? 'md' : 'sm'} color={selected ? 'primary' : 'base'} numberOfLines={1}>
              {item?.dispatcherName}-{item?.phone}
            </MBText>
          );
        },
      })),
    };
    return (
      <Modal
        headerLeft="取消"
        headerRight={this.rightElement()}
        title={showModal === 1 ? '请选择组织' : '请选择调度员'}
        position="bottom"
        visible
        onCancel={() => this.openModal(0)}
        onMaskClose={() => this.openModal(0)}
        onClose={() => this.openModal(0)}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        {listMap[showModal].length ? (
          <>
            <View style={{ flexDirection: 'column', width: '100%' }}>
              <Selector type={2} value={selectIndex} rowTitle="content" list={listMap[showModal]} onChange={this.handleChange} />
            </View>
            <Whitespace vertical={20} />
          </>
        ) : (
          <View style={{ justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20, height: autoFix(400) }}>
            <MBText color="#999999" size="xs">
              {errorText[showModal]}
            </MBText>
          </View>
        )}
      </Modal>
    );
  }
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render(): JSX.Element {
    const { showModal } = this.state;
    if (showModal === 0) {
      return this.mainListElement();
    } else {
      return this.listElement();
    }
  }
}

const styles = StyleSheet.create({
  bottomBtn: {
    flexDirection: 'row',
    height: autoFix(118),
  },
  btn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
