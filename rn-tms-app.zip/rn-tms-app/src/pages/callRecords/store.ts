import { observable, action } from 'mobx';

class Store {
  @observable data = null;
}
export default Store;
