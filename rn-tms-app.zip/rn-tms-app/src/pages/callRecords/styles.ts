import { StyleSheet } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  page: {
    flex: 1,
    position: 'relative',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  flexRowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  flexColumn: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerFilter: {
    backgroundColor: '#fff',
    height: autoFix(98),
    borderBottomColor: '#EEEEEE',
    borderBottomWidth: 1,
  },
  icon: {
    width: autoFix(30),
    height: autoFix(30),
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  itemCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    marginTop: autoFix(20),
    marginRight: autoFix(20),
    marginLeft: autoFix(20),
    paddingHorizontal: autoFix(24),
    paddingVertical: autoFix(32),
  },
  avatar: {
    height: autoFix(80),
    width: autoFix(80),
    backgroundColor: '#eee',
    borderRadius: 100,
  },
  tagText: {
    color: '#999999',
    fontSize: autoFix(22),
    backgroundColor: '#F4F4F4',
    padding: autoFix(5),
  },
  icon_telephone: {
    height: autoFix(48),
    width: autoFix(48),
  },
  icon_connect: {
    height: autoFix(28),
    width: autoFix(28),
    marginRight: autoFix(10),
  },
});
