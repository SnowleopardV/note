import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { Provider } from 'mobx-react';
import Store from '../store';
import taskManageStore from '~/pages/task-manage/store';

const CustomerSelector: React.FunctionComponent<any> = (props) => {
  const store = new Store();
  const RootStack = new RouterMap().getRouterMap(RouterPageName.callRecordsList);
  return (
    <Provider store={store} taskManageStore={taskManageStore}>
      <RootStack screenProps={props} />
    </Provider>
  );
};

export default CustomerSelector;
