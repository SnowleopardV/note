import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import callRecordsListPage from '~/pages/callRecords/list';
import TaskDetailPage from '~/pages/task-manage/detail';
/**
 * RN页面
 */
export enum RouterPageName {
  callRecordsList = 'callRecordsList',
  TaskDetail = 'TaskDetail',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        callRecordsList: { screen: callRecordsListPage, navigationOptions: () => ({ header: null }) }, // 通话记录列表
        TaskDetail: { screen: TaskDetailPage, navigationOptions: () => ({ header: null }) }, // 任务详情
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
