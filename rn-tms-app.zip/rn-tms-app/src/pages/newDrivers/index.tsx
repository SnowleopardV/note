import * as React from 'react';
import {
  View,
  TextInput,
  Image,
  SafeAreaView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import { YMMCommonNavBar, YMMText, HelperUtils, MBBridge } from '@ymm/rn-lib';
import { CellGroup, Whitespace, Button, LayProvider, MBText } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import InputItem from '~/components/common/InputItem/index';
import NavBar from '~/components/common/NavBar';
import verification from '~/extends/verification';
import NativeBridge from '~/extends/NativeBridge'; // 原生api
import API from './api'; // 原生api
// 新增承运司机
const styles = StyleSheet.create({
  foot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
    backgroundColor: '#FFFFFF',
  },
  btn: {
    margin: 10,
  },
  container: {
    flex: 1,
  },
  inner: {
    padding: 24,
    flex: 1,
    justifyContent: 'space-around',
  },
  header: {
    fontSize: 36,
    marginBottom: 48,
  },
  textInput: {
    height: 40,
    borderColor: '#000000',
    borderBottomWidth: 1,
    marginBottom: 36,
  },
  btnContainer: {
    backgroundColor: 'white',
    marginTop: 12,
  },
  hiddenFoot: {
    display: 'none',
  },
});

export interface Props {
  item: string;
}
export default class TaskList extends React.Component<Props, any> {
  timerBtn: any = null;
  keyboardDidHideListener: any = null;
  constructor(props: Props) {
    super(props);
    let item = {};
    try {
      item = JSON.parse(decodeURIComponent(this.props.item));
    } catch (error) {
      item = this.props.item;
    }
    const { driverType, carrierId } = item;
    this.state = {
      driverId: '', // 司机Id
      driverName: '', // 司机姓名
      driverPhone: '', // 司机手机号
      driverType: driverType, // 司机类型 11：自有 12：外调 13：承运商
      carrierId: carrierId, // 非必须 承运商id
      platformFlag: null, // 非必须 是否平台司机 1：是；0：否
      isHiddenBtn: false, // 是否隐藏底部按钮
    };
  }
  componentDidMount() {
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => {
      Keyboard.dismiss();
    });
  }
  componentWillUnmount() {
    this.keyboardDidHideListener.remove();
  }
  goBack = () => {
    MBBridge.rnruntime.handlebackResult({ data: JSON.stringify(this.state) });
    MBBridge.app.ui.closeWindow({});
  };
  // 点击保存
  submit = () => {
    const { driverName, driverPhone } = this.state;
    if (!verification.phone(driverPhone)) {
      NativeBridge.toast('手机号码格式错误');
    } else {
      this.api_addDriver();
    }
  };
  api_addDriver() {
    console.log(this.state);
    API.addDriver(this.state).then((res) => {
      console.log('添加司机', res);
      if (res.success) {
        NativeBridge.toast('添加司机成功');
        if (res.data) {
          this.setState({
            driverId: res.data,
          });
        }
        this.goBack();
      } else {
        NativeBridge.toast(res.msg);
      }
    });
  }
  // 改变司机名称
  changeName(text: string) {
    this.setState({ driverName: text });
  }
  // 改变司机电话
  changePhone = (text: string) => {
    this.setState({ driverPhone: text });
  };
  hiddenButton(val: boolean) {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ isHiddenBtn: val });
    }, 0);
  }
  // 是否可以提交
  submitDisabled() {
    const { driverName, driverPhone } = this.state;
    return driverName && driverPhone;
  }
  public render() {
    const { isHiddenBtn } = this.state;
    return (
      <LayProvider theme="skyblue" style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={{ flex: 1 }}>
            <NavBar title="新增承运司机" />
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <InputItem
                required
                title="司机名称"
                inputStyle={{ width: '100%', textAlign: 'right' }}
                placeholder="请输入"
                maxLength={20}
                returnKeyType="done"
                onSubmitEditing={Keyboard.dismiss}
                onChangeText={(text) => this.changeName(text)}
                onFocus={() => this.hiddenButton(true)}
                onBlur={() => this.hiddenButton(false)}
              />
            </CellGroup>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <InputItem
                inputStyle={{ width: '100%', textAlign: 'right' }}
                required
                title="司机电话"
                placeholder="请输入"
                keyboardType="numeric"
                maxLength={11}
                returnKeyType="done"
                onSubmitEditing={Keyboard.dismiss}
                onChangeText={this.changePhone}
                onFocus={() => this.hiddenButton(true)}
                onBlur={() => this.hiddenButton(false)}
              />
            </CellGroup>
            <View style={isHiddenBtn ? styles.hiddenFoot : styles.foot}>
              <SafeAreaView>
                <Button
                  radius
                  disabled={!this.submitDisabled()}
                  style={styles.btn}
                  onPress={this.submit.bind(this)}
                  size="sm"
                  type="primary"
                >
                  保存并使用
                </Button>
              </SafeAreaView>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </LayProvider>
    );
  }
}
