import server from '~/server';

// 文档 http://yapi.1111.com/#/project/2532/interface/api/187837
const Api = {
  // 创建调度-新增司机接口
  addDriver(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/add/driver',
      data: { ...params },
    });
  },
};

export default Api;
