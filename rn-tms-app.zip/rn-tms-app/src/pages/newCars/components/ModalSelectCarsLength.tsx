import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, Button, Theme, MBText, Whitespace } from '@ymm/rn-elements';
import keyMap from '~/pages/dispatch/keyMap';

// 选择车长 模态框
interface Props {
  visible?: boolean;
  onChange?: any;
  listMap?: any;
}

export default class SelectCarsLengthModal extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
    const carLengthList = keyMap.carLengthList.map((item: any) => {
      return { id: item.lengthId, name: item.lengthName };
    });
    const list = this.props?.listMap ? this.props.listMap : carLengthList;
    this.state = {
      index: 0,
      item: list[0],
      list: list.map((item: any) => {
        return {
          ...item,
          content(selected: boolean) {
            return (
              <Flex direction="row" justify="center" align="center">
                <MBText bold={selected} color={selected ? 'primary' : 'base'} numberOfLines={1}>
                  {item.name}
                </MBText>
              </Flex>
            );
          },
        };
      }),
    };
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { item } = this.state;
    onChange && onChange(item);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleChange = (position: number, item: any) => {
    this.setState({
      index: position,
      item: item,
    });
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { index, list } = this.state;
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请选择车长（米）"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row" justify="center" align="center">
            <Flex.Item key="time">
              <View style={{ flexDirection: 'column' }}>
                <Selector type={2} value={index} rowTitle="content" list={list} scaleFont={true} onChange={this.handleChange} />
              </View>
            </Flex.Item>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
