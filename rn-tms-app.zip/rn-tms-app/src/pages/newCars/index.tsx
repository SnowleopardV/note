import * as React from 'react';
import { View, SafeAreaView, StyleSheet } from 'react-native';
import { MBBridge, MBLog } from '@ymm/rn-lib';
import { LayProvider, CellGroup, Whitespace, Button } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import NavBar from '~/components/common/NavBar';
import ModalSelectCarsLength from './components/ModalSelectCarsLength'; // 选择车长
import ModalSelectCarsType from './components/ModalSelectCarsType'; // 选择车型
import NativeBridge from '~/extends/NativeBridge'; // 原生api
import verification from '~/extends/verification'; // 公共验证
import API from './api'; // 公共验证

// 新增车辆
const styles = StyleSheet.create({
  page: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  foot: {
    backgroundColor: '#FFFFFF',
  },
  btn: {
    margin: 10,
  },
});

export interface Props {
  item: string;
}
export default class newCars extends React.Component<Props, any> {
  constructor(props: Props) {
    super(props);
    let item = {};
    try {
      item = JSON.parse(decodeURIComponent(this.props.item));
    } catch (error) {
      item = this.props.item;
    }
    const { truckSource, carrierId } = item;
    if (!truckSource) {
      MBLog.log('未传值-车辆来源:truck-source,必传');
    }
    this.state = {
      showModal: 0, // 0 无 1 车长 2 车型
      truckTypeText: '', // 车型
      truckLengthText: '', // 车长
      formData: {
        truckNo: '', // 车牌号
        truckType: '', // 车型
        truckLength: '', // 车长
        truckSource: truckSource, // 车辆来源 1：自有 2：挂靠 3：合同 4：外调 5：承运商
        carrierId: carrierId, // 非必须 承运商id
        truckTypeText: '', // 车型文案
        truckLengthText: '', // 车长文案
        carId: '', // 车辆Id
      },
    };
  }

  goBack = () => {
    console.log('goBack');
    MBBridge.rnruntime.handlebackResult({ data: JSON.stringify(this.state.formData) });
    MBBridge.app.ui.closeWindow({ data: 1 });
  };
  openModal = (val: any) => {
    this.setState({ showModal: val, showDetail: false });
  };
  // 选择车长
  handleCarsLengthChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      this.setState(({ formData }) => ({
        truckLengthText: val.name, // 车长
        formData: { ...formData, truckLength: val.id, truckLengthText: val.name },
      }));
    }
  };
  // 车型
  handleCarsTypeChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      this.setState(({ formData }) => ({
        truckTypeText: val.name, // 车型
        formData: { ...formData, truckType: val.id, truckTypeText: val.name },
      }));
    }
  };
  // 车牌号
  inputLicenseNum = () => {
    MBBridge.app.ui.inputCarNumber({}).then((res) => {
      const val = res.data.value;
      this.setState(({ formData }) => ({
        formData: { ...formData, truckNo: val },
      }));
    });
  };
  // 点击保存
  submit = () => {
    console.log('保存', this.state);
    const { formData } = this.state;
    if (!verification.car(formData.truckNo)) {
      NativeBridge.toast('车牌号格式错误');
    } else if (!formData.truckLength) {
      NativeBridge.toast('请选择车长');
    } else if (!formData.truckType) {
      NativeBridge.toast('请选择车型');
    } else {
      this.api_addTruck();
    }
  };
  api_addTruck() {
    const { formData } = this.state;
    API.addTruck(formData).then((res) => {
      console.log('添加车辆', res);
      if (res.success) {
        NativeBridge.toast('添加成功');
        this.setState(({ formData }) => ({
          formData: { ...formData, carId: res.data },
        }));
        this.goBack();
      } else {
        NativeBridge.toast(res.msg);
      }
    });
  }
  // 是否可以提交
  submitDisabled() {
    const { formData } = this.state;
    return formData.truckNo && formData.truckType && formData.truckLength;
  }
  public render() {
    const { showModal, formData, truckLengthText, truckTypeText } = this.state;

    return (
      <LayProvider theme="skyblue" style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <View style={{ flex: 1 }}>
          <NavBar title="新增车辆" />
          <View style={styles.page}>
            <View>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="车牌号"
                  value={formData.truckNo}
                  align="right"
                  placeholder="请输入"
                  onPress={this.inputLicenseNum.bind(this)}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="车型"
                  value={truckTypeText}
                  align="right"
                  placeholder="请选择"
                  onPress={this.openModal.bind(this, 2)}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="车长"
                  value={truckLengthText}
                  align="right"
                  placeholder="请选择"
                  onPress={this.openModal.bind(this, 1)}
                />
              </CellGroup>
            </View>
            <View style={styles.foot}>
              <Button disabled={!this.submitDisabled()} radius style={styles.btn} onPress={this.submit.bind(this)} size="sm" type="primary">
                保存并使用
              </Button>
              <SafeAreaView style={{ backgroundColor: '#fff' }} />
            </View>
          </View>
          <ModalSelectCarsLength visible={showModal === 1} onChange={this.handleCarsLengthChange} />
          <ModalSelectCarsType visible={showModal === 2} onChange={this.handleCarsTypeChange} />
        </View>
      </LayProvider>
    );
  }
}
