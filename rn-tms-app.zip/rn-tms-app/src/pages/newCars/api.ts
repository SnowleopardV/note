import server from '~/server';

// 文档 http://yapi.1111.com/#/project/2532/interface/api/187845
const Api = {
  // 创建调度-新增车辆接口
  addTruck(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/add/truck',
      data: { ...params },
    });
  },
};

export default Api;
