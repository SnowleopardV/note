import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  flexing: {
    flex: 1,
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bgImg: {
    position: 'absolute',
    paddingTop: 50,
    backgroundColor: '#4885FF',
  },
  footer: {
    paddingHorizontal: 13,
    paddingVertical: 10,
    backgroundColor: '#fff',
    justifyContent: 'flex-end',
    flexWrap: 'wrap',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  btn: {
    paddingVertical: 5,
    paddingHorizontal: 16,
    borderRadius: 15,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 6,
  },
  btnTxt: {
    fontSize: 14,
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
    color: '#4885FF',
  },
});
