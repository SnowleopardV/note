import * as React from 'react';
import { View, ScrollView, SafeAreaView, Platform, BackHandler, Image, DeviceEventEmitter } from 'react-native';
import { LayProvider, MBText, Modal } from '@ymm/rn-elements';
import { PlatformKit, MBToast, MBBridge, AppStateCompat, App, MBAutoPVComponent } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import StatusBar from '~/components/orderDetail/StatusBar';
import DriverInfo from '~/components/orderDetail/DriverInfo';
import LoadInfo from '~/components/orderDetail/LoadInfo';
import CargoInfo from '~/components/orderDetail/CargoInfo';
import FeeInfo from '~/components/orderDetail/FeeInfo';
import SettlementInfo from '~/components/orderDetail/SettlementInfo'; // 结算方式
import OtherInfo from '~/components/orderDetail/OtherInfo';
import ShipInfo from '~/components/orderDetail/ShipInfo';
import Api from '../api';
import styles from './styles';
import EmptyPage from '~/components/common/EmptyPage';
import CopyModal from '../components/shareModal';
import images from '../../../../public/static/images/index';
import commonData, { goNetworkProtocol } from '~/pages/commonData';
import OpenDispatchResultModal from '~/components/OpenDispatchResultModal';
import FootButtonList from '~/components/FootButtonList';
import NativeBridge from '~/extends/NativeBridge';
import DeliveryInfo from '~/components/orderDetail/DeliveryInfo';

const Confirm = Modal.Confirm;
export default class WaybillDetail extends MBAutoPVComponent<any, any> {
  backHandleListener: any = null;
  pageListener: any;
  refOpenDispatchResult: any;
  isDetailRequestend = false; //标识是否已经请求过详情
  constructor(props: any) {
    super(props);
    this.state = {
      detail: {},
      loaded: false,
      title: '',
      appSupplementErrorData: {},
      showPermissionVisible: false,
      showModal: false,
      copyData: {
        pointBillingTime: '',
        transOrderNo: '',
        loadAddress: '',
        unloadAddress: '',
        cargoInfoForDisplay: '',
        carTypeLengthInfo: '',
        dispatchStatus: '',
        carInfoForDisplay: '',
        estimateTime: '',
        estimateUnloadEndTime: '',
      },
      // 是否来源生成
      isFromSupplyWaybill: false,
      isClose: false,
      isClosedBeiDouTrace: false,
    };
  }

  UNSAFE_componentWillMount = (): void => {
    const { source } = this.props.screenProps;
    // 判断来源
    this.setState({
      isFromSupplyWaybill: source === 'supplywaybill',
    });
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.goBack();
        return true;
      });
    }
  };

  componentDidMount() {
    super.componentDidMount();
    this.getWaybillDetail();
    // 监听当前页面 可见性切换事件,active: 页面是否可见,willUnMount: 页面是否将要销毁
    this.isDetailRequestend = false;
    this.pageListener = AppStateCompat.addPageActiveListener((active: boolean, willUnMount: boolean) => {
      if (active && this.isDetailRequestend) {
        this.getWaybillDetail();
      } else {
        this.isDetailRequestend = true;
      }
    }, this.props);

    MBBridge.app.storage.getItem({ key: 'isClosedBeiDouTrace' }).then((res) => {
      if (res.code === 0) {
        this.setState({
          isClosedBeiDouTrace: Number(res.data?.text),
        });
      }
    });
  }

  componentWillUnmount(): void {
    super.componentWillUnmount();
    this.backHandleListener?.remove();
    this.pageListener?.remove();
  }

  getPageName() {
    return 'dispatch_manage_detail';
  }

  getWaybillDetail = async () => {
    try {
      const { isFromSupplyWaybill } = this.state;

      const id = this.props.screenProps.id || this.props.navigation.state.params?.id;
      // 来自ymm生成参数key值为mybOrderId
      const params = isFromSupplyWaybill ? { mybOrderId: id } : { id };

      const res = await Api.getWaybillDetail(params);
      if (res.code === '90000') {
        this.setState({
          loaded: true,
          showPermissionVisible: true,
          appSupplementErrorData: res.data?.appSupplementError,
        });
      } else {
        let detail = {};
        if (res.data) {
          const { waybillStatusTab } = res.data;
          const { buttonList, ...restData } = res.data;
          buttonList.forEach((item: any) => {
            // 已调度下修改文案
            if (item.code === 'COPY' && waybillStatusTab === 'ALREADY_DISPATCH') {
              item.badge = '北斗轨迹';
              item.name = '分享';
            }
            return item;
          });
          detail = { ...restData, buttonList };
        }

        this.setState({
          loaded: true,
          showPermissionVisible: false,
          detail,
        });
      }
      // 是否显示满帮找车发货结果
      if (commonData.cargoRespList?.length) {
        this.refOpenDispatchResult?.openModal(res.data?.transOrderNo);
      }
    } catch (error) {
      if (error.code === '230074' || error.code === '50003' || error.code === '900002') {
        this.goBack();
      }
    }
  };

  // 获取状态栏
  get statusBarInfo() {
    const { detail } = this.state;
    if (JSON.stringify(detail) == '{}') return {};
    const { dispatchStatus, transOrderNo, mybOrderId, taskNo, mybOrderStatus, mybCorpIcon, orgName, orderFeature } = detail;
    return {
      status: detail.invalid ? '已作废' : dispatchStatus,
      transOrderNo,
      taskNo,
      mybOrderId,
      showMybCancel: mybOrderStatus == 3,
      mybCorpIcon,
      taskType: detail.taskType,
      orgName,
      orderFeature,
    };
  }

  // 获取承运信息
  get driverInfo() {
    const { detail } = this.state;
    return detail.schedulingInfo || null;
  }

  // 获取装货信息
  get loadInfo() {
    const { detail } = this.state;
    return detail.loadList || [];
  }

  // 获取卸货信息
  get unLoadInfo() {
    const { detail } = this.state;
    return detail.unloadList || [];
  }

  // 获取货物信息
  get cargoInfo() {
    const { detail } = this.state;
    return detail.cargoList || [];
  }

  // 获取应收信息
  get feeInfo() {
    const { detail } = this.state;
    let data = detail.feeList || [];
    data = data.map((item) => ({
      name: item.feeCodeDesc,
      value: item.amountDesc,
    }));
    return data;
  }

  // 获取结算信息
  get settlementInfo() {
    const { detail } = this.state;
    return detail.settlementList || [];
  }

  // 获取其他信息
  get otherInfo() {
    const { detail } = this.state;
    return { otherList: detail.otherList || [], dispatcherListInfo: detail.dispatcherListInfo || [] };
  }

  // 运单号
  get orderNo() {
    const { detail } = this.state;
    return detail.orderNo || null;
  }
  // 是否显示底部按钮区
  get showFoot() {
    // 从配载调度列表至运单详情过来的不显示操作按钮
    // 从再来一单列表页面入口过来的不显示操作按钮
    let show = true;
    if (this.props.screenProps.source === 'stowage' || this.props.screenProps.source === 'oneMoreOrder') {
      show = false;
    }
    return show;
  }

  // 获取发货信息
  get shipInfo() {
    const { detail } = this.state;
    return (
      detail.shipInfo || {
        title: '发货信息',
        options: [],
      }
    );
  }

  copyOrders = () => {
    this.setState({
      showModal: true,
    });
  };

  goBack = () => {
    const {
      screenProps: { source },
    } = this.props;

    if (source === 'create') {
      // 来源仅创建，路由返回运单列表
      // this.props.navigation.navigate('WaybillList');
      MBBridge.app.ui.closeWindow({});
      return;
    }

    if (source === 'createdispatch') {
      // 来源创建并调度，路由返回运单列表
      // this.props.navigation.navigate('WaybillList', { source });
      if (Platform.OS === 'android') {
        App.sendEvent('closeWaybillCreateView', { isClose: true });
        MBBridge.app.ui.closeWindow({});
      } else {
        setTimeout(() => {
          App.sendEvent('closeWaybillCreateView', { isClose: true });
        }, 200);
        MBBridge.app.ui.closeWindow({});
      }
      return;
    }

    // 来源调度
    if (source === 'dispatch') {
      if (Platform.OS === 'android') {
        App.sendEvent('refreshWaybillListView', { isClose: true });
        MBBridge.app.ui.closeWindow({});
      } else {
        setTimeout(() => {
          App.sendEvent('refreshWaybillListView', { isClose: true });
        }, 200);
        MBBridge.app.ui.closeWindow({});
      }
      return;
    }

    // 来源生成
    if (source === 'supplywaybill') {
      MBBridge.app.ui.closeWindow({});
      return;
    }

    MBBridge.app.ui.closeWindow({});
  };

  handleScroll = (event) => {
    const { y = 0 } = event.nativeEvent.contentOffset;
    if (y > 60) {
      this.setState({
        title: this.statusBarInfo.status,
      });
    } else {
      this.setState({
        title: '',
      });
    }
  };

  onActions = (val: number) => {
    const id = this.props.screenProps.id;
    if (val === 1) {
      // 去调度
      MBBridge.app.base.openSchema({ url: `ymm://rn.tms/dispatch?id=${id}&sourcepagename=waybill_detail` });
    }
  };
  /**
   * 删除单据
   * @returns {void}
   */
  onDeleteOrder(): void {
    const id = this.props.screenProps.id;
    Confirm({
      title: '删除该运单？',
      closable: true,
      confirmText: '删除',
      content: (
        <View>
          <MBText>运单删除后，将不可找回</MBText>
        </View>
      ),
      onConfirm: async () => {
        try {
          const { data } = await Api.deleteBill({ ids: [id] });
          console.log('成功了', data);
          MBToast.show('删除成功');
          MBBridge.rnruntime.handlebackResult({ data: JSON.stringify({ upDataList: [2] }) }); // 更新运单列表
          this.goBack();
        } catch (err) {
          this.controlErrorHandler(err);
        }
      },
    });
  }
  /**
   * 作废单据
   * @returns {void}
   */
  onDiscard() {
    const id = this.props.screenProps.id;
    Confirm({
      title: '作废该运单？',
      closable: true,
      confirmText: '作废',
      content: (
        <View>
          <MBText>该运单作废后将不能进行其他操作，若需要可恢复作废</MBText>
        </View>
      ),
      onConfirm: async () => {
        try {
          const data = await Api.orderInvalid({ ids: [id] });
          console.log('成功了');
          MBToast.show('作废成功');
          MBBridge.rnruntime.handlebackResult({ data: JSON.stringify({ upDataList: [0, 1, 2] }) }); // 更新运单列表
          this.goBack();
        } catch (err) {
          this.controlErrorHandler(err);
        }
      },
    });
  }
  /**
   * 恢复单据
   * @returns {void}
   */
  onRecover() {
    const id = this.props.screenProps.id;
    Confirm({
      title: '恢复该作废运单？',
      closable: true,
      confirmText: '恢复',
      content: (
        <View>
          <MBText>恢复后该运单将可以进行正常操作</MBText>
        </View>
      ),
      onConfirm: async () => {
        try {
          const { code, msg } = await Api.orderRecover({ ids: [id] });
          console.log('成功了', code);
          MBToast.show('运单恢复成功');
          MBBridge.rnruntime.handlebackResult({ data: JSON.stringify({ upDataList: [0, 1, 2] }) }); // 更新运单列表
          this.goBack();
        } catch (error) {
          this.controlErrorHandler(error);
        }
      },
    });
  }

  //操作报错，因单子被删除则跳转到列表，别的错误则重新请求
  controlErrorHandler(err: { code: string }) {
    const code = err?.code ?? '';
    if (code == '230056' || code == '230057' || code === '20610' || code === '50003') {
      MBBridge.rnruntime.handlebackResult({ data: JSON.stringify({ upDataList: [0, 1, 2] }) }); // 更新运单列表
      this.goBack();
      return;
    }
    this.getWaybillDetail();
  }

  // 底部按钮点击事件
  onClickBottomBtn = (type: string) => {
    const { detail } = this.state;
    // 修改
    if (type === 'UPDATE') {
      const id = this.props.screenProps.id;
      MBBridge.app.base.openSchemeForResult({ schemeUrl: `ymm://rn.tms/waybilledit?id=${id}` }).then((res: any) => {
        // 更新详情页面
        this.getWaybillDetail();
      });
    } else if (type === 'INVALID') {
      // 作废
      this.onDiscard();
    } else if (type === 'COPY') {
      // 文字分享
      this.copyOrders();
    } else if (type === 'SCHEDULING') {
      //调度
      this.onActions(1);
    } else if (type === 'DELETE') {
      // 删除
      this.onDeleteOrder();
    } else if (type === 'RECOVER') {
      // 恢复
      this.onRecover();
    } else if (type === 'FIND_CAR_PLATE') {
      // 跳转找车看板页面
      this.props.navigation.navigate('CarBoard', { orderNo: detail.transOrderNo });
    } else if (type === 'TRACE') {
      if (!this.state.isClosedBeiDouTrace) {
        MBBridge.app.storage.setItem({ key: 'isClosedBeiDouTrace', text: '1' });
      }

      // 轨迹
      NativeBridge.getTmsMoblieUrl().then((res: string) => {
        if (res) {
          const toViewInfo = { transOrderId: detail.orderId, defaultQueryFlag: false };
          const url = res + 'trackSharing/index?toViewInfo=' + encodeURIComponent(JSON.stringify(toViewInfo));
          NativeBridge.openWebViewPage(url);
        }
      });
    } else if (type === 'CONTRACT') {
      goNetworkProtocol(detail);
    } else if (type === 'FREIGHTASSISTANT') {
      // 运价助手
      this.props.navigation.navigate('FreightAssistant', { transOrderNo: detail.transOrderNo });
    }
  };

  render() {
    const { loaded, detail, title, showPermissionVisible, appSupplementErrorData, isFromSupplyWaybill, isClosedBeiDouTrace } = this.state;
    return (
      loaded && (
        <LayProvider theme="skyblue">
          <OpenDispatchResultModal navigation={this.props.navigation} ref={(el) => (this.refOpenDispatchResult = el)} />
          <NavBar
            title={title}
            titleStyle={{ color: '#fff' }}
            leftClick={this.goBack}
            bgColor="#4885FF"
            leftElementImagUri={images.icon_goBack}
          />
          {showPermissionVisible ? (
            <EmptyPage errorData={appSupplementErrorData} />
          ) : (
            <View style={styles.flexing}>
              <ScrollView style={styles.flexing} onScroll={this.handleScroll} scrollEventThrottle={16}>
                <View style={styles.bgImg}>
                  <Image
                    fadeDuration={0}
                    resizeMode="stretch"
                    style={{ width: PlatformKit.Width, height: 343 }}
                    source={images.detail_bg}
                  />
                </View>
                <StatusBar info={this.statusBarInfo} carLengthName={detail.carLengthName} carTypeName={detail.carTypeName} />
                <DriverInfo info={this.driverInfo} status={detail.taskState} lookingCarText={detail.lookingCarText} />
                <LoadInfo
                  loads={this.loadInfo}
                  unLoads={this.unLoadInfo}
                  custName={detail.customerName}
                  orderFeature={detail.orderFeature}
                />
                <CargoInfo info={this.cargoInfo} />
                <ShipInfo info={this.shipInfo} />
                <FeeInfo info={this.feeInfo} />
                <SettlementInfo info={this.settlementInfo} />
                <OtherInfo info={this.otherInfo} />
              </ScrollView>
              {this.showFoot ? (
                <View>
                  <View style={[styles.footer, styles.flexRow]}>
                    <FootButtonList
                      keyText="waybillDetail"
                      maxShowNum={4}
                      buttonList={detail.buttonList}
                      isFromWaybillDetail={true}
                      isClosedBeiDouTrace={isClosedBeiDouTrace}
                      onConfirm={(btn: any) => this.onClickBottomBtn(btn.code)}
                    />
                  </View>
                  <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
                </View>
              ) : null}
              {this.state.showModal && (
                <CopyModal
                  id={this.state.detail.orderId}
                  parent={this}
                  isFromSupplyWaybill={isFromSupplyWaybill}
                  pageName="运单管理详情"
                  navigation={this.props.navigation}
                  clickUrlCallback={() => this.onClickBottomBtn('TRACE')}
                />
              )}
            </View>
          )}
        </LayProvider>
      )
    );
  }
}
