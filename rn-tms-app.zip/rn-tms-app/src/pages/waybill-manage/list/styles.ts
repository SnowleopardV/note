import { StyleSheet, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
export default StyleSheet.create({
  flexing: {
    flex: 1,
  },
  task_list: {
    paddingHorizontal: 10,
    paddingBottom: 10,
  },
  card: {
    width: '100%',
    backgroundColor: '#ffffff',
    marginTop: 10,
    borderRadius: 2,
  },
  actions: {
    paddingVertical: 10,
    paddingLeft: 16,
    paddingRight: 13,
    borderTopWidth: 0.5,
    borderTopColor: '#E8E8E8',
    justifyContent: 'space-between',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  labelFee: {
    fontSize: 14,
    color: '#666',
    paddingTop: 5,
  },
  valueFee: {
    fontSize: 22,
    fontWeight: 'bold',
    // fontFamily: 'DINAlternate-Bold, DINAlternate;',
  },
  driverInfo: {
    marginLeft: 8,
  },
  driverName: {
    fontSize: 14,
    width: 163,
  },
  driverType: {
    paddingHorizontal: 3,
    borderWidth: 0.5,
    fontSize: 10,
    borderRadius: 4,
    borderBottomLeftRadius: 0,
  },
  truckInfo: {
    fontSize: 12,
    color: '#999',
  },
  btn: {
    paddingVertical: 5,
    paddingHorizontal: 16,
    borderRadius: 15,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 6,
  },
  btnTxt: {
    fontSize: 14,
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
    color: '#4885FF',
  },
  emptyIcon: {
    width: autoFix(287),
    height: autoFix(272),
  },
  empty: {
    height: 600,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchEmptyText: {
    color: '#A2ADC7',
    fontSize: autoFix(28),
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
  },
  pl20: {
    paddingLeft: autoFix(20),
  },
  pr20: {
    paddingRight: autoFix(20),
  },
});
