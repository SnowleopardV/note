import * as React from 'react';
import { View, TouchableWithoutFeedback, BackHandler, Platform, EmitterSubscription, Image, Text, TouchableOpacity } from 'react-native';
import { LayProvider, MBText, RefreshList, Drawer } from '@ymm/rn-elements';
import { MBBridge, MBJournal, MBLog, App, AppStateCompat, MBAutoPVComponent } from '@ymm/rn-lib';
import MBTabs from '~/components/common/MBTabs';
import NavBar from '~/components/common/NavBar';
import BaseInfo from '~/components/common/BaseInfo';
import DriverInfo from '~/components/orderDetail/DriverInfo'; // 承运信息
import NativeBridge from '~/extends/NativeBridge';
import Api from '../api';
import styles from './styles';
import ScreenDrawer from '../components/ScreenDrawer';
import Img from '../../../../public/static/images/index';
import server from '~/server';
import EmptyPage from '~/components/common/EmptyPage';
import CopyModal from '../components/shareModal';
import commonData, { goNetworkProtocol } from '~/pages/commonData';
import OpenDispatchResultModal from '~/components/OpenDispatchResultModal';
import FootButtonList from '~/components/FootButtonList';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export enum Tabs {
  '全部',
  '待调度' = 1,
  '已调度',
  '已作废',
}
export default class WaybillList extends MBAutoPVComponent<any, any> {
  subscription: EmitterSubscription | undefined;
  refreshListioner: any; // 刷新监听
  backHandler: any;
  refOpenDispatchResult: any;
  pageListener: any;
  constructor(props: any) {
    super(props);
    this.state = {
      waybillList: [
        { list: [], isEnd: false, loading: false, loaded: false, search: { pageNo: 0, pageSize: 20 } },
        { list: [], isEnd: false, loading: false, loaded: false, search: { dispatchStatus: 0, pageNo: 0, pageSize: 20 } },
        { list: [], isEnd: false, loading: false, loaded: false, search: { dispatchStatus: 1, pageNo: 0, pageSize: 20 } },
        { list: [], isEnd: false, loading: false, loaded: false, search: { dispatchStatus: 2, pageNo: 0, pageSize: 20 } },
      ],
      tabs: [
        { name: 0, title: '全部' },
        { name: 1, title: '待调度' },
        { name: 2, title: '已调度' },
        { name: 3, title: '已作废' },
      ],
      currentIndex: 1,
      visible: false,
      drawerVisible: false,
      drawerParmas: {
        0: {},
        1: {},
        2: {},
        3: {},
      },
      seachResultLength: {},
      copyData: {
        pointBillingTime: '',
        transOrderNo: '',
        loadAddress: '',
        unloadAddress: '',
        cargoInfoForDisplay: '',
        carTypeLengthInfo: '',
        dispatchStatus: '',
        carInfoForDisplay: '',
        estimateTime: '',
        estimateUnloadEndTime: '',
      },
      item: null,
      showModal: false,
      isLoading: false,
      errorData: {},
      showPermissionVisible: false,
      transTypeNecessarily: true,
    };
  }

  componentDidMount() {
    super.componentDidMount();
    this.api_systemInit(); // 获取系统设置
    const {
      state: { params },
    } = this.props.navigation;

    this.getAuthentication({ permissionCode: '100500' });
    const { tabindex } = this.props.screenProps;
    // 通过参数tabIndex跳转对应tab，如：首页广告栏配置跳转已调度
    if (!!tabindex) {
      this.setState({ currentIndex: Number(tabindex) });
    }

    // 调度后回到列表页
    this.refreshListioner = App.receiveEvent('refreshWaybillListView', (data: any) => {
      if (data?.isClose) {
        const currentIndex = data?.currentIndex ?? 2;
        this.setState({ currentIndex });
        this.getWaybillList(false, 2);
        this.getWaybillList(false, 1);
      }
    });

    if (Platform.OS === 'android') {
      this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
        if (this.state.drawerVisible) {
          this.setState({ drawerVisible: false }); //物理返回键关闭抽屉弹窗
          return true;
        }
        // 来源创建并调度
        if (params?.source === 'createdispatch') {
          if (Platform.OS === 'android') {
            App.sendEvent('closeWaybillCreateView', { isClose: true });
            MBBridge.app.ui.closeWindow({});
          } else {
            setTimeout(() => {
              App.sendEvent('closeWaybillCreateView', { isClose: true });
            }, 200);
            MBBridge.app.ui.closeWindow({});
          }
        } else {
          MBBridge.app.ui.closeWindow({});
        }
        return true;
      });
    }

    // 监听当前页面 可见性切换事件,active: 页面是否可见,willUnMount: 页面是否将要销毁
    this.pageListener = AppStateCompat.addPageActiveListener((active: boolean, willUnMount: boolean) => {
      if (active) {
        //用于解决 运单管理点击修改进入客户名称界面 在返回运单管理导致运单管理的tabs 被覆盖问题
        this.forceUpdate();
        // 是否显示满帮找车发货结果
        if (commonData.cargoRespList?.length) {
          this.refOpenDispatchResult?.openModal();
        }
      }
    }, this.props);
  }

  componentWillUnmount() {
    super.componentWillUnmount();
    this.backHandler?.remove();
    App.removeEmitListener(this.refreshListioner);
    this.pageListener?.remove();
  }
  api_systemInit() {
    Api.systemInit().then((res: any) => {
      if (res.data) {
        console.log('--------------------transTypeNecessarily-----------------------');
        console.log(res.data?.transTypeNecessarily);
        
        const transTypeNecessarily = res.data?.transTypeNecessarily || false; // 用户是否在白名单内
        this.setState({ transTypeNecessarily: transTypeNecessarily });
      }
    });
  }
  getPageName() {
    return 'dispatch_manage_list';
  }

  getWaybillList = (bool = false, index = 0, loading = false) => {
    const { waybillList, drawerParmas } = this.state;
    const tab = waybillList[index];
    console.log('--------------------getWaybillList 请求-------------------------', index, loading, tab.loading);
    if (tab.loading) return Promise.resolve();
    tab.loading = true;
    return Api.getWaybillList({ ...tab.search, ...(drawerParmas[index] ?? {}) }, loading ?? false)
      .then((res: any) => {
        console.log('getWaybillList数据请求成功', res);
        let list = res.data?.list || [];
        list = bool ? tab.list.concat(list) : list;
        waybillList[index] = {
          ...tab,
          list,
          loading: false,
          isEnd: !res.data?.hasNextPage,
        };
        const tabs = [...this.state.tabs];
        tabs[index]['title'] = Object.keys(drawerParmas[index]).length ? Tabs[index] + `(${res?.data?.total ?? 0})` : Tabs[index];
        this.setState({ waybillList, tabs });
        this.setState({
          seachResultLength: {
            ...this.state.seachResultLength,
            [index]: Object.keys(drawerParmas[index]).length ? res?.data?.total ?? 0 : undefined,
          },
        });
      })
      .catch(() => {
        waybillList[index].loading = true;
        tab.loading = false;
      });
  };
  // 鉴权
  getAuthentication = async (parmas: any) => {
    try {
      this.setState({
        isLoading: true,
      });
      const res = await server({
        url: '/saas-tms-trans/yzgApp/tenant/config/authentication',
        data: parmas,
      });
      if (res.success) {
        this.setState({
          errorData: res.data,
          showPermissionVisible: !res.data?.hasPermission,
        });
      }
      // 系统鉴权，单独处理
      if (res.code === '710012' || res.code === '710013') {
        this.setState({
          errorData: {
            image: 'https://image.ymm56.com/ymmfile/saas-tms-pub/detail.png',
            msg: res.msg,
          },
          showPermissionVisible: true,
        });
      }
    } catch (error) {
      MBLog.log({
        message: '获取鉴权失败',
        error: error,
      });
    } finally {
      this.setState({
        isLoading: false,
      });
    }
  };
  // 下拉刷新
  onRefresh(index: number = -1, loading?: boolean): Promise<any> {
    const { waybillList, currentIndex } = this.state;
    index = index > -1 ? index : currentIndex;
    waybillList[index].search.pageNo = 1;
    return new Promise((resolve) => this.getWaybillList(false, index, loading).finally(() => resolve()));
  }

  // 上拉加载
  onLoadMore(): Promise<any> {
    const { currentIndex, waybillList } = this.state;
    console.log('--------------上拉加载--------------', waybillList[currentIndex].loading);
    waybillList[currentIndex].loaded = true;
    ++waybillList[currentIndex].search.pageNo;
    return new Promise((resolve) => this.getWaybillList(true, currentIndex).finally(() => resolve()));
  }

  changeTab = (index: number, name: string) => {
    this.setState({ currentIndex: index });
    const item = this.state.waybillList[index];
    // 如果当前列表已经加载过页面，重新请求下数据
    if (item.loaded && !item.loading && !item.list.length) {
      this.onRefresh(index);
    }
  };

  jump = (item: any) => {
    MBBridge.app.base
      .openSchemeForResult({ schemeUrl: 'ymm://rn.tms/waybilldetail?source=waybillManageList&id=' + item.id })
      .then((res) => {
        if (res.data) {
          let data = { changeTabIndex: -1, upDataList: [] };
          try {
            data = JSON.parse(res.data);
          } catch (error) {
            data = res.data;
          }
          if (data.upDataList?.length) {
            data.upDataList.map((index: number) => {
              this.getWaybillList(false, index, true);
            });
          }
          if (data.changeTabIndex > -1) {
            this.setState({ currentIndex: data.changeTabIndex });
          }
        }
      });
  };
  /**
   * 跳转到配载调度
   */
  jumpStowage() {
    NativeBridge.setOpenUrl({ url: 'ymm://rn.tms/dispatchstowage' });
  }

  copyOrders = (item: any) => {
    this.setState({
      item: item,
      showModal: true,
    });
  };

  handleActions = (id: number) => {
    MBBridge.app.base.openSchemeForResult({ schemeUrl: `ymm://rn.tms/dispatch?id=${id}&sourcepagename=waybill_list` }).then((res) => {
      console.log(res);
      if (res.data === 1) {
        this.setState({ currentIndex: 2 });
        this.getWaybillList(false, 2, true);
        this.getWaybillList(false, 1, false);
      }
      if (res.data === 'refresh') {
        this.getWaybillList(false, 1, true);
      }
    });
  };

  // 底部按钮点击事件
  onClickBottomBtn = (type: string, item: any) => {
    console.log('底部按钮点击事件', type);
    // 修改
    if (type === 'UPDATE') {
      const { currentIndex } = this.state;
      MBBridge.app.base.openSchemeForResult({ schemeUrl: `ymm://rn.tms/waybilledit?id=${item.id}` }).then((res: any) => {
        // 更新运单列表页面
        this.getWaybillList(false, currentIndex);
      });
    } else if (type === 'COPY') {
      // 文字分享
      this.copyOrders(item);
    } else if (type === 'SCHEDULING') {
      //调度
      this.handleActions(item.id);
    } else if (type === 'FIND_CAR_PLATE') {
      // 跳转找车看板页面
      this.props.navigation.navigate('CarBoard', { orderNo: item.orderNo });
    } else if (type === 'TRACE') {
      // 轨迹
      NativeBridge.getTmsMoblieUrl().then((res: string) => {
        console.log('------------------', res, item.orderId);
        if (res) {
          const toViewInfo = { transOrderId: item.orderId, defaultQueryFlag: false };
          const url = res + 'trackSharing/index?toViewInfo=' + encodeURIComponent(JSON.stringify(toViewInfo));
          NativeBridge.openWebViewPage(url);
        }
      });
    } else if (type === 'CONTRACT') {
      // 协议
      goNetworkProtocol(item);
    } else if (type === 'FREIGHTASSISTANT') {
      // 运价助手
      this.props.navigation.navigate('FreightAssistant', { transOrderNo: item.orderNo });
    }
  };
  onCall = (telephone: string) => {
    NativeBridge.dial({ telephone });
  };
  renderItem = (item: any) => {
    const { currentIndex } = this.state;
    // 是否显示司机净得
    const showDriverFee = Boolean(item.taskState === 'LOOKING_CAR' && item.driverFee);
    // 是否显示承运商信息
    const showDriverInfo = item.taskState !== 'LOOKING_CAR' && item.schedulingInfo;
    // 是否显示列表底部部分
    const showBottom = showDriverFee || showDriverInfo || item.diapatchEnable;
    const buttonList = item.buttonList.map((row: any) => {
      if (row.code === 'COPY' && currentIndex === 2) {
        row.badge = '北斗轨迹'; // 只在已调度页面显示
        row.name = '分享'; // 只在已调度页面显示
      }
      return row;
    });

    return (
      <TouchableWithoutFeedback key={item.id} onPress={() => this.jump(item)}>
        <View style={styles.card}>
          <BaseInfo info={item}>
            {!!showBottom && item?.schedulingInfo && (
              <View style={[styles.actions, styles.flexRow, { padding: autoFix(20) }]}>
                <DriverInfo info={item?.schedulingInfo || null} source="list" />
                {item?.schedulingInfo?.driverPhone ? (
                  <TouchableOpacity activeOpacity={0.3} onPress={() => this.onCall(item.schedulingInfo.driverPhone)}>
                    <View style={{ marginLeft: 5 }}>
                      <Image style={{ width: 32, height: 32 }} source={Img.icon_telephone} />
                    </View>
                  </TouchableOpacity>
                ) : null}
              </View>
            )}
            <TouchableWithoutFeedback onPress={() => null}>
              <View style={[styles.actions, styles.flexRow]}>
                <View style={[styles.flexRow, { justifyContent: 'flex-end', flex: 1 }]}>
                  <FootButtonList
                    keyText="waybillList"
                    maxShowNum={3}
                    buttonList={buttonList}
                    onConfirm={(btn: any) => this.onClickBottomBtn(btn.code, item)}
                  />
                </View>
              </View>
            </TouchableWithoutFeedback>
          </BaseInfo>
        </View>
      </TouchableWithoutFeedback>
    );
  };

  renderEmpty = () => {
    const { drawerParmas, currentIndex } = this.state;
    return (
      <View style={styles.empty}>
        <Image source={{ uri: Img.icon_no_data }} style={styles.emptyIcon}></Image>
        {Object.keys(drawerParmas[currentIndex]).length ? (
          <MBText style={styles.searchEmptyText}>【{Tabs[this.state.currentIndex]}】下无满足筛选条件的运单</MBText>
        ) : (
          <MBText style={styles.emptyText}>暂无数据</MBText>
        )}
      </View>
    );
  };

  leftClick = () => {
    const {
      state: { params },
    } = this.props.navigation;

    // 来源创建并调度
    if (params?.source === 'createdispatch') {
      if (Platform.OS === 'android') {
        App.sendEvent('closeWaybillCreateView', { isClose: true });
        MBBridge.app.ui.closeWindow({});
      } else {
        setTimeout(() => {
          App.sendEvent('closeWaybillCreateView', { isClose: true });
        }, 200);
        MBBridge.app.ui.closeWindow({});
      }
    } else {
      MBBridge.app.ui.closeWindow({});
    }
  };

  render() {
    const { waybillList, tabs, currentIndex, transTypeNecessarily, isLoading, showPermissionVisible, errorData } = this.state;
    return (
      <LayProvider theme="skyblue">
        <Drawer
          visible={this.state.drawerVisible}
          position="right"
          onChange={(val) => {
            this.setState({
              drawerVisible: val,
            });
          }}
          navigationView={
            <ScreenDrawer
              showLeverInput={transTypeNecessarily}
              visible={this.state.drawerVisible}
              onClose={() => {
                this.setState({
                  drawerVisible: false,
                });
              }}
              onParams={(parmas, Refresh = true) => {
                this.setState(
                  {
                    drawerParmas: parmas,
                  },
                  () => {
                    Refresh && this.onRefresh(-1, true);
                  }
                );
              }}
              type={currentIndex}
            />
          }
        >
          <View style={styles.flexing}>
            <NavBar
              key="2"
              title="运单管理"
              rightElement={
                <View style={{ display: 'flex', flexDirection: 'row' }}>
                  <MBText style={styles.pr20} color="link" onPress={() => this.jumpStowage()}>
                    配载
                  </MBText>
                  <MBText
                    style={styles.pl20}
                    color="link"
                    onPress={() =>
                      this.setState({
                        drawerVisible: true,
                      })
                    }
                  >
                    筛选
                    {Object.keys(this.state.drawerParmas[currentIndex]).length > 0
                      ? `(${Object.keys(this.state.drawerParmas[currentIndex]).length})`
                      : ''}
                  </MBText>
                </View>
              }
            />
            {!isLoading ? (
              showPermissionVisible ? (
                <EmptyPage errorData={errorData} />
              ) : (
                <View style={styles.flexing}>
                  <MBTabs
                    tabs={[...tabs]}
                    onTabChange={this.changeTab}
                    defaultIndex={currentIndex}
                    renderTitle={(isActive: boolean, name: string) => (
                      <MBText style={{ color: isActive ? '#4885FF' : '#000' }}>{name}</MBText>
                    )}
                    renderList={(index: number) => {
                      return (
                        <View style={[styles.flexing, styles.task_list]}>
                          <RefreshList
                            isEnd={waybillList[index].isEnd}
                            data={waybillList[index].list}
                            showsVerticalScrollIndicator={false}
                            renderItem={(item: any) => this.renderItem(item)}
                            emptyRender={this.renderEmpty}
                            onRefresh={this.onRefresh.bind(this)}
                            onLoadMore={this.onLoadMore.bind(this)}
                            getLayoutTypeForIndex={() => 215}
                          />
                        </View>
                      );
                    }}
                  />
                  {this.state.showModal && (
                    <CopyModal
                      id={this.state.item.orderId}
                      parent={this}
                      pageName="运单管理列表"
                      navigation={this.props.navigation}
                      clickUrlCallback={() => this.onClickBottomBtn('TRACE', this.state.item)}
                    />
                  )}
                </View>
              )
            ) : null}
          </View>
        </Drawer>
        <OpenDispatchResultModal navigation={this.props.navigation} ref={(el) => (this.refOpenDispatchResult = el)} />
      </LayProvider>
    );
  }
}
