import server from '~/server';
const Api = {
  getWaybillList(data: any, isloading: boolean = true) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/dispatch/dispatchList',
        data,
      },
      { showLoading: isloading }
    );
  },

  // 获取运单详情
  getWaybillDetail(data: any) {
    if (data.mybOrderId) {
      // 生成运单详情
      return server({
        url: '/saas-tms-trans/yzgApp/supplement/loadTmsOrder',
        data,
      });
    }

    if (data.id) {
      // 正常运单详情
      return server({
        url: '/saas-tms-trans/yzgApp/dispatch/dispatchDetail',
        data,
      });
    }
  },

  // 获取可配置的订单复制字段
  getAppCopyOrderConfig(): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/user/config/getAppCopyOrderConfig',
    });
  },

  //运单删除
  deleteBill(data: { ids: number[] }): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/delete',
      data,
    });
  },

  //运单作废
  orderInvalid(data: { ids: number[] }): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/invalid',
      data,
    });
  },

  //运单作废恢复
  orderRecover(data: { ids: number[] }): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/recover',
      data,
    });
  },

  // 获取轨迹H5地址，在app 内打开H5
  getPositionUrl(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/getPositionUrl',
      data: { ...params },
    });
  },
  systemInit(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/trans/system/init',
        data: { ...params },
      },
      { showLoading: false, toastError: false }
    );
  },
};

export default Api;
