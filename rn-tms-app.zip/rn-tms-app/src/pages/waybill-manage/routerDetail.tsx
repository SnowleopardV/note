import { LayProvider } from '@ymm/rn-elements';
import React, { Component } from 'react';
import RouterRigister, { RouterPageName } from './router';

/**
 * 路由申明
 */
const RootStack = new RouterRigister().getRouterMap(RouterPageName.WAYBILL_DETAIL.toString());

/**
 * 路由组件
 */
export default class WaybillDetail extends Component<any, any> {
  constructor(props: any) {
    super(props);
  }

  render() {
    return (
      <LayProvider theme="skyblue">
        <RootStack screenProps={this.props} />
      </LayProvider>
    );
  }
}
