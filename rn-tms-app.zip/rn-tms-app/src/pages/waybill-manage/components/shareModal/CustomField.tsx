import { LayProvider, MBText, Whitespace } from '@ymm/rn-elements';
import React from 'react';
import { BackHandler, Dimensions, Image, Platform, StyleSheet, TouchableWithoutFeedback, View } from 'react-native';
import NavBar from '~/components/common/NavBar';
import images from '../../../../../public/static/images/index';
import API from './api';
import { MBToast } from '@ymm/rn-lib';
import AutoDragSortableView from '~/components/DragSortableView/AutoDragSortableView';
const { width } = Dimensions.get('window');
const keyMap = {
  task: '任务',
  order: '运单',
  other: '其他',
}; /** 定义分享字段文案 */
export default class CustomField extends React.Component<any, any> {
  backHandleListener: any;
  constructor(props: any) {
    super(props);
    this.state = {
      scrollEnabled: true,
      isEnterEdit: false,
      titleItem: { id: -1, name: '未选择' }, // 用来分隔拖拽列表
      selectedList: [],
      popoverLayout: null,
      topHeight: 0, // 距离顶部距离
      showPopover: true,
    };
  }
  componentDidMount() {
    this.api_getAppCopyOrderConfig();
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.goBack(false);
        return true;
      });
    }
    // 5秒关闭气泡
    setTimeout(() => {
      this.setState({ showPopover: false });
    }, 5000);
  }
  componentWillUnmount() {
    if (Platform.OS === 'android') {
      this.backHandleListener?.remove();
    }
  }
  // 获取复制运单配置
  api_getAppCopyOrderConfig() {
    API.getAppCopyOrderConfig()
      .then((res: any) => {
        console.log('获取复制运单配置', res.data.disableList);
        if (res?.data && (res.data?.enableList || res.data?.disableList)) {
          const list = res.data?.enableList.map((item: any, index: number) => {
            return { ...item, id: index + 1 };
          });
          list.push(this.state.titleItem);
          res.data?.disableList.map((item: any, index: number) => {
            list.push({ ...item, id: index + 1 });
          });
          this.setState({ selectedList: list });
        }
      })
      .catch((err) => {
        console.log('获取复制运单配置', err);
      });
  }
  // 保存
  api_setAppCopyOrderConfig = () => {
    if (this.state.selectedList.length == 0) {
      MBToast.show('至少需要1个分享字段');
      return;
    }
    const enableList: any[] = [];
    const disableList: any[] = [];
    let disabled = false;
    this.state.selectedList.map((item: any, index: number) => {
      if (item.id === -1) {
        disabled = true;
      } else {
        !disabled ? enableList.push({ ...item, seq: index + 1 }) : disableList.push({ ...item, seq: index });
      }
    });
    API.setAppCopyOrderConfig({ enableList: enableList, disableList: disableList })
      .then((res: any) => {
        if (res?.success) {
          console.log('自定义分享字段', res);
        }
      })
      .catch((err) => {
        console.log('保存复制运单配置', err);
      });
  };
  rightElement() {
    return (
      <MBText color="primary" onPress={() => this.goBack(true)}>
        确定
      </MBText>
    );
  }
  renderRow = (row: any, index: number) => {
    return (
      <View key={index} style={{ width: width, backgroundColor: row.id === -1 ? '#F6F7F9' : '#fff' }}>
        {row.id !== -1 ? (
          <View style={[styles.item]}>
            <MBText style={{ width: 80 }}>{row.id}</MBText>
            <MBText style={{ width: 100 }}>{keyMap[row?.belongModel] ?? ''}</MBText>
            <MBText style={{ flex: 1 }}>{row?.displayName}</MBText>
            <Image source={images.icon_readjust} style={{ width: 25, height: 17 }} />
          </View>
        ) : (
          <View style={[styles.item]}>
            <MBText color="#84848A">未选择</MBText>
          </View>
        )}
      </View>
    );
  };
  /** 气泡框 */
  Popover = () => {
    const { popoverLayout, topHeight, showPopover } = this.state;
    return !!popoverLayout && showPopover ? (
      <View style={[styles.popoverBox, { top: popoverLayout.y + topHeight + 10, left: popoverLayout.x }]}>
        <View style={styles.part}></View>
        <TouchableWithoutFeedback onPress={() => this.setState({ showPopover: !showPopover })}>
          <View>
            <MBText style={{ fontSize: 12 }} color="#FFFFFF">
              长按并拖动
              <MBText color="#FFFFFF">≡</MBText>
              图标可调整排序
            </MBText>
          </View>
        </TouchableWithoutFeedback>
      </View>
    ) : null;
  };
  /** 定位 气泡显示位置 */
  onPopoverLayout = (res: any) => {
    const { height, width, x, y } = res.nativeEvent.layout;
    const a = x - width - 30;
    const b = height + y;
    this.setState({ popoverLayout: { x: a, y: b } });
  };
  goBack(val: boolean) {
    this.props.navigation?.goBack();
    this.props.navigation?.state?.params?.onCallBack(val);
  }
  render() {
    const { selectedList, showPopover } = this.state;
    return (
      <LayProvider theme="skyblue" style={[styles.popover, { flex: 1, backgroundColor: '#F6F7F9' }]}>
        <NavBar title="分享字段设置" leftClick={() => this.goBack(true)} />
        <View style={[styles.title, styles.paddingH]} onLayout={(e) => this.setState({ topHeight: e.nativeEvent.layout.y })}>
          <MBText style={{ width: 80 }}>序号</MBText>
          <MBText style={{ width: 100 }}>归属</MBText>
          <MBText style={{ flex: 1 }}>字段名称</MBText>
          <TouchableWithoutFeedback onPress={() => this.setState({ showPopover: !showPopover })}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }} onLayout={this.onPopoverLayout}>
              <MBText>调整</MBText>
              <Image source={images.icon_help} style={{ width: 14, height: 14, marginLeft: 4 }} />
            </View>
          </TouchableWithoutFeedback>
        </View>
        <View style={{ flex: 1 }}>
          <AutoDragSortableView
            key="seleded"
            dataSource={selectedList}
            parentWidth={width}
            childrenWidth={width}
            childrenHeight={50}
            headerViewHeight={50}
            delayLongPress={100}
            autoThrottle={Platform.OS === 'android' ? 50 : 2}
            autoThrottleDuration={Platform.OS === 'android' ? 250 : 10}
            renderHeaderView={[
              <View style={[styles.paddingH, { paddingVertical: 15 }]}>
                <MBText color="#84848A">已选择</MBText>
              </View>,
            ]}
            renderBottomView={[<Whitespace vertical={50} />]}
            onDragStart={(startIndex: number, endIndex: number) => {
              if (!this.state.isEnterEdit) {
                this.setState({ isEnterEdit: true, scrollEnabled: false });
              } else {
                this.setState({ scrollEnabled: false });
              }
            }}
            onDragEnd={(startIndex: number) => {
              this.setState({ scrollEnabled: true });
            }}
            onDataChange={(data: any) => {
              if (data.length == selectedList.length) {
                let num = 0;
                const list = data.map((item: any) => {
                  if (item.id === -1) {
                    num = 0;
                  } else {
                    item.id = ++num;
                  }
                  return item;
                });
                this.setState({ selectedList: list }, () => this.api_setAppCopyOrderConfig());
              }
            }}
            onClickItem={(data: any, item: any, index: number) => {
              // click delete
              if (this.state.isEnterEdit) {
                console.log('单击了' + index);
              }
            }}
            keyExtractor={(item: any, index: number) => item.displayName} // FlatList作用一样，优化
            renderItem={(item: any, index: number) => {
              return this.renderRow(item, index);
            }}
          />
        </View>
        {this.Popover()}
      </LayProvider>
    );
  }
}

const styles = StyleSheet.create({
  popover: {
    position: 'relative',
  },
  popoverBox: {
    position: 'absolute',
    width: 150,
    backgroundColor: '#000000',
    opacity: 70,
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 4,
  },
  part: {
    position: 'absolute',
    width: 16,
    height: 16,
    backgroundColor: '#000000',
    opacity: 70,
    top: -5,
    right: 17,
    transform: [{ rotateZ: '45deg' }],
  },
  paddingH: {
    paddingHorizontal: 20,
  },
  title: {
    marginTop: 15,
    height: 50,
    lineHeight: 50,
    backgroundColor: '#FFF',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  item: {
    height: 50,
    lineHeight: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#F6F7F9',
    borderBottomWidth: 1,
    marginLeft: 20,
    paddingRight: 20,
  },
});
