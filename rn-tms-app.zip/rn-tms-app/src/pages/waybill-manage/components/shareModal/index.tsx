import React from 'react';
import { StyleSheet, View, Image, ScrollView, Dimensions, Clipboard, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import { MBText, Modal, Button, Whitespace } from '@ymm/rn-elements';
import { MBBridge, MBJournal, MBToast } from '@ymm/rn-lib';
import API from './api';
import Images from '~/../public/static/images';
import NativeBridge from '~/extends/NativeBridge';
const { height } = Dimensions.get('window');
const maxHeight = height * 0.8 - 100;
const minHeight = height * 0.2;
export default class CopyModal extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      emptyDataTips: '', // 空数据时的提示
      visible: false,
      copyData: [], // 需要进行复制粘贴
      userInfo: {
        userId: '',
        mobile: '',
        companyName: '', // 公司名
        name: '', // 用户名
        roles: [], // 角色 如：超级管理员, 可能有多个角色
      }, // 用户信息
      appName: '',
    };
  }

  UNSAFE_componentWillMount() {
    MBBridge.user.getUserInfo({}).then((res: any) => {
      let roles = [];
      try {
        roles = JSON.parse(res.data?.roles);
      } catch (error) {
        roles = res.data?.roles;
      }
      if (res.code == 0) {
        this.setState({
          userInfo: {
            name: res.data?.userName,
            mobile: res.data?.telephone,
            ...res.data,
            roles: roles?.map((item: any) => {
              return item.roleName;
            }),
          },
        });
      }
    });
    MBBridge.app.base.appInfo({}).then((res: any) => {
      const appId = res?.data?.appId;
      const isFromTms = appId === 'com.tms.merchant' || appId === 'com.tms8.merchant';
      if (isFromTms) {
        this.setState({ appName: 'tms' });
      } else {
        this.setState({ appName: 'ymm/hcb' });
      }
    });
  }

  componentDidMount() {
    this.api_init();
  }
  // 获取初始化数据
  api_init() {
    const { id } = this.props;
    API.shareOrderWords({ transOrderId: id })
      .then((res: any) => {
        const { contentList, emptyContentDefultTips } = res.data;
        if (contentList) {
          this.setState({ visible: true, copyData: res.data.contentList });
        } else if (emptyContentDefultTips) {
          this.setState({ visible: true, emptyDataTips: emptyContentDefultTips });
        } else {
          this.parentHideModal();
        }
      })
      .catch((err: any) => {
        this.parentHideModal();
      });
  }
  /** 复制到剪切板 */
  copyToClipboard() {
    const content = this.state.copyData
      .map((item: any) => {
        return item.label + item.value;
      })
      .join('\n');
    Clipboard.setString(content);
  }
  clearCopyContent() {
    this.setState({
      visible: false,
      copyData: [],
    });
    this.parentHideModal();
  }
  parentHideModal = () => {
    const parent = this.props.parent;
    parent.setState({ showModal: false });
  };
  toPaste = () => {
    this.setState({ visible: false });
    this.parentHideModal();
    this.copyToClipboard();
    // 埋点
    const { pageName, id } = this.props;
    const { userInfo, appName } = this.state;
    const extraDict = {
      userName: userInfo.name,
      user_name: userInfo.name,
      tenant: userInfo.companyName || 'ymm/hcb 无公司名',
      tmsRole: userInfo.roles || 'ymm/hcb 无角色名',
      user_id: userInfo.userId,
      new_user_id: userInfo.userId,
      waybill_id: id, // 运单id
      from_app: appName, // 来自什么app
    };
    MBJournal.tapJournal({
      elementId: 'copy_success_waybill',
      pageName: 'dispatch_manage_list',
      referPageName: pageName, // 上一个页面名称
      extraDict: extraDict,
    })?.then(() => {
      // 打开微信
      MBBridge.app.base.openWXApp({}).then((res: any) => {
        if (res.code == 0) {
          MBToast.show('抱歉！ 微信打开失败!');
        } else if (res.code == -1) {
          MBToast.show('抱歉！未检测到微信!');
        }
      });
    });
  };
  goShareConfig = () => {
    this.parentHideModal();
    this.props?.navigation.navigate('CustomField');
  };
  titleElement() {
    return (
      <View style={styles.flexRow}>
        <Image style={styles.done} source={{ uri: Images.icon_solid_check }}></Image>
        <MBText style={styles.copyTitle}>运单内容已复制</MBText>
      </View>
    );
  }
  checkURL(str: string) {
    const Expression = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
    const objExp = new RegExp(Expression);
    return objExp.test(str);
  }
  goWebView(url: string) {
    const { clickUrlCallback } = this.props;
    if (Platform.OS === 'ios') {
      this.parentHideModal();
      !!clickUrlCallback && clickUrlCallback();
      setTimeout(() => {
        this.props.parent.setState({ showModal: true });
      }, 1000);
    } else {
      !!clickUrlCallback && clickUrlCallback();
    }
  }
  renderItem(item: any) {
    return (
      <View style={styles.item}>
        <MBText color="#595959" style={{ paddingRight: autoFix(10) }}>
          {item.label}
        </MBText>
        <View style={{ flex: 1, justifyContent: 'flex-end', flexDirection: 'row' }}>
          {!this.checkURL(item.value) ? (
            <MBText color="#979797">{item.value}</MBText>
          ) : (
            <MBText style={{ fontSize: autoFix(26) }} color="#4885FF" onPress={() => this.goWebView(item.value)}>
              {item.value}
            </MBText>
          )}
        </View>
      </View>
    );
  }
  render() {
    const { copyData, emptyDataTips } = this.state;
    return (
      <Modal
        position="bottom"
        radius={true}
        autoAdjustPosition
        title={this.titleElement()}
        visible={this.state.visible}
        contentStyle={{ paddingHorizontal: 0 }}
        headerStyle={styles.modal}
        style={styles.modal}
        headerRight="设置"
        headerLeft="取消"
        onRequestClose={() => this.clearCopyContent()}
        onCancel={() => this.clearCopyContent()}
        onMaskClose={() => this.clearCopyContent()}
        onConfirm={() => this.goShareConfig()}
      >
        <View style={{ width: '100%', paddingVertical: 20 }}>
          <ScrollView alwaysBounceVertical={false} style={{ maxHeight: maxHeight, minHeight: minHeight }}>
            {copyData.length ? (
              copyData.map((item: any) => this.renderItem(item))
            ) : (
              <View style={{ width: '100%', alignItems: 'center' }}>
                <MBText color="#CCC">{emptyDataTips || '该运单无可用分享字段，可进入[设置] 新增分享字段'}</MBText>
              </View>
            )}
          </ScrollView>
          <Whitespace vertical={10} />
          <View style={{ flexDirection: 'row', width: '100%', paddingHorizontal: autoFix(36) }}>
            <Button radius type="primary" size="sm" style={[styles.flexRow, styles.modalButton]} onPress={this.toPaste}>
              <Image style={styles.weixinIcon} source={{ uri: Images.icon_weixin }}></Image>
              <MBText style={{ color: '#FFFFFF' }}>去微信粘贴给好友</MBText>
            </Button>
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  item: {
    width: '100%',
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 5,
    lineHeight: autoFix(50),
    justifyContent: 'space-between',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  weixinIcon: {
    width: autoFix(50),
    height: autoFix(40),
    marginRight: autoFix(15),
  },
  copyTitle: {
    fontSize: autoFix(36),
    fontWeight: 'bold',
    color: '#333333',
  },
  done: {
    width: autoFix(40),
    height: autoFix(40),
    marginRight: autoFix(15),
  },
  modal: {
    backgroundColor: '#F5F5F5',
  },
  modalButton: {
    backgroundColor: '#46BB36',
    height: autoFix(80),
    borderWidth: 0,
    flex: 1,
  },
  copyinfo: {
    fontSize: 12,
    lineHeight: 50,
    color: '#999999',
    textAlign: 'center',
  },
});
