import server from '~/server';
const Api = {
  // 获取复制运单配置 https://yapi.1111.com/#/project/2532/interface/api/281358
  getAppCopyOrderConfig(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/getPcCopyOrderConfig',
      data: { ...params },
    });
  },
  // 保存复制运单配置 https://yapi.1111.com/#/project/2532/interface/api/281361
  setAppCopyOrderConfig(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/setPcCopyOrderConfig',
      data: { ...params },
    });
  },
  //分享字段文案
  shareOrderWords(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/order/shareOrderWords',
      data: { ...params },
    });
  },
};

export default Api;
