import React, { useEffect, useState } from 'react';
import { Modal, Input, RefreshList, Flex, Selector, MBText, Whitespace, Splitline } from '@ymm/rn-elements';
import Styles from './DrawerStyle';
import { View, TouchableOpacity, Text, Image, Platform } from 'react-native';
import { scrrentItem } from './Enum';
import RegTest from '~/utils/RegTest';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Img from '../../../../../public/static/images/index';
import { MBToast } from '@ymm/rn-lib';
import { cloneDeep } from 'lodash';
const FlexItem = Flex.Item;
//模糊检索
const srarchFilter = (value: string, data: {}[], props: scrrentItem['props']): {}[] => {
  if (value === '') return data;
  return data.filter((item) => item[props?.label ?? ''].includes(value));
};
MBToast;
/**
 * @param {boolean} visible  控制弹窗显隐
 * @param {object} parmas  点击cell的参数
 * @param {function} onClose 关闭弹窗
 * @param {function} onSelect 选中item事件 返回item的值
 * @param {function} onRemote 开启远程检索 本地检索失效
 */

export default ({
  visible,
  parmas,
  onClose,
  onSelect,
  onRemote,
}: {
  visible: boolean; //控制弹窗显隐
  parmas: scrrentItem | undefined;
  onClose: () => void;
  //点击当前的值   type区分是确定还是选择
  onSelect: (item: { label: string; value: string; key: string; level?: number; originParams?: string }, type: string) => void;
  onRemote?: (value: string, callback: (data: {}[]) => void) => void;
}) => {
  const [copyOptionList, setcopyOptionList] = useState<{}[]>([]);
  const [value, setValue] = useState('');
  const [optionList, setOptionList] = useState<{}[]>([]);
  const [step, setStep] = useState<number>(1); // 用于滚动加载
  const size = 50; // 用于滚动加载
  const [selectorItem, setSelectorItem] = useState({}); //保存selector组件值
  useEffect(() => {
    setValue('');
    setOptionList(parmas?.optionList.slice(0, size * step) ?? []);
    setcopyOptionList(parmas?.optionList ?? []);
    setStep(1);
  }, [parmas?.key]);
  useEffect(() => {
    if (!visible) return;
    onRemote &&
      onRemote(value, (data) => {
        setOptionList(data);
      });
  }, [value, visible]);
  useEffect(() => {
    //当Cell上的value被清空掉 需要重新设置下拉内容和input值
    if (!parmas?.value) {
      setValue('');
      setOptionList(parmas?.optionList.slice(0, size * step) ?? []);
    }
  }, [parmas?.value]);
  useEffect(() => {
    if (!visible) return;
    !parmas?.placeholder &&
      setSelectorItem(
        parmas?.value
          ? {
              ...parmas.optionList.find((item) => item[parmas.props?.label ?? ''] === parmas?.value),
            }
          : {
              ...(parmas?.optionList?.[0] ?? {}),
            }
      );
  }, [visible]);
  return (
    <Modal
      autoAdjustPosition
      headerLeft="取消"
      headerRight={parmas?.props?.label === parmas?.props?.value || !parmas?.placeholder ? '确定' : ' '}
      title={parmas?.modalTitle ? parmas.modalTitle : '请选择' + parmas?.title ?? ''}
      position="bottom"
      visible={visible}
      onCancel={() => {
        onClose && onClose();
      }}
      onConfirm={() => {
        if (parmas?.props?.label === parmas?.props?.value) {
          onSelect({ label: value, value, key: parmas?.key ?? '' }, 'confirm');
          onClose && onClose();
        }
        if (!parmas?.placeholder) {
          onSelect(
            {
              label: selectorItem[parmas?.props?.label ?? 'label'] ?? '',
              value: selectorItem[parmas?.props?.value ?? 'value'] ?? '',
              key: parmas?.key ?? '',
            },
            'confirm'
          );
          onClose && onClose();
        }
      }}
      onRequestClose={() => {
        onClose && onClose();
      }}
      onMaskClose={() => {
        onClose && onClose();
      }}
      contentStyle={{ paddingHorizontal: 0 }}
    >
      {parmas?.styleType === 'selector' && (
        <Flex direction="row" justify="center" align="center">
          <Flex.Item key="time">
            <View style={{ flexDirection: 'column', height: autoFix(400) }}>
              <Selector
                type={1}
                value={parmas?.value ? parmas.optionList.findIndex((item) => parmas.value === item[parmas.props?.label ?? '']) : 0}
                rowTitle={parmas?.props?.label}
                list={parmas?.optionList}
                onChange={(index: number, item: {}) => {
                  setSelectorItem(item);
                }}
              />
            </View>
          </Flex.Item>
        </Flex>
      )}
      {Boolean(parmas?.styleType === 'subName') && (
        <View style={{ width: '100%', height: autoFix(400) }}>
          {optionList.map((item: any, index: number) => {
            return (
              <View style={{ width: '100%' }}>
                <TouchableOpacity
                  activeOpacity={item.disabled ? 1 : 0.2}
                  onPress={() => {
                    if (item.disabled) {
                      MBToast.show(item.pickupSubName);
                      return;
                    }
                    onClose && onClose();
                    onSelect &&
                      onSelect(
                        {
                          ...item,
                          label: item[parmas?.props?.label ?? 'label'] ?? '',
                          value: item[parmas?.props?.value ?? 'value'] ?? '',
                          key: parmas?.key ?? '',
                        },
                        'select'
                      );
                  }}
                >
                  <Flex direction="row">
                    <FlexItem style={{ height: autoFix(100), justifyContent: 'center' }}>
                      <MBText
                        align="center"
                        color={item.disabled && '#ccc'}
                        style={[{ fontSize: autoFix(32) }, !item.disabled && { fontWeight: 'bold' }]}
                      >
                        {item[parmas?.props?.label ?? '']}
                      </MBText>
                      <Whitespace vertical={2} />
                      {item.pickupSubName && (
                        <MBText align="center" color="#ccc" size="xs">
                          {item.pickupSubName}
                        </MBText>
                      )}
                    </FlexItem>
                  </Flex>
                </TouchableOpacity>
                {index !== optionList.length - 1 && <Splitline />}
              </View>
            );
          })}
        </View>
      )}
      {!Boolean(parmas?.styleType) && (
        <View style={Styles.searchModalContent}>
          {Boolean(parmas?.placeholder) && (
            <View style={Styles.inputView}>
              <Input
                returnKeyType={Platform.OS == 'ios' ? 'default' : 'done'}
                returnKeyLabel={Platform.OS == 'ios' ? 'default' : 'done'}
                maxLength={100}
                multiline={true}
                style={Styles.inputItem}
                placeholder={parmas?.placeholder}
                value={value}
                onChangeText={(val) => {
                  if (RegTest.emoji(val)) return;
                  setValue(val);
                  //不启动远程检索的时候，才支持模糊查询
                  if (!onRemote) {
                    const seachAllList = srarchFilter(val, parmas?.optionList ?? [], parmas?.props);
                    setOptionList(cloneDeep(seachAllList.slice(0, size)));
                    setcopyOptionList([...seachAllList]);
                  }
                }}
              ></Input>
              {Boolean(value) && (
                <TouchableOpacity
                  style={[Styles.closeIcon, Styles.searchClose]}
                  onPress={() => {
                    setValue('');
                  }}
                >
                  <Image source={{ uri: Img.icon_close }} style={Styles.closeIcon}></Image>
                </TouchableOpacity>
              )}
            </View>
          )}
          <View style={{ width: '100%' }}>
            {
              <View style={[Styles.Width, Styles.h500]}>
                <RefreshList
                  keyboardShouldPersistTaps={'handled'}
                  pullRefresh={false}
                  isEnd={step * size >= copyOptionList.length}
                  data={optionList}
                  footerRefreshingText=""
                  footerFailureText=""
                  footerNoMoreDataText=""
                  emptyRender={() => (
                    <View style={Styles.noData}>
                      <Text>{'暂无数据'}</Text>
                    </View>
                  )}
                  renderItem={(item) => {
                    return (
                      <TouchableOpacity
                        style={{ width: '100%' }}
                        onPress={() => {
                          onClose && onClose();
                          onSelect &&
                            onSelect(
                              {
                                ...item,
                                label: item[parmas?.props?.label ?? 'label'] ?? '',
                                value: item[parmas?.props?.value ?? 'value'] ?? '',
                                key: parmas?.key ?? '',
                              },
                              'select'
                            );
                        }}
                      >
                        <View style={Styles.searchModalItem}>
                          <Text style={Styles.billItemText}>
                            {value ? (
                              item[parmas?.props?.label ?? ''].split(value).map((stringItem: string, index: number) => {
                                console.log(stringItem, 'ewqeqeqwqe');
                                return (
                                  <Text>
                                    {stringItem}
                                    {index <= item[parmas?.props?.label ?? ''].split(value).length - 2 && (
                                      <Text style={{ color: '#4885FF' }}>{value}</Text>
                                    )}
                                  </Text>
                                );
                              })
                            ) : (
                              <Text>{item[parmas?.props?.label ?? 'label'] ?? ''}</Text>
                            )}{' '}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  }}
                  onLoadMore={() => {
                    return new Promise((resolve) => {
                      if (step * size < copyOptionList.length) {
                        setOptionList(copyOptionList.slice(0, (step + 1) * size));
                        setStep(step + 1);
                      }
                      resolve();
                    });
                  }}
                ></RefreshList>
              </View>
            }
          </View>
        </View>
      )}
    </Modal>
  );
};
