import { StyleSheet, Dimensions, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
const Width = Dimensions.get('window').width;
export default StyleSheet.create({
  title: {
    paddingTop: autoFix(38),
    paddingLeft: autoFix(52),
    paddingBottom: autoFix(28),
    borderBottomColor: '#E8E8E8',
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: autoFix(20),
    height: autoFix(112),
  },
  titleText: {
    color: '#333',
    fontSize: autoFix(32),
    fontWeight: '600',
  },
  screenItem: {
    display: 'flex',
    marginBottom: autoFix(32),
    paddingHorizontal: autoFix(20),
  },
  screenItemText: {
    marginBottom: autoFix(20),
    color: '#333333',
    fontSize: autoFix(30),
    fontWeight: '500',
    //paddingLeft: autoFix(20),
  },
  flex: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
  },
  bottom: {
    paddingVertical: autoFix(20),
    paddingHorizontal: autoFix(32),
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  clear: {
    borderTopLeftRadius: autoFix(40),
    borderBottomLeftRadius: autoFix(40),
    width: autoFix(145),
    height: autoFix(80),
    borderRightWidth: 0,
  },
  clearBorder: {
    borderColor: '#CCD2DE',
    borderWidth: autoFix(2.67),
  },
  clearText: {
    color: '#4885FF',
    fontSize: autoFix(32),
    lineHeight: autoFix(75),
    textAlign: 'center',
  },
  check: {
    borderTopRightRadius: autoFix(40),
    borderBottomRightRadius: autoFix(40),
    width: autoFix(234),
    height: autoFix(80),
    // borderColor: '#4885FF',
    // borderWidth: autoFix(2.67),
    backgroundColor: '#4885FF',
  },
  checkText: {
    color: '#fff',
    fontSize: autoFix(32),
    lineHeight: autoFix(75),
    textAlign: 'center',
  },

  triangleBootom: {
    width: 0,
    height: 0,
    borderWidth: 6,
    borderTopColor: '#000',
    borderRightColor: 'transparent',
    borderLeftColor: 'transparent',
    borderBottomColor: 'transparent',
    marginLeft: autoFix(12),
  },
  dropContent: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },
  billItem: {
    paddingVertical: autoFix(18),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#ccc',
    width: Width,
    alignItems: 'center',
  },
  billItemText: {
    fontSize: autoFix(30),
    color: '#000',
  },
  textAreaView: {
    paddingHorizontal: autoFix(25),
  },
  textArea: {
    //backgroundColor: '#F6F6F6',
    textAlignVertical: 'top',
    paddingTop: autoFix(16),
    paddingLeft: autoFix(20),
    height: '100%',
    borderRadius: autoFix(10),
    borderColor: '#DEDEDE',
    borderWidth: StyleSheet.hairlineWidth,
  },
  h229: {
    height: autoFix(229),
  },
  time: {
    borderRadius: autoFix(10),
    borderColor: '#DEDEDE',
    borderWidth: StyleSheet.hairlineWidth,
    height: autoFix(80),
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: autoFix(20),
  },
  startTime: {
    height: '100%',
    display: 'flex',
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  line: {
    paddingRight: autoFix(42),
  },
  timeText: {
    fontSize: autoFix(30),
    color: '#ccc',
  },
  CellGroup: {
    marginHorizontal: autoFix(32),
    marginLeft: autoFix(0),
    // borderBottomColor: '#E8E8E8',
    // borderBottomWidth: StyleSheet.hairlineWidth,
  },
  cellTitle: {
    color: '#333333',
    fontSize: autoFix(30),
    fontWeight: '500',
  },
  inputView: {
    paddingBottom: autoFix(20),
    width: '90%',
    display: 'flex',
    flexDirection: 'row',

    //alignItems:'center',
    // borderBottomWidth:autoFix(2),
    // borderBottomColor:'#DEDEDE'
  },
  inputItem: {
    width: '100%',
    height: autoFix(80),
    borderWidth: autoFix(2),
    borderColor: '#DEDEDE',
    borderRadius: autoFix(8),
    paddingLeft: autoFix(20),
    paddingRight: autoFix(60),
    textAlignVertical: 'center',
    fontSize: autoFix(25),
    ...Platform.select({
      ios: {
        lineHeight: autoFix(42),
      },
    }),
  },
  h500: {
    height: autoFix(500),
  },
  Width: {
    width: '100%',
  },
  searchModalItem: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#ccc',
    width: '100%',
    alignItems: 'center',
    paddingVertical: autoFix(20),
    paddingRight: autoFix(55),
    paddingLeft: autoFix(25),
  },
  searchModalContent: {
    width: Width,
    paddingHorizontal: autoFix(20),
    paddingVertical: autoFix(35),
    paddingTop: autoFix(30),
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
  },
  noData: {
    justifyContent: 'center',
    alignItems: 'center',
    height: autoFix(500),
  },
  splitLine: {
    width: '100%',
    marginBottom: autoFix(25),
  },
  closeIcon: {
    width: autoFix(34),
    height: autoFix(34),
  },
  smallCloseIcon: {
    width: autoFix(30),
    height: autoFix(30),
  },
  pr12: {
    marginRight: autoFix(12),
  },
  searchClose: {
    position: 'absolute',
    right: autoFix(30),
    top: autoFix(24),
  },
});
