import React, { useEffect, useState } from 'react';
import { Text, View, TouchableOpacity, Platform, Keyboard } from 'react-native';
import { MBBridge } from '@ymm/rn-lib';
import { Input, Modal, MBText, Whitespace } from '@ymm/rn-elements';
import RegTest from '~/utils/RegTest';
import { dropDdownType, billNumber } from './Enum';
import Styles from './DrawerStyle';
const behavior = Platform.OS == 'ios';
export default ({
  onSelect,
  onChange,
  textArea,
  type,
  scrollRef,
}: {
  onSelect?: (item: { label: string; value: string; content: string }, arry: string[]) => void;
  onChange?: (item: { label: string; value: string; content: string }) => void;
  textArea: string;
  type: number;
  scrollRef: object;
}) => {
  const [visible, setVisible] = useState<boolean>(false);
  const [allLabel, setAllLabel] = useState<dropDdownType>({ 0: billNumber[0][0], 1: billNumber[1][0], 2: billNumber[2][0] });
  const [currentLabel, setcurrentLabel] = useState<{ label: string; value: string; content?: string }>(billNumber[type][0]);
  const [keyHeight, setKeyHeight] = useState<number>(0);
  const [isFromTms, setIsFromTms] = useState(false);
  useEffect(() => {
    setcurrentLabel(allLabel[type] ?? billNumber[type][0]);
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      if (isFromTms && behavior) {
        scrollRef?.current?.scrollTo(e.endCoordinates.height, 0);
        setKeyHeight(e.endCoordinates.height);
      }
    });
    const hidden = Keyboard.addListener('keyboardDidHide', (e) => {
      if (isFromTms && behavior) {
        scrollRef?.current?.scrollTo(0, 0);
        setKeyHeight(0);
      }
    });
    return () => {
      show.remove();
      hidden.remove();
    };
  }, [type]);
  useEffect(() => {
    if (Platform.OS === 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
    MBBridge.app.base.appInfo({}).then(({ data: { appId } }) => {
      setIsFromTms(appId === 'com.tms.merchant' || appId === 'com.tms8.merchant');
    });
  }, []);
  return (
    <View style={[Styles.screenItem, Styles.textAreaView, { paddingBottom: keyHeight }]}>
      <TouchableOpacity
        onPress={() => {
          setVisible(true);
        }}
      >
        <View style={Styles.dropContent}>
          <MBText style={Styles.screenItemText}>{currentLabel.label}</MBText>
          <View style={Styles.triangleBootom}></View>
        </View>
      </TouchableOpacity>
      <View style={Styles.h229}>
        <Input
          returnKeyType={'done'}
          returnKeyLabel={'done'}
          numberOfLines={6}
          placeholder={'支持批量搜索，多个单号用逗号/空格隔开'}
          blurOnSubmit={Platform.OS === 'ios'}
          onSubmitEditing={(event) => {
            if (Platform.OS === 'ios') {
              Keyboard.dismiss();
            }
          }}
          value={textArea}
          multiline={true}
          onChangeText={(val: string) => {
            if (RegTest.emoji(val)) return;
            onChange && onChange({ ...currentLabel, content: val });
          }}
          style={Styles.textArea}
        ></Input>
      </View>
      <Modal
        autoAdjustPosition
        headerLeft="取消"
        headerRight=" "
        title="请选择筛选单据类型"
        position="bottom"
        visible={visible}
        onCancel={() => {
          setVisible(false);
        }}
        onConfirm={() => {
          setVisible(false);
        }}
        onRequestClose={() => {
          setVisible(false);
        }}
        onMaskClose={() => {
          setVisible(false);
        }}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        <View>
          {billNumber[type].map((item: { label: string; value: string }, index: number) => (
            <TouchableOpacity
              onPress={() => {
                setVisible(false);
                setcurrentLabel(item);
                onSelect &&
                  onSelect(
                    { ...item, content: textArea },
                    billNumber[type].reduce((total: string[], current: { label: string; value: string }) => {
                      if (current.value !== item.value) {
                        total.push(current.value);
                      }
                      return total;
                    }, [])
                  );
                allLabel[type] = { ...item };
                setAllLabel(allLabel);
              }}
            >
              <View style={Styles.billItem}>
                <Text style={Styles.billItemText}>{item.label}</Text>
              </View>
            </TouchableOpacity>
          ))}
          <Whitespace vertical={20} />
        </View>
      </Modal>
    </View>
  );
};
