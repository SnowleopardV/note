import server from '~/server/index';

//查询客户名称列表
export const getCustomerList = (): Promise<ResponseData<{ list: [{ customerList: [{ id: string; custName: string }] }] }>> =>
  server({
    url: '/saas-tms-trans/yzgApp/crm/selectCustomerList',
    data: {},
  });

//查询业务员列表
export const dispatcherList = (): Promise<
  ResponseData<{ tmsDispatcherId: string; tmsDispatcherName: string; tmsDispatcherPhone: string }[]>
> =>
  server({
    url: '/saas-permission-app/yzgApp/employee/dispatcherList',
    data: {},
  });

// 查询承运商
export const queryCarrierList = (params: { carrierName: string }): Promise<ResponseData<{ carrierId: string; carrierName: string }[]>> =>
  server(
    {
      url: '/saas-tms-trans/yzgApp/capacity/page/queryCarrierList',
      data: {
        ...params,
        pageSize: 50,
        pageNo: 1,
      },
    },
    { showLoading: false }
  );

// 查询车辆列表
export const queryTruckList = (): Promise<ResponseData<{ list: { carNo: string }[] }>> =>
  server({
    url: '/saas-tms-trans/yzgApp/capacity/page/queryTruckList',
    data: {
      pageSize: 100000,
      pageNo: 1,
    },
  });

// 查询司机列表
export const queryDriverList = (params: {
  driverName: string;
}): Promise<ResponseData<{ list: { driverName: string; driverPhone: string; driverId: string }[] }>> =>
  server(
    {
      url: '/saas-tms-trans/yzgApp/capacity/page/queryDriverList',
      data: {
        ...params,
        pageSize: 50,
        pageNo: 1,
      },
    },
    { showLoading: false }
  );

// 查询平台调度员
export const dispatchList = (params: {
  organizationId: string | number | null; // 组织id
}): Promise<ResponseData<{ dispatchList: { dispatcherName: string; phone: string }[] }>> =>
  server(
    {
      url: '/saas-permission-app/yzgApp/companyAuth/dispatchList',
      data: { ...params },
    },
    { toastError: false }
  );

// 查询运单状态接口
export const getDropDownBoxEnum = (params: any): Promise<ResponseData<{ key: string; value: string }[]>> =>
  server({
    url: '/saas-tms-trans/yzgApp/tenant/config/getDropDownBoxEnum',
    data: { ...params },
  });
