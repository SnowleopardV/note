import React, { useEffect, useRef, useState } from 'react';
import { Text, View, SafeAreaView, ScrollView, TouchableOpacity, Image } from 'react-native';
import Styles from './DrawerStyle';
import { ScreenList as _ScreenList_, scrrentItem, remoteSearchConfig, Params } from './Enum';
import { getCustomerList, dispatcherList, dispatchList, queryTruckList, getDropDownBoxEnum } from './Api';
import { Modal, CellGroup, MBText } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import SearchModal from './SearchModal';
import dayjs from 'dayjs';
import Img from '../../../../../public/static/images/index';
import { Tabs } from '../../list/index';
import { DatePicker } from 'react-native-common-date-picker';
import TextArea from './TextArea';
import { cloneDeep } from 'lodash';
import { MBToast } from '@ymm/rn-lib';
import SelectModal from '~/components/SelectModal';

export interface ScreenDrawerProps {
  onClose: () => void;
  onParams: (params: Params, requset?: boolean) => void;
  type: number;
  visible: boolean;
  showLeverInput?: boolean;
}

//远程搜索方法
const remoteSearch = (value: string, type: string, callback: (data: {}[]) => void) => {
  remoteSearchConfig[type]?.({
    [type === 'driverName' ? 'condition' : type]: value,
  }).then((result: { data: { list: {}[] } }) => {
    callback &&
      callback(
        type === 'driverName'
          ? result.data.list.map((item: { driverName?: string; driverPhone?: string }) => ({
              ...item,
              driverName: item.driverName + '/' + item.driverPhone,
              origindriverName: item.driverName,
            }))
          : result.data.list
      );
  });
};

//设置默认日期值
const setDefaultDate = (type: string, value: number): string => (value ? dayjs(value).format('YYYY-MM-DD') : '');

/**
 * 日期选择弹窗
 */
const DateModal = ({
  visible,
  setVisible,
  onConfirm,
  minDate,
  maxDate,
  defaultDate = '',
  title = '',
}: {
  visible: boolean;
  setVisible: (visible: boolean) => void;
  onConfirm: (time: string) => void;
  minDate?: string | number;
  maxDate?: string | number;
  defaultDate?: string;
  title: string;
}) => {
  const [time, setTime] = useState<string>(dayjs().format('YYYY-MM-DD'));
  useEffect(() => {
    setTime(defaultDate ? defaultDate : dayjs().format('YYYY-MM-DD'));
  }, [defaultDate]);
  return (
    <Modal
      headerLeft="取消"
      headerRight={'确定'}
      title={title}
      position="bottom"
      visible={visible}
      onCancel={() => {
        setVisible(false);
      }}
      onConfirm={() => {
        onConfirm && onConfirm(time);
        setVisible(false);
      }}
      onRequestClose={() => {
        setVisible(false);
      }}
    >
      <SafeAreaView>
        <DatePicker
          showToolBar={false}
          minDate={minDate ? new Date(minDate) : dayjs().subtract(6, 'months').toDate()}
          maxDate={maxDate ? new Date(maxDate) : new Date()}
          yearSuffix={' '}
          onValueChange={(val: string) => {
            setTime(val);
          }}
          defaultDate={defaultDate}
        />
      </SafeAreaView>
    </Modal>
  );
};
/**
 * onClose 关闭弹窗
 * onParams 传递参数
 * type 列表当前的类型
 */

export default ({ onClose, onParams, type, visible, showLeverInput }: ScreenDrawerProps) => {
  const [ScreenList, setScreenList] = useState(JSON.parse(JSON.stringify(_ScreenList_)));
  const [screen, setScreen] = useState<scrrentItem[]>([]);
  const [params, setParmas] = useState<Params>({ 0: {}, 1: {}, 2: {}, 3: {} }); //选中的参数集合，传给服务端
  const [currentCell, setCurrentCell] = useState<scrrentItem | undefined>(); //点击cell的值
  const [searchModalVisible, setSearchModalVisible] = useState<boolean>(false); //搜索弹窗的显隐
  const [dateModalVisible, setDateModalVisible] = useState<boolean>(false);
  const [dateModalTitle, setdateModalTitle] = useState(''); //时间弹窗标题
  const [timeType, setTimeType] = useState<string>('start'); // 区分点击的日期类型
  const [showSelectModal, setshowSelectModal] = useState<any>(null); // 普通单选框

  const [astrictTime, setAstrictTime] = useState<{ minDate: string | number; maxDate: string | number }>({ minDate: '', maxDate: '' }); //用于限制日期选择
  const scrollRef = useRef(null);
  const onTextAreaChange = (item: { label: string; value: string; content: string }, arry?: string[]) => {
    const currentParams = { ...params };
    arry && arry.map((itemDrop) => delete currentParams[type][itemDrop]); //清空之前选择的下拉框参数
    if (item.content) {
      currentParams[type][item.value] = item.content.split(/,|，|\s+/);
      currentParams[type]['currentTextAreaValue'] = item.content;
    } else {
      delete currentParams[type][item.value];
      delete currentParams[type]['currentTextAreaValue'];
    }
    setParmas(currentParams);
  };
  useEffect(() => {
    setScreen([...ScreenList[type]]);
  }, [type]);
  useEffect(() => {
    if (!visible) return; //弹窗不显示的时候不进行请求
    let waybillStatusParams = { code: 'searchDispatch.wayBillStatus' };
    if (type === 0) {
      waybillStatusParams = { code: 'ALL_WAYBILL_STATUS' };
    }

    [0, 1, 2, 3].includes(type) &&
      getCustomerList().then((res) => {
        const totalList = res.data.list.reduce((total: {}[], current) => {
          const merge = [...total, ...current.customerList];
          return merge;
        }, []);
        const currentIndex: number = screen.findIndex((item) => item.key === 'customerName');
        if (currentIndex > -1) {
          screen[currentIndex].optionList = totalList;
          setScreen([...screen]);
        }
      });
    [0, 1, 2].includes(type) &&
      dispatcherList().then((result) => {
        const currentIndex: number = screen.findIndex((item) => item.key === 'dispatcherIds');
        if (currentIndex > -1) {
          screen[currentIndex].optionList = result.data?.map((item) => ({
            ...item,
            tmsDispatcherName: item.tmsDispatcherName + '/' + item.tmsDispatcherPhone,
          }));
          setScreen([...screen]);
        }
      });
    const currentDispatchListIndex: number = screen.findIndex((item) => item.key === 'dispatcherPhone');
    [0, 2].includes(type) &&
      dispatchList({ organizationId: null })
        .then((result) => {
          if (currentDispatchListIndex > -1) {
            screen[currentDispatchListIndex].optionList = result.data.dispatchList?.map((item) => ({
              ...item,
              dispatcherName: item.dispatcherName + '/' + item.phone,
            }));
            delete screen[currentDispatchListIndex].errorInfo;
            setScreen([...screen]);
          }
        })
        .catch(() => {
          screen[currentDispatchListIndex].optionList = [];
          screen[currentDispatchListIndex].errorInfo = '';
        });
    [0, 2].includes(type) &&
      queryTruckList().then((result) => {
        const currentIndex: number = screen.findIndex((item) => item.key === 'waybillCarNo');
        if (currentIndex > -1) {
          screen[currentIndex].optionList = [...result.data.list];
          setScreen([...screen]);
        }
      });
    [0, 2].includes(type) &&
      getDropDownBoxEnum(waybillStatusParams).then((result) => {
        const currentIndex: number = screen.findIndex((item) => item.key === 'waybillStatuses');
        if (currentIndex > -1) {
          screen[currentIndex].optionList = [...result.data];
          setScreen([...screen]);
        }
      });
  }, [visible]);
  return (
    <SafeAreaView>
      <View style={Styles.flex}>
        <View style={Styles.title}>
          <Text style={Styles.titleText}>在【{Tabs[type]}】下搜索</Text>
        </View>
        <View style={{ flex: 1 }}>
          <ScrollView
            style={{ flex: 1 }}
            keyboardShouldPersistTaps="handled"
            showsHorizontalScrollIndicator={false}
            scrollEnabled={true}
            ref={scrollRef}
          >
            <CellGroup withBottomLine style={Styles.CellGroup}>
              {screen.map((item, index) => {
                if (!showLeverInput && (item.key === 'custLevel' || item.key === 'orderCargoLevel')) {
                  return null;
                }
                return (
                  <Cell
                    title={item.title}
                    titleStyle={Styles.cellTitle}
                    value={item.value}
                    align="right"
                    placeholder="请选择"
                    onPress={() => {
                      if (item?.styleType === 'select') {
                        setshowSelectModal(item);
                      } else {
                        setCurrentCell(item);
                        setSearchModalVisible(true);
                      }
                    }}
                    rightElement={
                      item.value ? (
                        <TouchableOpacity
                          style={Styles.closeIcon}
                          onPress={() => {
                            const currentSreen = [...screen];
                            currentSreen[index] = { ...item, value: undefined };
                            ScreenList[type] = currentSreen;
                            setScreen(currentSreen);
                            setScreenList(ScreenList);
                            delete params[type][item.key];
                            setParmas(params);
                          }}
                        >
                          <Image source={{ uri: Img.icon_close }} style={Styles.closeIcon}></Image>
                        </TouchableOpacity>
                      ) : undefined
                    }
                    style={{ padding: 0, margin: 0 }}
                  />
                );
              })}
              {/* 用于给最后一个cell添加底线 */}
              <View style={Styles.splitLine}></View>
            </CellGroup>
            <TextArea
              onSelect={onTextAreaChange}
              onChange={onTextAreaChange}
              textArea={params[type]['currentTextAreaValue'] ?? ''}
              type={type}
              scrollRef={scrollRef}
            />
            <View style={Styles.screenItem}>
              <TouchableOpacity>
                <MBText style={Styles.screenItemText}>开单日期</MBText>
              </TouchableOpacity>
              <View style={Styles.time}>
                <TouchableOpacity
                  style={[Styles.startTime]}
                  onPress={() => {
                    setTimeType('start');
                    setDateModalVisible(true);
                    setAstrictTime({
                      ...astrictTime,
                      minDate: '',
                      maxDate: params[type].billingEndTime ? dayjs(params[type].billingEndTime).valueOf() : '',
                    });
                    setdateModalTitle('请选择开始时间');
                  }}
                >
                  <View style={[Styles.startTime]}>
                    {params[type].billingStartTime ? (
                      <Text style={Styles.timeText}>{dayjs(params[type].billingStartTime).format('YYYY-MM-DD')}</Text>
                    ) : (
                      <Text style={Styles.timeText}>开始时间</Text>
                    )}
                  </View>
                </TouchableOpacity>
                {params[type].billingStartTime && (
                  <TouchableOpacity
                    style={[Styles.smallCloseIcon, Styles.pr12]}
                    onPress={() => {
                      delete params[type].billingStartTime;
                      setAstrictTime({ ...astrictTime, minDate: '' });
                      setParmas({ ...params });
                    }}
                  >
                    <Image source={{ uri: Img.icon_close }} style={Styles.smallCloseIcon}></Image>
                  </TouchableOpacity>
                )}
                <Text style={Styles.line}>-</Text>
                <TouchableOpacity
                  style={[Styles.startTime]}
                  onPress={() => {
                    setTimeType('end');
                    setDateModalVisible(true);
                    setAstrictTime({
                      ...astrictTime,
                      maxDate: '',
                      minDate: params[type].billingStartTime ? dayjs(params[type].billingStartTime).add(1, 'day').valueOf() : '',
                    });
                    setdateModalTitle('请选择结束时间');
                  }}
                >
                  <View style={[Styles.startTime]}>
                    {params[type].billingEndTime ? (
                      <Text style={Styles.timeText}>{dayjs(params[type].billingEndTime).format('YYYY-MM-DD')}</Text>
                    ) : (
                      <Text style={Styles.timeText}>结束时间</Text>
                    )}
                  </View>
                </TouchableOpacity>
                {params[type].billingEndTime && (
                  <TouchableOpacity
                    style={[Styles.smallCloseIcon, Styles.pr12]}
                    onPress={() => {
                      delete params[type].billingEndTime;
                      setParmas({ ...params });
                      setAstrictTime({ ...astrictTime, maxDate: '' });
                    }}
                  >
                    <Image source={{ uri: Img.icon_close }} style={Styles.smallCloseIcon}></Image>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </ScrollView>
          <View style={Styles.bottom}>
            <TouchableOpacity
              style={Styles.clear}
              onPress={() => {
                onParams && onParams({ ...params, [type]: {} }, false);
                setParmas({ ...params, [type]: {} });
                const currentScreen = [...screen];

                currentScreen.map((item) => delete item.value);
                setScreen(currentScreen);
              }}
            >
              <View style={[Styles.clear, Styles.clearBorder]}>
                <Text style={Styles.clearText}>清空</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[Styles.check]}
              onPress={() => {
                const { billingStartTime, billingEndTime } = params[type];
                if (Boolean(billingStartTime) === true && Boolean(billingEndTime) === false) {
                  return MBToast.show('请选择结束时间');
                }
                if (Boolean(billingStartTime) === false && Boolean(billingEndTime) === true) {
                  return MBToast.show('请选择开始时间');
                }
                onClose && onClose();
                const copyParams = cloneDeep(params);
                Object.keys(copyParams).map((item) => {
                  delete copyParams[item]['currentTextAreaValue'];
                });
                console.log(params, '提交');
                onParams && onParams(copyParams);
              }}
            >
              <View style={[Styles.check]}>
                <Text style={[Styles.checkText]}>查询</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
        {/* 单选弹窗 */}
        {!!showSelectModal && (
          <SelectModal
            visible={true}
            list={showSelectModal.optionList}
            title={showSelectModal.modalTitle}
            onConfirm={(item, index) => {
              setParmas({ ...params, [type]: { ...params[type], [showSelectModal?.key ?? '']: item.value } });
              const currentIndex = screen.findIndex((item) => item.key === showSelectModal?.key);
              if (currentIndex > -1) {
                const updateScreen = [...screen];
                updateScreen[currentIndex].value = item.label;
                setScreen(updateScreen);
              }
              setshowSelectModal(null);
            }}
            onCancel={() => setshowSelectModal(null)}
          />
        )}
        <SearchModal
          onSelect={(selectItem, seachType) => {
            if (selectItem) {
              if (selectItem.label === '' || selectItem.label === null) return;
              let currentValue: string | {}[] = '';
              // 有多选标志时，要转换成数组
              if (['startCode', 'endCode'].includes(currentCell?.key ?? '')) {
                currentValue = [{ level: selectItem.level, cityCode: selectItem.value }];
              } else {
                //如果multiple：true参数转换成数组
                // 如果originParams:true 在传给后台的参数取originKey
                // 满足type=select的才会取originKey
                currentValue = currentCell?.multiple
                  ? [selectItem?.value ?? '']
                  : currentCell?.originParams && seachType === 'select'
                  ? selectItem['origin' + selectItem.key]
                  : selectItem?.value ?? '';
              }
              console.log(currentValue, 'currentValue');
              setParmas({ ...params, [type]: { ...params[type], [currentCell?.key ?? '']: currentValue } });
              console.log(params, '/saas-tms-trans/yzgApp/dispatch/dispatchList');
            }
            const currentIndex = screen.findIndex((item) => item.key === selectItem?.key);
            if (currentIndex > -1) {
              const updateScreen = [...screen];
              updateScreen[currentIndex].value = selectItem.label;
              setScreen(updateScreen);
            }
          }}
          onRemote={
            currentCell?.remote
              ? (value, callback) => {
                  remoteSearch(value, currentCell?.key ?? '', callback);
                }
              : undefined
          }
          visible={searchModalVisible}
          onClose={() => {
            setSearchModalVisible(false);
          }}
          parmas={currentCell}
        />
      </View>

      <DateModal
        visible={dateModalVisible}
        title={dateModalTitle}
        setVisible={setDateModalVisible}
        onConfirm={(time) => {
          setParmas({
            ...params,
            [type]: {
              ...params[type],
              [timeType === 'start' ? 'billingStartTime' : 'billingEndTime']: dayjs(time)[timeType + 'Of']('day').valueOf(), //开始时间使用 dayjs().startOf 结束时间用endOf
            },
          });
        }}
        minDate={astrictTime.minDate}
        maxDate={astrictTime.maxDate}
        defaultDate={setDefaultDate(timeType, timeType === 'start' ? params[type]['billingStartTime'] : params[type]['billingEndTime'])}
      />
    </SafeAreaView>
  );
};
