import City from './multipleCity.json';
import { queryDriverList, queryCarrierList } from './Api';
export interface scrrentItem {
  key: string; //该选项传给后台的key
  title: string; //标题
  optionList: {}[]; //下拉内容
  placeholder: string; //没有值代表没有搜索框
  multiple?: boolean; //可以多选
  props?: { label: string; value: string };
  remote?: boolean; //是否开启远程搜索
  value?: string; //选中的值
  errorInfo?: string; //接口请求过来得错误提示信息
  modalTitle?: string; //弹窗标题
  originParams?: Boolean; //从origin开头的字段读取参数用于传给后台
  styleType?: string; //搜索框内的类型
}
export interface dropDdownType {
  0: { label?: string; value?: string; content?: string };
  1: { label?: string; value?: string; content?: string };
  2: { label?: string; value?: string; content?: string };
  3: { label?: string; value?: string; content?: string };
}
export interface Params {
  0: { billingStartTime?: string; billingEndTime?: string };
  1: { billingStartTime?: string; billingEndTime?: string };
  2: { billingStartTime?: string; billingEndTime?: string };
  3: { billingStartTime?: string; billingEndTime?: string };
}
const custLevel = {
  styleType: 'select',
  key: 'custLevel',
  title: '客户等级',
  modalTitle: '请选择客户等级',
  optionList: [
    { label: 'A', value: 'A' },
    { label: 'B', value: 'B' },
    { label: 'C', value: 'C' },
    { label: 'D', value: 'D' },
  ],
  placeholder: '请输入客户等级',
  value: '',
};
const orderCargoLevel = {
  styleType: 'select',
  key: 'orderCargoLevel',
  title: '货源质量',
  modalTitle: '请选择货源质量',
  optionList: [
    { label: 'A', value: 'A' },
    { label: 'B', value: 'B' },
    { label: 'C', value: 'C' },
    { label: 'D', value: 'D' },
  ],
  placeholder: '请输入货源质量',
  value: '',
};

export const ScreenList = {
  0: [
    // {
    //   key: 'waybillStatuses',
    //   title: '运单状态',
    //   multiple: true,
    //   optionList: [],
    //   placeholder: '',
    //   styleType: 'selector',
    //   props: {
    //     label: 'key',
    //     value: 'value',
    //   },
    // },
    {
      key: 'dispatcherModes',
      multiple: true,
      title: '调度方式',
      props: {
        label: 'label',
        value: 'value',
      },
      optionList: [
        {
          label: '满帮找车',
          value: 4,
        },
        {
          label: '自有车',
          value: 1,
        },
        {
          label: '承运商',
          value: 2,
        },

        {
          label: '外调车',
          value: 3,
        },
      ],
      placeholder: '',
      styleType: 'selector',
    },
    {
      key: 'customerName',
      title: '客户名称',
      optionList: [],
      placeholder: '请输入客户名称',
      props: {
        label: 'custName',
        value: 'custName',
      },
    },
    custLevel, // 客户等级
    orderCargoLevel, // 货源质量
    {
      key: 'startCode',
      title: '出发城市',
      optionList: City,
      placeholder: '请输入省/市/区',
      multiple: true,
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
    {
      key: 'endCode',
      title: '到达城市',
      optionList: City,
      multiple: true,
      placeholder: '请输入省/市/区',
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
    {
      key: 'dispatcherIds',
      title: '调度员',
      placeholder: '请输入调度员',
      multiple: true,
      props: {
        label: 'tmsDispatcherName',
        value: 'tmsDispatcherId',
      },
      optionList: [],
    },
  ],
  1: [
    {
      key: 'customerName',
      title: '客户名称',
      optionList: [],
      placeholder: '请输入客户名称',
      props: {
        label: 'custName',
        value: 'custName',
      },
    },
    custLevel, // 客户等级
    orderCargoLevel, // 货源质量
    {
      key: 'startCode',
      title: '出发城市',
      optionList: City,
      placeholder: '请输入省/市/区',
      multiple: true,
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
    {
      key: 'endCode',
      title: '到达城市',
      optionList: City,
      multiple: true,
      placeholder: '请输入省/市/区',
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
    {
      key: 'dispatcherIds',
      title: '调度员',
      placeholder: '请输入调度员',
      multiple: true,
      props: {
        label: 'tmsDispatcherName',
        value: 'tmsDispatcherId',
      },
      optionList: [],
    },
  ],
  3: [
    {
      key: 'customerName',
      title: '客户名称',
      optionList: [],
      placeholder: '请输入客户名称',
      props: {
        label: 'custName',
        value: 'custName',
      },
    },
    custLevel, // 客户等级
    orderCargoLevel, // 货源质量
    {
      key: 'loadCityCodes',
      title: '出发城市',
      optionList: City,
      placeholder: '请输入省/市/区',
      multiple: true,
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
    {
      key: 'unloadCityCodes',
      title: '到达城市',
      optionList: City,
      multiple: true,
      placeholder: '请输入省/市/区',
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
  ],
  2: [
    {
      key: 'waybillStatuses',
      title: '运单状态',
      multiple: true,
      optionList: [],
      placeholder: '',
      styleType: 'selector',
      props: {
        label: 'key',
        value: 'value',
      },
    },
    {
      key: 'loadType',
      title: '提货',
      modalTitle: '请选择是否提货',
      props: {
        label: 'label',
        value: 'value',
      },
      optionList: [
        {
          label: '否',
          value: 'DIRECT_SEND',
        },
        {
          label: '是',
          value: 'SELF_LOAD',
          pickupSubName: '暂不支持「小车上门提货」，若需要请前往pc端操作',
          disabled: true,
        },
      ],
      multiple: true,
      placeholder: '请选择',
      styleType: 'subName',
    },
    {
      key: 'dispatcherModes',
      multiple: true,
      title: '调度方式',
      props: {
        label: 'label',
        value: 'value',
      },
      optionList: [
        {
          label: '满帮找车',
          value: 4,
        },
        {
          label: '自有车',
          value: 1,
        },
        {
          label: '承运商',
          value: 2,
        },

        {
          label: '外调车',
          value: 3,
        },
      ],
      placeholder: '',
      styleType: 'selector',
    },
    {
      key: 'customerName',
      title: '客户名称',
      optionList: [],
      placeholder: '请输入客户名称',
      props: {
        label: 'custName',
        value: 'custName',
      },
    },
    custLevel, // 客户等级
    orderCargoLevel, // 货源质量
    {
      key: 'startCode',
      title: '出发城市',
      optionList: City,
      placeholder: '支持城市搜索，请输入省/市/区',
      multiple: true,
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },
    {
      key: 'endCode',
      title: '到达城市',
      optionList: City,
      multiple: true,
      placeholder: '支持城市搜索，请输入省/市/区',
      props: {
        label: 'label',
        value: 'cityCode',
      },
    },

    {
      key: 'carrierName',
      title: '承运商',
      optionList: [],
      remote: true,
      placeholder: '请输入承运商',
      props: {
        label: 'carrierName',
        value: 'carrierName',
      },
    },
    {
      key: 'driverName',
      title: '司机',
      optionList: [],
      placeholder: '请输入司机',
      props: {
        label: 'driverName',
        value: 'driverName',
      },
      originParams: true,
      remote: true,
    },
    {
      key: 'waybillCarNo',
      title: '车牌号',
      optionList: [],
      placeholder: '请输入车牌号',
      props: {
        label: 'carNo',
        value: 'carNo',
      },
    },
    {
      key: 'dispatcherIds',
      title: '调度员',
      placeholder: '请输入调度员',
      multiple: true,
      props: {
        label: 'tmsDispatcherName',
        value: 'tmsDispatcherId',
      },
      optionList: [],
    },
    {
      key: 'dispatcherPhone',
      title: '平台调度员',
      placeholder: '请输入平台调度员',
      props: {
        label: 'dispatcherName',
        value: 'phone',
      },
      optionList: [],
    },
  ],
};

export const billNumber = {
  0: [
    {
      label: '客户单号',
      value: 'moreCustomerOrderNoList',
    },
    {
      label: '运单号',
      value: 'transOrderNos',
    },
    {
      label: '客户物流单号',
      value: 'moreCustomerWaybillNo',
    },
  ],
  1: [
    {
      label: '客户单号',
      value: 'moreCustomerOrderNoList',
    },
    {
      label: '运单号',
      value: 'transOrderNos',
    },
    {
      label: '客户物流单号',
      value: 'moreCustomerWaybillNo',
    },
  ],
  3: [
    {
      label: '客户单号',
      value: 'moreCustomerOrderNoList',
    },
    {
      label: '运单号',
      value: 'transOrderNos',
    },
    {
      label: '客户物流单号',
      value: 'moreCustomerWaybillNo',
    },
  ],
  2: [
    {
      label: '客户单号',
      value: 'moreCustomerOrderNoList',
    },
    {
      label: '运单号',
      value: 'transOrderNos',
    },
    {
      label: '任务号',
      value: 'taskNos',
    },
    {
      label: '平台单号',
      value: 'mybOrderIds',
    },
    {
      label: '客户物流单号',
      value: 'moreCustomerWaybillNo',
    },
    {
      label: '承运商单号',
      value: 'carrierNumbers',
    },
  ],
};
export enum remoteSearchType {
  driverName,
  carrierName,
}

export const remoteSearchConfig = {
  driverName: queryDriverList,
  carrierName: queryCarrierList,
};
