import React, { Component } from 'react';
import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import WaybillList from './list';
import WaybillDetail from './detail';
import CustomField from './components/shareModal/CustomField';
import CarBoardPage from '../task-manage/car-board';
import FreightAssistant from '../dispatch/freight-assistant';

/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        WaybillList: {
          screen: WaybillList,
          navigationOptions: () => ({
            header: null,
          }),
        },
        WaybillDetail: {
          screen: WaybillDetail,
          navigationOptions: () => ({
            header: null,
          }),
        },
        /** 自定义分享字段 */
        CustomField: {
          screen: CustomField,
          navigationOptions: () => ({
            header: null,
          }),
        },
        /** 找车看板 */
        CarBoard: {
          screen: CarBoardPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        // 运价助手
        FreightAssistant: {
          screen: FreightAssistant,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: string) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}

/**
 * RN页面
 */
export enum RouterPageName {
  /**
   * 列表
   */
  WAYBILL_LIST = 'WaybillList',

  /**
   * 详情
   */
  WAYBILL_DETAIL = 'WaybillDetail',
  /** 自定义分享字段 */
  CUSTOM_FIELD = 'CustomField',
}
