import * as React from 'react';
import { View, TextInput, SafeAreaView, StyleSheet, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { MBBridge } from '@ymm/rn-lib';
import { CellGroup, Whitespace, Button, LayProvider, MBText } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import InputItem from '~/components/common/InputItem/index';
import NavBar from '~/components/common/NavBar';
import NativeBridge from '~/extends/NativeBridge'; // 原生api
import API from './api'; // 原生api
import RegTest from '~/utils/RegTest';
// 新增承运商
const styles = StyleSheet.create({
  foot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
    backgroundColor: '#FFFFFF',
  },
  btn: {
    margin: 10,
  },
  container: {
    flex: 1,
  },
  inner: {
    padding: 24,
    flex: 1,
    justifyContent: 'space-around',
  },
  header: {
    fontSize: 36,
    marginBottom: 48,
  },
  textInput: {
    height: 40,
    borderColor: '#000000',
    borderBottomWidth: 1,
    marginBottom: 36,
  },
  btnContainer: {
    backgroundColor: 'white',
    marginTop: 12,
  },
});

export interface Props {
  item: string;
}
export default class TaskList extends React.Component<Props, any> {
  timerBtn: any = null;
  keyboardDidHideListener: any = null;
  constructor(props: Props) {
    super(props);
    this.state = {
      carrierName: '', // 承运商名称
      carrierNo: '', // 承运商编号
      isHiddenBtn: false,
      carrierId: '', // 承运商Id
    };
  }
  componentWillMount() {
    this.api_carrierGenerateNo();
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => {
      Keyboard.dismiss();
    });
  }
  componentWillUnmount() {
    this.keyboardDidHideListener.remove();
  }
  goBack = () => {
    MBBridge.rnruntime.handlebackResult({ data: JSON.stringify(this.state) });
    MBBridge.app.ui.closeWindow({});
  };
  // 点击保存
  submit = () => {
    this.api_addCarrier();
  };
  // 获取承运商编号接口
  api_carrierGenerateNo() {
    API.carrierGenerateNo().then((res: any) => {
      if (res.success && res.data) {
        this.setState({
          carrierNo: res.data,
        });
      }
    });
  }
  api_addCarrier(): void {
    const formData = {
      carrierName: this.state.carrierName, // 承运商名称
      carrierNo: this.state.carrierNo, // 承运商编号
    };
    API.addCarrier(formData).then((res: any) => {
      if (res.success) {
        NativeBridge.toast('添加承运商成功');
        if (res.data && res.data.carrierId) {
          this.setState({
            carrierId: res.data.carrierId,
          });
        }
        this.goBack();
      }
    });
  }
  // 改变名称
  changeName(text: string) {
    if (!RegTest.emoji(text)) {
      this.setState({ carrierName: text });
    }
  }
  // 改变编号
  changeNo(text: string) {
    if (!RegTest.emoji(text)) {
      this.setState({ carrierNo: text });
    }
  }
  hiddenButton(val: boolean) {
    clearTimeout(this.timerBtn);
    this.timerBtn = setTimeout(() => {
      this.setState({ isHiddenBtn: val });
    }, 0);
  }
  // 是否可以提交
  submitDisabled() {
    const { carrierName, carrierNo } = this.state;
    return carrierName && carrierNo;
  }
  public render() {
    const { isHiddenBtn } = this.state;
    return (
      <LayProvider theme="skyblue" style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={{ flex: 1 }}>
            <NavBar title="新增承运商" />
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <InputItem
                required
                title="承运商编号"
                style={{ backgroundColor: '#FFFFFF' }}
                inputStyle={{ width: '100%', textAlign: 'right' }}
                value={this.state.carrierNo}
                placeholder="请输入"
                maxLength={32}
                returnKeyType="done"
                onSubmitEditing={Keyboard.dismiss}
                onChangeText={(text) => this.changeNo(text)}
                onFocus={() => this.hiddenButton(true)}
                onBlur={() => this.hiddenButton(false)}
              />
            </CellGroup>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <InputItem
                required
                title="承运商名称"
                style={{ backgroundColor: '#FFFFFF' }}
                inputStyle={{ width: '100%', textAlign: 'right' }}
                value={this.state.carrierName}
                placeholder="请输入"
                maxLength={64}
                returnKeyType="done"
                onSubmitEditing={Keyboard.dismiss}
                onChangeText={(text) => this.changeName(text)}
                onFocus={() => this.hiddenButton(true)}
                onBlur={() => this.hiddenButton(false)}
              />
            </CellGroup>
            <View style={styles.foot}>
              <SafeAreaView>
                <Button
                  radius
                  disabled={!this.submitDisabled()}
                  style={isHiddenBtn ? { display: 'none' } : styles.btn}
                  onPress={this.submit.bind(this)}
                  size="sm"
                  type="primary"
                >
                  保存并使用
                </Button>
              </SafeAreaView>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </LayProvider>
    );
  }
}
