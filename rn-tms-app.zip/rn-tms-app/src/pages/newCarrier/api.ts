import server from '~/server';

const Api = {
  // 创建调度-新增承运商接口 http://yapi.1111.com/#/project/2532/interface/api/204641
  addCarrier(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/add/carrier',
      data: { ...params },
    });
  },
  // 获取承运商编号接口
  carrierGenerateNo(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/task/carrier/generate/no',
      data: { ...params },
    });
  },
};

export default Api;
