import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { CellGroup, Whitespace, Button, MBText, Flex, Checkbox, RNElementsUtil } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';

import Cell from '~/components/common/Cell';
import keyMap from './keyMap'; // 枚举值
import filterFormat from '~/extends/filterFormat'; //格式化
import NativeBridge from '~/extends/NativeBridge';
import SelectOrganizeCell from '../../components/SelectOrganize/SelectOrganizeCell';
import CellAddressloadUnload from './components/CellAddressloadUnload';
import CellCargoDealMode from './components/CellCargoDealMode';

// 进入调度后的背景 ，假页面
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  page: {
    flex: 1,
  },
  foot: {
    backgroundColor: '#FFFFFF',
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
  icon: {
    width: 15,
    height: 15,
  },
  notes: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingRight: 5,
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
  },
  checkbox: {
    marginTop: 27,
    marginLeft: 10,
    marginRight: 10,
  },
  bottomShadow: {
    borderTopColor: '#EEE',
    borderTopWidth: 2,
    // shadowColor: '#000',
    // shadowOpacity: 0.5,
    // shadowOffset: { width: 10, height: 50 },
    // shadowRadius: 5,
    // elevation: 2,
  },
});
export interface PlatformProps {
  openTypeModal?: (val: boolean) => void; // 打开调度方式选择弹窗
  store?: any;
}
@inject('store')
@observer
export default class Platform extends React.Component<PlatformProps, any> {
  constructor(props: PlatformProps) {
    super(props);
    keyMap.tagData = []; // 初始化 备注快捷标签
    this.state = {
      showModal: 0, // 0 无，1 发票 2 调度员 3 车型车长 4是否跟车 5 应收运费 6 司机订金
      invoiceMap: ['不开票', '满帮专票'],
      deliverymanMap: ['不跟车', '1人跟车', '2人跟车'],
      isAgreedCheck: true, // 协议是否同意
    };
  }
  openTypeModal(): void {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }
  openModal(val: number): void {
    this.setState({ showModal: val, showDetail: false });
  }
  // 发票类型 1 不开票 2 专票
  handleInviceChange = (val: number): void => {
    this.setState({ showModal: 0 });
    if (typeof val === 'number') {
      const data = {
        invoiceFlag: val, // 开票信息, 0不开票 1开专票
      };
      this.props.store.setFormData(4, data);
    }
  };
  // TODO 暂时不用
  submit(): void {
    console.log('智能议价');
  }
  goAgreement = (val: number): void => {
    console.log('跳转协议', val);
  };
  // 点击协议
  handleAgreedCheck = (): void => {
    this.setState(({ isAgreedCheck }: any) => {
      return { isAgreedCheck: !isAgreedCheck };
    });
  };
  // 协议
  AgreedCheckbox(): React.ReactNode {
    const { invoiceFlag } = this.props.store.formData_4;
    const { isAgreedCheck } = this.state;
    return (
      <Flex direction="row" align="center" wrap="wrap" style={styles.checkbox}>
        <Checkbox
          type="primary"
          size="sm"
          checked={isAgreedCheck}
          onChange={this.handleAgreedCheck.bind(this)}
          style={{ alignItems: 'flex-start' }}
        >
          {invoiceFlag ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 1)}>
                《货物运输交易协议》
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 2)}>
                《满运宝保障条款（托运人版本）》
              </MBText>
            </MBText>
          ) : (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 3)}>
                《货物运输协议》
              </MBText>
            </MBText>
          )}
        </Checkbox>
      </Flex>
    );
  }
  // 电话找车 , 默认电话找车 （保存并使用）
  submitPhone(): void {
    const formData = this.props.store.formData_4;
    const { loadTime, unloadTime } = formData;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
    const { isAgreedCheck } = this.state;
    if (!isAgreedCheck) {
      NativeBridge.toast('请确认同意相关协议');
      return;
    }
    const pass = this.isSubmit();
    this.setState({ isRulesTips: !pass });
    if (!pass) {
      NativeBridge.toast('有必选项未填');
      return;
    }
  }

  isSubmit(): boolean {
    const { isAgreedCheck } = this.state;
    const formData = this.props.store.formData_4;
    const { dispatcherId, platformCarType, deliveryFee, deposit, loadTime } = formData;
    return isAgreedCheck && dispatcherId && platformCarType.length && deliveryFee && deposit && loadTime.dateCode;
  }
  // 底部按钮
  footElement(): React.ReactNode {
    return (
      <View style={[styles.foot, styles.bottomShadow]}>
        <Whitespace vertical={5} />
        <Button radius style={styles.btn} onPress={this.submitPhone.bind(this)} size="sm" type="primary">
          确定调度
        </Button>
      </View>
    );
  }
  render(): React.ReactNode {
    const { invoiceMap } = this.state;
    const { store } = this.props;
    const formData = store.formData_4;
    const {
      deliveryFee,
      deliveryUnit,
      platformCarType,
      platformCarLength,
      invoiceFlag,
      dispatcherName,
      refundDeposit,
      loadTime,
      unloadTime,
      selectedText,
      tmsLoadUnloads,
      mybCompanyName,
    } = formData;
    const dispatcherText = dispatcherName ? `${dispatcherName}` : ''; // 调度员

    const carTypeText = platformCarType.map((item: string) => keyMap.carTypeAll[item]).join('、');
    const carLengthText = platformCarLength.map((item: string) => keyMap.carLengthAll[item]).join('、');

    const carTypeLength = carTypeText + (carTypeText ? ' / ' + carLengthText : carLengthText); // 车型 车长

    const deliveryFeeText = deliveryFee ? `¥ ${filterFormat.moneyDecFormat(deliveryFee)} / ${keyMap.unitMap[deliveryUnit]}` : '';
    const depositText = formData.deposit
      ? `¥ ${filterFormat.moneyDecFormat(formData.deposit)} ${refundDeposit ? ' / 退还' : ' / 不退'}`
      : '';
    let notesText = selectedText && selectedText.length ? selectedText.join(';') : '';
    notesText = (formData.remark ? formData.remark + ';' : '') + notesText; // 备注
    return (
      <View style={styles.page}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <SelectOrganizeCell from={4} />
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell title="调度方式" value="满帮找车" align="right" valueStyle={styles.valueStyle} onPress={this.openTypeModal.bind(this)} />
            <Cell
              title="发票类型"
              value={invoiceMap[invoiceFlag]}
              align="right"
              valueStyle={styles.valueStyle}
              onPress={this.openModal.bind(this, 1)}
            />
            {mybCompanyName && <Cell title="发票抬头" readonly={true} value={mybCompanyName} align="right" />}
          </CellGroup>
          <Whitespace vertical={10} />
          <CellAddressloadUnload tmsLoadUnloads={tmsLoadUnloads} required={true} />
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell
              required
              title="装货时间"
              value={loadTime.displayValue}
              align="right"
              placeholder="请选择"
              valueStyle={styles.valueStyle}
              onPress={this.openModal.bind(this, 7)}
              extra={
                this.state.isRulesTips &&
                !loadTime.displayValue && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      装货时间未选择
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
            <Cell
              title="卸货时间"
              value={unloadTime.displayValue}
              align="right"
              placeholder="请选择"
              valueStyle={styles.valueStyle}
              onPress={this.openModal.bind(this, 8)}
            />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell
              title="调度员"
              value={dispatcherText}
              required
              align="right"
              placeholder="请选择"
              onPress={this.openModal.bind(this, 2)}
              extra={
                this.state.isRulesTips &&
                !dispatcherName && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      调度员未选择
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
            <Cell
              title="车型车长"
              value={carTypeLength}
              required
              align="right"
              placeholder="请选择"
              onPress={this.openModal.bind(this, 3)}
              extra={
                this.state.isRulesTips &&
                !carTypeLength && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      车型车长未选择
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <CellCargoDealMode title="成交方式" from={4} readonlyNotDusty />
            <Cell
              title="应付运费"
              value={deliveryFeeText}
              required
              name="freight"
              align="right"
              placeholder="请输入"
              numberOfLines={1}
              onPress={this.openModal.bind(this, 5)}
              extra={
                this.state.isRulesTips &&
                !formData.deliveryFee && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      应付运费未填
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
            <Cell
              title="司机订金"
              value={depositText}
              required
              name="type"
              align="right"
              placeholder="请输入"
              onPress={this.openModal.bind(this, 6)}
              numberOfLines={1}
              extra={
                this.state.isRulesTips &&
                !formData.deposit && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      调度员未选择
                    </MBText>
                    <Whitespace vertical={14} />
                  </View>
                )
              }
            />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell value={notesText} title="服务要求与备注" name="notes" align="right" placeholder="请输入" numberOfLines={1} />
          </CellGroup>
        </ScrollView>
      </View>
    );
  }
}
