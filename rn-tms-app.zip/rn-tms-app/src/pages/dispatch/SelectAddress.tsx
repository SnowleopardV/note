import React from 'react';
import { View, SafeAreaView, StyleSheet, Platform, BackHandler } from 'react-native';
import { Button, CellGroup, Whitespace } from '@ymm/rn-elements';
import { HandleOnceUtil } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import CityPicker from '~/components/common/CityPicker';
// 选择地址 - 装货地址-- 卸货地址
const defaultAddress = {
  province: 0,
  provinceName: '',
  city: 0,
  cityName: '',
  area: 0,
  areaName: '',
  address: '',
  longitude: '0',
  latitude: '0',
  mapType: 2, // 地图类型：1-百度 2-高德
};
// 接口需要的字段映射
const formDataMap = {
  districtCode: 'area', // 区code
  districtName: 'areaName', // 区名称
  provinceCode: 'province', // 省code
  provinceName: 'provinceName', // 省名称
  cityCode: 'city', // 市code
  cityName: 'cityName', // 市名称
  address: 'address', // 地址
  addressLongitude: 'longitude', // 经度
  addressLatitude: 'latitude', // 纬度
};
@inject('store')
@observer
export default class checkList extends React.Component<any, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    const formData = {};
    if (this.props.navigation.state?.params?.data) {
      const data = this.props.navigation.state.params.data;
      Object.keys(formDataMap).map((key: string) => {
        formData[formDataMap[key]] = data[key];
      });
    }
    this.state = {
      title: this.props.navigation.state?.params?.title || '装货地址',
      formData: {
        ...defaultAddress,
        ...formData,
      },
      showModal: 0, // 打开弹窗 1 地址选择
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  isSubmit = () => {
    const { province, provinceName, city, cityName, area, areaName, address, longitude, latitude } = this.state.formData;
    return !(province && provinceName && city && cityName && address && longitude && latitude);
  };
  // 提交
  submit() {
    const { navigation } = this.props;
    const { formData } = this.state;
    const data = {};
    Object.keys(formDataMap).map((key: string) => {
      data[key] = formData[formDataMap[key]];
    });
    const { provinceName, cityName, areaName } = this.state.formData;
    data.areaAddress = provinceName + cityName + areaName;
    navigation?.goBack(); // 返回得到的地址信息
    navigation.state?.params?.onSuccess(data); // 返回得到的地址信息
  }
  openTypeModal = () => {};
  render() {
    const { title, formData } = this.state;
    return (
      <View style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>
          <NavBar
            title={title}
            leftClick={() => {
              this.props.navigation?.goBack();
            }}
          />
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <CityPicker
              value={formData}
              onPress={(type: any) => {
                console.log(type);
              }}
              onChange={(value) => {
                this.setState({ formData: value });
              }}
            />
          </CellGroup>
          <Whitespace vertical={10} />
        </View>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}>
          <View style={styles.foot}>
            <Button
              disabled={this.isSubmit()}
              radius
              onPress={() =>
                HandleOnceUtil.callOnceInInterval(() => {
                  this.submit();
                }, 1500)
              }
              size="sm"
              type="primary"
              style={{ backgroundColor: '#4885FF', borderColor: '#4885FF' }}
            >
              确定
            </Button>
          </View>
        </SafeAreaView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  foot: {
    backgroundColor: '#FFFFFF',
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
    lineHeight: 20,
  },
});
