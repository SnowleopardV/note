import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, Button, Theme, MBText, Whitespace } from '@ymm/rn-elements';
import { MBBridge } from '@ymm/rn-lib';
import NativeBridge from '../../../extends/NativeBridge';
import API from '../api';

// 选择承运商 模态框
const styles = StyleSheet.create({
  selectItem: {
    color: Theme.color_primary,
  },
  btn: {
    marginTop: 20,
    marginBottom: 10,
    width: 179,
    height: 40,
    borderRadius: 50,
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
  noText?: string; // 无数据显示文本
}

export default class SelectCarrierModal extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      item: {},
      id: 0,
      list: [],
      isAdd: false,
    };
  }
  componentWillMount() {
    this.api_queryCarrierList(false);
  }
  // 获取指派承运商接口
  api_queryCarrierList(isFill: boolean) {
    API.queryCarrierList().then((res) => {
      if (res.success) {
        const list = res.data.carrierList;
        this.setState(
          {
            isAdd: res.data.enableCreation,
            item: list[0],
            list: list.map((item: any, index: number) => {
              return {
                ...item,
                id: index,
                content(selected: boolean) {
                  return (
                    <Flex direction="row" justify="center" align="center">
                      <MBText bold={selected} color={selected ? 'primary' : 'base'} numberOfLines={1}>
                        {item.carrierName}
                      </MBText>
                    </Flex>
                  );
                },
              };
            }),
          },
          () => {
            if (isFill) {
              this.handleConfirm();
            }
          }
        );
      }
    });
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { item, list } = this.state;
    onChange && onChange(item);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  // 新增承运商
  handleAdd() {
    this.handleCancel();
    setTimeout(() => {
      this.goPages();
    }, 400);
  }
  goPages() {
    MBBridge.app.base.openSchemeForResult({ schemeUrl: 'ymm://rn.tms/newcarrier' }).then((res: any) => {
      if (res.data) {
        this.api_queryCarrierList(true);
      }
    });
  }
  noPermission() {
    NativeBridge.toast('您还没有#新增承运商权限#，请联系管理员开通');
  }
  handleChange = (position: number, item: any) => {
    this.setState({
      item: item,
      id: position,
    });
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { id, list, isAdd } = this.state;
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请选择承运商"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row" justify="center" align="center">
            {list.length ? (
              <Flex.Item key="time">
                <View style={{ flexDirection: 'column' }}>
                  <Selector type={2} value={id} rowTitle="content" list={list} scaleFont={true} onChange={this.handleChange} />
                </View>
              </Flex.Item>
            ) : (
              <MBText style={{ marginVertical: 50 }} color="#999999">
                无维护的承运商
              </MBText>
            )}
          </Flex>
          <Button
            type="bordered"
            size="xs"
            style={[styles.btn, !isAdd && { opacity: 0.3 }]}
            onPress={(el) => (isAdd ? this.handleAdd() : this.noPermission())}
          >
            新增承运商
          </Button>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
