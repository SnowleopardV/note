import React, { PureComponent } from 'react';
import { View } from 'react-native';
import Cell from '~/components/common/Cell';
import { inject, observer } from 'mobx-react';
import NativeBridge from '~/extends/NativeBridge';
import keyMap from '../../keyMap';
import { MBText, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
/** 承运车辆 */
export interface Props {
  required?: boolean; // 是否必选
  store?: any;
  readonly?: boolean; // 只读 文字置灰
  from: number;
  navigation: any;
  isRulesTips?: boolean; // 是否进行验证提示
  $parent?: any; // 父级对象
}

@inject('store')
@observer
export default class CellCarryingVehicle extends PureComponent<Props, any> {
  static defaultProps = {
    readonly: false,
    required: false,
    from: 31,
  };
  $parent: any;
  constructor(props: any) {
    super(props);
    this.$parent = this.props.$parent;
    this.state = {};
  }
  handleConfirm() {}
  // 只读情况下点击回调
  toastNotEdit = (text: string | undefined) => {
    text && NativeBridge.toast(`不支持修改#${text}#`);
  };
  // 跳转到修改 承运车辆信息页面
  goUpdataPage() {
    const { navigation } = this.props;
    navigation.navigate('UpdataCarInfo', {
      //其他参数透传
      from: 31, // 指派外调车 -开发票
    });
  }
  // 显示 承运车辆 拼接信息
  carrierVehicle() {
    const { from, store } = this.props;
    const formData = store[`formData_${from}`];
    const { carNo, carType, carLength } = formData;
    const data = [];
    if (carNo && carType && keyMap.carTypePlate[carType] && carLength && keyMap.carLengthPlate[carLength]) {
      carNo && data.push(carNo);
      carType && keyMap.carTypePlate[carType] && data.push(keyMap.carTypePlate[carType]);
      carLength && keyMap.carLengthPlate[carLength] && data.push(keyMap.carLengthPlate[carLength] + '米');
      return data.join(' ');
    } else {
      return '';
    }
  }
  render() {
    const { from, store, readonly, isRulesTips } = this.props;
    const formData = store[`formData_${from}`];
    const { driverName } = formData;
    return (
      <View>
        {!!driverName && (
          <Cell
            required
            title="承运车辆"
            align="right"
            value={this.carrierVehicle()}
            placeholder="请输入"
            numberOfLines={1}
            onPress={() => this.goUpdataPage()}
            bottomLine={true}
            readonly={readonly}
            onReadOnlyPress={this.toastNotEdit.bind(this, '承运车辆')}
            extra={
              isRulesTips &&
              !this.carrierVehicle() && (
                <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                  <MBText size="xs" color="#F54242" align="right">
                    车辆信息未选择
                  </MBText>
                  <Whitespace vertical={12} />
                </View>
              )
            }
          />
        )}
      </View>
    );
  }
}
