import * as React from 'react';
import { View, SafeAreaView, StyleSheet, Platform, BackHandler } from 'react-native';
import { inject, observer } from 'mobx-react';
import { LayProvider, CellGroup, Whitespace, Button } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import NavBar from '~/components/common/NavBar';
import NativeBridge from '~/extends/NativeBridge'; // 原生api
import keyMap from '~/pages/dispatch/keyMap';
import ModalSelectCarsLength from '~/pages/newCars/components/ModalSelectCarsLength';
import ModalSelectCarsType from '~/pages/newCars/components/ModalSelectCarsType';

// 修改承运车辆 车长 车型
const styles = StyleSheet.create({
  page: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  foot: {
    backgroundColor: '#FFFFFF',
  },
  btn: {
    margin: 10,
  },
});

export interface Props {
  navigation: any;
  store: any;
}
@inject('store')
@observer
export default class updataCarInfo extends React.Component<Props, any> {
  backHandleListener: any;
  from: any;
  constructor(props: Props) {
    super(props);
    this.from = props.navigation.state.params.from;
    const formData = props.store[`formData_${this.from}`];
    const carTypePlate = Object.keys(keyMap.carTypePlate).map((key: string) => {
      return { id: key, name: keyMap.carTypePlate[key].toString() };
    });
    const carLengthPlate = Object.keys(keyMap.carLengthPlate).map((key: string) => {
      return { id: key, name: keyMap.carLengthPlate[key].toString() };
    });
    this.state = {
      showModal: 0, // 0 无 1 车长 2 车型
      carNo: formData.carNo || null, // 车牌
      carType: formData.carType || null, // 车型
      carLength: formData.carLength || null, // 车长
      carTypePlate: carTypePlate,
      carLengthPlate: carLengthPlate,
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  goBack = () => {
    this.props.navigation?.goBack();
  };
  openModal = (val: any) => {
    this.setState({ showModal: val });
  };
  // 选择车长
  handleCarsLengthChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      this.setState({ carLength: val.id });
    }
  };
  // 车型
  handleCarsTypeChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      this.setState({ carType: val.id });
    }
  };
  // 点击保存
  submit = () => {
    console.log('保存', this.state);
    const { carType, carLength } = this.state;
    const isCarType = this.showText('carTypePlate', carType);
    const isCarLength = this.showText('carLengthPlate', carLength);
    if (!isCarType) {
      NativeBridge.toast('请选择车长');
    } else if (!isCarLength) {
      NativeBridge.toast('请选择车型');
    } else {
      this.props.store.setFormData(this.from, { carType, carLength });
      this.goBack();
    }
  };
  // 是否可以提交
  submitDisabled() {
    const { carLength, carType } = this.state;
    return carType && carLength;
  }
  showText(key: string, id: any) {
    return keyMap[key][id] || '';
  }
  public render() {
    const { carLength, carType, showModal, carNo, carLengthPlate, carTypePlate } = this.state;

    return (
      <LayProvider theme="skyblue" style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <View style={{ flex: 1 }}>
          <NavBar title="承运车辆" leftClick={() => this.goBack()} />
          <View style={styles.page}>
            <View>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell required title="车牌号" value={carNo} align="right" placeholder="请输入" readonly={true} />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="车型"
                  value={this.showText('carTypePlate', carType)}
                  align="right"
                  placeholder="请选择"
                  onPress={this.openModal.bind(this, 2)}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="车长"
                  value={this.showText('carLengthPlate', carLength)}
                  align="right"
                  placeholder="请选择"
                  onPress={this.openModal.bind(this, 1)}
                />
              </CellGroup>
            </View>
            <View style={styles.foot}>
              <Button disabled={!this.submitDisabled()} radius style={styles.btn} onPress={this.submit.bind(this)} size="sm" type="primary">
                确定
              </Button>
              <SafeAreaView style={{ backgroundColor: '#fff' }} />
            </View>
          </View>
          <ModalSelectCarsLength visible={showModal === 1} onChange={this.handleCarsLengthChange} listMap={carLengthPlate} />
          <ModalSelectCarsType visible={showModal === 2} onChange={this.handleCarsTypeChange} listMap={carTypePlate} />
        </View>
      </LayProvider>
    );
  }
}
