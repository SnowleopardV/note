import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { Theme, Checkbox, MBText, Flex } from '@ymm/rn-elements';
const FlexItem = Flex.Item;
const styles = StyleSheet.create({
  checkbox: {
    marginTop: 27,
    marginLeft: 10,
    marginRight: 10,
    flexDirection: 'row',
  },
  checkbox_text: {
    fontSize: 14,
    color: '#666666',
  },
  checkbox_url: {
    color: Theme.color_link,
  },
});

export default class AgreedCheckbox extends React.Component {
  constructor(props: any) {
    super(props);
    this.state = {};
  }

  render() {
    const { text, agreedText, onChange } = this.props;
    return (
      <Flex direction="row" align="center" style={styles.checkbox} wrap="wrap">
        <Checkbox type="primary" size="xs" onChange={onChange}>
          <MBText style={styles.checkbox_text}>{text}</MBText>
        </Checkbox>
        <MBText style={styles.checkbox_url}>{agreedText[0]}</MBText>
        <MBText style={styles.checkbox_url}>{agreedText[1]}</MBText>
      </Flex>
    );
  }
}

AgreedCheckbox.defaultProps = {
  text: '我已阅读并同意',
  agreedText: ['《货物运输交易协议》'],
};
