import React, { PureComponent } from 'react';
import { TouchableOpacity, View } from 'react-native';
import Cell from '~/components/common/Cell';
import { inject, observer } from 'mobx-react';
import { Flex, MBText, Modal, Selector, Whitespace } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import InputItem from '~/components/common/InputItem';
import verification from '~/extends/verification';
import RegTest from '~/utils/RegTest';
/** 是否开票  依赖 文件 CellCostInput/index.tsx 中的 api_getFeeInputBoxes() */
export interface Props {
  placeholder?: string;
  required?: boolean; // 是否必选
  store?: any;
  readonly?: boolean; // 只读 文字置灰
  from: number;
  navigation: any;
  title?: string;
  isRulesTips?: boolean; // 是否进行验证提示
  $parent?: any; // 父级对象
}

@inject('store')
@observer
export default class CellInvoice extends PureComponent<Props, any> {
  static defaultProps = {
    readonly: false,
    required: false,
    title: '是否开票',
  };
  $parent: any;
  constructor(props: any) {
    super(props);
    this.$parent = this.props.$parent;
    this.state = {
      visible: 0, // 1 是否开票 2 计税方式
      invoicelist: [
        { label: '是', value: 1 },
        { label: '否', value: 0 },
      ],
      taxWaylist: [
        { label: '应付合计含税', value: 1 },
        { label: '应付合计不含税', value: 2 },
      ], // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
      item: null,
    };
  }
  handleConfirm() {
    const { visible, item } = this.state;
    const { from } = this.props;
    switch (visible) {
      case 1:
        let data;
        if (item.value) {
          data = {
            carrierInvoiceFlag: 1,
            taxWay: 1, // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
          };
        } else {
          data = {
            carrierInvoiceFlag: 0,
            taxWay: null, // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
            taxRate: null, // 税率 两位小数 只在承运商下显示
            taxFee: null, // 税金 单位分 只在承运商下显示
          };
        }

        this.props.store.setFormData(from, data);
        break;
      case 2:
        this.props.store.setFormData(from, { taxWay: item.value });
        break;
      default:
        break;
    }
    this.props.store.getTax(from); // 计算税金
    this.handleCancel();
  }
  handleCancel = () => {
    this.setState({ visible: 0, item: null });
  };

  handleChange = (index: number, item: any) => {
    this.setState({ item: item });
  };
  showModal(val: number) {
    const { invoicelist, taxWaylist } = this.state;
    this.setState({ visible: val, item: val == 1 ? invoicelist[0] : taxWaylist[0] });
  }
  changeText(val: string, index: number) {
    const { from } = this.props;
    switch (index) {
      case 1:
        if (RegTest.zeroHundredTwoPrecision(val) || val === '') {
          const taxRate = val;
          this.props.store.setFormData(from, { taxRate: taxRate });
          this.props.store.getTax(from); // 计算税金
        }
        break;
      case 2:
        if (verification.price(val) || val === '') {
          this.props.store.setFormData(from, { taxFee: val });
        }
        break;
      default:
        break;
    }
  }
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  // 只读情况下点击回调
  toastNotEdit = (text: string | undefined) => {
    text && NativeBridge.toast(`不支持修改#${text}#`);
  };
  ModalInvoiceElement() {
    const { store, from } = this.props;
    const formData = store[`formData_${from}`];
    const { visible, invoicelist, taxWaylist } = this.state;
    const list = visible == 1 ? invoicelist : taxWaylist;
    let value = 0;
    if (visible == 1) {
      value = invoicelist?.findIndex((item: any) => item.value == formData.carrierInvoiceFlag);
    } else if (visible == 2) {
      value = taxWaylist?.findIndex((item: any) => item.value == formData.taxWay);
    }
    return (
      <Modal
        animationType="slide"
        headerLeft="取消"
        headerRight={this.rightElement()}
        title={visible == 1 ? '是否开票' : '请选择计税方式'}
        position="bottom"
        visible={!!visible}
        headerLine={false}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        <Flex direction="row" justify="center" align="center">
          <Flex.Item key="time">
            <View style={{ flexDirection: 'column' }}>
              <Selector type={1} value={value > 0 ? value : 0} rowTitle="label" list={list} onChange={this.handleChange} />
            </View>
            <Whitespace vertical={20} />
          </Flex.Item>
        </Flex>
      </Modal>
    );
  }
  render() {
    const { store, from, title, readonly } = this.props;
    const { taxWaylist, invoicelist } = this.state;
    const formData = store[`formData_${from}`];
    const carrierInvoiceFlag = invoicelist?.find((item: any) => item.value == formData.carrierInvoiceFlag)?.label; // 0：不开票；1：开票
    const taxWay = taxWaylist?.find((item: any) => item.value == formData.taxWay)?.label; // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
    const taxRate = formData.taxRate;
    const taxFee = formData.taxFee;
    const { showCellCostInput } = store;
    return (
      <View>
        {!!showCellCostInput.carrierInvoiceFlag && (
          <Cell
            title={title}
            align="right"
            value={carrierInvoiceFlag}
            placeholder="请输入"
            numberOfLines={1}
            onPress={() => this.showModal(1)}
            bottomLine={true}
            readonly={readonly}
            onReadOnlyPress={this.toastNotEdit.bind(this, title)}
          />
        )}
        {!!formData.carrierInvoiceFlag && !!showCellCostInput.taxType && (
          <Cell
            title="计税方式"
            align="right"
            value={taxWay}
            placeholder="请输入"
            numberOfLines={1}
            onPress={() => this.showModal(2)}
            bottomLine={true}
            readonly={readonly}
            onReadOnlyPress={this.toastNotEdit.bind(this, '计税方式')}
          />
        )}
        {!!formData.carrierInvoiceFlag && !!showCellCostInput.taxRate && (
          <InputItem
            title="税率"
            textAlign="right"
            style={{ flex: 1 }}
            value={taxRate}
            onChangeText={(text: string) => this.changeText(text, 1)}
            placeholder="请输入"
            keyboardType="numeric"
            clearButtonMode="while-editing"
            blurOnSubmit={false}
            bottomLine={true}
            extraNode={<MBText style={{ marginLeft: 10, color: readonly ? '#CCC' : '#333' }}>%</MBText>}
            readonly={readonly}
            editable={!readonly}
            onFocus={() => store.setShowFooterBtn(false, true)}
            onBlur={() => store.setShowFooterBtn(true)}
          />
        )}
        {!!formData.carrierInvoiceFlag && !!showCellCostInput.feeTax && (
          <InputItem
            title="税费"
            textAlign="right"
            style={{ flex: 1 }}
            value={taxFee}
            onChangeText={(text: string) => this.changeText(text, 2)}
            placeholder="请输入"
            keyboardType="numeric"
            clearButtonMode="while-editing"
            blurOnSubmit={false}
            bottomLine={true}
            extraNode={<MBText style={{ marginLeft: 10, color: readonly ? '#CCC' : '#333' }}>元</MBText>}
            readonly={readonly}
            editable={!readonly}
            onFocus={() => store.setShowFooterBtn(false, true)}
            onBlur={() => store.setShowFooterBtn(true)}
          />
        )}
        {this.ModalInvoiceElement()}
      </View>
    );
  }
}
