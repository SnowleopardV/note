import { MBText, Modal, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import React, { Component } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
// 单项选择调度员框
export interface Props {
  onChange: (item: Item | null) => void;
  visible: boolean;
  list: Item[];
  selected: string; // 选择的成交方式
}
export interface Item {
  label: string;
  value: string;
}
export interface State {
  selectedItem: Item | null;
}
export default class SingleSelectdispatcherModal extends Component<Props, State> {
  static defaultProps = {
    showOrgName: false,
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      selectedItem: null, // 用于保存选中值
    };
  }
  componentWillReceiveProps(nextProps: Props): void {
    if (nextProps.visible && nextProps.selected) {
      const selectedItem = nextProps.list.find((item: Item) => item.value === nextProps.selected);
      this.setState({ selectedItem: selectedItem || null });
    }
  }
  handleConfirm = (item: Item): void => {
    const { onChange } = this.props;
    onChange && onChange(item);
  };
  handleCancel = (): void => {
    const { onChange } = this.props;
    onChange && onChange(null);
  };
  listItemElement(item: Item, index: number): React.ReactNode {
    const { selectedItem } = this.state;
    return (
      <TouchableOpacity style={[styles.item, index ? styles.borderTop : null]} key={index} onPress={() => this.handleConfirm(item)}>
        <MBText size="md" numberOfLines={1} color={selectedItem?.value == item.value ? '#4885FF' : '#333333'}>
          {item.label}
        </MBText>
      </TouchableOpacity>
    );
  }

  render(): React.ReactNode {
    const { visible, list } = this.props;
    return (
      <Modal
        title="选择成交方式"
        position="bottom"
        visible={visible}
        headerLine={false}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        <View style={{ width: '100%' }}>
          {list.map((item: Item, index: number) => this.listItemElement(item, index))}
          <View style={{ backgroundColor: '#F7F7F7', width: '100%', height: 10 }}></View>
          <TouchableOpacity style={[styles.item, { width: '100%' }]} onPress={this.handleCancel.bind(this)}>
            <MBText size="md" numberOfLines={1}>
              取消
            </MBText>
          </TouchableOpacity>
          <Whitespace vertical={20} />
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  borderTop: {
    borderTopColor: '#EEEEEE',
    borderTopWidth: 1,
  },
  item: {
    height: RNElementsUtil.autoFix(96),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: RNElementsUtil.autoFix(30),
  },
  inputStyle: {
    flex: 1,
    textAlign: 'right',
    paddingRight: 0,
  },
});
