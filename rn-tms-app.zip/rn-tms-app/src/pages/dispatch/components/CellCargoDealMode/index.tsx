import React, { Component } from 'react';
import Cell from '~/components/common/Cell';
import { inject, observer } from 'mobx-react';
import NativeBridge from '~/extends/NativeBridge';
import CellCargoDealModal from './CellCargoDealModal';
// 选择调度员多选 cell
export interface Props {
  placeholder?: string;
  store?: any;
  readonly?: boolean; // 只读 文字置灰
  readonlyNotDusty?: boolean; // 只读 文字不置灰，
  required?: boolean; // 是否必选
  from: number;
  title: string;
}
export interface Item {
  label: string;
  value: string;
}

export interface State {
  showModal: boolean;
}
@inject('store')
@observer
export default class CellCargoDealMode extends Component<Props, State> {
  static defaultProps = {
    required: false, // 默认非必选
    readonly: false, // 默认非只读
    readonlyNotDusty: false, // 只读不置灰
    placeholder: '请选择',
    title: '成交方式',
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
    };
  }
  componentDidMount(): void {
    this.api_initData();
  }
  // 获取 开关默认值接口
  api_initData(): void {
    this.props.store?.cargoDealModeInit();
  }
  // 只读情况下点击回调
  toastNotEdit = (text: string): void => {
    const { showCellCargoDealMode } = this.props.store;
    if (!showCellCargoDealMode) {
      NativeBridge.toast(`不支持修改#${text}#`);
    }
  };
  openModal(val: boolean): void {
    this.setState({ showModal: val });
  }
  /** 单选结果 */
  changeSingleModal(item: Item | null): void {
    const { from } = this.props;
    this.openModal(false);
    if (item) {
      this.props.store.setFormData(from, { cargoDealMode: item.value });
    }
  }
  // 单选显示的文本
  get cargoDealModeText(): string {
    const { cargoDealMode } = this.props.store[`formData_${this.props.from}`];
    const { cargoDealModeList } = this.props.store;
    const text = cargoDealModeList.find((item: any) => item.value === cargoDealMode)?.label;
    return text || cargoDealMode;
  }
  render(): React.ReactNode {
    const { required, readonly, title, placeholder, readonlyNotDusty } = this.props;
    const { cargoDealMode } = this.props.store[`formData_${this.props.from}`];
    const { showCellCargoDealMode, cargoDealModeList } = this.props.store;
    const { showModal } = this.state;
    return (
      <>
        <Cell
          title={title}
          align="right"
          value={this.cargoDealModeText}
          placeholder={placeholder}
          numberOfLines={1}
          readonly={readonly ? true : !showCellCargoDealMode}
          onPress={() => this.openModal(true)}
          bottomLine={true}
          required={!!required}
          onReadOnlyPress={this.toastNotEdit.bind(this, title)}
        />
        {!readonlyNotDusty && (
          <CellCargoDealModal
            visible={showModal}
            onChange={(item) => this.changeSingleModal(item)}
            list={cargoDealModeList}
            selected={cargoDealMode}
          />
        )}
      </>
    );
  }
}
