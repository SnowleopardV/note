import React from 'react';
import { View, StyleSheet, ScrollView, Platform, BackHandler, SafeAreaView, Keyboard } from 'react-native';
import { Whitespace, MBText, Splitline, LayProvider, RNElementsUtil } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';

import NavBar from '~/components/common/NavBar';
import InputItem from '~/components/common/InputItem';
import verification from '~/extends/verification';
import filterFormat from '~/extends/filterFormat';
import NativeBridge from '~/extends/NativeBridge';

// 费用输入页（成本费用|应付费用）
export interface inputItem {
  feeCode: number; // 费用code
  feeCodeDesc: string; // 描述
  isDeductionFee: boolean; // 是否是扣减费用
  isRequired: boolean; // 是否必填
  amount: string | number; // 金额
  NoShow?: boolean; // 是否显示
}
export interface State {
  inputList: Array<inputItem>;
  verification: boolean;
  keyBoardHeight: number;
}
@inject('store')
@observer
export default class CostInputsPage extends React.Component<any, State> {
  backHandleListener: any;
  refInput: Array<any> = [];
  refScrollView: any;
  refScrollLayout: any; // 当前滚轮位置
  scrollViewHeight: number = 0; // 可滚动view 高度
  inputLayoutList: any = []; // 记录没有输入的布局位置
  keyBoardHeight = 360; // 获取键盘的高度
  keyboardDidShowListener: any;
  keyboardDidHideListener: any;
  constructor(props: any) {
    super(props);
    const { inputList } = this.props.navigation.state.params;
    this.state = {
      inputList: inputList.map((item: inputItem) => {
        return {
          ...item,
          amount: filterFormat.moneyDecFormat(item.amount),
        };
      }),
      verification: false, // 是否验证必选项 已必填了
      keyBoardHeight: 0,
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.goBack();
        return true;
      });
    } else {
      this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow.bind(this));
      this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide.bind(this));
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
    this.keyboardDidShowListener?.remove();
    this.keyboardDidHideListener?.remove();
  }
  _keyboardDidShow(e: any) {
    this.keyBoardHeight = e.endCoordinates.height;
    this.setState({ keyBoardHeight: this.keyBoardHeight });
  }
  _keyboardDidHide(e: any) {
    this.keyBoardHeight = e.endCoordinates.height;
    this.setState({ keyBoardHeight: 0 });
  }
  setRefInput(el: any, index: number) {
    this.refInput[index] = el;
  }
  // 下一步 光标到下一个输入框
  onSubmitEditing(index: number) {
    if (Platform.OS == 'ios') {
      this.refInput[index]?.blur();
    } else {
      this.refInput[index + 1]?.focus() || this.refInput[index]?.blur();
    }
  }

  changeText(text: string, item: inputItem) {
    // console.log('改变了', text);
    if (
      // 调整费用：37， 可正可负
      (item.feeCode != 37 && verification.price(text)) ||
      (item.feeCode == 37 && verification.negativePrice(text)) ||
      text === ''
    ) {
      item.amount = text;
      this.forceUpdate();
    }
  }
  onFocus(val: number) {
    // ios 下 键盘弹起会遮挡底部输入框，如果焦点到底部输入框，通过计算进行页面滚动
    if (Platform.OS == 'ios') {
      const y = this.inputLayoutList[val]?.y;
      const scrollY = this.refScrollLayout?.contentOffset?.y || 0;
      const keyBoardHeight = this.keyBoardHeight || 360; // 键盘高度
      const viewHeight = this.scrollViewHeight - keyBoardHeight - this.inputLayoutList[val].height - 20;
      const isScroll = y > scrollY + viewHeight;
      // console.log(viewHeight, y, isScroll, y + viewHeight);
      if (isScroll) {
        this.refScrollView.scrollTo({ y: y - viewHeight });
      }
    }
  }
  goBack() {
    this.props.navigation?.goBack();
  }
  onSubmit() {
    console.log('确定');
    const { from } = this.props.navigation.state.params;
    const { inputList } = this.state;
    const varData = inputList.filter((item: any) => item.isRequired && !item.amount);
    if (varData && varData.length) {
      this.setState({ verification: true }); // 开启验证
      NativeBridge.toast(`${varData[0].feeCodeDesc}未填`);
      const index = varData[0]?.sort || 0;
      this.refInput[index]?.focus()
      return;
    }
    const data = {
      feeDetails: inputList.map((item: any) => {
        item.amount = filterFormat.moneyFormat(item.amount);
        return item;
      }),
    };
    this.props.store.setFormData(from, data);
    this.props.store.getTax(from); // 计算税金
    this.goBack();
  }

  render() {
    const { title } = this.props.navigation.state.params;
    const { inputList, verification, keyBoardHeight } = this.state;
    return (
      <LayProvider theme="skyblue" style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <NavBar
          title={title}
          leftClick={() => this.props.navigation?.goBack()}
          rightElement={
            <MBText color="primary" size="md" onPress={() => this.onSubmit()}>
              确定
            </MBText>
          }
        />
        <SafeAreaView style={{ flex: 1 }}>
          <ScrollView
            style={{ flex: 1 }}
            ref={(el) => (this.refScrollView = el)}
            onScroll={(event) => (this.refScrollLayout = event.nativeEvent)}
            scrollEventThrottle={200}
            onLayout={(el) => (this.scrollViewHeight = el.nativeEvent.layout.height)}
          >
            <Whitespace vertical={10} />
            {inputList
              .filter((item: any) => !item.NoShow)
              .map((item: any, index: number) => {
                return (
                  <View
                    key={item.feeCode}
                    style={{ flex: 1, paddingHorizontal: 20, backgroundColor: '#FFFFFF' }}
                    onLayout={(el) => (this.inputLayoutList[index] = el.nativeEvent.layout)}
                  >
                    <InputItem
                      ref={(el) => this.setRefInput(el, index)}
                      title={item.feeCodeDesc}
                      required={item.isRequired}
                      value={item.amount}
                      onSubmitEditing={() => this.onSubmitEditing(index)}
                      style={styles.item}
                      inputStyle={styles.inputStyle}
                      styleItem={{ paddingRight: 0 }}
                      extraNode={
                        <MBText bold style={{ marginLeft: 10 }}>
                          元
                        </MBText>
                      }
                      onChangeText={(text: string) => this.changeText(text, item)}
                      blurOnSubmit={false}
                      returnKeyType={Platform.OS == 'ios' ? 'done' : 'next'}
                      placeholder="请输入"
                      keyboardType="numeric"
                      extra={
                        verification &&
                        item.isRequired &&
                        !item.amount && (
                          <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                            <MBText size="xs" color="#F54242" align="right">
                              {item.feeCodeDesc}未填
                            </MBText>
                            <Whitespace vertical={12} />
                          </View>
                        )
                      }
                      onFocus={() => this.onFocus(index)}
                    />
                    <Splitline color="#f6f6f6" />
                  </View>
                );
              })}
            <Whitespace vertical={keyBoardHeight + 200} />
          </ScrollView>
        </SafeAreaView>
      </LayProvider>
    );
  }
}

const styles = StyleSheet.create({
  item: {
    flex: 1,
    paddingLeft: 0,
  },
  inputStyle: {
    flex: 1,
    textAlign: 'right',
    paddingRight: 0,
  },
});
