import React, { PureComponent } from 'react';
import { View } from 'react-native';
import Cell from '~/components/common/Cell';
import { inject, observer } from 'mobx-react';
import filterFormat from '~/extends/filterFormat';
import api from '../../api';
import { MBText, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
// 表单显示用
export interface Props {
  placeholder?: string;
  store?: any;
  readonly?: boolean; // 只读 文字置灰
  from: number;
  navigation: any;
  title: string;
  /**
   *页面id	页面名称	页面编号
      1	运单开单页	trans_order_create
      2	任务自有车调度页	mainline_self_dispatch
      3	任务承运商调度页	mainline_outTrans_dispatch
      4	任务外调车不开票调度页	mainline_mybAssignOffline_noInvoice_dispatch
      5	任务外调车满帮专票调度页	mainline_mybAssignOffline_invoice_dispatch
      6	任务自有车详情页	mainline_self_detail
      7	任务承运商详情页	mainline_outTrans_detail
      8	任务外调车不开票详情页	mainline_mybAssignOffline_noInvoice_detail
      9	任务外调车满帮专票详情页	mainline_mybAssignOffline_invoice_detail
      10	任务满帮车不开票详情页	mainline_mybFindTruck_noInvoice_detail
   *
   */
  pageCode: string; // 页面编码
  isRulesTips?: boolean; // 是否进行验证提示
  $parent?: any; // 父级对象
}

@inject('store')
@observer
export default class CellCostInput extends PureComponent<Props, any> {
  static defaultProps = {
    readonly: false,
  };
  $parent: any;
  constructor(props: any) {
    super(props);
    this.$parent = this.props.$parent;
    this.state = {
      inputList: [
        // {
        //   feeCode: 1, // 费用code
        //   feeDesc: '描述', // 描述
        //   isDeductionFee: true, // 是否是扣减费用
        //   isRequired: true, // 是否必填
        //   amount: '', // 金额
        // },
      ],
      requireData: null, // 请求的服务端配置项，费用项
    };
  }
  componentDidMount() {
    this.api_getFeeInputBoxes(false);
  }
  /** 获取用户自定义费用内容 */
  api_getFeeInputBoxes(isGo: boolean = false) {
    const { from, pageCode, store } = this.props;
    const { feeDetails } = store[`formData_${from}`];
    this.props.store.setShowCellCostInput(false); // 清空之前的是否开票显藏状态
    api
      .getFeeInputBoxes({ code: pageCode })
      .then((res: any) => {
        console.log('===============获取用户自定义费用内容=================');
        console.log(res?.data);
        this.setState({ requireData: res.data });
        const data = {}; // 远程配置项 需要和详情里的费用项进行合并，配置项没有的标记不显示
        res?.data.map((item: any, index: number) => {
          item.sort = index;
          switch (item.fieldName) {
            case 'carrierInvoiceFlag': // 是否开票
              this.props.store.setShowCellCostInput({ carrierInvoiceFlag: item });
              break;
            case 'taxType': // 计税方式
              this.props.store.setShowCellCostInput({ taxType: item });
              break;
            case 'taxRate': // 税率
              this.props.store.setShowCellCostInput({ taxRate: item });
              break;
            case 'feeTax': // 税费
              this.props.store.setShowCellCostInput({ feeTax: item });
              break;
            default:
              data[item.feeCode] = item;
              break;
          }
        });
        feeDetails.map((item: any) => {
          data[item.feeCode] = {
            ...data[item.feeCode],
            ...item,
            NoShow: !data[item.feeCode], // 如果配置项里没有就标记就不显示
          };
        });
        const inputList = Object.values(data).sort((a: any, b: any) => a.sort - b.sort);
        this.props.store.setFormData(from, { feeDetails: inputList });
        isGo && this.goCostInputPage(false);
      })
      .catch((err: any) => {
        console.log('获取用户自定义费用内容', err);
      });
  }
  /** 跳转到成本费用页面 */
  goCostInputPage = (isGo: boolean = false) => {
    console.log('-----------------跳转到成本费用页面--------------------');
    const { navigation, title, from, store } = this.props;
    const { requireData } = this.state;
    const feeDetails = store[`formData_${from}`].feeDetails;
    if (requireData && requireData?.length) {
      // 如果没有获取到配置费用项，就不进入下一页
      navigation.navigate('CostInputsPage', {
        title: title,
        from: from,
        inputList: feeDetails,
      });
    } else if (isGo) {
      this.api_getFeeInputBoxes(isGo);
    }
  };
  // 只读情况下点击回调
  toastNotEdit = (text: string) => {
    NativeBridge.toast(`不支持修改#${text}#`);
  };
  render() {
    const { readonly, title, store, from, isRulesTips } = this.props;
    const feeDetails = store[`formData_${from}`].feeDetails;
    const ChargesText = feeDetails
      .filter((item: any) => item.amount && !item.NoShow)
      .map((item: any) => {
        return item.feeCodeDesc + '¥' + filterFormat.moneyDecFormat(item.amount);
      })
      .join('；');
    const feeDetailsTip = feeDetails.find((item: any) => item.isRequired && !item.amount);
    const required = feeDetails.find((item: any) => item.isRequired); // 只要有一个子费用字段设置为必填，则总费用字段显示为必填
    return (
      <Cell
        title={title}
        align="right"
        value={ChargesText}
        placeholder="请输入"
        numberOfLines={1}
        readonly={readonly}
        onPress={() => this.goCostInputPage(true)}
        bottomLine={true}
        required={!!required}
        onReadOnlyPress={this.toastNotEdit.bind(this, title)}
        extra={
          isRulesTips &&
          feeDetailsTip && (
            <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
              <MBText size="xs" color="#F54242" align="right">
                {feeDetailsTip.feeCodeDesc}未填
              </MBText>
              <Whitespace vertical={12} />
            </View>
          )
        }
      />
    );
  }
}
