import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Modal, Splitline, Whitespace, Flex, MBText } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import verification from '~/extends/verification';
import NativeBridge from '~/extends/NativeBridge';
import xyMath from '~/extends/xyMath';

import images from '../../../../public/static/images';
import SelectOilCardModal from './ModalOilCardSelect';

// 关联油卡 模态框
const styles = StyleSheet.create({
  from: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  item: {
    flex: 1,
    paddingLeft: 0,
    paddingRight: 0,
  },
  flexRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  icon: {
    width: 15,
    height: 15,
  },
  line: {
    width: '100%',
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
  formData?: any;
}

export default class ModalOilCardAssociated extends React.Component<Props, any> {
  refInput: React.RefObject<any>;
  constructor(props: any) {
    super(props);
    this.refInput = React.createRef();
    this.state = {
      showOilCard: false, // 显示油卡选择弹窗
      recieveDeposit: null, // 油卡押金
      oilCardId: null, // 油卡号
      amount: 0, // 金额，单位分
      status: null, // 状态 1：未分配 2：已分配 3：停用
    };
  }
  componentWillReceiveProps(nextProps: any) {
    const { visible, formData } = nextProps;
    if (visible) {
      setTimeout(() => {
        this.refInput.current?.focus();
      }, 300);
      this.setState({
        recieveDeposit: formData.recieveDeposit,
        oilCardId: formData.oilCardId,
      });
    }
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { recieveDeposit } = this.state;
    if (recieveDeposit > 1000) {
      NativeBridge.toast('押金范围0-1000元');
    } else {
      onChange && onChange(this.state);
    }
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  changeGasMoney = (val: any) => {
    if (verification.price(val) || val === '') {
      this.setState({ recieveDeposit: val });
    }
  };
  // 点击了油卡号
  handleOilCard() {
    this.setState({ showOilCard: true });
  }
  // 油卡选择弹窗返回值
  handleOilCardChange = (val: any) => {
    console.log(val);
    this.setState({ showOilCard: false });
    if (val) {
      this.setState({
        oilCardId: val.number, // 油卡号
        amount: val.amount, // 金额，单位分
        status: val.status, // 状态 1：未分配 2：已分配 3：停用
      });
    }
  };
  oilCardNoElement = () => {
    const { oilCardId, amount } = this.state;
    const balance = xyMath.accDiv(amount, 100);
    if (oilCardId) {
      return (
        <View style={{ flex: 1, paddingLeft: 20, flexDirection: 'row', alignItems: 'center' }}>
          <MBText size="xs" color="#666666">
            {oilCardId}
          </MBText>
          <View style={{ marginLeft: 20, flexDirection: 'row', alignItems: 'center' }}>
            <MBText size="xs" color="#666666">
              余额(元)
            </MBText>
            <MBText color="#FD4444" size="sm" bold style={{ marginLeft: 5 }}>
              {balance}
            </MBText>
          </View>
        </View>
      );
    } else {
      return (
        <View style={{ flex: 1, paddingLeft: 29, flexDirection: 'row', alignItems: 'center' }}>
          <MBText color="#CCCCCC">请选择</MBText>
        </View>
      );
    }
  };
  rightElement() {
    const { oilCardId } = this.state;
    return (
      <TouchableOpacity
        onPress={() => {
          !!oilCardId && this.handleConfirm();
        }}
      >
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color={!oilCardId ? 'disabled' : 'primary'} size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { showOilCard, recieveDeposit } = this.state;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="关联油卡"
          position="bottom"
          visible={visible && !showOilCard}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          autoAdjustPosition={true}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row">
            <View style={[styles.item, styles.flexRow, { paddingHorizontal: 15, height: 43 }]}>
              <MBText>油卡号</MBText>
              <MBText color="#FD4444">*</MBText>
              <TouchableOpacity onPress={this.handleOilCard.bind(this)} style={{ flex: 1, marginLeft: 5 }}>
                {this.oilCardNoElement()}
              </TouchableOpacity>
              <Image style={styles.icon} source={{ uri: images.icon_arrow_gray }} />
            </View>
          </Flex>
          <Splitline style={styles.line} color="#D9D9D9" />
          <Flex direction="row">
            <InputItem
              ref={this.refInput}
              style={styles.item}
              value={recieveDeposit}
              inputStyle={{ marginLeft: 20 }}
              title="油卡押金"
              onChangeText={this.changeGasMoney}
              placeholder="押金范围0-1000元"
              keyboardType="numeric"
            />
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
        <SelectOilCardModal visible={showOilCard} onChange={this.handleOilCardChange} />
      </View>
    );
  }
}
