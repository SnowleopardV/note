import * as React from 'react';
import { View, StyleSheet, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Modal, Whitespace, TagGroup, Tag, MBText, Flex } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import keyMap from '../keyMap';

const FlexItem = Flex.Item;
const { height } = Dimensions.get('window');
// 选择车型和车长 模态框
const styles = StyleSheet.create({
  from: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  modalheight: {
    maxHeight: Number((height * 0.9).toFixed(0)),
  },
});

interface FollowCarProps {
  visible?: boolean;
  onChange?: any;
  item?: any;
  multiple?: boolean;
  carTypeLengthData?: any;
}

export default class ModalCarTypeLength extends React.Component<FollowCarProps, any> {
  static defaultProps = {
    multiple: false,
  };
  constructor(props: FollowCarProps) {
    super(props);
    const listData = props.carTypeLengthData || keyMap;
    const carTypeList = Object.keys(listData.carTypePlate).map((key: string) => {
      return { id: key, name: listData.carTypePlate[key] };
    });
    const carLengthList = Object.keys(listData.carLengthPlate).map((key: string) => {
      return { id: key, name: listData.carLengthPlate[key].toString() };
    });
    this.state = {
      carTypeList: carTypeList,
      carLengthList: carLengthList,
      carLengthSelected: this.props?.item?.platformCarLength || [],
      carTypeSelected: this.props?.item?.platformCarType || [],
    };
  }

  UNSAFE_componentWillReceiveProps(nextProps: any, prevProps: any) {
    const { item } = nextProps;
    if (item?.platformCarType) {
      this.setState({ carLengthSelected: item.platformCarLength });
    }
    if (item?.platformCarType) {
      this.setState({ carTypeSelected: item.platformCarType });
    }
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { carTypeList, carLengthList, carLengthSelected, carTypeSelected } = this.state;
    if (carLengthSelected.length && carTypeSelected.length) {
      onChange &&
        onChange({
          carLength: carLengthList.filter((item: any) => carLengthSelected.includes(item.id)),
          carType: carTypeList.filter((item: any) => carTypeSelected.includes(item.id)),
        });
    }
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  // 改变车长选择
  onLengthClick = (val: any) => {
    const { multiple } = this.props;
    let { carLengthSelected } = this.state;
    if (multiple) {
      // 多选
      if (carLengthSelected.includes(val.id)) {
        carLengthSelected = carLengthSelected.filter((id: number) => id !== val.id);
      } else if (carLengthSelected.length < 3) {
        carLengthSelected.push(val.id);
      } else {
        NativeBridge.toast(`最多选择3种车长`);
      }
    } else {
      // 单选
      if (carLengthSelected.includes(val.id)) {
        carLengthSelected = carLengthSelected.filter((id: number) => id !== val.id);
      } else {
        carLengthSelected = [val.id];
      }
    }
    this.setState({ carLengthSelected: carLengthSelected });
  };
  // 改变车型选择
  onTypeClick = (val: any) => {
    const { multiple } = this.props;
    let { carTypeSelected } = this.state;

    if (multiple) {
      // 多选
      if (carTypeSelected.includes(val.id)) {
        carTypeSelected = carTypeSelected.filter((id: number) => id !== val.id);
      } else if (carTypeSelected.length < 3) {
        carTypeSelected.push(val.id);
      } else {
        return NativeBridge.toast(`最多选择3种车型`);
      }
    } else {
      // 单选
      if (carTypeSelected.includes(val.id)) {
        carTypeSelected = carTypeSelected.filter((id: number) => id !== val.id);
      } else {
        carTypeSelected = [val.id];
      }
    }
    this.setState({ carTypeSelected: carTypeSelected });
  };
  rightElement() {
    const { carLengthSelected, carTypeSelected } = this.state;
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText size="md" color={carLengthSelected.length && carTypeSelected.length ? 'primary' : 'disabled'}>
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible, multiple } = this.props;
    const { carTypeList, carLengthList, carLengthSelected, carTypeSelected } = this.state;

    return (
      <Modal
        headerLeft="取消"
        headerLine={false}
        headerRight={this.rightElement()}
        title="请选择车长/车型"
        position="bottom"
        visible={visible}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        <ScrollView style={styles.modalheight}>
          <Flex direction="row" justify="space-between" align="center">
            <FlexItem style={styles.flexRow}>
              <MBText>车长</MBText>
              <MBText color="#FD4444">*</MBText>
              {multiple ? <MBText color="#999999">（必选，最多3项）</MBText> : null}
            </FlexItem>
          </Flex>
          <Flex direction="row" justify="space-between" align="center">
            <TagGroup
              defaultSelected={carLengthSelected}
              rowId="id"
              space={12}
              rowSize={4}
              multiple={multiple}
              maxNumber={3}
              onPress={this.onLengthClick}
            >
              {carLengthList.map((item: any) => {
                return (
                  <Tag key={item.id} item={item}>
                    {item.name}
                  </Tag>
                );
              })}
            </TagGroup>
          </Flex>
          <Whitespace vertical={20} />
          <Flex direction="row" justify="space-between" align="center">
            <FlexItem style={styles.flexRow}>
              <MBText>车型</MBText>
              <MBText color="#FD4444">*</MBText>
              {multiple ? <MBText color="#999999">（必选，最多3项）</MBText> : null}
            </FlexItem>
          </Flex>
          <Flex direction="row" justify="space-between" align="center">
            <TagGroup
              defaultSelected={carTypeSelected}
              rowId="id"
              space={12}
              rowSize={4}
              multiple={multiple}
              maxNumber={3}
              onPress={this.onTypeClick}
            >
              {carTypeList.map((item: any) => {
                return (
                  <Tag key={item.id} item={item}>
                    {item.name}
                  </Tag>
                );
              })}
            </TagGroup>
          </Flex>
          <Whitespace vertical={50} />
        </ScrollView>
      </Modal>
    );
  }
}
