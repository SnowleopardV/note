import * as React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, MBText } from '@ymm/rn-elements';
import NativeBridge from '../../../extends/NativeBridge';
import API from '../api';

// 选择油卡号 模态框

interface Props {
  visible?: boolean;
  onChange?: any;
}

export default class SelectOilCardModal extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      item: {},
      id: 0,
      list: [],
    };
  }
  componentDidMount() {
    this.api_queryOilCardList();
  }
  //油卡列表
  api_queryOilCardList() {
    API.queryOilCardList().then((res) => {
      console.log('油卡列表:', res);
      if (res.data && res.data.success) {
        res = res.data;
      }
      if (res.success && res.data) {
        const list = res.data ? res.data : [];
        const statusMap: any = { 1: '未分配', 2: '已分配', 3: '停用' };
        this.setState({
          item: list[0],
          list: list.map((item: any, index: number) => {
            return {
              ...item,
              id: index,
              content(selected: boolean) {
                return (
                  <Flex direction="row" justify="center" align="center">
                    <MBText bold={selected} color={selected ? (item.status === 1 ? 'primary' : '#CCCCCC') : 'base'} numberOfLines={1}>
                      {item.number} {statusMap[item.status]}
                    </MBText>
                  </Flex>
                );
              },
            };
          }),
        });
      }
    });
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { item } = this.state;
    if (item.status === 1) {
      onChange && onChange(item);
    } else if (item.status === 2) {
      NativeBridge.toast('已分配，可到油卡管理操作后分配');
    } else if (item.status === 3) {
      NativeBridge.toast('已停用');
    }
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleChange = (position: number, item: any) => {
    this.setState({
      item: item,
      id: item.id,
    });
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { id, list } = this.state;
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请选择油卡号"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          {list.length ? (
            <Flex direction="row" justify="center" align="center">
              <Flex.Item key="time">
                <View style={{ flexDirection: 'column' }}>
                  <Selector type={2} value={id} rowTitle="content" list={list} scaleFont={true} onChange={this.handleChange} />
                </View>
              </Flex.Item>
            </Flex>
          ) : (
            <MBText style={{ marginVertical: 50 }} color="#999999">
              无匹配油卡
            </MBText>
          )}
        </Modal>
      </View>
    );
  }
}
