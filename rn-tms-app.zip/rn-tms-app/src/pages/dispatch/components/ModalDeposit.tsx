import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Modal, Whitespace, Flex, TagGroup, Tag, MBText } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import { inject, observer } from 'mobx-react';
import verification from '~/extends/verification';
import NativeBridge from '~/extends/NativeBridge';
import filterFormat from '~/extends/filterFormat';
import xyMath from '~/extends/xyMath';

const FlexItem = Flex.Item;
// 输入订金 模态框
const styles = StyleSheet.create({
  from: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  item: {
    flex: 1,
    marginTop: 10,
    paddingLeft: 0,
  },
});

interface depositProps {
  visible?: boolean;
  onChange?: any;
  store?: any;
  from: number; // 1指派自有车 2 指派承运商 3 指派外调车 4 满帮找车
}
@inject('store')
@observer
export default class ModalDeposit extends React.Component<depositProps, any> {
  refInput: React.RefObject<any>;
  constructor(props: depositProps) {
    super(props);
    this.refInput = React.createRef();
    this.state = {
      item: null, //
      defaultSelected: [],
      deposit: '', // 订金
      list: [
        { id: 1, name: '退还' },
        { id: 0, name: '不退还' },
      ],
    };
  }
  componentWillReceiveProps(nextProps: any) {
    const { deposit, refundDeposit } = nextProps.store['formData_' + nextProps.from];
    if (nextProps.visible) {
      this.setState({
        deposit: filterFormat.moneyDecFormat(deposit), // 订金
        defaultSelected: refundDeposit || refundDeposit == 0 ? [refundDeposit] : [],
        item: refundDeposit || refundDeposit == 0 ? { id: refundDeposit } : null,
      });
    }
  }

  handleConfirm = () => {
    const { onChange, from } = this.props;
    const { item, deposit } = this.state;
    const {
      deliveryFee,
      deliveryUnit,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
    } = this.props.store['formData_' + from];
    console.log('订金 ', deliveryFee);
    let serviceFeeTotal = 0;
    if (deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin,platformTotalWeight)
      serviceFeeTotal = xyMath.accMul(deliveryFee, weight); // 运费
    } else if (deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin,platformTotalVolume)
      serviceFeeTotal = xyMath.accMul(deliveryFee, volume); // 运费
    } else {
      // 趟
      serviceFeeTotal = deliveryFee; // 运费
    }
    serviceFeeTotal = Number(filterFormat.moneyDecFormat(serviceFeeTotal));
    if (!item) {
      NativeBridge.toast('请填写退还方式');
    } else if (deposit < 50) {
      NativeBridge.toast('订金不得低于50元');
    } else if (deposit > 1000) {
      NativeBridge.toast('订金不得高于1000元');
    } else if (deliveryFee && serviceFeeTotal <= deposit) {
      NativeBridge.toast('定金不得高于或等于运费');
    } else {
      onChange && onChange(this.state);
    }
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  // 改变选择
  handleChange = (val: any) => {
    console.log(val);
    this.setState({ item: val, defaultSelected: [val.id] });
  };
  inputDeposit = (val: any) => {
    if (verification.number(val) || val === '') {
      this.setState({ deposit: val });
    }
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { list, defaultSelected, deposit, item } = this.state;
    if (visible) {
      setTimeout(() => {
        this.refInput.current?.focus();
      }, 250);
    }
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerLine={false}
          headerRight={this.rightElement()}
          title="请输入订金"
          position="bottom"
          autoAdjustPosition={true}
          visible={visible}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row" justify="space-between" align="center">
            <InputItem
              ref={this.refInput}
              title="司机订金（元）"
              value={deposit}
              style={styles.item}
              inputStyle={{ marginLeft: 10 }}
              onChangeText={this.inputDeposit}
              placeholder="请输入"
              keyboardType="numeric"
            />
            <TagGroup
              defaultSelected={defaultSelected}
              style={{ width: 130, marginRight: 0, marginTop: 10 }}
              fixedWidth={false}
              rowId="id"
              space={0}
              rowSize={2}
              autoCollapse
              onPress={this.handleChange}
            >
              {list.map((item: any) => {
                return (
                  <Tag key={item.id} item={item} style={{ width: 60, marginLeft: !item.id ? 10 : 0 }} size="sm">
                    {item.name}
                  </Tag>
                );
              })}
            </TagGroup>
          </Flex>
          {/* <Splitline color="#D9D9D9" /> */}
          <Flex direction="row">
            <View style={{ flex: 1 }}>
              <MBText size="xs" color="primary">
                {item?.id === 0 && '司机支付订金到平台用于订货信息费，司机装货后，支付给您'}
                {item?.id === 1 && '司机支付订金到平台用于订货押金，您收货后，退还给司机'}
              </MBText>
            </View>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
