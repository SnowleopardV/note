import * as React from 'react';
import { View, StyleSheet, ActivityIndicator } from 'react-native';

export interface Props {
  size?: number | 'small' | 'large' | undefined;
}
export default class LoadingView extends React.Component<Props> {
  static defaultProps = {
    size: 'large',
  };
  constructor(props: Props) {
    super(props);
  }

  render() {
    const { size } = this.props;
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size={size} color="#4885ff" />
      </View>
    );
  }
}

const styles = StyleSheet.create({});
