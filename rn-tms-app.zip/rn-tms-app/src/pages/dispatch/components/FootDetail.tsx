import React from 'react';
import PropTypes from 'prop-types';
import { Dimensions, ScrollView, StyleSheet, View } from 'react-native';
import { MBText } from '@ymm/rn-elements';
const { height } = Dimensions.get('window');
export interface infoListModel {
  text: string;
  num: number;
}

// 底部明细
const footDetail = ({ infoList = [] }: any): JSX.Element => (
  <ScrollView style={{ maxHeight: height * 0.7 }}>
    {infoList.map((item: infoListModel) => {
      return (
        <View style={styles.detailItem} key={item.text}>
          <MBText>{item.text}（元）</MBText>
          <MBText>{item.num}</MBText>
        </View>
      );
    })}
  </ScrollView>
);

footDetail.propTypes = {
  infoList: PropTypes.arrayOf(
    PropTypes.shape({
      text: PropTypes.string.isRequired,
      num: PropTypes.number.isRequired,
    }).isRequired
  ).isRequired,
};

export default footDetail;

const styles = StyleSheet.create({
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 40,
    paddingHorizontal: 20,
  },
});
