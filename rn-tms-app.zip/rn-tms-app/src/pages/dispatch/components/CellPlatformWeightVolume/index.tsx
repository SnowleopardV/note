import React, { PureComponent } from 'react';
import { Keyboard, Platform, StyleSheet, View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText, RNElementsUtil, Splitline, Whitespace } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import InputItem from '~/components/common/InputItem';
import verification from '~/extends/verification';
import API from '~/pages/dispatch/api';
import commonData from '~/pages/commonData';
/** 满帮货物重量/体积 */
export interface Props {
  store?: any;
  readonly?: boolean; // 只读 文字置灰
  from: number;
  title?: string;
  isRulesTips?: boolean; // 是否进行验证提示
  WeightVolumeLayout: any; // 当前组件在页面上的位置
}

@inject('store')
@observer
export default class CellPlatformWeightVolume extends PureComponent<Props, any> {
  static defaultProps = {
    readonly: false,
  };
  backHandleListener: any;
  keyboardDidShowListener: any;
  keyboardDidHideListener: any;
  keyBoardHeight: number = 0;
  cellHeight: number = 0;
  refInpunt: any[] = [];
  constructor(props: any) {
    super(props);
    this.state = {
      onFocusIndex: 0, // 当前有聚焦的输入框
      platformWeightMaxLimit: 0, // 不开票平台货物重量最大值
      mybPlatformWeightMaxLimit: 0, // 企满开专票平台货物重量最大值
      platformVolumeMaxLimit: 0, // 不开票平台货物体积最大值
      mybPlatformVolumeMaxLimit: 0, // 企满开专票平台货物体积最大值
      generalInvoicePlatformWeightMaxLimit: 0, // 普票-平台货物重量最大值
      generalInvoicePlatformVolumeMaxLimit: 0, // 普票-平台货物体积最大值
      platformWeightIntervalLimit: 0, // 重量区间限制，适用所有场景
      platformVolumeIntervalLimit: 0, // 体积区间限制，适用所有场景
      showTipsTextWeight: true, // 重量是否显示错误范围提示
      showTipsTextVolume: true, // 体积是否显示错误范围提示
    };
  }
  componentWillMount() {
    this.api_cargoIntervalConfig();
    if (Platform.OS === 'ios') {
      // 监听键盘弹起，并得到键盘高度
      this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow.bind(this));
    }
  }
  componentWillUnmount(): void {
    this.keyboardDidShowListener?.remove();
  }
  _keyboardDidShow(e: any) {
    this.keyBoardHeight = e.endCoordinates.height;
  }
  api_cargoIntervalConfig() {
    if (Object.keys(commonData.cargoIntervalConfig).length) {
      this.setState(commonData.cargoIntervalConfig);
    } else {
      API.cargoIntervalConfig()
        .then((res: any) => {
          console.log('区间配置', res);
          if (res.data) {
            commonData.cargoIntervalConfig = res.data;
            this.setState(res.data);
          }
        })
        .catch((err: any) => {
          console.log('区间配置', err);
        });
    }
  }
  changeText(val: string, index: number, type: string = 'max'): void {
    const { from, store } = this.props;
    const formData = store[`formData_${from}`];
    const { invoiceFlag, platformTotalWeight, platformTotalWeightMin, platformTotalVolume, platformTotalVolumeMin } = formData;
    const { mybPlatformWeightMaxLimit, generalInvoicePlatformWeightMaxLimit, mybPlatformVolumeMaxLimit, generalInvoicePlatformVolumeMaxLimit, platformWeightMaxLimit, platformVolumeMaxLimit } = this.state;
    if (verification.price(val) || val === '') {
      switch (index) {
        case 1:
          if (invoiceFlag == 1 || invoiceFlag == 2) {
            let weightLimit = mybPlatformWeightMaxLimit;
            if (invoiceFlag == 2) {
              weightLimit = generalInvoicePlatformWeightMaxLimit;
            }
            if (!weightLimit || val <= weightLimit) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalWeight: val } : { platformTotalWeightMin: val });
            } else if (
              (type === 'max' && platformTotalWeight > weightLimit) ||
              (type === 'min' && platformTotalWeightMin > weightLimit)
            ) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalWeight: val } : { platformTotalWeightMin: val });
            }
          } else {
            if (!platformWeightMaxLimit || val <= platformWeightMaxLimit) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalWeight: val } : { platformTotalWeightMin: val });
            } else if (
              (type === 'max' && platformTotalWeight > platformWeightMaxLimit) ||
              (type === 'min' && platformTotalWeightMin > platformWeightMaxLimit)
            ) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalWeight: val } : { platformTotalWeightMin: val });
            }
          }
          break;
        case 2:
          if (invoiceFlag == 1 || invoiceFlag == 2) {
            let volumeLimit = mybPlatformVolumeMaxLimit;
            if (invoiceFlag == 2) {
              volumeLimit = generalInvoicePlatformVolumeMaxLimit;
            }
            if (!volumeLimit || val <= volumeLimit) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalVolume: val } : { platformTotalVolumeMin: val });
            } else if (
              (type === 'max' && platformTotalVolume > volumeLimit) ||
              (type === 'min' && platformTotalVolumeMin > volumeLimit)
            ) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalVolume: val } : { platformTotalVolumeMin: val });
            }
          } else {
            if (!platformVolumeMaxLimit || val <= platformVolumeMaxLimit) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalVolume: val } : { platformTotalVolumeMin: val });
            } else if (
              (type === 'max' && platformTotalVolume > platformVolumeMaxLimit) ||
              (type === 'min' && platformTotalVolumeMin > platformVolumeMaxLimit)
            ) {
              this.props.store.setFormData(from, type === 'max' ? { platformTotalVolume: val } : { platformTotalVolumeMin: val });
            }
          }
          break;
        default:
          break;
      }
    }
  }
  // 只读情况下点击回调
  toastNotEdit = (text: string | undefined) => {
    text && NativeBridge.toast(`不支持修改#${text}#`);
  };
  onBlur(val: number) {
    this.setState({ onFocusIndex: 0, showTipsTextWeight: true, showTipsTextVolume: true });
    this.props.store.setShowFooterBtn(true);
    const { store, from } = this.props;
    const formData = store[`formData_${from}`];
    let { platformTotalWeightMin, platformTotalVolumeMin, platformTotalWeight, platformTotalVolume } = formData;
    platformTotalWeight = Number(platformTotalWeight)?.toString();
    platformTotalVolume = Number(platformTotalVolume)?.toString();
    platformTotalWeightMin = Number(platformTotalWeightMin)?.toString();
    platformTotalVolumeMin = Number(platformTotalVolumeMin)?.toString();
    if (platformTotalWeight === '0') {
      this.props.store.setFormData(from, { platformTotalWeight: '' });
    }
    if (platformTotalVolume === '0') {
      this.props.store.setFormData(from, { platformTotalVolume: '' });
    }
    this.props.store.setFormData(from, {
      platformTotalWeight: platformTotalWeight === '0' ? '' : platformTotalWeight,
      platformTotalVolume: platformTotalVolume === '0' ? '' : platformTotalVolume,
      platformTotalWeightMin: platformTotalWeightMin === '0' ? '' : platformTotalWeightMin,
      platformTotalVolumeMin: platformTotalVolumeMin === '0' ? '' : platformTotalVolumeMin,
    });
    if (formData.invoiceFlag == 1 || formData.invoiceFlag == 2) {
      this.props.store.api_serviceFee(from); // 重新计算服务费
    }
  }
  onFocus(val: number) {
    this.setState({ onFocusIndex: val });
    if (val === 1) {
      this.setState({ showTipsTextWeight: false });
    } else if (val === 2) {
      this.setState({ showTipsTextVolume: false });
    }
    this.props.store.setShowFooterBtn(false);
    if (Platform.OS == 'ios') {
      // 滚动页面防止被键盘挡住输入框
      const { WeightVolumeLayout } = this.props;
      const { onPagesScrollLayout, refPageScrollView, pageScrollHeight } = this.props.store;
      const y = WeightVolumeLayout?.y + (val + 2) * this.cellHeight;
      const scrollY = onPagesScrollLayout?.contentOffset?.y || 0;
      const keyBoardHeight = this.keyBoardHeight || 360; // 键盘高度
      const viewHeight = pageScrollHeight - keyBoardHeight;
      const isScroll = y > scrollY + viewHeight;
      // console.log(viewHeight, y, isScroll, y + viewHeight);
      if (isScroll) {
        refPageScrollView.scrollTo({ y: y - viewHeight });
      }
    }
  }
  setLayout(val: any) {
    const {
      nativeEvent: { layout },
    } = val;
    this.cellHeight = layout.height / 2;
  }
  extraElement(text: string): React.ReactNode {
    return (
      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {text}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }
  rigthElement(val: number) {
    const { readonly } = this.props;
    const unit = { 1: '吨', 2: '方' };
    return (
      <MBText onPress={() => this.refInpunt[val]?.focus()} style={{ color: readonly ? '#CCC' : '#333' }}>
        {unit[val]}
      </MBText>
    );
  }
  get placeholderWeight() {
    const { store, from } = this.props;
    const formData = store[`formData_${from}`];
    const { invoiceFlag } = formData;
    if (invoiceFlag == 1) {
      return this.state.mybPlatformWeightMaxLimit ? `0 - ${this.state.mybPlatformWeightMaxLimit}` : '请输入';
    } else if (invoiceFlag == 2) {
      return this.state.generalInvoicePlatformWeightMaxLimit ? `0 - ${this.state.generalInvoicePlatformWeightMaxLimit}` : '请输入';
    } else {
      return this.state.platformWeightMaxLimit ? `0 - ${this.state.platformWeightMaxLimit}` : '请输入';
    }
  }
  get placeholderVolume() {
    const { store, from } = this.props;
    const formData = store[`formData_${from}`];
    const { invoiceFlag } = formData;
    if (invoiceFlag == 1) {
      return this.state.mybPlatformVolumeMaxLimit ? `0 - ${this.state.mybPlatformVolumeMaxLimit}` : '请输入';
    } else if (invoiceFlag == 2) {
      return this.state.generalInvoicePlatformVolumeMaxLimit ? `0 - ${this.state.generalInvoicePlatformVolumeMaxLimit}` : '请输入';
    } else {
      return this.state.platformVolumeMaxLimit ? `0 - ${this.state.platformVolumeMaxLimit}` : '请输入';
    }
  }
  /** 重量区间超出提示 */
  get weightLimitTip() {
    const { store, from } = this.props;
    const formData = store[`formData_${from}`];
    const { platformTotalWeight, platformTotalWeightMin, invoiceFlag } = formData;
    const { platformWeightIntervalLimit, mybPlatformWeightMaxLimit, generalInvoicePlatformWeightMaxLimit, platformWeightMaxLimit } = this.state;
    if (
      platformWeightIntervalLimit &&
      platformTotalWeight &&
      platformTotalWeightMin &&
      Math.abs(platformTotalWeight - platformTotalWeightMin) > platformWeightIntervalLimit
    ) {
      return `重量最大值与最小值之差不能大于"${platformWeightIntervalLimit}"吨`;
    } else {
      if (invoiceFlag == 1 || invoiceFlag == 2) {
        let weightLimit = mybPlatformWeightMaxLimit;
        if (invoiceFlag === 2) {
          weightLimit = generalInvoicePlatformWeightMaxLimit;
        }
        if (
          weightLimit &&
          (platformTotalWeight > weightLimit || platformTotalWeightMin > weightLimit)
        ) {
          return `重量不能大于"${weightLimit}"吨`;
        }
      } else {
        if (platformWeightMaxLimit && (platformTotalWeight > platformWeightMaxLimit || platformTotalWeightMin > platformWeightMaxLimit)) {
          return `重量不能大于"${platformWeightMaxLimit}"吨`;
        }
      }
    }
    return null;
  }
  /** 体积区间超出提示 */
  get volumeLimitTip() {
    const { store, from } = this.props;
    const formData = store[`formData_${from}`];
    const { platformTotalVolume, platformTotalVolumeMin, invoiceFlag } = formData;
    const { platformVolumeIntervalLimit, mybPlatformVolumeMaxLimit, generalInvoicePlatformVolumeMaxLimit, platformVolumeMaxLimit } = this.state;
    if (
      platformVolumeIntervalLimit &&
      platformTotalVolume &&
      platformTotalVolumeMin &&
      Math.abs(platformTotalVolume - platformTotalVolumeMin) > platformVolumeIntervalLimit
    ) {
      return `体积最大值与最小值之差不能大于"${platformVolumeIntervalLimit}"方`;
    } else {
      if (invoiceFlag == 1 || invoiceFlag == 2) {
        let volumeLimit = mybPlatformVolumeMaxLimit;
        if (invoiceFlag === 2) {
          volumeLimit = generalInvoicePlatformVolumeMaxLimit;
        }
        if (
          volumeLimit &&
          (platformTotalVolume > volumeLimit || platformTotalVolumeMin > volumeLimit)
        ) {
          return `体积不能大于"${volumeLimit}"吨`;
        }
      } else {
        if (platformVolumeMaxLimit && (platformTotalVolume > platformVolumeMaxLimit || platformTotalVolumeMin > platformVolumeMaxLimit)) {
          return `体积不能大于"${platformVolumeMaxLimit}"吨`;
        }
      }
    }
    return null;
  }
  itemRowElement(title: string, index: number, valueMin: string, value: string, placeholder: string): JSX.Element {
    const { readonly } = this.props;
    return (
      <View style={styles.itemRow}>
        <MBText color={readonly ? '#CCC' : ''}>{title}</MBText>
        <View style={styles.valueBox}>
          <InputItem
            textAlign="center"
            ref={(el: any) => (this.refInpunt[index] = el)}
            style={{ flex: 1, maxWidth: RNElementsUtil.autoFix(180) }}
            inputStyle={{ textAlign: 'center' }}
            value={valueMin || ''}
            styleItem={{ paddingRight: 0 }}
            onChangeText={(text: string) => this.changeText(text, index, 'min')}
            placeholder={placeholder}
            keyboardType="numeric"
            blurOnSubmit={false}
            readonly={readonly}
            editable={!readonly}
            onFocus={() => this.onFocus(index)}
            onBlur={() => this.onBlur(index)}
            onReadOnlyPress={() => this.toastNotEdit(title)}
          />
          <MBText color={readonly ? '#CCC' : ''}>至</MBText>
          <InputItem
            textAlign="center"
            style={{ flex: 1, maxWidth: RNElementsUtil.autoFix(180) }}
            inputStyle={{ textAlign: 'center' }}
            styleItem={{ paddingRight: 0 }}
            value={value || ''}
            onChangeText={(text: string) => this.changeText(text, index)}
            placeholder={placeholder}
            keyboardType="numeric"
            blurOnSubmit={false}
            readonly={readonly}
            editable={!readonly}
            onFocus={() => this.onFocus(index)}
            onBlur={() => this.onBlur(index)}
            onReadOnlyPress={() => this.toastNotEdit(title)}
          />
          {this.rigthElement(index)}
        </View>
      </View>
    );
  }
  render() {
    const { store, from, isRulesTips } = this.props;
    const formData = store[`formData_${from}`];
    const { platformTotalWeight, platformTotalVolume, platformTotalWeightMin, platformTotalVolumeMin } = formData;
    const { showTipsTextWeight, showTipsTextVolume } = this.state;
    return (
      <View onLayout={(el: any) => this.setLayout(el)}>
        {this.itemRowElement('满帮货物重量', 1, platformTotalWeightMin, platformTotalWeight, this.placeholderWeight)}
        {showTipsTextWeight && !!this.weightLimitTip && this.extraElement(this.weightLimitTip)}
        <View style={{ paddingLeft: RNElementsUtil.autoFix(28) }}>
          <Splitline dashWidth={1} />
        </View>
        {this.itemRowElement('满帮货物体积', 2, platformTotalVolumeMin, platformTotalVolume, this.placeholderVolume)}
        {showTipsTextVolume && !!this.volumeLimitTip && this.extraElement(this.volumeLimitTip)}
        {isRulesTips &&
          !platformTotalVolume &&
          !platformTotalVolumeMin &&
          !platformTotalWeight &&
          !platformTotalWeightMin &&
          this.extraElement('重量体积不能同时为空')}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: RNElementsUtil.autoFix(28),
  },
  valueBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
});
