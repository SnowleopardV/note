import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Modal, Whitespace, MBText, Flex } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import { MBBridge, MBToast } from '@ymm/rn-lib';
import RegTest from '~/utils/RegTest';
import TouchableThrottle from '~/components/TouchableThrottle';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NativeBridge from '~/extends/NativeBridge';

const FlexItem = Flex.Item;

const styles = StyleSheet.create({
  contentStyle: {
    paddingHorizontal: 0,
  },

  contentWrapperStyle: {
    width: '100%',
    paddingHorizontal: autoFix(32),
  },

  tipWrapper: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#FFFBE6',
    paddingHorizontal: autoFix(32),
    paddingVertical: autoFix(12),
  },

  topTextStyle: {
    color: '#FFBB44',
    fontSize: autoFix(26),
    marginLeft: autoFix(8),
    paddingRight: autoFix(16),
  },

  iconTip: {
    height: autoFix(30),
    width: autoFix(30),
  },

  selectWrapper: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },

  selectMoreWrapper: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-around',
  },

  flexRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: autoFix(20),
    height: autoFix(60),
    borderRadius: autoFix(30),
    borderColor: '#F0F0F0',
    borderWidth: 1,
    backgroundColor: '#F0F0F0',
    marginTop: autoFix(20),
  },

  selectedStyle: {
    borderColor: '#4885FF',
    backgroundColor: 'rgba(72, 133, 255, 0.2)',
  },

  textStyle: {
    fontSize: autoFix(26),
    color: '#999999',
  },

  selectedTextStyle: {
    color: '#4885FF',
  },

  flexRowRight: {
    marginLeft: autoFix(28),
  },

  inputItemContainer: {
    paddingLeft: 0,
    flex: 1,
  },

  inputItem: {
    paddingRight: 0,
  },

  inputStyle: {
    paddingVertical: autoFix(20),
    paddingHorizontal: autoFix(32),
    backgroundColor: '#F6F6F6',
    borderRadius: autoFix(8),
  },

  confirmBtn: {
    height: autoFix(100),
    width: autoFix(100),
    justifyContent: 'center',
    alignItems: 'flex-end',
  },

  agreementStyle: {
    fontSize: autoFix(26),
  },
});

interface CargoInsuranceProps {
  visible?: boolean;
  onChange?: any;
  cargoInsurance?: any;
  invoiceFlag?: number;
  goodsPrice?: number;
  cargoInsuranceTipText?: string;
  dispatcherInfoList?: any;
  cargoInsuranceSelectItem?: any;
}

export default class ModalCargoInsurance extends React.Component<CargoInsuranceProps, any> {
  refInput: React.RefObject<any>;
  constructor(props: CargoInsuranceProps) {
    super(props);
    this.refInput = React.createRef();

    this.state = {
      selectItem: {
        cargoAmountNoticeConfig: {},
      },
      goodsPrice: '', // 申明价值
      tipText: '',
    };
  }

  componentWillReceiveProps(nextProps: any) {
    const { visible, goodsPrice, cargoInsuranceTipText, cargoInsuranceSelectItem } = nextProps;
    if (visible) {
      setTimeout(() => {
        this.refInput.current?.focus();
      }, 300);
    }

    this.setState({
      goodsPrice: goodsPrice || goodsPrice === 0 ? goodsPrice : '',
      tipText: cargoInsuranceTipText,
      selectItem: cargoInsuranceSelectItem,
    });
  }

  handleConfirm = () => {
    const { onChange, invoiceFlag, cargoInsurance } = this.props;
    const { goodsPrice, tipText, selectItem } = this.state;
    const minInsuranceAmount = cargoInsurance.cargoInsuranceCheckAmountThreshold;
    let handleGoodsPrice = null;

    if (minInsuranceAmount < goodsPrice && !selectItem.companyName) {
      return MBToast.show('请点击选中保险公司');
    }

    if (
      (invoiceFlag === 1 && 0 < goodsPrice && goodsPrice <= minInsuranceAmount) ||
      (minInsuranceAmount < goodsPrice && selectItem.companyName)
    ) {
      handleGoodsPrice = goodsPrice || goodsPrice === 0 ? this.returnFloat(goodsPrice) : '';
    }

    onChange && onChange(handleGoodsPrice, tipText, selectItem);
  };

  handleCancel = () => {
    const { onChange, goodsPrice, cargoInsuranceSelectItem } = this.props;
    this.setState({
      selectItem: { ...cargoInsuranceSelectItem },
      goodsPrice, // 申明价值
      tipText: '',
      dispatcherListTipText: '',
    });
    onChange && onChange(goodsPrice, '', cargoInsuranceSelectItem);
  };

  rightElement() {
    return (
      <TouchableOpacity onPress={this.handleConfirm}>
        <View style={styles.confirmBtn}>
          <MBText size="md" color="primary">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }

  onClickAgreement = () => {
    const { onChange, cargoInsurance } = this.props;
    onChange && onChange();
    if (cargoInsurance?.insuranceTermsUrl) {
      NativeBridge.openWebViewPage(cargoInsurance.insuranceTermsUrl);
    }
  };

  onSelectInsurance = (item: any) => {
    const { cargoInsurance, dispatcherInfoList } = this.props;
    const { goodsPrice, selectItem } = this.state;

    let handleItem = item;
    let tipText = '';
    let dispatcherListTipText = '';
    // 货运险校验金额
    const minInsuranceAmount = cargoInsurance.cargoInsuranceCheckAmountThreshold;
    // 1、申明货值≤2万元时, 2、未填写申明货值时, 3、剩余额度小于申明货值时，禁止选中
    if (!goodsPrice || goodsPrice <= minInsuranceAmount || item.remainQuota < goodsPrice) {
      return;
    }

    if (item.companyName === selectItem.companyName) {
      // 再次点击取消选择, 初始化选项
      handleItem = { cargoAmountNoticeConfig: {} };
    }

    this.setState({
      selectItem: handleItem,
    });

    const {
      companyName,
      cargoAmountNoticeConfig: { maxThreshold, minThreshold, cargoPriceBetweenMinAndMaxThreshold, cargoPriceMoreThanMaxThreshold },
    } = handleItem;

    // 已选中保险
    if (companyName) {
      // 2万元<当申明货值≤300万元，且勾选了保险
      if (minThreshold < goodsPrice && goodsPrice <= maxThreshold) {
        tipText = cargoPriceBetweenMinAndMaxThreshold;
      }
      // 当申明货值＞300万元，且勾选了保险，
      if (maxThreshold < goodsPrice) {
        tipText = cargoPriceMoreThanMaxThreshold;
      }
      // 有多个调度员时取第一个调度员投保，勾选保险后且选择多个调度员时，展示文案提醒：选择多调度员时，每票货成交后都会按照货值投保
      if (dispatcherInfoList && 1 < dispatcherInfoList.length) {
        dispatcherListTipText = '选择多调度员时，每票货成交后都会按照货值投保';
      }
    } else {
      dispatcherListTipText = '';
    }

    this.setState({
      tipText,
      dispatcherListTipText,
    });
  };

  onChangeText = (value: string) => {
    const { invoiceFlag, cargoInsurance } = this.props;
    const { selectItem } = this.state;
    // 货运险校验金额
    const minInsuranceAmount = cargoInsurance.cargoInsuranceCheckAmountThreshold;
    const mybGivingSafeguardText = cargoInsurance.mybGivingSafeguardText;
    const {
      companyName,
      remainQuota,
      cargoAmountNoticeConfig: { maxThreshold, minThreshold, cargoPriceBetweenMinAndMaxThreshold, cargoPriceMoreThanMaxThreshold },
    } = selectItem;
    if (!RegTest.twoPrecision(value) && value) return;

    const goodsPrice = value;
    let tipText = '';

    this.setState({
      goodsPrice,
    });

    // 当0<申明货值≤2万元时，且发票要求选择了专票
    if (0 < goodsPrice && goodsPrice <= minInsuranceAmount && invoiceFlag === 1) {
      tipText = mybGivingSafeguardText;
    }

    // 已选中保险
    if (companyName) {
      // 2万元<当申明货值≤300万元，且勾选了保险
      if (minThreshold < goodsPrice && goodsPrice <= maxThreshold) {
        tipText = cargoPriceBetweenMinAndMaxThreshold;
      }
      // 当申明货值＞300万元，且勾选了保险，
      if (maxThreshold < goodsPrice) {
        tipText = cargoPriceMoreThanMaxThreshold;
      }
    }

    // 当剩余额度小于申明货值时
    if (remainQuota < goodsPrice) {
      tipText = '';
    }

    // 当1、申明货值≤2万元时, 2、未填写申明货值时, 3、剩余额度小于申明货值时保险选项置灰不可勾选 并 初始化选项
    if (goodsPrice <= minInsuranceAmount || !goodsPrice || remainQuota < goodsPrice) {
      this.setState({
        selectItem: { cargoAmountNoticeConfig: {} },
        dispatcherListTipText: '',
      });
    }

    this.setState({
      tipText,
    });
  };

  onBlur = (value: string) => {
    this.setState({
      goodsPrice: value ? Number(value) : '',
    });
  };

  returnFloat = (value: any) => {
    let handleValue = (Math.round(parseFloat(value) * 100) / 100).toString();
    let s = handleValue.split('.');
    if (s.length == 1) {
      handleValue = handleValue + '.00';
      return handleValue;
    }
    if (s.length > 1) {
      if (s[1].length < 2) {
        handleValue = handleValue + '0';
      }
      return handleValue;
    }
  };

  render() {
    const { selectItem, goodsPrice, tipText, dispatcherListTipText } = this.state;
    const { visible, cargoInsurance, invoiceFlag } = this.props;
    const list = cargoInsurance?.insurerCurrentQuoteList || [];

    // 货运险校验金额
    const minInsuranceAmount = cargoInsurance?.cargoInsuranceCheckAmountThreshold;

    return (
      <Modal
        headerLeft="取消"
        headerLine={false}
        headerRight={this.rightElement()}
        title="货运险"
        position="bottom"
        visible={visible}
        contentStyle={styles.contentStyle}
        autoAdjustPosition={true}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        {dispatcherListTipText ? <Whitespace vertical={10} /> : null}
        {dispatcherListTipText ? (
          <View style={styles.tipWrapper}>
            <Image style={styles.iconTip} source={images.icon_warning_yellow} />
            <MBText style={styles.topTextStyle}>{dispatcherListTipText}</MBText>
          </View>
        ) : null}

        <View style={styles.contentWrapperStyle}>
          <Whitespace vertical={6} />
          <View style={[styles.selectWrapper, list.length > 1 ? styles.selectMoreWrapper : {}]}>
            {list.map((item: any, index: number) => {
              return (
                <TouchableThrottle
                  waitSecond={0.2}
                  activeOpacity={goodsPrice <= minInsuranceAmount || !goodsPrice || item.remainQuota < goodsPrice ? 1 : 0.8}
                  onPress={() => {
                    this.onSelectInsurance(item);
                  }}
                  key={index}
                >
                  <View
                    style={[
                      styles.flexRow,
                      !!goodsPrice &&
                      minInsuranceAmount < goodsPrice &&
                      goodsPrice <= item.remainQuota &&
                      item.companyName === selectItem.companyName
                        ? styles.selectedStyle
                        : {},
                      index === list.length - 1 && 1 < list.length ? styles.flexRowRight : {},
                    ]}
                  >
                    <MBText
                      style={[
                        styles.textStyle,
                        !!goodsPrice &&
                        minInsuranceAmount < goodsPrice &&
                        goodsPrice <= item.remainQuota &&
                        item.companyName === selectItem.companyName
                          ? styles.selectedTextStyle
                          : {},
                      ]}
                    >{`${item.cargoAmountNoticeConfig?.insurerShotCompanyName}(剩余${item.remainQuota}万元)`}</MBText>
                  </View>
                </TouchableThrottle>
              );
            })}
          </View>

          <Flex direction="row">
            <InputItem
              ref={this.refInput}
              style={styles.inputItemContainer}
              styleItem={styles.inputItem}
              inputStyle={styles.inputStyle}
              title="申明货值（万元）"
              placeholder="请输入"
              value={goodsPrice + ''}
              keyboardType="numeric"
              onChangeText={this.onChangeText}
              onBlur={() => this.onBlur(goodsPrice)}
              extraNode={<View></View>}
            />
          </Flex>

          <Flex direction="row" justify="flex-start">
            <FlexItem style={{ flexDirection: 'row' }}>
              <MBText style={styles.textStyle}>
                {tipText}
                {0 < goodsPrice && goodsPrice <= minInsuranceAmount && invoiceFlag === 1 ? (
                  <MBText style={styles.agreementStyle} color="primary" onPress={this.onClickAgreement}>
                    {cargoInsurance.insuranceTermsName}
                  </MBText>
                ) : null}
              </MBText>
            </FlexItem>
          </Flex>

          {tipText ? <Whitespace vertical={16} /> : null}
        </View>
      </Modal>
    );
  }
}
