import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { Flex, Modal, MBText, Splitline, Whitespace } from '@ymm/rn-elements';

const FlexItem = Flex.Item;

const ModalTruckType = (props: any) => {
  const { visible, onConfirm, onCancel, transType } = props;
  const [transTypeList, settransTypeList] = useState<any[]>([
    {
      transType: 1,
      transName: '整车',
    },
    {
      transType: 2,
      transName: '零担',
    },
  ]);
  const [transTypeItem, setTransTypeItem] = useState<any>({
    transType: 1,
  });

  useEffect(() => {
    setTransTypeItem(() => {
      const lastTransTypeArr = transTypeList.filter((item) => item.transType === transType);
      return lastTransTypeArr.length ? lastTransTypeArr[0] : { transType: 1 };
    });
  }, [transType]);

  // 用车类型确认
  const onModalConfirm = (value: number) => {
    setTransTypeItem(value);
    console.log(value);
    onConfirm && onConfirm(value);
  };

  return (
    <Modal
      title="请选择用车类型"
      position="bottom"
      visible={visible}
      autoAdjustPosition={true}
      contentStyle={styles.contentStyle}
      headerLine={false}
      onMaskClose={() => {
        onCancel && onCancel();
      }}
      onRequestClose={() => {
        onCancel && onCancel();
      }}
    >
      {transTypeList.map((item: any, index: number) => {
        const selected = transTypeItem.transType === item.transType;
        return (
          <View key={item.id} style={{ width: '100%' }}>
            <TouchableOpacity
              activeOpacity={0.2}
              onPress={() => {
                onModalConfirm(item.transType);
              }}
            >
              <Flex direction="row">
                <FlexItem style={styles.selectItem}>
                  <MBText align="center" color={selected ? 'primary' : ''} style={selected ? styles.selected : ''}>
                    {item.transName}
                  </MBText>
                </FlexItem>
              </Flex>
            </TouchableOpacity>
            {index !== transTypeList.length - 1 && <Splitline />}
          </View>
        );
      })}
      <View style={styles.splitline}></View>
      <View style={{ width: '100%' }}>
        <TouchableOpacity
          onPress={() => {
            onCancel && onCancel();
          }}
        >
          <Flex direction="row">
            <FlexItem style={styles.selectItem}>
              <MBText align="center">取消</MBText>
            </FlexItem>
          </Flex>
        </TouchableOpacity>
      </View>
      <Whitespace vertical={20} />
    </Modal>
  );
};

const styles = StyleSheet.create<any>({
  contentStyle: {
    paddingHorizontal: 0,
  },

  selectItem: {
    height: 55,
    justifyContent: 'center',
  },

  splitline: {
    backgroundColor: '#F7F7F7',
    width: '100%',
    height: 10,
  },

  selected: {
    fontWeight: 'bold',
  },
});

export default ModalTruckType;
