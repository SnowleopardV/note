import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { MBBridge } from '@ymm/rn-lib';
import { Selector, Modal, Flex, Button, Theme, MBText, Whitespace } from '@ymm/rn-elements';
import NativeBridge from '../../../extends/NativeBridge';
import keyMap from '../keyMap';
import API from '../api';
// 选择承运车辆 模态框
const styles = StyleSheet.create({
  selectItem: {
    color: Theme.color_primary,
  },
  btn: {
    marginTop: 20,
    marginBottom: 10,
    width: 179,
    height: 40,
    borderRadius: 50,
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
  from: number;
  noData?: string;
}
const truckSourceMap: any = { 1: 1, 2: 5, 3: 4, 4: null };
export default class SelectCarModal extends React.Component<Props, any> {
  static defaultProps = {
    from: null, // 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
  };
  constructor(props: any) {
    super(props);
    this.state = {
      item: {},
      id: 0,
      list: [],
      isAdd: false, // 是否可以添加操作
    };
  }
  /**
   * @description 车辆列表 父级直接 ref 调用
   * @param carrierId 承运商id
   * @param isPassVal 是否直接传值
   */
  api_queryTruckList(carrierId: number, isPassVal: boolean = false) {
    this.setState({ carrierId: carrierId });
    const { from } = this.props;
    const formData = {
      truckSource: truckSourceMap[from],
      carrierId: carrierId ? carrierId : null,
    };
    return new Promise((resolve, reject) => {
      API.queryTruckList(formData)
        .then((res) => {
          console.log('车辆列表', res);
          if (res.success) {
            const list = res.data.truckList;
            resolve(list);
            this.setState(
              {
                id: 0,
                item: list[0],
                isAdd: res.data.enableCreation,
                list: list.map((item: any, index: number) => {
                  return {
                    ...item,
                    id: index,
                    content(selected: boolean) {
                      return (
                        <Flex direction="row" justify="center" align="center">
                          <MBText bold={selected} color={selected ? 'primary' : 'base'} numberOfLines={1}>
                            {item.carNo}
                            {item.carType && keyMap.carTypeAll[item.carType] ? '-' + keyMap.carTypeAll[item.carType] : ''}
                            {item.carLength && keyMap.carLengthAll[item.carLength] ? '-' + keyMap.carLengthAll[item.carLength] + '米' : ''}
                          </MBText>
                          {/* {!!item.status && <TagMini color={item.color}>{item.tag}</TagMini>} */}
                        </Flex>
                      );
                    },
                  };
                }),
              },
              () => {
                if (isPassVal) {
                  // 如果有承运商 就传第一个传出去
                  this.handleConfirm();
                }
              }
            );
          } else {
            reject(res);
          }
        })
        .catch((err) => {
          reject(err);
        });
    });
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { item, list } = this.state;
    onChange && onChange(item);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleChange = (position: number, item: any) => {
    this.setState({
      item: item,
      id: position,
    });
  };
  // 新增车辆按钮
  handleAddCar = () => {
    this.handleCancel();
    setTimeout(() => {
      this.goPages();
    }, 400);
  };
  goPages() {
    // from // 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
    // truckSource 车辆来源 1：自有 2：挂靠 3：合同 4：外调 5：承运商
    const { from } = this.props;
    const { carrierId } = this.state;
    const truckSource = truckSourceMap[from];
    const item = {
      truckSource: truckSource,
      carrierId: carrierId,
    };
    MBBridge.app.base
      .openSchemeForResult({ schemeUrl: 'ymm://rn.tms/newcars?item=' + encodeURIComponent(JSON.stringify(item)) })
      .then((res) => {
        console.log(res);
        this.api_queryTruckList(carrierId, true);
      });
  }
  // 无权限提示
  noPermission() {
    NativeBridge.toast('您还没有#新增车辆权限#，请联系管理员开通');
  }
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible, noData } = this.props;
    const { id, list, isAdd } = this.state;
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请选择承运车辆"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          {list.length ? (
            <Flex direction="row" justify="center" align="center">
              <Flex.Item key="time">
                <View style={{ flexDirection: 'column' }}>
                  <Selector type={1} value={id} rowTitle="content" list={list} onChange={this.handleChange} />
                </View>
              </Flex.Item>
            </Flex>
          ) : (
            <MBText style={{ marginVertical: 50 }} color="#999999">
              {noData ? noData : '无车辆信息，请新增'}
            </MBText>
          )}
          <Button
            type="bordered"
            size="xs"
            style={[styles.btn, !isAdd && { opacity: 0.3 }]}
            onPress={(el) => (isAdd ? this.handleAddCar() : this.noPermission())}
          >
            新增车辆
          </Button>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
