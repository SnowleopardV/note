import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Theme, Modal, MBText, Splitline, Whitespace } from '@ymm/rn-elements';
import TagMini from '~/components/TagMini';

// 选择调车方式 模态框
const styles = StyleSheet.create({
  box: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  selectItem: {
    color: Theme.color_primary,
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  line: {
    width: 350,
  },
  tag: {
    position: 'absolute',
    backgroundColor: '#FF3A3A',
    right: -40,
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
  disabledList?: Array<number>; // 禁止选择的下标id
}

export default class ModalShuntingMethod extends React.Component<Props, any> {
  constructor(props: Props) {
    super(props);
    const list = [
      { title: '满帮找车', id: 4, tag: '推荐' },
      { title: '自有车', id: 1 },
      { title: '承运商', id: 2 },
      { title: '外调车', id: 3, hidden: true },
    ];
    this.state = {
      item: {},
      list: list,
    };
  }
  onPress(item: any, index: number, disabled: boolean) {
    const { onChange } = this.props;
    !disabled && onChange && onChange(item ? item.id : 0);
  }
  onCancel = () => {
    const { onChange } = this.props;
    onChange && onChange(0);
  };
  render() {
    const { visible, disabledList } = this.props;
    let { list } = this.state;
    list = list.map((item: any) => {
      return {
        ...item,
        disabled: disabledList ? disabledList.some((id: number) => item.id === id) : false,
      };
    });
    return (
      <Modal
        title="选择调度方式"
        animationType="slide"
        position="bottom"
        visible={visible}
        style={styles.box}
        onMaskClose={this.onCancel}
        onRequestClose={this.onCancel}
      >
        {list.map((item: any, index: number) => {
          return (
            <View key={item.id} style={{ width: '100%' }}>
              <TouchableOpacity style={styles.selectItem} onPress={this.onPress.bind(this, item, index, item.disabled)}>
                <View style={{ position: 'relative' }}>
                  <MBText color={item.disabled ? '#ccc' : ''}>{item.title}</MBText>
                  {item.tag && (
                    <TagMini color="#FFFFFF" style={[styles.tag, item.disabled ? { backgroundColor: '#ccc' } : null]}>
                      {item.tag}
                    </TagMini>
                  )}
                </View>
              </TouchableOpacity>
              {item.hidden ? null : <Splitline color="#E8E8E8" />}
            </View>
          );
        })}
        <View style={{ backgroundColor: '#F7F7F7', width: 400, height: 10 }}></View>
        <TouchableOpacity style={[styles.selectItem, { width: '100%' }]} onPress={this.onCancel.bind(this)}>
          <MBText>取消</MBText>
        </TouchableOpacity>
        <Whitespace vertical={20} />
      </Modal>
    );
  }
}
