import { MBText, Modal, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import React, { Component } from 'react';
import { Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import images from '~public/static/images';
import LoadingView from '../LoadingView';
import ModalSelectPhone from './ModalSelectPhone';
// 单项选择调度员框
export interface Props {
  onChange: any;
  visible: boolean;
  list: any[];
  noDataText?: string; // 错误提示
  loading?: boolean;
  showOrgName: boolean;
  selectedId: string; // 已选调度员id
  showPhoneNumber: boolean; // 是否显示手机号码选择框
}
export default class SingleSelectdispatcherModal extends Component<Props, any> {
  static defaultProps = {
    showOrgName: false,
    showPhoneNumber: false,
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      selectedItem: {}, // 用于保存选中值
      showModalSelectPhone: false, // 显示来电号码
      selectContactList: [],
      listGroupIndex: null, // 要修改号码的数组分组下标
      selectContactIndex: null, // 要修改号码的数组下标
      defaultContact: null, // 选择号码默认选择的号码
    };
  }
  componentWillReceiveProps(nextProps: Props): void {
    if (nextProps.visible && !nextProps.loading) {
      let selectedItem = {};
      for (const item of nextProps?.list) {
        selectedItem = item.dispatchList?.find((row: any) => row.dispatcherId == nextProps?.selectedId);
        if (selectedItem) break;
      }
      this.setState({ selectedItem: selectedItem || {} });
    }
  }
  handleConfirm = (): void => {
    const { onChange } = this.props;
    const { selectedItem } = this.state;

    onChange && onChange(selectedItem);
  };
  handleCancel = (): void => {
    const { onChange } = this.props;
    onChange && onChange(null);
  };
  changeSelect(item: any): void {
    this.setState({ selectedItem: item });
  }
  /** 选择接听手机号 */
  selectPhoneNumber(item: any, index: number, itemIndex: number) {
    console.log('选择接听手机号', item);
    if (!item.selectTips) {
      this.setState({
        selectContactList: item.selectContactList || [],
        listGroupIndex: index,
        selectContactIndex: itemIndex,
        showModalSelectPhone: true,
        defaultContact: item.consignorContact,
      });
    }
  }
  onChangeContact = (val: any, defaultPhone: string | null) => {
    if (val) {
      const { selectContactIndex, listGroupIndex } = this.state;
      const row = this.props.list[listGroupIndex];
      if(selectContactIndex > -1){
        row.dispatchList[selectContactIndex].consignorContact = val === -1 ? null : val;
        row.dispatchList[selectContactIndex].defaultPhone = defaultPhone;
      }
    }
    this.setState({ showModalSelectPhone: false });
  };
  listItemElement(item: any): React.ReactNode {
    const { selectedItem } = this.state;
    return (
      <View style={[styles.item, styles.borderBottom]} key={item.dispatcherId}>
        <TouchableOpacity style={{ flexDirection: 'row', flex: 1, justifyContent: 'center' }} onPress={() => this.changeSelect(item)}>
          <MBText
            size="md"
            style={{ flexShrink: 1 }}
            numberOfLines={1}
            color={selectedItem?.dispatcherId == item.dispatcherId ? '#4885FF' : '#333333'}
          >
            {item.dispatcherName + '-' + item.phone}
          </MBText>
          <MBText size="md" color={selectedItem?.dispatcherId == item.dispatcherId ? '#4885FF' : '#333333'}>
            （剩{item.remainDispatchNumber}次）
          </MBText>
        </TouchableOpacity>
      </View>
    );
  }
  iconDefault() {
    return (
      <View style={{ borderColor: '#4885FF', borderWidth: 1, paddingHorizontal: 4, marginLeft: RNElementsUtil.autoFix(20) }}>
        <MBText style={{ fontSize: RNElementsUtil.autoFix(22) }} color="#4885FF">
          默认
        </MBText>
      </View>
    );
  }
  listItemShowPhoneNumberElement(item: any, index: number, itemIndex: number): React.ReactNode {
    const { selectedItem } = this.state;
    return (
      <TouchableOpacity
        style={[selectedItem?.dispatcherId == item.dispatcherId ? styles.selectedBg : null, styles.borderBottom]}
        onPress={() => this.changeSelect(item)}
      >
        <View style={styles.item} key={item.dispatcherId}>
          <View style={{ flexDirection: 'row', flex: 1, alignItems: 'flex-end' }}>
            <MBText size="md" style={{ flexShrink: 1 }} numberOfLines={1}>
              {item.dispatcherName}
            </MBText>
            <MBText style={{ marginLeft: 5, fontSize: RNElementsUtil.autoFix(26) }} color="#999999">
              {item.phone}（剩{item.remainDispatchNumber}次）
            </MBText>
          </View>
          <View style={{ width: 50, height: 48, justifyContent: 'center', alignItems: 'flex-end' }}>
            {selectedItem?.dispatcherId == item.dispatcherId && (
              <Image style={{ width: RNElementsUtil.autoFix(28), height: RNElementsUtil.autoFix(18) }} source={images.icon_check_mark} />
            )}
          </View>
        </View>
        {!item.selectTips && (
          <TouchableOpacity style={[styles.itemPhoneNumber]} onPress={() => this.selectPhoneNumber(item, index, itemIndex)}>
            <View style={styles.flexRow}>
              <MBText style={{ fontSize: RNElementsUtil.autoFix(26), flexShrink: 1 }} color="#999999" numberOfLines={1}>
                {item.selectTips ? '' : item.consignorContact || '全选'}
              </MBText>
              {item.consignorContact && item.consignorContact === item.defaultPhone && this.iconDefault()}
            </View>
            {!item.selectTips && (
              <View style={styles.flexRow}>
                <MBText style={{ fontSize: RNElementsUtil.autoFix(26) }} color="#666666">
                  选择接听司机来电号码
                </MBText>
                <Image style={styles.sortArrow} source={{ uri: images.sortArrows }}></Image>
              </View>
            )}
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    );
  }
  render(): React.ReactNode {
    const { visible, list, noDataText, loading, showOrgName, showPhoneNumber } = this.props;
    const { showModalSelectPhone, selectContactList, defaultContact, listGroupIndex, selectContactIndex } = this.state;
    const row = this.props.list[listGroupIndex];
    const selectedDispatcherId = row?.dispatchList[selectContactIndex].dispatcherId;
    const defaultPhone = row?.dispatchList[selectContactIndex].defaultPhone;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight="确定"
          title="选择调度员"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
          contentStyle={{ paddingHorizontal: 0 }}
        >
          {!!loading ? (
            <View style={{ height: RNElementsUtil.autoFix(400) }}>
              <LoadingView size="small" />
            </View>
          ) : (
            <View style={{ width: '100%' }}>
              {list?.length ? (
                <ScrollView style={styles.scrollView}>
                  <View style={{ flex: 1 }}>
                    {list.map((item: any, index: number) => {
                      return (
                        <View key={index}>
                          {showOrgName && (
                            <View style={[styles.orgNameTitle, { justifyContent: 'center' }]}>
                              <MBText color="#9DA1B0" numberOfLines={2} size="sm">
                                {item.orgName}
                              </MBText>
                            </View>
                          )}
                          {item.dispatchList.map((row: any, i: number) =>
                            showPhoneNumber ? this.listItemShowPhoneNumberElement(row, index, i) : this.listItemElement(row)
                          )}
                        </View>
                      );
                    })}
                    <Whitespace vertical={50} />
                  </View>
                </ScrollView>
              ) : (
                <View
                  style={{ justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20, height: RNElementsUtil.autoFix(400) }}
                >
                  <MBText color="#999999" size="xs">
                    {noDataText}
                  </MBText>
                </View>
              )}
            </View>
          )}
          <Whitespace vertical={20} />
        </Modal>
        {!!showPhoneNumber && (
          <ModalSelectPhone
            visible={showModalSelectPhone}
            list={selectContactList}
            default={defaultContact}
            onChange={this.onChangeContact}
            dispatcherId={selectedDispatcherId || null}
            defPhone={defaultPhone || null}
          />
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  selectedBg: {
    backgroundColor: '#E4EDFF',
  },
  scrollView: {
    maxHeight: RNElementsUtil.autoFix(700),
  },
  item: {
    height: RNElementsUtil.autoFix(96),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: RNElementsUtil.autoFix(30),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  borderBottom: {
    borderBottomColor: '#EEEEEE',
    borderBottomWidth: 1,
  },
  sortArrow: {
    width: RNElementsUtil.autoFix(13),
    height: RNElementsUtil.autoFix(26),
    marginLeft: RNElementsUtil.autoFix(20),
  },
  itemPhoneNumber: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: RNElementsUtil.autoFix(30),
    paddingBottom: RNElementsUtil.autoFix(32),
  },
  inputStyle: {
    flex: 1,
    textAlign: 'right',
    paddingRight: 0,
  },
  orgNameTitle: {
    height: RNElementsUtil.autoFix(68),
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    backgroundColor: '#F5F5F5',
  },
});
