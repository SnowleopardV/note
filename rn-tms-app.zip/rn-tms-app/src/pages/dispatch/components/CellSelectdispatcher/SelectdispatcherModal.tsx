import { MBText, Modal, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import React, { Component } from 'react';
import { Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import images from '../../../../../public/static/images/index';
import LoadingView from '../LoadingView';
import ModalSelectPhone from './ModalSelectPhone';
// 多选调度员选择弹窗
export interface Props {
  onChange: any;
  visible: boolean;
  list: any[];
  noDataText?: string; // 错误提示
  loading?: boolean;
  showOrgName: boolean;
  showPhoneNumber: boolean; // 是否显示手机号码选择框
}
export default class SelectdispatcherModal extends Component<Props, any> {
  static defaultProps = {
    showOrgName: false,
    showPhoneNumber: false,
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      totalSelected: false,
      listMap: {}, // 用于保存选中状态
      showModalSelectPhone: false, // 显示来电号码
      selectContactList: [],
      listGroupIndex: null, // 要修改号码的数组分组下标
      selectContactIndex: null, // 要修改号码的数组下标
      defaultContact: null, // 选择号码默认选择的号码
    };
  }
  componentWillReceiveProps(nextProps: Props): void {
    if (nextProps.visible && !nextProps.loading) {
      const listMap = {};
      nextProps?.list?.forEach((item: any) => {
        item.dispatchList?.forEach((row: any) => {
          listMap[row.dispatcherId] = row;
        });
      });
      this.setState({ listMap: listMap });
    }
  }
  handleConfirm = (): void => {
    const { onChange } = this.props;
    const { listMap } = this.state;
    const list: any[] = [];
    this.props.list?.forEach((item: any) => {
      item.dispatchList?.forEach((row: any) => {
        if (listMap[row.dispatcherId].selected) {
          list.push(row);
        }
      });
    });

    onChange && onChange(list);
  };
  handleCancel = (): void => {
    const { onChange } = this.props;
    onChange && onChange(null);
  };
  // 全选
  changeTotalSelect(val: boolean): void {
    const { listMap } = this.state;
    Object.keys(listMap)?.forEach((key: any) => {
      listMap[key].selected = !val;
    });
    this.setState({ totalSelected: !val });
  }
  changeSelect(item: any): void {
    const { listMap } = this.state;
    listMap[item.dispatcherId].selected = !listMap[item.dispatcherId]?.selected;
    this.forceUpdate();
    const isTotal = Object.keys(listMap).find((key: any) => {
      return !listMap[key]?.selected;
    });
    this.setState({ totalSelected: !isTotal });
  }
  /** 选择接听手机号 */
  selectPhoneNumber(item: any, index: number, itemIndex: number) {
    console.log('选择接听手机号', item, index);
    if (!item.selectTips) {
      this.setState({
        selectContactList: item.selectContactList || [],
        listGroupIndex: index,
        selectContactIndex: itemIndex,
        showModalSelectPhone: true,
        defaultContact: item.consignorContact,
      });
    }
  }
  onChangeContact = (val: any, defaultPhone: string | null) => {
    if (val) {
      const { selectContactIndex, listGroupIndex } = this.state;
      const row = this.props.list[listGroupIndex];
      if (selectContactIndex > -1) {
        row.dispatchList[selectContactIndex].consignorContact = val === -1 ? null : val;
        row.dispatchList[selectContactIndex].defaultPhone = defaultPhone;
      }
    }
    this.setState({ showModalSelectPhone: false });
  };
  iconDefault() {
    return (
      <View style={{ borderColor: '#4885FF', borderWidth: 1, paddingHorizontal: 4, marginLeft: RNElementsUtil.autoFix(20) }}>
        <MBText style={{ fontSize: RNElementsUtil.autoFix(22) }} color="#4885FF">
          默认
        </MBText>
      </View>
    );
  }
  listItemElement(item: any): React.ReactNode {
    const { listMap } = this.state;
    return (
      <TouchableOpacity style={[styles.item, styles.borderBottom]} key={item.dispatcherId} onPress={() => this.changeSelect(item)}>
        <View style={{ flexDirection: 'row', flex: 1 }}>
          <MBText size="md" style={{ flexShrink: 1 }} numberOfLines={1}>
            {item.dispatcherName + '-' + item.phone}
          </MBText>
          <MBText size="md">（剩{item.remainDispatchNumber}次）</MBText>
        </View>
        <View style={{ width: 50, height: 48, justifyContent: 'center', alignItems: 'flex-end' }}>
          <Image
            style={{ height: 20, width: 20 }}
            source={listMap[item.dispatcherId]?.selected ? images.icon_circleSelectCheck : images.icon_circleSelect}
          />
        </View>
      </TouchableOpacity>
    );
  }
  listItemShowPhoneNumberElement(item: any, index: number, itemIndex: number): React.ReactNode {
    const { listMap } = this.state;
    return (
      <TouchableOpacity key={item.dispatcherId} style={styles.borderBottom} onPress={() => this.changeSelect(item)}>
        <View style={styles.item} key={item.dispatcherId}>
          <View style={{ flexDirection: 'row', flex: 1, alignItems: 'flex-end' }}>
            <MBText size="md" style={{ flexShrink: 1 }} numberOfLines={1}>
              {item.dispatcherName}
            </MBText>
            <MBText style={{ marginLeft: 5, fontSize: RNElementsUtil.autoFix(26) }} color="#999999">
              {item.phone}（剩{item.remainDispatchNumber}次）
            </MBText>
          </View>
          <View style={{ width: 50, height: 48, justifyContent: 'center', alignItems: 'flex-end' }}>
            <Image
              style={{ height: 20, width: 20 }}
              source={listMap[item.dispatcherId]?.selected ? images.icon_circleSelectCheck : images.icon_circleSelect}
            />
          </View>
        </View>
        {!item.selectTips && (
          <TouchableOpacity style={[styles.itemPhoneNumber]} onPress={() => this.selectPhoneNumber(item, index, itemIndex)}>
            <View style={styles.flexRow}>
              <MBText style={{ fontSize: RNElementsUtil.autoFix(26), flexShrink: 1 }} color="#999999" numberOfLines={1}>
                {item.consignorContact || '全选'}
              </MBText>
              {item.consignorContact && item.consignorContact === item.defaultPhone && this.iconDefault()}
            </View>
            {!item.selectTips && (
              <View style={styles.flexRow}>
                <MBText style={{ fontSize: RNElementsUtil.autoFix(26) }} color="#666666">
                  选择接听司机来电号码
                </MBText>
                <Image style={styles.sortArrow} source={{ uri: images.sortArrows }}></Image>
              </View>
            )}
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    );
  }
  render(): React.ReactNode {
    const { visible, list, noDataText, loading, showOrgName, showPhoneNumber } = this.props;
    const { totalSelected, showModalSelectPhone, selectContactList, defaultContact, listGroupIndex, selectContactIndex } = this.state;
    const row = this.props.list[listGroupIndex];
    const selectedDispatcherId = row?.dispatchList[selectContactIndex].dispatcherId;
    const defaultPhone = row?.dispatchList[selectContactIndex].defaultPhone;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight="确定"
          title="选择调度员"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
          contentStyle={{ paddingHorizontal: 0 }}
        >
          {!!loading ? (
            <View style={{ height: RNElementsUtil.autoFix(400) }}>
              <LoadingView size="small" />
            </View>
          ) : (
            <View style={{ width: '100%' }}>
              {list?.length ? (
                <View style={{ width: '100%' }}>
                  <View
                    style={{ backgroundColor: '#FFFBE6', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', height: 26 }}
                  >
                    <Image
                      style={{ height: RNElementsUtil.autoFix(30), width: RNElementsUtil.autoFix(30), paddingHorizontal: 5 }}
                      source={images.icon_warning_yellow}
                    />
                    <MBText size="xs" color="#FFBB44" style={{ marginLeft: 5 }}>
                      可以选择多个调度同时找车，在找车看板中查看结果
                    </MBText>
                  </View>
                  <View style={[styles.item, styles.borderBottom]}>
                    <MBText size="md">全选</MBText>
                    <TouchableOpacity
                      onPress={() => this.changeTotalSelect(totalSelected)}
                      style={{ width: 50, height: 48, justifyContent: 'center', alignItems: 'flex-end' }}
                    >
                      <Image
                        style={{ height: 20, width: 20 }}
                        source={totalSelected ? images.icon_circleSelectCheck : images.icon_circleSelect}
                      />
                    </TouchableOpacity>
                  </View>
                  <ScrollView style={styles.scrollView}>
                    {list.map((item: any, index: number) => {
                      return (
                        <View key={index}>
                          {showOrgName && (
                            <View style={styles.orgNameTitle}>
                              <MBText color="#999999" numberOfLines={2} size="sm">
                                {item.orgName}
                              </MBText>
                            </View>
                          )}
                          {item.dispatchList.map((row: any, i: number) =>
                            showPhoneNumber ? this.listItemShowPhoneNumberElement(row, index, i) : this.listItemElement(row)
                          )}
                        </View>
                      );
                    })}
                    <Whitespace vertical={50} />
                  </ScrollView>
                </View>
              ) : (
                <View
                  style={{ justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20, height: RNElementsUtil.autoFix(400) }}
                >
                  <MBText color="#999999" size="xs">
                    {noDataText}
                  </MBText>
                </View>
              )}
            </View>
          )}
          <Whitespace vertical={20} />
        </Modal>
        {!!showPhoneNumber && (
          <ModalSelectPhone
            visible={showModalSelectPhone}
            list={selectContactList}
            default={defaultContact}
            onChange={this.onChangeContact}
            dispatcherId={selectedDispatcherId || null}
            defPhone={defaultPhone || null}
          />
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  sortArrow: {
    width: RNElementsUtil.autoFix(13),
    height: RNElementsUtil.autoFix(26),
    marginLeft: RNElementsUtil.autoFix(20),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scrollView: {
    maxHeight: RNElementsUtil.autoFix(700),
  },
  item: {
    height: RNElementsUtil.autoFix(96),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: RNElementsUtil.autoFix(30),
  },
  borderBottom: {
    borderBottomColor: '#EEEEEE',
    borderBottomWidth: 1,
  },
  itemPhoneNumber: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: RNElementsUtil.autoFix(30),
    paddingBottom: RNElementsUtil.autoFix(32),
  },
  inputStyle: {
    flex: 1,
    textAlign: 'right',
    paddingRight: 0,
  },
  orgNameTitle: {
    paddingLeft: RNElementsUtil.autoFix(30),
    height: RNElementsUtil.autoFix(68),
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
});
