import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, MBText, Whitespace, RNElementsUtil, CellGroup, Switch } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import Api from '~/pages/dispatch/api';
import { MBToast } from '@ymm/rn-lib';

// 选择接听司机来电号码

interface Props {
  visible?: boolean;
  onChange?: any;
  list?: any[];
  default: string | null;
  dispatcherId?: string | null;
  defPhone?: string | null;
}
export default class ModalSelectPhone extends React.Component<Props, any> {
  static defaultProps = {
    list: [],
    default: null,
  };
  constructor(props: any) {
    super(props);
    this.state = {
      position: 0,
      defaultPhone: null, // 设置的默认号码
    };
  }
  componentWillReceiveProps(nextProps: Props) {
    if(nextProps.visible){
      if(nextProps.default){
        const position = nextProps.list?.indexOf(nextProps.default) || 0;
        console.log('nextProps.list[position+1]', nextProps.defPhone);
        
        this.setState({
          position: position > -1 ? position + 1 : 0,
          defaultPhone: nextProps.list && position > -1 ? nextProps.defPhone : null,
        })
      } else {
        this.setState({position: 0})
      }
    } 
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { position, defaultPhone } = this.state;
    const item = this.listData[position];
    onChange && onChange(item?.text || -1, defaultPhone);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleChange = (position: number) => {
    this.setState({ position: position });
  };
  switchChange = (val: any) => {
    const { position } = this.state;
    const item: {text: string | undefined, content: JSX.Element} = this.listData[position];
    if(val){
      this.api_dispacherContactDefault(item.text, 0)
    } else {
      this.api_dispacherContactDefault(item.text, 1)
    }
  }
  api_dispacherContactDefault(defaultPhone: string | undefined, type: number){
    if(!this.props.dispatcherId) return;
    const data = {
      dispatcherId: this.props.dispatcherId, // 调度员id
      defaultPhone: defaultPhone,
      operateType: type, // 操作类型 0：设置默认 1：取消默认
    }
    Api.dispacherContactDefault(data).then((res: any) => {
      console.log('设置默认接听号码', res);
      if(res.code == '10000'){
        this.setState({defaultPhone: !type ? defaultPhone : null})
        MBToast.show(type ? '已取消默认' : '已设为默认');
      }
    }).catch((err: any)=>{
      console.log('设置默认接听号码',err);
      this.forceUpdate()
    })
  }
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  get listData (): any[] {
    let data = [{
      content(selected: boolean) {
        return (
          <Flex direction="row" justify="center" align="center">
            <MBText bold={selected} size="md" color={selected ? 'primary' : 'base'} numberOfLines={1}>
              全选
            </MBText>
          </Flex>
        );
      },
    }]
    const data1 = this.props.list?.map((item: any)=>{
      return {
        text: item,
        content(selected: boolean) {
          return (
            <Flex direction="row" justify="center" align="center">
              <MBText bold={selected} size="md" color={selected ? 'primary' : 'base'} numberOfLines={1}>
                {item || ''}
              </MBText>
            </Flex>
          );
        },
      };
    })
    return data.concat(data1 || [])
  }

  get isChecked() {
    const { defaultPhone, position } = this.state;
    const item: {text: string | undefined, content: JSX.Element} = this.listData[position];
    return defaultPhone === item.text;
  }
  render() {
    const { visible, dispatcherId } = this.props;
    const { position } = this.state;
    return (
      <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="设置接听司机来电号码"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
          contentStyle={{paddingHorizontal: 0}}
        >
          {this.listData?.length ? (
            <View style={styles.content}>
              <Selector type={2} value={position} rowTitle="content" list={this.listData} onChange={this.handleChange} />
              <CellGroup withBottomLine>
                {!!position && (
                  <Cell title="设为默认电话" titleStyle={styles.cellTitle}  rightElement={<Switch disabled={!position && !!dispatcherId} checked={this.isChecked} onChange={this.switchChange} />}/>
                )}
              </CellGroup>
            </View>
          ) : (
            <MBText style={{ marginVertical: 50 }} color="#999999">暂无数据</MBText>
          )}
          <Whitespace vertical={34} />
        </Modal>
    );
  }
}
const styles = StyleSheet.create({
  content:{
    width: '100%',
    zIndex: -1,
    marginHorizontal: RNElementsUtil.autoFix(-34),
    flexDirection: 'column',
  },
  cellTitle:{
    color: '#333333',
    fontSize: RNElementsUtil.autoFix(32),
    fontWeight: '400',
  }
});