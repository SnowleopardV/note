import { MBText, Modal, RNElementsUtil, TagContent, Whitespace } from '@ymm/rn-elements';
import React, { Component } from 'react';
import { View } from 'react-native';
import Cell from '~/components/common/Cell';
import { inject, observer } from 'mobx-react';
import NativeBridge from '~/extends/NativeBridge';
import SelectdispatcherModal from './SelectdispatcherModal';
import API from '../../api';
import { MBLog } from '@ymm/rn-lib';
import keyMap from '../../keyMap';
import SingleSelectdispatcherModal from './SingleSelectdispatcherModal';
// 选择调度员多选 cell
export interface Props {
  placeholder?: string;
  store?: any;
  readonly?: boolean; // 只读 文字置灰 调度页面置灰不用选择， 运单页需要选择
  required?: boolean; // 是否必选
  from: number;
  isRulesTips?: boolean;
  isSingleChoice?: boolean; // 是否是单选调度员
  title: string;
  showPhoneNumber: boolean; // 是否显示手机号码选择框
  setMybAuthState: any; // 设置满运宝是否认证的state
}
@inject('store')
@observer
export default class CellSelectdispatcher extends Component<Props, any> {
  static defaultProps = {
    required: false, // 默认非必选
    readonly: false, // 默认非只读
    placeholder: '请选择',
    showPhoneNumber: false,
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      showModal: false,
      dispatcherList: [],
      errorText: ['该公司未关联满运宝企业暂无可用调度账号，请前往pc端（www.tms8.com）登陆后进行授权：公司管理-服务授权-授权'],
      loading: true,
      showOrgName: false,
      consignorContactEnable: 0, // 接口返回 是否可选接听号码 0否 1是
    };
  }
  componentWillMount(): void {
    const { orgId } = this.props.store[`formData_${this.props.from}`];
    const { readonly, showPhoneNumber } = this.props;
    if (!readonly) {
      this.api_mybAuth(orgId || null);
    }
    if (showPhoneNumber) {
      this.api_systemShowPhoneNumber().then(() => this.api_initData()); // 获取是否显现接听电话设置按钮
    } else {
      this.api_initData(); // 获取调度员列表和默认调度员列表
    }
  }
  componentDidMount(): void {}

  //  获取快捷标签接口 服务要求备注里的
  api_queryRemarkTags(dispatcherId: string | number | null): void {
    console.log('获取快捷标签接口', dispatcherId);
    if (dispatcherId) {
      API.queryRemarkTags({ dispatcherId: dispatcherId }).then((res: any) => {
        console.log('获取快捷标签接口', res);
        if (res.success && res.data) {
          keyMap.tagData = res.data.map((item: any) => {
            return { id: item.tagId, name: item.content };
          });
        } else {
          keyMap.tagData = [];
        }
      });
    } else {
      keyMap.tagData = [];
    }
  }
  /** 获取是否显现接听电话设置按钮开关设置 */
  api_systemShowPhoneNumber() {
    return new Promise((resolve: any) => {
      API.systemShowPhoneNumber()
        .then((res: any) => {
          console.log('获取是否显现接听电话设置按钮开关设置', res);
          this.setState({ consignorContactEnable: res.data?.consignorContactEnable ?? 0 }, () => resolve()); // 开关配置获取到了就请求调度列表接口
        })
        .catch((err: any) => {
          console.log('电话设置按钮设置错误', err);
          resolve();
        });
    });
  }
  // 获取 默认选择调度员，和调度员列表
  api_initData(): void {
    const { readonly } = this.props;
    // 只读模式下无需请求接口
    if (readonly) {
      return;
    }
    const { orgId } = this.props.store[`formData_${this.props.from}`];
    const { isSingleChoice } = this.props;
    this.setState({ loading: true });
    Promise.all([
      API.queryDispatcherList({ organizationId: orgId || null }), // 调度员列表
      API.defaultDispatcherList({ orgId: orgId || null }), // 获取默认调度员列表
    ])
      .then((res: any) => {
        const { consignorContactEnable } = this.state;
        this.setState({ loading: false, showOrgName: res[0].data?.showOrgName || false });
        if (res[0].code == 10000 && res[1].code == 10000) {
          const list = res[0].data.list;
          list?.forEach((item: any) => {
            item.dispatchList.forEach((row: any) => {
              row.dispatcherId = row.mybConsignorId || row.dispatcherId; // 调度员id
              row.dispatcherPhone = row.phone || row.dispatcherPhone; // 调度员手机号
              row.defaultPhone = consignorContactEnable ? row.consignorContact || null : null; // 默认手机号
            });
          });
          this.api_queryRemarkTags(list[0]?.dispatchList[0]?.dispatcherId || null); // 获取快捷标签
          //单选调度如果有多个默认值就清空选项，如果只有一个则带入
          let defaultList = [];
          const defaultListData = res[1].data?.defaultList || [];
          if (isSingleChoice) {
            defaultList = defaultListData?.length == 1 ? defaultListData : [];
          } else {
            // 多选
            defaultList = defaultListData;
          }
          const defaultListObj = {}; // 用于合并数组
          defaultList.map((item: any) => (defaultListObj[item.dispatcherId] = item));
          const defaultListConsignorContact: any[] = []; // 将默认调度员的接听号码找到
          for (const item of list) {
            item.dispatchList?.forEach((row: any) => {
              row.selected = !!defaultListObj[row.dispatcherId];
              (row.consignorContact = consignorContactEnable ? row.consignorContact : null), //  开关关闭不填入接听号码
                row.selected && defaultListConsignorContact.push(row);
            });
          }
          if (isSingleChoice) {
            // 单选
            this.props.store.setFormData(this.props.from, {
              dispatcherId: defaultListConsignorContact[0]?.dispatcherId || null, // 调度员id 单选
              dispatcherName: defaultListConsignorContact[0]?.dispatcherName || null, // 调度员姓名 单选
              dispatcherPhone: defaultListConsignorContact[0]?.dispatcherPhone || null, // 调度员手机号 单选
              remainDispatchNumber: defaultListConsignorContact[0]?.remainDispatchNumber || null, // 调度员扣减次数 单选
              consignorContact: consignorContactEnable ? defaultListConsignorContact[0]?.consignorContact || null : null, //  接听号码
            });
          } else {
            // 多选
            this.props.store.setFormData(this.props.from, {
              dispatcherInfoList: defaultListConsignorContact,
              dispatcherId: defaultListConsignorContact[0]?.dispatcherId || null, // 调度员id 单选
              dispatcherName: defaultListConsignorContact[0]?.dispatcherName || null, // 调度员姓名 单选
              dispatcherPhone: defaultListConsignorContact[0]?.dispatcherPhone || null, // 调度员手机号 单选
              remainDispatchNumber: defaultListConsignorContact[0]?.remainDispatchNumber || null, // 调度员扣减次数 单选
              consignorContact: consignorContactEnable ? defaultListConsignorContact[0]?.consignorContact || null : null, //  接听号码
            });
          }
          this.setState({ dispatcherList: list });
          // 根据调度员获取用户购买保险列表
          if (defaultList[0]?.dispatcherId) {
            this.getCargoInsurance(defaultList[0].dispatcherId);
          } else {
            this.getCargoInsurance(''); // 清空选择调度员后，保险数据初始化
          }
        }
        this.state.errorText[1] = undefined;
      })
      .catch((err: any) => {
        this.setState({ loading: false });
        this.state.errorText[1] = err.msg;
      });
  }

  // 获取保险列表
  getCargoInsurance = (dispatcherId: any) => {
    const { getCargoInsuranceList, formDataWaybill, waybillDetails, stowageSelectedList } = this.props.store;
    let goodsType = '';
    if (formDataWaybill) {
      goodsType = formDataWaybill.cargoList[0].cargoName;
    }

    if (waybillDetails && waybillDetails.cargoList?.length) {
      goodsType = waybillDetails.cargoList[0].cargoName;
    }

    if (stowageSelectedList && stowageSelectedList.length) {
      goodsType = stowageSelectedList[0].cargoName;
    }

    if (dispatcherId) {
      getCargoInsuranceList({
        goodsType,
        dispatcherId,
      });
    } else {
      getCargoInsuranceList({
        goodsType,
        dispatcherId: '',
      });
    }
  };

  // 查询组织是否有满运宝认证
  api_mybAuth(id: string | null): Promise<void> {
    const { setMybAuthState } = this.props;
    return API.mybAuth({ orgId: id || null })
      .then((res: any) => {
        setMybAuthState && setMybAuthState(!res.data.showDialog);
        console.log('查询组织是否有满运宝认证', res);
        if (res.data && res.data.showDialog) {
          const text = res.data.content;
          Modal.Alert({
            title: '提示', // 可以传null隐藏头部
            content: <TagContent textAttribute={true} content={text} />, // 富文本提示内容
            buttonText: '我知道了',
            onConfirm: () => {
              console.log('我知道了');
            },
          });
        }
        return res.data;
      })
      .catch((err: any) => {
        MBLog.log(err);
      });
  }
  // 只读情况下点击回调
  toastNotEdit = (text: string): void => {
    NativeBridge.toast(`不支持修改#${text}#`);
  };
  openModal(val: boolean): void {
    if (val && this.state.errorText[1]) {
      this.api_initData();
    }
    this.setState({ showModal: val });
  }
  /** 多选结果 */
  changeModal(list: any[]): void {
    this.openModal(false);
    if (list) {
      const { consignorContactEnable } = this.state;
      const data = list.map((item: any) => {
        const { selected, ...other } = item;
        return other;
      });
      const data_1 = {
        dispatcherInfoList: data, // 多选
        dispatcherId: data[0]?.dispatcherId || null, // 调度员id 单选
        dispatcherName: data[0]?.dispatcherName || null, // 调度员姓名 单选
        dispatcherPhone: data[0]?.dispatcherPhone || null, // 调度员手机号 单选
        remainDispatchNumber: data[0]?.remainDispatchNumber || null, // 调度员扣减次数 单选
        consignorContact: consignorContactEnable ? data[0]?.consignorContact || null : null, //  接听号码
      };
      this.props.store.setFormData(this.props.from, data_1);
      const { orgId } = this.props.store[`formData_${this.props.from}`];
      !!list?.length && this.api_mybAuth(orgId || null); // 检查是否该组织下是否可以选择调度员，是否需要进行满运宝认证
      if (data[0]?.dispatcherId) {
        this.getCargoInsurance(data[0].dispatcherId); // 选择调度员后，重新获取保险列表
      }
    }

    if (!list?.length) {
      this.getCargoInsurance(''); // 清空选择调度员后，保险数据初始化
    }
  }
  /** 单选结果 */
  changeSingleModal(item: any): void {
    this.openModal(false);
    if (item?.dispatcherId) {
      const { consignorContactEnable } = this.state;
      const data = {
        dispatcherId: item.dispatcherId, // 调度员id
        dispatcherName: item.dispatcherName, // 调度员姓名
        dispatcherPhone: item.dispatcherPhone, // 调度员手机号
        remainDispatchNumber: item.remainDispatchNumber, // 调度员扣减次数
        consignorContact: consignorContactEnable ? item?.consignorContact || null : null, //  接听号码
      };
      this.props.store.setFormData(this.props.from, data);
      const { orgId } = this.props.store[`formData_${this.props.from}`];
      this.api_mybAuth(orgId || null); // 检查是否该组织下是否可以选择调度员，是否需要进行满运宝认证
      this.getCargoInsurance(item.dispatcherId); // 选择调度员后，重新获取保险列表
    } else {
      this.getCargoInsurance(''); // 清空选择调度员后，保险数据初始化
    }
  }
  /** 显示多选结果 */
  get dispatcherInfoListText(): React.ReactNode {
    let { dispatcherInfoList } = this.props.store[`formData_${this.props.from}`];
    const { readonly } = this.props;
    if (readonly && !dispatcherInfoList?.length) {
      // 在修改 只读模式下，如果多选调度员没有数据，使用老调度员字段
      const { dispatcherId, dispatcherName, dispatcherPhone, remainDispatchNumber } = this.props.store[`formData_${this.props.from}`];
      dispatcherInfoList = [
        {
          dispatcherId: dispatcherId || null, // 调度员id
          dispatcherName: dispatcherName || null, // 调度员姓名
          dispatcherPhone: dispatcherPhone || null, // 调度员手机号
          remainDispatchNumber: remainDispatchNumber || null, // 调度员扣减次数
        },
      ];
    } else {
      dispatcherInfoList = dispatcherInfoList || [];
    }

    const list = dispatcherInfoList?.slice(0, 3) || [];
    const textList = [];
    for (const index in list) {
      const item = list[index];
      if (Number(index) > 0) {
        textList.push(
          <MBText color={readonly ? 'placeholder' : '#666'} style={{ marginHorizontal: 4 }}>
            /
          </MBText>
        );
      }
      textList.push(
        <MBText color={readonly ? 'placeholder' : '#666'} numberOfLines={1} style={{ flexShrink: 1 }}>
          {item.dispatcherName}
        </MBText>
      );
    }
    if (dispatcherInfoList.length > 3) {
      textList.push(<MBText color={readonly ? 'placeholder' : '#666'}> {dispatcherInfoList.length}人</MBText>);
    }
    return (
      <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end', paddingRight: 8, alignItems: 'center' }}>
        {dispatcherInfoList.length ? textList : <MBText color="placeholder">{this.props.placeholder}</MBText>}
      </View>
    );
  }
  // 单选显示的文本
  get singledInfoText(): React.ReactNode {
    const { dispatcherName } = this.props.store[`formData_${this.props.from}`];
    const { readonly, placeholder } = this.props;
    return (
      <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end', paddingRight: 8 }}>
        {!!dispatcherName ? (
          <MBText numberOfLines={1} style={{ flex: 1, textAlign: 'right' }} color={readonly ? 'placeholder' : 'base'}>
            {dispatcherName}
          </MBText>
        ) : (
          <MBText color="placeholder">{placeholder}</MBText>
        )}
      </View>
    );
  }
  render(): React.ReactNode {
    const { isRulesTips, required, readonly, isSingleChoice, title, showPhoneNumber } = this.props;
    const { dispatcherId } = this.props.store[`formData_${this.props.from}`];
    const { showModal, dispatcherList, errorText, loading, showOrgName, consignorContactEnable } = this.state;
    return (
      <>
        <Cell
          title={title}
          align="right"
          rightTag={isSingleChoice ? this.singledInfoText : this.dispatcherInfoListText}
          placeholder=""
          numberOfLines={1}
          readonly={readonly}
          onPress={() => this.openModal(true)}
          bottomLine={true}
          required={!!required}
          onReadOnlyPress={this.toastNotEdit.bind(this, '调度员')}
          extra={
            isRulesTips &&
            !dispatcherId && (
              <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                <MBText size="xs" color="#F54242" align="right">
                  调度员未填
                </MBText>
                <Whitespace vertical={12} />
              </View>
            )
          }
        />
        {isSingleChoice ? (
          <SingleSelectdispatcherModal
            visible={showModal}
            onChange={(list: any[]) => this.changeSingleModal(list)}
            list={dispatcherList}
            noDataText={errorText[1] || errorText[0]}
            loading={loading}
            showOrgName={showOrgName}
            selectedId={dispatcherId}
            showPhoneNumber={showPhoneNumber && !!consignorContactEnable}
          />
        ) : (
          <SelectdispatcherModal
            visible={showModal}
            onChange={(list: any[]) => this.changeModal(list)}
            list={dispatcherList}
            noDataText={errorText[1] || errorText[0]}
            loading={loading}
            showOrgName={showOrgName}
            showPhoneNumber={showPhoneNumber && !!consignorContactEnable}
          />
        )}
      </>
    );
  }
}
