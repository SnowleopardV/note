import * as React from 'react';
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Theme, Modal, MBText, Whitespace } from '@ymm/rn-elements';
import { MBToast } from '@ymm/rn-lib';
import images from '../../../../public/static/images/index';
import API from '~/pages/dispatch/api';

// 选择发票类型 模态框
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectItem: {
    color: Theme.color_primary,
    height: 88.5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    padding: 10,
  },
  selected: {
    borderColor: '#4885FF',
    backgroundColor: '#E4EDFF',
    borderWidth: 1,
    borderRadius: 4,
  },
});

interface InvoiceTypeProps {
  visible?: boolean;
  onChange?: any;
  id?: number;
  setInvoiceMap?: any;
  isGeneralInvoiceEnable?: boolean;
  toastContent?: any;
  dispatcherMode?: number;
  isMybAuth?: boolean;
}

export default class ModalInvoiceType extends React.Component<InvoiceTypeProps, any> {
  constructor(props: InvoiceTypeProps) {
    super(props);
    this.state = {
      id: props.id,
      invoiceType: [] // 发票类型集合
    };
  }
  componentDidMount(): void {
    // 获取发票类型
    this.getInvoiceType();
  }
  componentWillReceiveProps(next: any) {
    if (next.visible) {
      this.setState({ id: next.id });
    }
  }
  /** 获取发票类型 **/
  async getInvoiceType(): Promise<void> {
    const data = (await API.getInvoiceType()).data;
    const { dispatcherMode } = this.props;
    let temArr:any;
    if (dispatcherMode === 4) {
      // 满帮找车时的发票类型
      temArr = data.findTruckList && data.findTruckList.length > 0 ? data.findTruckList : [];
    } else if (dispatcherMode === 3) {
      // 外调车时的发票类型
      temArr = data.taskInvoiceList && data.taskInvoiceList.length > 0 ? data.taskInvoiceList : [];
    }
    this.setState({invoiceType : temArr});

    let names: Array<string> = [];
    temArr.forEach((item: any) => {
      names.push(item.invoiceName);
    });
    const { setInvoiceMap } = this.props;
    setInvoiceMap && setInvoiceMap(names);
  }
  onPress(id: number) {
    this.setState((state: { id: number }) => ({ id: state.id === id ? 0 : id }));
  }
  handleConfirm = () => {
    const { onChange, isGeneralInvoiceEnable, isMybAuth, toastContent } = this.props;
    const { id } = this.state;
    onChange && onChange(id);
    if (id === 2 && !isGeneralInvoiceEnable && isMybAuth) {
      MBToast.show(toastContent);
    }
  };
  handleCancel = () => {
    const { onChange, id } = this.props;
    onChange && onChange(id);
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { id, invoiceType } = this.state;
    return (
      <Modal
        animationType="slide"
        headerLeft="取消"
        headerRight={this.rightElement()}
        title="选择发票类型"
        position="bottom"
        visible={visible}
        headerLine={false}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        <Whitespace vertical={10} />
        {invoiceType.map((item: any) => {
          return (
            <TouchableOpacity
              key={item.invoiceId}
              style={[styles.selectItem, id === item.invoiceId && styles.selected]}
              onPress={this.onPress.bind(this, item.invoiceId)}
            >
              <View style={{ flex: 1 }}>
                <View style={styles.flexRow}>
                  <MBText color="#333333" size="md" style={{ fontWeight: '700' }}>
                    {item.invoiceName}
                  </MBText>
                  {
                    item.invoiceIconPicUrl && item.invoiceIconPicUrl.length > 0 ?
                    <Image style={{ width: item.invoiceId === 1 ? 83.57 : 49.5, height: 18, marginLeft: 10 }} source={{ uri: item.invoiceIconPicUrl }} /> : null
                  }
                </View>
                <MBText color="#666666" style={{ marginTop: 6 }}>
                  {item.invoiceDescription}
                </MBText>
              </View>
              <View style={{ width: 14, height: 8.5, marginLeft: 14 }}>
                {id === item.invoiceId && <Image style={{ width: 14, height: 8.5 }} source={images.icon_check_mark} />}
              </View>
            </TouchableOpacity>
          );
        })}
        <Whitespace vertical={20} />
      </Modal>
    );
  }
}
