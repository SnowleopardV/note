import * as React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { Modal, MBText } from '@ymm/rn-elements';

const { height } = Dimensions.get('window');
//分摊策略 提示框
const styles = StyleSheet.create({
  column: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  modalheight: {
    maxHeight: Number((height * 0.9).toFixed(0)),
    paddingVertical: 30,
    paddingHorizontal: 10,
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
}

export default class ModalStrategy extends React.Component<Props, any> {
  constructor(props: Props) {
    super(props);
    this.state = {};
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    onChange && onChange(true);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  render() {
    const { visible } = this.props;
    return (
      <Modal
        headerLine={false}
        position="center"
        confirmText="知道了"
        visible={visible}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        <View style={styles.modalheight}>
          <MBText size="md">分摊策略用于将合计运费按分摊策略分摊到运单里，以便算出每个运单的利润{'\n'}</MBText>
          <MBText size="md">
            按运单数分摊：{'\n'}按照单据里包含的运单数量平均分配的合计运费。{'\n'}
          </MBText>
          <MBText size="md">
            按件数分摊：{'\n'}按照每个运单里的件数的占比来分摊合计运费。{'\n'}
          </MBText>
          <MBText size="md">
            按重量分摊：{'\n'}按照每个运单里的重量的占比来分摊合计运费。{'\n'}
          </MBText>
          <MBText size="md">按体积分摊：{'\n'}按照每个运单里的体积的占比来分摊合计运费。</MBText>
        </View>
      </Modal>
    );
  }
}
