import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Modal, Whitespace, TagGroup, Tag, MBText } from '@ymm/rn-elements';

// 是否跟车 模态框
const styles = StyleSheet.create({
  from: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  item: {
    width: 400,
  },
});

interface FollowCarProps {
  visible?: boolean;
  onChange?: any;
}

export default class ModalFollowCar extends React.Component<FollowCarProps, any> {
  constructor(props: FollowCarProps) {
    super(props);
    this.state = {
      current: 1, // 当前选择的 0 无 1：不跟车 2： 1人跟车 3：2人跟车
      list: [
        { id: 1, name: '不跟车' },
        { id: 2, name: '1人跟车' },
        { id: 3, name: '2人跟车' },
      ],
    };
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { list, current } = this.state;
    onChange && onChange(list.find((item: any) => item.id === current));
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  // 改变选择
  handleChange = (val: any) => {
    console.log(val);
    this.setState({ current: val.id });
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { list, current } = this.state;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerLine={false}
          headerRight={this.rightElement()}
          title="是否跟车"
          position="bottom"
          visible={visible}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <View style={styles.from}>
            <Whitespace vertical={10} />
            <TagGroup
              defaultSelected={list.filter((item: any) => item.id === current).map((item: any) => item.id)}
              rowId="id"
              space={10}
              rowSize={3}
              autoCollapse
              onPress={this.handleChange}
            >
              {list.map((item: any) => {
                return (
                  <Tag key={item.id} item={item}>
                    {item.name}
                  </Tag>
                );
              })}
            </TagGroup>
            <Whitespace vertical={20} />
            <MBText color="#999999" size="xs">
              跟车有可能导致人身伤害，满帮作为专业货运平台，对人生安全的保障能力有限，强烈建议您请勿跟车。如您坚持选择跟车的，满帮将会在能力方位内提供相应安全保护措施
            </MBText>
          </View>
          <Whitespace vertical={116} />
        </Modal>
      </View>
    );
  }
}
