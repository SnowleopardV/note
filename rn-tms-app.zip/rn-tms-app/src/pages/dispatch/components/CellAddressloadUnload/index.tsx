import React, { PureComponent } from 'react';
import { Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText, RNElementsUtil, Whitespace } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import Images from '../../../../../public/static/images/index';
import { tmsLoadUnload } from '../../PropTypes';
import ModalAddresslist from './ModalAddresslist';
import API from '../../api';
import { MBLog } from '@ymm/rn-lib';
/**
 * 多装多卸 两装两卸
 */
export interface Props {
  tmsLoadUnloads: Array<any>;
  required?: boolean; // 是否必选
  store?: any;
  readonly?: boolean; // 只读 文字置灰
  isRulesTips?: boolean; // 是否进行验证提示
  $parent?: any; // 父级对象
  otherNode?: React.ReactNode;
  topNode?: React.ReactNode;
  sensitiveWordList?: any;
}
const tmsLoadUnloadsItem = {
  contactId: null, // 联系人id
  contactName: null, // 联系人姓名
  contactPhone: null, // 联系人电话
  districtCode: null, // 区code
  districtName: null, // 区名称
  provinceCode: null, // 省code
  provinceName: null, // 省名称
  cityCode: null, // 市code
  cityName: null, // 市名称
  address: null, // 地址
  addressLongitude: null, // 经度
  addressLatitude: null, // 纬度
  addressMapType: 2, // 地图类型：1-百度 2-高德
  loadType: null, // 装卸类型 1:装货 2:卸货
};
@inject('store')
@observer
export default class CellAddressloadUnload extends PureComponent<Props, any> {
  static defaultProps = {
    readonly: false,
    required: false,
  };
  $parent: any;
  apiTimer: any;
  refScrollView: any; // 键盘弹起用来滚动到特定的位置
  constructor(props: any) {
    super(props);
    this.$parent = this.props.$parent;
    this.state = {
      addressList: [], // 搜索出来的地址
      searchAddressLoading: false,
      addressValue: '', // 用来在选择地址列表中高亮填写地址
      inputLayout: null, // 聚焦的输入框布局信息
      addressLayout: null, // 聚焦的输入框布局信息
      isAddressChanged: false,
      focusIndex: null, // 当前聚焦的输入框下标
      focusType: null, // 当前聚焦的输入框下标 装：1 卸：2
    };
  }

  componentDidMount() {
    const { tmsLoadUnloads } = this.props;
    this.initData(tmsLoadUnloads);
  }

  /** 初始化地址 */
  initData(tmsLoadUnloads: tmsLoadUnload[]) {
    if (tmsLoadUnloads?.length) {
      // 检查装货地址 是否有值
      const isLoading = this.props.store.loadingList?.filter((item: tmsLoadUnload) => item.loadType == 1 && item.address);
      if (!isLoading?.length) {
        const loadingList = tmsLoadUnloads?.filter((item: tmsLoadUnload) => {
          item.val = item.address;
          return item.loadType == 1;
        });
        if (loadingList.length) {
          this.props.store.setLoadingUnloading(1, loadingList, -1);
        } else {
          // 如果没有找到值，就填入默认空值
          this.props.store.setLoadingUnloading(
            1, // 装
            [
              {
                ...tmsLoadUnloadsItem,
                loadType: 1, // 装卸类型 1:装货 2:卸货
              },
            ],
            -1 // 全覆盖
          );
        }
      }
      // 检查卸货地址 是否有值
      const isUnloading = this.props.store.unloadingList?.filter((item: tmsLoadUnload) => item.loadType == 2 && item.address);
      if (!isUnloading?.length) {
        const unloadingList = tmsLoadUnloads?.filter((item: tmsLoadUnload) => {
          item.val = item.address;
          return item.loadType == 2 && item.address;
        });
        if (unloadingList.length) {
          this.props.store.setLoadingUnloading(2, unloadingList, -1);
        } else {
          this.props.store.setLoadingUnloading(
            2, // 卸
            [
              {
                ...tmsLoadUnloadsItem,
                loadType: 2, // 装卸类型 1:装货 2:卸货
              },
            ],
            -1 // 全覆盖
          );
        }
      }
    }
  }

  api_addressAssociate(address: string) {
    clearTimeout(this.apiTimer);
    this.apiTimer = setTimeout(() => {
      this.setState({ searchAddressLoading: !!address });
      !!address &&
        API.addressAssociate({ keyWord: address, isNoNeedCode: true })
          .then((res: any) => {
            console.log('查询联想地址:', res);
            if (res?.data) {
              this.setState({
                isAddressChanged: true,
                addressList: res.data.map((item: any) => {
                  const { detailAddress, coordinate, ...restItem } = item;
                  const diffParams = {
                    address: detailAddress,
                    addressLongitude: coordinate.longitude, // 经度
                    addressLatitude: coordinate.latitude, // 纬度
                    addressMapType: 2,
                  };
                  return { ...restItem, ...diffParams };
                }),
              });
            }
          })
          .catch((err: any) => {
            MBLog.log({ message: '查询联想地址失败', err });
          })
          .finally(() => {
            this.setState({ searchAddressLoading: false });
          });
    }, 800);
  }
  changeText(text: any, item: any) {
    console.log(text);
    if (text != item.val) {
      item.val = text;
      this.setState({ addressValue: text });
      this.api_addressAssociate(text);
    }
  }
  titleElement = (isImg: boolean, type: number) => {
    if (isImg) {
      return (
        <Image
          style={[styles.itemIcon, { opacity: this.props.readonly ? 0.4 : 1 }]}
          source={{ uri: type === 1 ? Images.icon_shipper : Images.icon_consignee }}
        />
      );
    } else {
      return (
        <View style={[styles.itemIcon, { justifyContent: 'center', alignItems: 'center' }]}>
          <View
            style={[styles.point, { backgroundColor: type === 1 ? '#4885FF' : '#333333', opacity: this.props.readonly ? 0.4 : 1 }]}
          ></View>
        </View>
      );
    }
  };
  /**
   * 改变装卸货数组结构， 添加，删减
   */
  changeList(list: Array<tmsLoadUnload>, type: number, index: number) {
    if (this.props.readonly) return; // 只读下不操作
    if (list.length === 1) {
      // 加
      list.push({
        ...tmsLoadUnloadsItem,
        loadType: type, // 装卸类型 1:装货 2:卸货
      });
    } else {
      // 减
      list.splice(index, 1);
    }
  }
  // 选择框中选择的地址
  onSelect = (val: any) => {
    console.log('=====================选择框中选择的地址====================');
    console.log(val.item);
    const { loadingList, unloadingList } = this.props.store;
    const { focusIndex, focusType } = this.state;
    const addressKeyWord = this.state.addressValue;
    const { poiName, address } = val.item;
    const { sensitiveWordList } = this.props;

    this.setState({ isAddressChanged: false, addressValue: '' });
    const item = focusType === 1 ? loadingList[focusIndex] : unloadingList[focusIndex];
    item.val = val.item.address;

    let handleAddress = '';
    let isSensitiveWordpoiName = false;
    let isSensitiveWordAddress = false;
    if (poiName) {
      isSensitiveWordpoiName = sensitiveWordList.some((item: any) => {
        return poiName.includes(item);
      });
    }

    isSensitiveWordAddress = sensitiveWordList.some((item: any) => {
      return address.includes(item);
    });

    if (isSensitiveWordpoiName) {
      handleAddress = address;
    }

    if (isSensitiveWordAddress) {
      handleAddress = poiName;
    }

    if (!isSensitiveWordpoiName && !isSensitiveWordAddress) {
      /**
       * 1、poiName中包含检索值keyWord，选中值 = address + poiName
       * 2、poiName和detailAddress中都包含检索值keyWord，选中值 = detailAddress
       * 3、poiName中不包含检索值keyWord，选中值 = detailAddress
       */
      handleAddress = address;
      if (addressKeyWord && poiName && poiName.includes(addressKeyWord) && !address.includes(addressKeyWord)) {
        handleAddress = address + poiName;
      }
    }

    this.props.store.setLoadingUnloading(focusType, { ...item, ...val.item, address: handleAddress, val: handleAddress }, focusIndex);
  };

  onFocus(item: any, type: number, index: number) {
    const { addressLayout } = this.state;
    this.props.store.setShowFooterBtn(false);
    this.setState({ inputLayout: item.layout, focusIndex: index, focusType: type });
    const y = (addressLayout?.y + item.layout?.y - item.layout?.height).toFixed(0);
    this.refScrollView.scrollTo({ y: Number(y) }); // 滚动到底部
  }
  onBlur() {
    const { loadingList, unloadingList } = this.props.store;
    const { focusIndex, focusType } = this.state;
    const item = focusType === 1 ? loadingList[focusIndex] : unloadingList[focusIndex];
    item.val = item?.address;

    this.setState({ isAddressChanged: false, addressValue: '', inputLayout: null, focusIndex: null, focusType: null, addressList: [] });
    this.props.store.setShowFooterBtn(true);
  }
  extraNode = (list: Array<any>, type: number, index: number) => {
    return (
      <TouchableOpacity style={{ paddingLeft: 10 }} onPress={() => this.changeList(list, type, index)}>
        <Image
          style={[styles.icon, { opacity: this.props.readonly ? 0.4 : 1 }]}
          source={{ uri: list?.length === 1 ? Images.icon_plus_sign : Images.icon_del_circle }}
        />
      </TouchableOpacity>
    );
  };
  setRefPageScrollView(el: any): void {
    this.refScrollView = el;
    this.props.store.setRefPageScrollView(el);
  }
  setOnPagesScrollLayout(el: any): void {
    this.props.store.setOnPagesScrollLayout(el.nativeEvent);
  }
  setPageScrollHeight(el: any): void {
    this.props.store.setPageScrollHeight(el.nativeEvent.layout.height);
  }
  render() {
    const { readonly, store, topNode, otherNode, required, isRulesTips } = this.props;
    const { loadingList, unloadingList } = store;
    const { searchAddressLoading, addressList, addressValue, isAddressChanged, inputLayout, focusType } = this.state;
    return (
      <View style={{ flex: 1 }}>
        <ScrollView
          ref={(el) => this.setRefPageScrollView(el)}
          onScroll={(el) => this.setOnPagesScrollLayout(el)}
          onLayout={(el) => this.setPageScrollHeight(el)}
          scrollEnabled={!focusType}
          keyboardShouldPersistTaps="never"
          showsVerticalScrollIndicator={false}
          alwaysBounceVertical={false}
          nestedScrollEnabled={true}
          scrollEventThrottle={1000}
        >
          {topNode}
          <View
            onLayout={(el: any) => {
              this.setState({ addressLayout: el.nativeEvent.layout });
            }}
          />
          <CellGroup withBottomLine style={{ zIndex: 999999, position: 'relative' }}>
            {loadingList?.map((item: any, index: number) => {
              return (
                <View key={item.loadType + index} onLayout={(el: any) => (item.layout = el.nativeEvent.layout)}>
                  <InputItem
                    titleIcon={this.titleElement(!index, 1)}
                    style={{ flex: 1 }}
                    value={item.val}
                    onChangeText={(text: string) => this.changeText(text, item)}
                    placeholder="必填，请输入装货地址"
                    onReadOnlyPress={this.props.store?.toastNotEdit?.bind(this, '装货地址')}
                    blurOnSubmit={false}
                    bottomLine={true}
                    extraNode={this.extraNode(loadingList, 1, index)}
                    readonly={readonly}
                    editable={!readonly}
                    onFocus={() => this.onFocus(item, 1, index)}
                    onBlur={() => this.onBlur()}
                    extra={
                      isRulesTips &&
                      required &&
                      !item.val && (
                        <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                          <MBText size="xs" color="#F54242" align="right">
                            装货地址未填
                          </MBText>
                          <Whitespace vertical={12} />
                        </View>
                      )
                    }
                  />
                </View>
              );
            })}
            {unloadingList?.map((item: any, index: number) => {
              return (
                <View key={item.loadType + index} onLayout={(el: any) => (item.layout = el.nativeEvent.layout)}>
                  <InputItem
                    titleIcon={this.titleElement(!index, 2)}
                    style={{ flex: 1 }}
                    value={item.val}
                    onChangeText={(text: string) => this.changeText(text, item)}
                    placeholder="必填，请输入卸货地址"
                    blurOnSubmit={false}
                    bottomLine={true}
                    onReadOnlyPress={this.props.store?.toastNotEdit?.bind(this, '卸货地址')}
                    extraNode={this.extraNode(unloadingList, 2, index)}
                    readonly={readonly}
                    editable={!readonly}
                    onFocus={() => this.onFocus(item, 2, index)}
                    onBlur={() => this.onBlur()}
                    extra={
                      isRulesTips &&
                      required &&
                      !item.val && (
                        <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                          <MBText size="xs" color="#F54242" align="right">
                            卸货地址未填
                          </MBText>
                          <Whitespace vertical={12} />
                        </View>
                      )
                    }
                  />
                </View>
              );
            })}
          </CellGroup>
          {otherNode}
        </ScrollView>
        <ModalAddresslist
          addressValue={addressValue}
          isAddressChanged={isAddressChanged}
          searchLoading={searchAddressLoading}
          addressList={addressList}
          onSelect={this.onSelect}
          top={inputLayout?.height + inputLayout?.height}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  itemIcon: {
    width: autoFix(42),
    height: autoFix(42),
    marginRight: 14,
  },
  point: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  icon: {
    width: autoFix(40),
    height: autoFix(40),
  },
});
