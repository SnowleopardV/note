import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { MBText, Whitespace } from '@ymm/rn-elements';
import AddressList from '~/components/AddressList';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import LoadingView from '../LoadingView';

/**
 * 装卸货地址组件
 */

export interface StateAddressModel {
  districtCode: 0; // 区code
  districtName: ''; // 区名称
  provinceCode: 0; // 省code
  provinceName: ''; // 省名称
  cityCode: 0; // 市code
  cityName: ''; // 市名称
  address: ''; // 地址
  addressLongitude: '0'; // 经度
  addressLatitude: '0'; // 纬度
  addressMapType: 2; // 地图类型：1-百度 2-高德
}

interface ModalAddresslistProps {
  addressValue?: string;
  isAddressChanged?: boolean;
  searchLoading?: boolean;
  addressList: StateAddressModel[];
  top?: string; // 距离顶部距离
  onSelect: (data: any) => void;
}

const ModalAddresslist: React.FunctionComponent<ModalAddresslistProps> = (props) => {
  const { addressList, isAddressChanged, searchLoading, addressValue, top, onSelect } = props;
  return (
    <>
      {searchLoading ? (
        <View style={[styles.addressAssociate, { top: top || 0 }]}>
          <LoadingView size="small" />
        </View>
      ) : addressList.length && isAddressChanged && addressValue ? (
        <View style={[styles.addressAssociate, { top: top || 0 }]}>
          <AddressList inputText={addressValue} addressList={addressList} onSelect={(item) => onSelect({ item })} />
        </View>
      ) : isAddressChanged && addressValue ? (
        <View style={[styles.addressAssociate, { top: top || 0 }]}>
          <Whitespace vertical={14} />
          <MBText align="center" color="#ccc">
            无搜索结果
          </MBText>
        </View>
      ) : null}
    </>
  );
};

const styles = StyleSheet.create({
  addressAssociate: {
    position: 'absolute',
    left: autoFix(160),
    top: autoFix(320),
    width: autoFix(540),
    minHeight: autoFix(132),
    maxHeight: autoFix(532),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 5, height: 5 },
    shadowRadius: autoFix(20),
    elevation: 20,
    borderRadius: autoFix(8),
  },
});

export default ModalAddresslist;
