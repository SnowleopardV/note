import * as React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Selector, Modal, Flex, MBText, Whitespace } from '@ymm/rn-elements';
import keyMap from '../keyMap';
// 选择 分摊策略

interface Props {
  visible?: boolean;
  onChange?: any;
  id: number;
}
export default class SelectCarModal extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      index: 0,
      list: Object.keys(keyMap.allocationStrategyMap).map((key: string) => {
        const text = keyMap.allocationStrategyMap[key];
        return {
          text: text,
          id: key,
          content(selected: boolean) {
            return (
              <Flex direction="row" justify="center" align="center">
                <MBText bold={selected} color={selected ? 'primary' : 'base'} numberOfLines={1}>
                  {text}
                </MBText>
              </Flex>
            );
          },
        };
      }),
    };
  }
  componentWillReceiveProps(nextProps: any) {
    const { visible, id } = nextProps;
    if (visible) {
      for (const i in this.state.list) {
        console.log(this.state.list[i].id, id);
        if (this.state.list[i].id == id) {
          this.setState({ index: Number(i) });
          break;
        }
      }
    }
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { index, list } = this.state;
    onChange && onChange(list[index]);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleChange = (val: any) => {
    this.setState({ index: val });
  };
  goPages() {}
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { index, list } = this.state;
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请选择分摊策略"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row" justify="center" align="center">
            <Flex.Item key="time">
              <View style={{ flexDirection: 'column' }}>
                <Selector type={1} value={index} rowTitle="content" list={list} onChange={this.handleChange} />
              </View>
            </Flex.Item>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
