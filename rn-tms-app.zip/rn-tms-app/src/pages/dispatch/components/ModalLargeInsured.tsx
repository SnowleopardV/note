import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Modal, Whitespace, MBText, Flex, Checkbox, Splitline } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import { MBBridge, MBToast } from '@ymm/rn-lib';
import RegTest from '~/utils/RegTest';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NativeBridge from '~/extends/NativeBridge';
import filterFormat from '~/extends/filterFormat';

const FlexItem = Flex.Item;

const styles = StyleSheet.create({
  contentStyle: {
    paddingHorizontal: 0,
  },

  contentWrapperStyle: {
    width: '100%',
  },

  contentPaddingStyle: {
    paddingHorizontal: autoFix(32),
  },

  tipWrapper: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#FFFBE6',
    paddingHorizontal: autoFix(32),
    paddingVertical: autoFix(12),
  },

  topTextStyle: {
    color: '#FFBB44',
    fontSize: autoFix(26),
    marginLeft: autoFix(8),
    paddingRight: autoFix(16),
  },

  iconTip: {
    height: autoFix(30),
    width: autoFix(30),
  },

  selectedStyle: {
    borderColor: '#4885FF',
    backgroundColor: 'rgba(72, 133, 255, 0.2)',
  },

  titleStyle: {
    fontSize: autoFix(30),
    color: '#333',
    marginRight: autoFix(50),
  },

  textStyle: {
    fontSize: autoFix(26),
    color: '#999999',
  },

  selectedTextStyle: {
    color: '#4885FF',
  },

  inputItemContainer: {
    paddingLeft: 0,
    flex: 1,
  },

  inputItem: {
    paddingRight: 0,
  },

  inputStyle: {
    paddingTop: autoFix(20),
    paddingBottom: autoFix(20),
    paddingHorizontal: autoFix(32),
    backgroundColor: '#F6F6F6',
    borderRadius: autoFix(8),
  },

  confirmBtn: {
    height: autoFix(100),
    width: autoFix(100),
    justifyContent: 'center',
    alignItems: 'flex-end',
  },

  agreementStyle: {
    fontSize: autoFix(26),
  },

  insuredFeeWrapper: {
    marginTop: autoFix(36),
    paddingHorizontal: autoFix(32),
  },

  tipTitleStyle: {
    fontSize: autoFix(30),
    fontWeight: 'bold',
    color: '#333333',
  },

  insuredFeeStyle: {
    marginLeft: autoFix(12),
    fontSize: autoFix(30),
    fontWeight: 'bold',
    color: '#FF6969',
  },

  insuredFeeRateStyle: {
    marginLeft: autoFix(16),
    fontSize: autoFix(26),
    color: '#999999',
  },

  agreementTipWrapper: {
    position: 'relative',
  },

  toolTipWrapper: {
    backgroundColor: '#000000',
    borderRadius: autoFix(10),
    position: 'absolute',
    width: autoFix(500),
    height: autoFix(180),
    right: autoFix(-145),
    bottom: autoFix(34),
    padding: autoFix(20),
    opacity: 0.7,
    zIndex: 100,
  },

  toolTipText: {
    fontSize: autoFix(28),
    color: '#ffffff',
  },

  toolTipTriangle: {
    position: 'absolute',
    bottom: autoFix(-7),
    right: autoFix(148),
    borderStyle: 'solid',
    borderBottomColor: '#000000',
    borderBottomWidth: autoFix(16),
    borderLeftWidth: autoFix(16),
    borderLeftColor: 'transparent',
    transform: [{ rotate: '45deg' }],
  },

  iconTipStyle: {
    width: autoFix(24),
    height: autoFix(24),
  },
});

interface CargoInsuranceProps {
  visible?: boolean;
  onChange?: any;
  goodsPrice?: number; // 货物价值
  largeInsuranceRate?: any; // 大额保价费率
  largeInsuranceCost?: any; // 大额保价费
  hasLargeInsurance?: any; // 是否勾选大额保价
  cargoList?: any; // 货物数组
  checkLargeInsurance?: any;
  totalDeliveryFee?: any; // 应付运费
  readonly?: boolean; // 只读？
}

export default class ModalCargoInsurance extends React.Component<CargoInsuranceProps, any> {
  refInput: React.RefObject<any>;
  constructor(props: CargoInsuranceProps) {
    super(props);
    this.refInput = React.createRef();

    this.state = {
      goodsPrice: '',
      largeInsuranceCost: '',
      hasLargeInsurance: false,
      showAgreementTip: false,
    };
  }

  componentWillReceiveProps(nextProps: any) {
    const { visible, goodsPrice, largeInsuranceCost, hasLargeInsurance, readonly } = nextProps;
    if (visible) {
      setTimeout(() => {
        this.refInput.current?.focus();
      }, 300);
    }

    this.setState({
      goodsPrice: goodsPrice || goodsPrice == 0 ? goodsPrice : '',
      largeInsuranceCost: readonly ? (hasLargeInsurance ? largeInsuranceCost : null) : largeInsuranceCost,
      hasLargeInsurance,
    });
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { goodsPrice, largeInsuranceCost, hasLargeInsurance } = this.state;
    onChange && onChange({ goodsPrice, largeInsuranceCost, hasLargeInsurance });
  };

  handleCancel = () => {
    const { onChange, goodsPrice, largeInsuranceCost, hasLargeInsurance, readonly } = this.props;
    this.setState({
      goodsPrice, // 货物价值
      largeInsuranceCost,
      hasLargeInsurance,
    });
    if (!readonly && onChange) {
      onChange({ goodsPrice, largeInsuranceCost, hasLargeInsurance });
    } else if (readonly && onChange) {
      onChange();
    }
  };

  rightElement() {
    return (
      <TouchableOpacity onPress={this.handleConfirm}>
        <View style={styles.confirmBtn}>
          <MBText size="md" color="primary">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }

  onClickAgreement = () => {
    const { onChange } = this.props;
    onChange && onChange();
    const insuranceTermsUrl =
      'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=323&categoryId=234&userAgreement=true';
    NativeBridge.openWebViewPage(insuranceTermsUrl);
  };

  cancelChecked = () => {
    this.setState({
      hasLargeInsurance: false,
    });
  };

  clearLargeInsuranceCost = () => {
    this.setState({
      largeInsuranceCost: null,
    });
  };

  onChangeText = async (value: string) => {
    const { hasLargeInsurance } = this.state;
    const valueArr = value.split('.');

    if (valueArr[0].length > 7) return;
    if (!RegTest.twoPrecision(value) && value) return;

    const goodsPrice = value;

    this.setState({
      goodsPrice,
    });

    if (hasLargeInsurance) {
      const insuranceChecked = this.commonCheckInsurance(goodsPrice);
      if (!insuranceChecked) {
        return;
      }
    }
  };

  onChangeCheckedAgreement = async () => {
    const { goodsPrice, hasLargeInsurance } = this.state;
    const { readonly } = this.props;
    if (!readonly) {
      if (!hasLargeInsurance) {
        const insuranceChecked = await this.commonCheckInsurance(goodsPrice);
        if (!insuranceChecked) {
          return;
        }
      } else {
        this.clearLargeInsuranceCost();
      }
    } else {
      this.setState({ largeInsuranceCost: !hasLargeInsurance ? this.props.largeInsuranceCost : null });
    }
    this.setState({ hasLargeInsurance: !hasLargeInsurance });
  };

  commonCheckInsurance = (goodsPrice: any) => {
    const { cargoList, checkLargeInsurance, totalDeliveryFee } = this.props;
    let insuranceChecked = true;
    return new Promise(async (resolve, reject) => {
      if (cargoList && cargoList.length) {
        const keyWords = cargoList[0].cargoName;
        const checkData = await checkLargeInsurance({ keyWords, goodsValue: goodsPrice });

        this.setState({
          largeInsuranceCost: checkData.insuranceCost,
        });

        if (!checkData.checkFlag) {
          MBToast.show(checkData.respDesc);
          insuranceChecked = false;
          this.clearLargeInsuranceCost();
          this.cancelChecked();
        } else {
          if (!!totalDeliveryFee && totalDeliveryFee < 500) {
            MBToast.show('运费大于等于500元可享受保价运输服务');
            insuranceChecked = false;
            this.clearLargeInsuranceCost();
            this.cancelChecked();
          }
        }
      } else {
        MBToast.show('请如实规范填写货物名称');
        insuranceChecked = false;
        this.cancelChecked();
        this.clearLargeInsuranceCost();
      }

      resolve(insuranceChecked);
    });
  };

  onBlur = (value: string) => {
    this.setState({
      goodsPrice: value ? Number(value) : '',
    });
  };

  returnFloat = (value: any) => {
    let handleValue = (Math.round(parseFloat(value) * 100) / 100).toString();
    const s = handleValue.split('.');
    if (s.length == 1) {
      handleValue = handleValue + '.00';
      return handleValue;
    }
    if (s.length > 1) {
      if (s[1].length < 2) {
        handleValue = handleValue + '0';
      }
      return handleValue;
    }
  };

  onClickAgreementTip = () => {
    this.setState(({ showAgreementTip }: any) => ({
      showAgreementTip: !showAgreementTip,
    }));
  };

  render() {
    const { goodsPrice, hasLargeInsurance, largeInsuranceCost, showAgreementTip } = this.state;
    const { visible, largeInsuranceRate, readonly } = this.props;
    return (
      <Modal
        headerLeft="取消"
        headerLine={false}
        headerRight={this.rightElement()}
        title="保价运输服务"
        position="bottom"
        visible={visible}
        contentStyle={styles.contentStyle}
        autoAdjustPosition={true}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        <View style={styles.contentWrapperStyle}>
          {!readonly && (
            <>
              <Flex direction="row" style={styles.contentPaddingStyle}>
                <InputItem
                  ref={this.refInput}
                  style={styles.inputItemContainer}
                  styleItem={styles.inputItem}
                  inputStyle={styles.inputStyle}
                  titleStyle={styles.titleStyle}
                  title="货物价值(元)"
                  placeholder="请如实填写货物价值"
                  value={goodsPrice + ''}
                  keyboardType="numeric"
                  onChangeText={this.onChangeText}
                  onBlur={() => this.onBlur(goodsPrice)}
                  extraNode={<View></View>}
                />
              </Flex>
              <Splitline color="#E8E8E8" />
              <Whitespace vertical={12} />
            </>
          )}
          {readonly && <Whitespace vertical={20} />}
          <Flex direction="row" align="center" wrap="wrap" style={styles.contentPaddingStyle}>
            <Checkbox
              type="primary"
              size="sm"
              useState={false}
              checked={hasLargeInsurance}
              onChange={this.onChangeCheckedAgreement}
              style={{ alignItems: 'flex-start' }}
            >
              <Flex direction="row">
                <MBText color="#333333" size="sm">
                  保价运输服务
                </MBText>
              </Flex>
            </Checkbox>

            <MBText style={styles.agreementStyle} color="primary" onPress={this.onClickAgreement}>
              《保价运输条款》
            </MBText>

            <View style={styles.agreementTipWrapper}>
              {showAgreementTip ? (
                <View style={styles.toolTipWrapper}>
                  <MBText style={styles.toolTipText} color="#333333">
                    保价运输服务是满帮平台为满运宝企业客户提供的一项增值服务，客户购买保价运输服务，发生货损后，最高可获得200万元赔付
                  </MBText>
                  <View style={styles.toolTipTriangle}></View>
                </View>
              ) : null}

              <TouchableOpacity onPress={this.onClickAgreementTip}>
                <Image style={styles.iconTipStyle} source={images.icon_tips} />
              </TouchableOpacity>
            </View>
          </Flex>

          <Flex direction="row" justify="flex-start" style={styles.insuredFeeWrapper}>
            <FlexItem style={{ flexDirection: 'row', alignItems: 'center' }}>
              <MBText style={styles.tipTitleStyle}>保价费用</MBText>
              <MBText style={styles.insuredFeeStyle}>¥{largeInsuranceCost ? largeInsuranceCost : '0'}</MBText>
              <MBText style={styles.insuredFeeRateStyle}>
                保价费率：{largeInsuranceRate ? (readonly ? largeInsuranceRate : `${largeInsuranceRate}%`) : ''}
              </MBText>
            </FlexItem>
          </Flex>
          {readonly && (
            <View style={{ padding: autoFix(40) }}>
              <MBText color="#999999" size="xs">
                提示：协议签订完成后，会对保价运输费进行自动扣款，请保证账户余额充足。
              </MBText>
            </View>
          )}
          <Whitespace vertical={40} />
        </View>
      </Modal>
    );
  }
}
