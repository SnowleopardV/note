import React from 'react';
import { View, StyleSheet, Image, TouchableOpacity, Platform, BackHandler } from 'react-native';
import { MBText, RefreshList, Input } from '@ymm/rn-elements';
import { PlatformKit } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import verification from '~/extends/verification';
import NativeBridge from '~/extends/NativeBridge';
import API from './api';
import images from '~public/static/images';

// 承运司机 CarrierDriver
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    height: 36,
    width: 36,
    margin: 16,
    borderRadius: 100,
  },
  item: {
    flexDirection: 'row',
    flex: 1,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
    marginHorizontal: 10,
    backgroundColor: '#FFFFFF',
  },
  empty: {
    height: 600,
    alignContent: 'center',
    justifyContent: 'center',
  },
});

@inject('store')
@observer
export default class CarrierDriver extends React.Component<any, any> {
  backHandleListener: any;
  constructor(props: any) {
    super(props);
    const from = props.navigation.state.params.from;
    this.state = {
      from: from ? from.toString().slice(0, 1) : 3, // 来自哪个页面 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
      dispatcherId: props.navigation.state.params.dispatcherId, // 调度员Id
      list: [],
      searchText: '', // 搜索
      isEnd: true, // 是否加载结束
      loading: false,
    };
  }
  componentWillMount() {
    this.api_searchDriver();
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  // 司机列表
  api_searchDriver() {
    const { searchText, from, dispatcherId } = this.state;
    const form = {
      keyword: searchText ? searchText : null, // 搜索条件，现在只支持手机号码，并且不是模糊匹配
      dispatcherMode: from.toString(), // 调度方式 1：指派自有车 2：指派承运商 3：指派外调车 4：满帮找车
      invoiceFlag: '1', // 是否需要平台ETC取票  0：不开票 1：满帮专票
      dispatcherId: dispatcherId, // 调度员id
    };
    this.setState({ isEnd: false });
    return new Promise((resolve, reject) => {
      API.searchDriver(form)
        .then((res) => {
          console.log('司机列表', res);
          if (res.success && res.data) {
            this.setState({ list: res.data });
            resolve(res);
          } else {
            reject(res);
          }
        })
        .catch((err) => {
          reject(err);
        })
        .finally(() => {
          this.setState({ isEnd: true });
        });
    });
  }
  // 提交
  onSubmitEditing = () => {
    const { searchText } = this.state;
    if(searchText === ''){
      this.api_searchDriver()
    } else if (!verification.phone(searchText)) {
      NativeBridge.toast('手机号码格式不对');
    } else {
      this.api_searchDriver();
    }
  };

  onRefresh = () => {
    return this.api_searchDriver();
  };
  onLoadMore = () => {
    return new Promise((resolve) => {
      resolve();
    });
  };
  // 搜索手机号码
  onSearch = (val: string) => {
    console.log('val', val);
    if (val.length === 11) {
      console.log('开始搜索', val);
      this.setState({ searchText: val }, () => {
        this.api_searchDriver();
      });
    } else if (val.length > 11) {
      return;
    } else if (verification.number(val) || val === '') {
      this.setState({
        searchText: val,
      });
    }
  };
  onItem = (val) => {
    console.log(val);
    const from = this.props.navigation.state.params.from;
    const data = {
      carId: val.carId || null, // 车辆id
      carNo: val.carNo || null, // 车牌
      carType: val.carType || null, // 车型
      carLength: val.carLength || null, // 车长
      driverId: val.driverId || null, // 司机id
      driverName: val.driverName || null, // 司机姓名
      driverPhone: val.driverPhone || null, // 司机电话
    };
    this.props.store.setFormData(from, data); // 外调车 开票 表单
    this.props.navigation?.goBack();
  };
  getLayoutTypeForIndex = () => {
    return 220;
  };
  setLayoutForType = (type, dim) => {
    if (!dim.width || !dim.height) {
      dim.width = PlatformKit.Width;
      dim.height = type;
    }
  };
  renderItem = (item: any) => {
    return (
      <TouchableOpacity key={item.driverId} style={styles.item} onPress={this.onItem.bind(this, item)}>
        <Image resizeMode={'stretch'} source={{ uri: item.driverPhoto }} style={styles.avatar} />
        <View style={{ flex: 1 }}>
          <MBText>{item.driverName}</MBText>
          <View style={styles.flexRow}>
            <MBText size="xs" color="#999999">
              {item.carInfoForDisplay}
            </MBText>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <MBText bold color="#666" style={{ textAlign: 'center' }}>
          暂无数据
        </MBText>
      </View>
    );
  };
  render() {
    const { list, isEnd, searchText } = this.state;
    return (
      <View style={{ flex: 1 }}>
        <NavBar
          title="承运司机"
          leftClick={() => {
            this.props.navigation?.goBack();
          }}
        />
        <View style={{ backgroundColor: '#FFFFFF', paddingHorizontal: 20, paddingBottom: 10 }}>
          <View style={[{ backgroundColor: '#F0F0F0', borderRadius: 50 }, styles.flexRow]}>
            <TouchableOpacity onPress={this.onSubmitEditing}>
              <Image resizeMode={'stretch'} source={{ uri: images.icon_input_search }}style={{ width: 17, height: 17, marginHorizontal: 15 }}/>
            </TouchableOpacity>
            <Input
              value={searchText}
              onChangeText={this.onSearch}
              style={{ flex: 1, height: 40, marginVertical: 0 }}
              placeholder="请输入司机手机号"
              keyboardType="numeric"
              returnKeyType={Platform.OS === 'ios' ? 'done' : 'search'}
              onSubmitEditing={this.onSubmitEditing}
              onBlur={this.onSubmitEditing}
            />
          </View>
        </View>
        <View style={{ flex: 1, paddingBottom: 20 }}>
          <RefreshList
            isEnd={isEnd}
            data={list}
            renderItem={(item: any) => this.renderItem(item)}
            emptyRender={this.renderEmpty}
            onRefresh={this.onRefresh}
            onLoadMore={this.onLoadMore}
            getLayoutTypeForIndex={this.getLayoutTypeForIndex}
            setLayoutForType={this.setLayoutForType}
          />
        </View>
      </View>
    );
  }
}
