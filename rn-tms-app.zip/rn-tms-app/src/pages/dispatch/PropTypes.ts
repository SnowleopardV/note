export interface PageProps {
  openTypeModal: any; // 打开调度方式选择弹窗
  store?: any;
  navigation: any;
  screenProps?: any;
}

export interface AssociateResponseParams {
  poiName: string;
  provinceName: string;
  provinceCode: number;
  cityName: string;
  cityCode: string;
  districtName: string;
  districtCode: number;
  regionAddress: string;
  streetAddress: string;
  regionAddressWithSpace: string;
  address: string;
  addressLongitude: string; // 经度
  addressLatitude: string; // 纬度
}

export interface tmsLoadUnload {
  contactId: string | number | null; // 联系人id
  contactName: string | null; // 联系人姓名
  contactPhone: string | number | null; // 联系人电话
  districtCode: string | number | null; // 区code
  districtName: string | null; // 区名称
  provinceCode: string | number | null; // 省code
  provinceName: string | null; // 省名称
  cityCode: string | number | null; // 市code
  cityName: string | null; // 市名称
  address: string | null; // 地址
  addressLongitude: string | number | null; // 经度
  addressLatitude: string | number | null; // 纬度
  addressMapType: number; // 地图类型：1-百度 2-高德
  loadType: number; // 装卸类型 1:装货 2:卸货
  val?: string | null; // 临时字段用于搜索
  focus?: boolean | null; // 临时字段用于搜索
  layout?: any;
}

export interface AssociateRequestParams {
  keyWord: string;
  isNoNeedCode: boolean;
}

export interface addressRequiredConfigModel {
  loadAddressConfig: boolean;
  unloadAddressConfig: boolean;
}

/**
 * 多选调度员
 */
export interface dispatcherInfo {
  dispatcherId: string;
  dispatcherPhone: string;
  dispatcherName: string;
}
