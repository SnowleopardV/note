import { observable, action } from 'mobx';
import { AssociateResponseParams, AssociateRequestParams, addressRequiredConfigModel, tmsLoadUnload } from './PropTypes';
import API from './api';
import xyMath from '~/extends/xyMath';
import { MBLog, MBToast } from '@ymm/rn-lib';
import { Modal } from '@ymm/rn-elements';
import server from '~/server';
import keyMap from './keyMap';
import filterFormat from '~/extends/filterFormat';
import { Platform } from 'react-native';
import { xyzMath } from '~/utils/xyzMath';
/**
 *  公共stroe, 用于管理：创建调度、修改调度、配置调度 状态，请不要把私有状态放到该文件下
 */
export const formData = {
  dispatcherMode: 1, // 调度方式 1：指派自有车 2：指派承运商 3：指派外调车 4：满帮找车
  driverId: null, // 司机id
  driverName: null, // 司机姓名
  driverPhone: null, // 司机电话
  carId: null, // 车辆id
  carNo: null, // 车牌
  carType: null, // 车型，1平板、2高栏、3厢式、4集装箱、5全封闭、6特种、7危险品、8自卸、9冷藏、10保温、11沙石、12高低板、13面包车、14棉被车、15爬梯车、16飞翼车、17依维柯、99其他
  carLength: null, // 车长，1：1.8、2：2.7、3：3.8、4：4.2、5：5、6：6.2、7：6.8、8：7.7、9：8.2、10：8.7、11：9.6、12：11.7、13：12.5、14：13、15：13.7、16：15、17：16、18：17.5
  feeDetails: [
    // {
    //   feeCode: null, // 费用类型，0 运费 1：装卸费 8：保险费 14：路桥费 16：住宿费 7 其他费 12（油费）
    //   amount: null, // 费用金额
    // },
  ], //费用信息
  remark: null, // 备注
  carrierId: null, // 承运商id
  carrierName: null, // 承运商名称
  settlementList: [
    // {
    //   settleType: null, // 1：现付；2：到付;3：回付 4:月结 5：油卡
    //   amount: null, // 金额
    //   oilCardId: null, // 油卡id
    //   recieveDeposit: null, // 油卡押金
    // },
  ], // 付费方式
  invoiceFlag: null, // 开票信息, 0不开票 1开专票
  dispatcherId: null, // 调度员id
  dispatcherName: null, // 调度员姓名
  dispatcherPhone: null, // 调度员手机号
  remainDispatchNumber: null, // 调度员扣减次数
  dispatcherInfoList: [
    // {
    //   dispatcherId: null, // 调度员id
    //   dispatcherName: null, // 调度员姓名
    //   dispatcherPhone: null, // 调度员手机号
    // },
  ], // 多选调度员
  deliverymanType: null, // 是否跟车, 0:不跟车 1:1人跟车 2:2人跟车
  shortcut: null, // 快捷标签(1：三不超 2：需雨布 3：有禁区 4：需回单 5：需压车 6：禁止配货 7：全程高速 9：随时装 10：高价急走 11：绿通 12：到付 13：全部现金)
  deliveryFee: null, // 运费
  deliveryUnit: 1, // 运费单位(吨方趟,// 趟1,吨2,方3,件4,个5,台6,桶7)
  serviceFee: null, // 服务费,自动计算得出
  serviceFeeRate: null, // 服务费率
  technicalServiceFee: null, // 技术服务费
  electronicContractFee: null, // 电子协议费
  positionCheckFee: null, // 轨迹校验费
  technicalServiceRate: null, // 技术服务费率
  deposit: null, // 定金
  refundDeposit: null, // 定金是否退还，0:不退，1:退还
  paymentCircle: null, // 付款时间,默认30
  platformCarType: [], // 满帮找车车型多选,最多3个 枚举参考carType
  platformCarLength: [], // 满帮找车车长多选,最多3个
  auctionMode: null, // 是否智能调度找车,本期不做,参数预留
  id: null, // 运单表主键
  // taskNo: null, // 同pc端 -- 暂时无用
  loadTime: {
    // 预计装货时间
    startTimestamp: null, // 	选择区间的开始时间戳（弱关联不做强校验，方便问题定位）
    endTimestamp: null, // 选择区间的结束时间戳（弱关联不做强校验，方便问题定位）
    dateCode: null, // 一级日期枚举Code，日期的年月日（yyyyMMdd）
    timeInterval: null, // 	二级时间区间枚举
    hourPeriod: null, // 三级小时时段枚举
    displayValue: null, // 详情显示字段
  },
  unloadTime: {
    // 预计卸货时间，结构同loadTime
    startTimestamp: null,
    endTimestamp: null,
    dateCode: null,
    timeInterval: null,
    hourPeriod: null,
    displayValue: null,
  },
  chargeMileage: null, // 计费里程
  tmsLoadUnloads: [
    {
      contactId: null, // 联系人id
      contactName: null, // 联系人姓名
      contactPhone: null, // 联系人电话
      districtCode: null, // 区code
      districtName: null, // 区名称
      provinceCode: null, // 省code
      provinceName: null, // 省名称
      cityCode: null, // 市code
      cityName: null, // 市名称
      address: null, // 地址
      addressLongitude: null, // 经度
      addressLatitude: null, // 纬度
      addressMapType: 2, // 地图类型：1-百度 2-高德
      loadType: 1, // 装卸类型 1:装货 2:卸货
    },
    {
      contactId: null, // 联系人id
      contactName: null, // 联系人姓名
      contactPhone: null, // 联系人电话
      districtCode: null, // 区code
      districtName: null, // 区名称
      provinceCode: null, // 省code
      provinceName: null, // 省名称
      cityCode: null, // 市code
      cityName: null, // 市名称
      address: null, // 地址
      addressLongitude: null, // 经度
      addressLatitude: null, // 纬度
      addressMapType: 2, // 地图类型：1-百度 2-高德
      loadType: 2, // 装卸类型 1:装货 2:卸货
    },
  ], // 装卸货信息
  oilInfo: [
    // {
    //   id: null, // 油卡id
    //   recieveDeposit: null, // 押金
    // },
  ],
  totalVolume: null, // 总体积	从已选运单中找到最大的那个体积
  totalWeight: null, // 总重量 从已选运单中找到最大的重量
  orgId: null, // 所属组织 id
  orgName: null, // 所属组织 名称
  // 只在承运商下显示
  carrierInvoiceFlag: null, // 承运商是否开票标识，0：不开票；1：开票 只在承运商下显示
  taxWay: null, // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
  taxRate: null, // 税率 两位小数 只在承运商下显示
  taxFee: null, // 税金 单位分 只在承运商下显示
  platformTotalWeight: null, // 用于承载发往平台的货源的重量体积；
  platformTotalVolume: null, // 用于承载发往平台的货源的重量体积；
  platformTotalWeightMin: null, // 满帮货物最小重量
  platformTotalVolumeMin: null, // 满帮货物最小体积
  cargoDealMode: null, // 成交模式 BUYOUT=一口价,TEL=电议
};
class Store {
  // 指派自有车 -- 表单
  @observable formData_1: any = { ...formData, dispatcherMode: 1 };
  // 指派承运商 -- 表单
  @observable formData_2: any = { ...formData, dispatcherMode: 2 };
  // 指派外调车 -- 表单
  @observable formData_30: any = { ...formData, dispatcherMode: 3, invoiceFlag: 0 }; // 不开票
  @observable formData_31: any = { ...formData, dispatcherMode: 3, invoiceFlag: 1 }; // 专票、普票
  // 指派满帮找车 -- 表单
  @observable formData_4: any = { ...formData, dispatcherMode: 4, invoiceFlag: 1, cargoDealMode: 'TEL', transType: 1 }; // 不开票 / 专票

  @observable referPageName: string = ''; // 上一个页面名称
  // 搜索联想地址loading
  @observable searchAddressLoading: boolean = false;
  // 搜索联想地址
  @observable addressAssociateList: AssociateResponseParams[] = [];
  // 装卸货地址是否必需配置
  @observable addressRequiredConfig: addressRequiredConfigModel = {
    loadAddressConfig: false,
    unloadAddressConfig: false,
  };
  // 装货地址输入change标记
  @observable isLoadAddressChanged: boolean = false;
  @observable isAddressChanged_1: boolean = false;
  @observable isAddressChanged_2: boolean = false;
  @observable isAddressChanged_30: boolean = false;
  @observable isAddressChanged_31: boolean = false;
  @observable isAddressChanged_4: boolean = false;
  @observable isUnloadAddressChanged: boolean = false;
  // 外调车是否开票
  @observable isInvoiceOutboundCar: boolean = true;
  // 是否显示底部按钮
  @observable showFooterBtn: boolean = true;
  // 装卸货类型 装货：0，卸货：1
  @observable addressType: number = 0;
  defaultContact = {
    districtCode: null, // 区code
    districtName: null, // 区名称
    provinceCode: null, // 省code
    provinceName: null, // 省名称
    cityCode: null, // 市code
    cityName: null, // 市名称
    address: null, // 地址
    addressLongitude: null, // 经度
    addressLatitude: null, // 纬度
    addressMapType: 2, // 地图类型：1-百度 2-高德
    street: null, //四级地址
  };

  // 货物信息 -- 运单详情里取得
  @observable waybillDetails: any = {
    cargoList: [
      // {
      //   cargoName: '', // 货物名称
      //   volume: '100', // 货物体积，单位方
      //   weight: '2000000', //  货物重量，单位克
      //   cargoUnit: '', // 包装
      //   quantity: '', // 件数
      //   remark: '', // 备注
      // },
    ],
  };
  @observable formDataWaybill: any = null; // 创建运单表单
  @observable remainNumberInfo: any = {}; // 扣减发货次数
  @observable totalFee: string | number = 0; // 修改时需要在表单中传 费用合计
  @observable refScrollView: any = null; // 页面的 ScrollView 实例，用于在聚焦输入框时滚动到底部
  /** 用来标识 是否显示 cell */
  @observable showCellCostInput: any = {
    carrierInvoiceFlag: null, // 承运商是否开票标识，0：不开票；1：开票 只在承运商下显示
    taxWay: null, // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
    taxRate: null, // 税率 两位小数 只在承运商下显示
    taxFee: null, // 税金 单位分 只在承运商下显示
  };
  @observable loadingList: Array<tmsLoadUnload> = []; // 装货地址, 用于平台的多装多卸
  @observable unloadingList: Array<tmsLoadUnload> = []; // 卸货地址， 用于平台的多装多卸
  @observable batchDispatchFlag: number = 0; // 查询是否在批量调度白名单中（新增）不在白名单中 选择调度员使用单选弹窗，否则使用多选 0不显示调度员 1 单选 2多选
  @observable onPagesScrollLayout: any = null; // 查看滚动条位置
  @observable refPageScrollView: any = null; // 页面中的 Scroll, 可用来滚动页面
  @observable pageScrollHeight: number | null = null; // 页面中的 Scroll 的高度
  @observable showCellCargoDealMode: boolean = false; // 是否显示 成交方式 Cell // 调度方式 - 满帮找车 - 开票/不开票
  @observable cargoInsurance: any = null; // 货运险数据
  @observable cargoInsuranceTipText: any = ''; // 货运险提示文案
  @observable cargoInsurancePrice: any = ''; // 货运险货物价格
  @observable cargoInsuranceSelectItem: any = {
    cargoAmountNoticeConfig: {},
  }; // 货运险选中的保险
  @observable sensitiveWordList: any = []; // 敏感词汇集合

  @observable largeInsurancePrice: any = null; // 大额保价货物价格
  @observable largeInsuranceRate: any = null; // 大额保价费率
  @observable largeInsuranceCost: any = null; // 大额保价保费
  @observable hasLargeInsurance: any = false; // 是否勾选大额保价
  @observable largeInsuranceCheckData: any = null; // 校验大额保价内容结果

  @observable cargoList: any = []; // 货物数组
  @observable cargoDealModeList: any = [
    {
      value: 'TEL',
      label: '电议',
      disabled: false,
    },
    {
      value: 'BUYOUT',
      label: '一口价',
      disabled: false,
    },
  ]; // 成交方式数组，默认兜底成交类型

  @action setOnPagesScrollLayout(val: any): void {
    this.onPagesScrollLayout = val;
  }
  @action setRefPageScrollView(val: any): void {
    this.refPageScrollView = val;
  }
  @action setPageScrollHeight(val: any): void {
    this.pageScrollHeight = val;
  }
  /**
   * 查询是否在批量调度白名单中（新增），
   */
  @action getBatchDispatchFlag(loading: boolean) {
    API.getAppBusinessConfig(loading)
      .then((res: any) => {
        console.log('====================查询是否在批量调度白名单中=====================');
        console.log(res);
        this.batchDispatchFlag = res?.data?.batchDispatchFlag ? 2 : 1;
      })
      .catch((err: any) => {
        this.batchDispatchFlag = 1;
      });
  }

  /**
   * 修改 装货地址 卸货地址，
   * @param type 1 装货地址 2 卸货地址
   * @param data 要进行填充的数据
   * @param index 下标，如果是-1，就覆盖整个数组
   */
  @action setLoadingUnloading(type: number, data: any, index: number) {
    if (type == 1) {
      if (index == -1) {
        this.loadingList = data;
      } else {
        this.loadingList[index] = data;
      }
    } else if (type == 2) {
      if (index == -1) {
        this.unloadingList = data;
      } else {
        this.unloadingList[index] = data;
      }
    }
  }
  // 修改 费用合计
  @action setShowCellCostInput(data: any) {
    if (data) {
      this.showCellCostInput = {
        ...this.showCellCostInput,
        ...data,
      };
    } else {
      this.showCellCostInput = {
        carrierInvoiceFlag: null, // 承运商是否开票标识，0：不开票；1：开票 只在承运商下显示
        taxWay: null, // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
        taxRate: null, // 税率 两位小数 只在承运商下显示
        taxFee: null, // 税金 单位分 只在承运商下显示
      };
    }
  }

  // 修改 费用合计
  @action setTotalFee(data: any) {
    this.totalFee = data;
  }

  // 计算运费服务费
  @action api_serviceFee(type: number) {
    const {
      deliveryUnit,
      deliveryFee,
      dispatcherId,
      orgId,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
      invoiceFlag,
    } = this[`formData_${type}`];
    let serviceFeeTotal = 0;
    if (deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      serviceFeeTotal = xyMath.accMul(deliveryFee, weight); // 运费
    } else if (deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      serviceFeeTotal = xyMath.accMul(deliveryFee, volume); // 运费
    } else {
      // 趟
      serviceFeeTotal = deliveryFee; // 运费
    }
    serviceFeeTotal = Number(Number(serviceFeeTotal).toFixed(2));
    const data = {
      freightFee: serviceFeeTotal, // 运费（分）
      dispatcherId: dispatcherId, // 调度员ID
      orgId: orgId, // 所属组织
    };
    if (!serviceFeeTotal || invoiceFlag != 1) return;
    if (invoiceFlag === 1) {
      API.serviceFee(data).then((res: any) => {
        console.log('计算运费服务费', serviceFeeTotal, res);
        if (res.success) {
          this[`formData_${type}`].serviceFee = res.data.serviceFee;
          this[`formData_${type}`].serviceFeeRate = res.data.serviceFeeRate;
        }
      });
    } else if (invoiceFlag === 2) {
      API.calculateServiceFee({amount: data.freightFee}).then((res: any) => {
        if (res.success) {
          this[`formData_${type}`].technicalServiceFee = res?.data?.technicalServiceFee;
          this[`formData_${type}`].electronicContractFee = res?.data?.electronicContractFee;
          this[`formData_${type}`].positionCheckFee = res?.data?.positionCheckFee;
          this[`formData_${type}`].technicalServiceRate = res?.data?.technicalServiceRate;
        }
      });
    }
  }
  /** 平台找车需要这两个字段 【满帮货物重量】【满帮货物体积】 */
  @action platformWeightVolume() {
    const platformTotalWeight = this.computesWeight();
    const platformTotalVolume = this.computesVolume();
    const weightVolumeData = {
      platformTotalWeightMin: parseFloat(platformTotalWeight?.toFixed(2)) || null, // 用于承载发往平台的货源的重量体积；
      platformTotalVolumeMin: parseFloat(platformTotalVolume?.toFixed(2)) || null, // 用于承载发往平台的货源的重量体积；
    };
    return weightVolumeData;
  }
  // 计算 吨 合计
  @action computesWeight(): number {
    const { cargoList } = this.formDataWaybill || this.waybillDetails;
    let weight = '0';
    for (const item of cargoList) {
      if (item.weight) {
        weight = xyMath.accAdd(item.weight, weight);
      }
    }
    // 获取的是 吨
    return Number(weight);
  }
  // 计算 方 合计
  @action computesVolume(): number {
    const { cargoList } = this.formDataWaybill || this.waybillDetails;
    let volume = '0';
    for (const item of cargoList) {
      if (item.volume) {
        volume = xyMath.accAdd(item.volume, volume);
      }
    }
    return Number(volume);
  }

  // 调度0823修改

  // 处理【创建并调度】和【调度详情】带过来的装卸货地址
  @action
  handleContactList = (type: number, contactList: any) => {
    const tmsLoadUnloads = contactList.map((item: any, index: number) => {
      const { contactType, area, areaName, province, city, cityName, address, longitude, latitude, ...restItem } = item;
      const { loadAddressConfig, unloadAddressConfig } = this.addressRequiredConfig;
      const loadType = contactType || index + 1;
      const addressConfig = loadType === 1 ? loadAddressConfig : unloadAddressConfig;
      // 经纬度同时存在判断
      const longlatitudeFlag = longitude && longitude !== '0' && latitude && latitude !== '0';

      // 默认转换字段名称，并带入地址信息
      const diffParams = {
        districtCode: area || null,
        districtName: areaName,
        provinceCode: province || null,
        cityCode: city || null,
        cityName: cityName,
        address: address,
        addressLongitude: longitude,
        addressLatitude: latitude,
        addressMapType: 2,
        loadType,
      };

      let handleItem = { ...restItem, ...diffParams };

      // 处理不带入地址，并初始化地址字段
      // 1、指派自有车/指派承运商/指派外调车-不开票
      if (type == 1 || type == 2 || type == 30) {
        // 地址无经纬度 且 后台设置必须经纬度
        if (!longlatitudeFlag && addressConfig) {
          handleItem = { ...this.defaultContact, loadType };
        }
      } else {
        // 2、指派外调车开票/平台找车
        // 地址无经纬度
        if (!longlatitudeFlag) {
          handleItem = { ...this.defaultContact, loadType };
        }
      }
      return handleItem;
    });
    return tmsLoadUnloads;
  };

  // 初始化装卸货货地址
  @action
  initLoadUnloadAddress = (type: number, data: any) => {
    const formData = this[`formData_${type}`];
    const tmsLoadUnloads = this.handleContactList(type, data.contactList);

    this[`formData_${type}`] = { ...formData, ...{ tmsLoadUnloads } };
  };

  // 计算线路里程
  @action
  getCostMileage = async (dispatchType: number, params: any) => {
    const { loadLatitude, loadLongitude, unloadLatitude, unloadLongitude } = params;
    const handleParams = {
      loadAddressLatitude: loadLatitude.toString(),
      loadAddressLongitude: loadLongitude.toString(),
      unloadAddressLatitude: unloadLatitude.toString(),
      unloadAddressLongitude: unloadLongitude.toString(),
    };
    try {
      const url = '/saas-tms-trans/yzgApp/address/distance';
      const res = await server({ url, data: { ...handleParams } }, { showLoading: false });
      if (res.success) {
        this[`formData_${dispatchType}`].chargeMileage = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '查询线路里程失败',
        error,
      });
    }
  };

  // 获取是否必须经纬度开关
  @action
  getAddressConfig = async (showLoading: boolean = false) => {
    try {
      const url = '/saas-tms-trans/yzgApp/tenant/config/getAddressConfig';
      const res = await server({ url, data: {} }, { showLoading });
      if (res.success) {
        this.addressRequiredConfig = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '查询经纬度开关失败',
        error,
      });
    }
  };

  // 获取地址联想列表数据
  @action
  fetchAddressAssociate = async (params: AssociateRequestParams) => {
    try {
      this.searchAddressLoading = true;
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/address/associate',
          data: { ...params },
        },
        { showLoading: false }
      );
      if (res.success) {
        this.addressAssociateList = res.data.map((item: any) => {
          const { detailAddress, coordinate, ...restItem } = item;
          const diffParams = {
            address: detailAddress,
            addressLongitude: coordinate.longitude, // 经度
            addressLatitude: coordinate.latitude, // 纬度
            addressMapType: 2,
          };

          return { ...restItem, ...diffParams };
        });
      }
    } catch (error) {
      MBLog.log({
        message: '查询联想地址失败',
        error,
      });
    } finally {
      this.searchAddressLoading = false;
    }
  };

  // 装卸货地址输入变化
  @action onAddressInputChange = (value: boolean, index: number) => {
    if (!index) {
      this.isLoadAddressChanged = value;
    } else {
      this.isUnloadAddressChanged = value;
    }
  };

  // 清空联想地址列表数据
  @action
  clearAddressAssociateList = () => {
    this.addressAssociateList = [];
  };

  // 装卸货地址改变
  @action
  onChangeAddress = (data: any) => {
    const { value, addressType, dispatchType } = data;
    const { id } = this[`formData_${dispatchType}`].tmsLoadUnloads[addressType];
    const diffParams = {
      id,
      address: value,
      loadType: addressType + 1,
    };
    this[`isAddressChanged_${dispatchType}`] = true;

    this[`formData_${dispatchType}`].tmsLoadUnloads[addressType] = { ...this.defaultContact, ...diffParams };

    this.onAddressInputChange(true, addressType);

    if (!value) {
      this.clearAddressAssociateList();
      return;
    }

    this.fetchAddressAssociate({
      keyWord: value,
      isNoNeedCode: true,
    });
  };

  // 联想框选择地址,addressType: 0 装货，1 卸货
  @action
  onSelectAddressAssociate = (data: any) => {
    const { item, addressType, dispatchType } = data;
    const { id } = this[`formData_${dispatchType}`].tmsLoadUnloads[addressType];
    const diffParams = {
      id,
      loadType: addressType + 1,
    };
    this[`formData_${dispatchType}`].tmsLoadUnloads[addressType] = { ...item, ...diffParams };
    this[`isAddressChanged_${dispatchType}`] = true;
    // 重置isLoadAddressChanged,isUnloadAddressChanged
    this.onAddressInputChange(false, addressType);
    // 清空联想地址列表数据
    this.clearAddressAssociateList();
  };

  // 地址输入框聚焦
  @action
  onFoucsAddress = (data: any) => {
    const { addressType, dispatchType } = data;
    this.addressType = addressType;
    this.onAddressInputChange(true, addressType);

    const address = this[`formData_${dispatchType}`].tmsLoadUnloads[addressType]?.address;
    this.showFooterBtn = false;
    if (!this.addressAssociateList.length && address) {
      this.fetchAddressAssociate({
        keyWord: address,
        isNoNeedCode: true,
      });
    }
  };
  showFooterBtnTimer: any = null;
  // 底部按钮区 显隐藏
  @action setShowFooterBtn(val: boolean, isScrollToEnd: boolean) {
    clearTimeout(this.showFooterBtnTimer);
    this.showFooterBtnTimer = setTimeout(() => {
      this.showFooterBtn = val;
      if (!val) {
        if (Platform.OS === 'ios' && isScrollToEnd) {
          this.refScrollView?.scrollToEnd(); // 滚动到底部
        }
      }
    }, 60);
  }

  // 地址输入框失焦
  @action
  onBlurAddress = (data: any) => {
    const { addressType } = data;
    this.onAddressInputChange(false, addressType);
    this.clearAddressAssociateList();
    this.showFooterBtn = true;
  };

  // 记录外调车是否开票
  @action
  onInvoiceOutboundCar = (value: boolean) => {
    this.isInvoiceOutboundCar = value;
  };

  // 调度时强弱阻断提示
  showConfirmModal = (tips: string) => {
    Modal.Alert({
      title: '提示',
      content: tips,
      buttonText: '知道了',
    });
  };

  // 强弱阻断
  showBlockTip = (res: any) => {
    if (res.data?.tipType === 'toast') {
      MBToast.show(res.data?.tips);
    }

    if (res.data?.tipType === 'frame') {
      this.showConfirmModal(res.data?.tips);
    }
  };

  // 获取车型
  @action api_getTruckTypeList() {
    // if (keyMap.carTypeList.length) {
    //   return Promise.resolve();
    // }
    return API.getTruckTypeList({ toPlatform: false, queryType: 2 })
      .then((res: any) => {
        console.log('----------------获取车型-------------------');
        if (res.success && res.data) {
          const carType: any = {};
          for (const item of res.data) {
            carType[item.typeId] = item.typeName;
          }
          keyMap.carType = carType; // 修改 枚举里的值
          keyMap.carTypeList = res.data; // 用于添加车辆时 选择车型顺序不变
        }
      })
      .catch((er) => MBLog.error(er));
  }
  // 获取车长
  @action api_getTruckLengthList(): Promise<any> {
    // if (keyMap.carLengthList.length) {
    //   return Promise.resolve();
    // }
    return API.getTruckLengthList({ toPlatform: false, queryType: 2 })
      .then((res: any) => {
        console.log('----------------获取车长-------------------');
        if (res.success && res.data) {
          const carLength: any = {};
          for (const item of res.data) {
            carLength[item.lengthId] = item.lengthName;
          }
          keyMap.carLength = carLength; // 修改 枚举里的值
          keyMap.carLengthList = res.data; // 用于添加车辆时 选择车型顺序不变
        }
        return res;
      })
      .catch((er) => MBLog.error(er));
  }
  // 获取平台车型
  @action api_getTruckTypePlateList(): Promise<any> {
    if (Object.keys(keyMap.carTypePlate).length) {
      return Promise.resolve();
    }
    return API.getTruckTypeList({ toPlatform: true, queryType: 1 })
      .then((res: any) => {
        console.log('----------------获取平台车型-------------------');
        if (res.success && res.data) {
          const carType: any = {};
          for (const item of res.data) {
            carType[item.typeId] = item.typeName;
          }
          keyMap.carTypePlate = carType; // 修改 枚举里的值
        }
      })
      .catch((er) => MBLog.error(er));
  }
  // 获取平台车长
  @action api_getTruckLengthPlateList(): Promise<any> {
    if (Object.keys(keyMap.carLengthPlate).length) {
      return Promise.resolve();
    }
    return API.getTruckLengthList({ toPlatform: true, queryType: 1 })
      .then((res: any) => {
        console.log('----------------获取平台车长-------------------');
        if (res.success && res.data) {
          const carLength: any = {};
          for (const item of res.data) {
            carLength[item.lengthId] = item.lengthName;
          }
          keyMap.carLengthPlate = carLength; // 修改 枚举里的值
        }
      })
      .catch((er) => MBLog.error(er));
  }
  // 获取可用的车型
  @action api_getTruckTypeAllList(): Promise<any> {
    if (Object.keys(keyMap.carTypeAll).length) {
      return Promise.resolve();
    }
    return API.getTruckTypeList({ toPlatform: false, queryType: 0 })
      .then((res: any) => {
        console.log('----------------获取可用的车型-------------------');
        if (res.success && res.data) {
          const carType: any = {};
          for (const item of res.data) {
            carType[item.typeId] = item.typeName;
          }
          keyMap.carTypeAll = carType; // 修改 枚举里的值
        }
      })
      .catch((er) => MBLog.error(er));
  }
  // 获取可用的车长
  @action api_getTruckLengthAllList(): Promise<any> {
    if (Object.keys(keyMap.carLengthAll).length) {
      return Promise.resolve();
    }
    return API.getTruckLengthList({ toPlatform: false, queryType: 0 })
      .then((res: any) => {
        console.log('----------------获取可用的车长-------------------');
        if (res.success && res.data) {
          const carLength: any = {};
          for (const item of res.data) {
            carLength[item.lengthId] = item.lengthName;
          }
          keyMap.carLengthAll = carLength; // 修改 枚举里的值
        }
      })
      .catch((er) => MBLog.error(er));
  }

  // 计算税金
  @action getTax(from: number) {
    // 根据 含税方式和税率 计算税金
    const formData = this[`formData_${from}`];
    const feeDetails = formData.feeDetails.filter((item: any) => item.amount);
    const totalFee = feeDetails.reduce((total: string, item: any) => {
      return item.isDeductionFee ? xyMath.subtr(total, item.amount) : xyMath.accAdd(total, item.amount);
    }, '0');
    const taxRate = formData?.taxRate;
    let taxFee = 0;
    if (formData?.taxWay == 1 && taxRate && totalFee > 0) {
      //含税价
      const T = xyMath.accMul(totalFee, taxRate);
      const D = xyMath.accAdd(100, taxRate);
      const data = xyMath.accDiv(T, D);
      taxFee = filterFormat.moneyDecFormat(data);
    } else if (formData?.taxWay == 2 && taxRate && totalFee) {
      // 不含税价
      const data = xyMath.accMul(totalFee, taxRate);
      taxFee = filterFormat.moneyDecFormat(filterFormat.moneyDecFormat(data));
    }
    console.log('===============计算税金=================', taxFee, totalFee, formData?.taxWay);

    formData.taxFee = taxFee;
  }

  // 获取免扣发货次数
  @action
  getRemainNumber = async (): Promise<void> => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/delivery/queryRemainNumber',
          data: {},
        },
        { showLoading: false }
      );

      if (res.success && res.data) {
        this.remainNumberInfo = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '获取免扣发货次数失败',
        error: error,
      });
    }
  };
  // 获取一口价露出开关配置
  @action
  cargoDealModeInit = (showLoading: boolean = false, toastError: boolean = false): void => {
    const cargoDealMode = this.formData_4.cargoDealMode;
    API.cargoDealModeInit(showLoading, toastError)
      .then((res: any) => {
        console.log('获取一口价露出开关配置', res);
        if (res.data) {
          this.showCellCargoDealMode = res.data.isShow; // 是否显示
          this.formData_4.cargoDealMode = cargoDealMode || res.data.value || 'TEL'; // BUYOUT=一口价,TEL=电议,SMART=智能成交
          if (res.data.options?.length) {
            this.cargoDealModeList = res.data.options; // 成交方式列表数据
          }
        }
      })
      .catch((err: any) => {
        console.log('获取一口价露出开关配置错误', err);
        this.showCellCargoDealMode = false; // 是否显示
        this.formData_4.cargoDealMode = cargoDealMode || 'TEL'; // BUYOUT=一口价,TEL=电议
      });
  };

  // 获取货运险
  @action
  getCargoInsuranceList = async (params: any): Promise<void> => {
    if (params.dispatcherId) {
      try {
        const res = await server(
          {
            url: '/saas-tms-trans/yzgApp/order/dispatch/insurance/list',
            data: { ...params },
          },
          { showLoading: false, toastError: false }
        );

        if (res.data) {
          const insurerList = res.data.insurerCurrentQuoteList;
          let remainTotalNum = null;
          if (insurerList) {
            remainTotalNum = this.computedInsurerList(insurerList);
          }
          this.cargoInsurance = { ...res.data, ...{ remainTotalNum: remainTotalNum } };
        }
      } catch (error) {
        MBLog.log({
          message: '获取货运险失败',
          error: error,
        });
      }
    } else {
      this.cargoInsurance = null;
    }
  };

  // 费用求和
  @action
  computedInsurerList = (data: any) => {
    return data.reduce((total: any, item: any) => {
      return xyzMath.add(total, item.remainQuota);
    }, 0);
  };

  // 获取大额保价费率
  @action
  getlargeInsuranceRate = async (): Promise<void> => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/insurance/large/insurance/rate',
          data: {},
        },
        { showLoading: false, toastError: false }
      );

      if (res.data) {
        this.largeInsuranceRate = res.data;
      }
    } catch (error) {
      MBLog.log({
        message: '获取大额保价费率失败',
        error: error,
      });
    }
  };

  // 查询敏感词数据
  @action
  getSystemInit = async () => {
    try {
      const res = await server(
        {
          url: '/saas-tms-trans/yzgApp/trans/system/init',
          data: {},
        },
        { showLoading: false }
      );
      if (res.success) {
        this.sensitiveWordList = res.data?.sensitiveWordList || [];
      }
    } catch (error) {
      MBLog.log({
        message: '查询敏感词数据失败',
        error: error,
      });
    }
  };

  // 用车方式枚举过滤
  filterTransType = (transType: any) => {
    let handleTransType;
    switch (transType) {
      case 1:
        handleTransType = '整车';
        break;
      case 2:
        handleTransType = '零担';
        break;
      default:
        handleTransType = '';
        break;
    }
    return handleTransType;
  };
}
export default Store;
