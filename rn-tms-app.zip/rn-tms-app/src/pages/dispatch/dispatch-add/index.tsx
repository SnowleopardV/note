import * as React from 'react';
import { View, Platform, SafeAreaView, ImageBackground, BackHandler } from 'react-native';
import { MBBridge, MBLog, App } from '@ymm/rn-lib';
import { LayProvider } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import Images from '../../../../public/static/images';
import API from '../api';
import ModalShuntingMethod from '../components/ModalShuntingMethod'; // 调度方式
import OwnCar from './OwnCar'; // 指派自有车
import Carrier from './Carrier'; // 指派承运商
import OutboundCar from './OutboundCar'; // 指派外调车
import PlatformFind from './Platform'; // 满帮找车
import IndexBackground from '../indexBackground'; // 背景 假页面
import LoadingView from '../components/LoadingView';

export interface Props {
  navigation?: any;
  screenProps?: any;
  store?: any;
}
@inject('store')
@observer
export default class DispatchList extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: Props) {
    super(props);
    this.state = {
      showTypeModal: true, // 显示调度选择弹窗
      type: 0, // 当前选择的调度类型 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
      loadingNum: 0, // 要等待车长和车型加载好，加载好就加1 到2就说明两个加载好了
    };
  }
  UNSAFE_componentWillMount() {
    const { id, sourcepagename, form } = this.props.screenProps;
    !!id && this.props.store.setOrderId(id, sourcepagename);
    if (form) {
      let data = {};
      try {
        data = JSON.parse(decodeURIComponent(form));
      } catch (error) {
        data = form;
      }
      this.props.store.setformDataWaybill(data);
      this.setState({ loadingNum: this.state.loadingNum + 1 });
    } else {
      this.api_dispatchDetail(id); // 获取运单详情
    }
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.goBack();
        return true;
      });
    }

    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  }

  componentDidMount() {
    const {
      store: { trackPageView, getAddressConfig, getlargeInsuranceRate, getSystemInit },
    } = this.props;
    // 记录PV埋点
    trackPageView();
    getAddressConfig();
    // 获取车型车长 三种状态的下的枚举值
    const list = [
      this.props.store.api_getTruckTypeList(),
      this.props.store.api_getTruckLengthList(),
      this.props.store.api_getTruckTypePlateList(),
      this.props.store.api_getTruckLengthPlateList(),
      this.props.store.api_getTruckTypeAllList(),
      this.props.store.api_getTruckLengthAllList(),
    ];
    Promise.all(list).finally(() => {
      this.setState({ loadingNum: this.state.loadingNum + 6 });
    });
    this.props.store.getBatchDispatchFlag(false); // 查询是否在批量调度白名单中
    getlargeInsuranceRate(); // 获取大额保价费率
    // 系统配置接口（包含查询敏感词数据）
    getSystemInit();
  }

  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  openTypeModal = (val: boolean) => {
    // 兼容iOS无法在有蒙层的时候关闭loading
    if (Platform.OS === 'ios') {
      MBBridge.ui.hideLoading({});
    }
    this.setState({ showTypeModal: val });
  };
  // 调度方式改变
  handleTypeChange = (val: number) => {
    // 兼容iOS无法在有蒙层的时候关闭loading
    if (Platform.OS === 'ios') {
      MBBridge.ui.hideLoading({});
    }
    this.setState({ showTypeModal: false });
    if (this.state.type === 0 && !val) {
      val = 4;
    }

    // 处理地址显示
    this.handleDefaultAddress(val);

    val && this.setState({ type: val });
  };

  // 处理地址显示
  handleDefaultAddress = (val: number) => {
    const {
      store: {
        formDataWaybill,
        waybillDetails,
        initLoadUnloadAddress,
        isAddressChanged_1,
        isAddressChanged_2,
        isAddressChanged_30,
        isAddressChanged_31,
        isAddressChanged_4,
      },
    } = this.props;
    // 切换调度方式时，展示装卸货默认值
    if (val) {
      const isLoadAddressChanged = this.props.store.isLoadAddressChanged;
      const isUnloadAddressChanged = this.props.store.isUnloadAddressChanged;
      if (isLoadAddressChanged) {
        this.props.store.isLoadAddressChanged = false;
      }
      if (isUnloadAddressChanged) {
        this.props.store.isUnloadAddressChanged = false;
      }

      // 均未做更改时，将初始地址的值带入，遵循默认显示规则
      if (!isAddressChanged_1 && !isAddressChanged_2 && !isAddressChanged_30 && !isAddressChanged_31 && !isAddressChanged_4) {
        if (formDataWaybill) {
          initLoadUnloadAddress(val, formDataWaybill);
        }
        // 装卸货改变后，不初始化装卸货默认值
        if (waybillDetails?.contactList) {
          initLoadUnloadAddress(val, waybillDetails);
        }
      }
    }
  };

  // 获取运单详情
  api_dispatchDetail(id: string) {
    if (!id) {
      MBLog.log('没有传单运单id');
      return;
    }
    API.dispatchDetail({ id: id })
      .then((res: any) => {
        console.log('-------------------获取运单详情------------------');
        if (res.success && res.data) {
          this.props.store.setWaybillDetails(res.data);
        }
      })
      .catch((er) => {
        if (er?.code === '900002') {
          const { sourcepagename } = this.props.screenProps;
          if (sourcepagename === 'waybill_list') {
            App.sendEvent('refreshWaybillListView', { isClose: true, currentIndex: 0 });
          }
          MBBridge.rnruntime.handlebackResult({});
          if (Platform.OS == 'ios') {
            setTimeout(() => {
              MBBridge.app.ui.closeWindow({});
            }, 300);
          }
        }
        MBLog.error(er);
      })
      .finally(() => {
        this.setState({ loadingNum: this.state.loadingNum + 1 });
      });
  }

  // 左上角返回键
  goBack = () => {
    this.props.store?.goBack();
  };
  listBox(type: number) {
    const { navigation, screenProps } = this.props;
    const { loadingNum } = this.state;
    if (loadingNum > 6) {
      switch (type) {
        case 1:
          return <OwnCar openTypeModal={this.openTypeModal} navigation={navigation} screenProps={screenProps} />;
        case 2:
          return <Carrier openTypeModal={this.openTypeModal} navigation={navigation} screenProps={screenProps} />;
        case 3:
          return <OutboundCar openTypeModal={this.openTypeModal} navigation={navigation} screenProps={screenProps} />;
        case 4:
          return <PlatformFind openTypeModal={this.openTypeModal} navigation={navigation} screenProps={screenProps} />;
        default:
          return <IndexBackground openTypeModal={this.openTypeModal} />;
      }
    } else {
      return <LoadingView />;
    }
  }
  public render() {
    const { showTypeModal, type } = this.state;
    return (
      <LayProvider theme="skyblue">
        <ImageBackground source={{ uri: Images.icon_bg_map }} style={{ flex: 1 }}>
          <NavBar title="调度" leftClick={this.goBack} />
          <View style={{ flex: 1 }}>{this.listBox(type)}</View>
        </ImageBackground>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
        <ModalShuntingMethod visible={showTypeModal} onChange={this.handleTypeChange} />
      </LayProvider>
    );
  }
}
