import { observable, action } from 'mobx';
import { Platform } from 'react-native';
import { MBToast, MBBridge, MBJournal, MBLog, App } from '@ymm/rn-lib';
import API from '../api';
import commonStore from '../commonStore'; // 公共stroe, 存放共有特性
import filterFormat from '~/extends/filterFormat';
class Store extends commonStore {
  constructor() {
    super();
  }
  @observable id: any = null; // 运单id
  @observable transOrderNo: any = null; // 运单号
  @observable isRequestFail: boolean = false; // 请求创建运单是否失败
  @observable getCreateOrganizeFail: boolean = false; // 请求创建运单时组织校验是否失败
  @observable vaildLimitFail: boolean = false; //校验权限是否失败
  @observable truckTypeModalVisible: boolean = false; // 用车类型

  // 修改 创建运单表单
  @action setformDataWaybill(data: any) {
    this.formDataWaybill = { ...data };
    this.initLoadUnloadAddress(1, data);
    this.initLoadUnloadAddress(2, data);
    this.initLoadUnloadAddress(30, data);
    this.initLoadUnloadAddress(31, data);
    this.initLoadUnloadAddress(4, data);
    this.setOrg(data);
    // 找到平台需要的总重量合体积
    const weightVolumeData = this.platformWeightVolume();
    this.setFormData(31, weightVolumeData);
    this.setFormData(4, weightVolumeData);
    this.vaildLimitFail = false;
    this.cargoList = data.cargoList;
  }
  // 修改 运单表主键
  @action setOrderId(data: any, referPageName: string) {
    this.id = data;
    this.referPageName = referPageName;
  }

  // 修改 运单详情
  @action setWaybillDetails(data: any) {
    this.waybillDetails = { ...this.waybillDetails, ...data };
    this.initLoadUnloadAddress(1, data);
    this.initLoadUnloadAddress(2, data);
    this.initLoadUnloadAddress(30, data);
    this.initLoadUnloadAddress(31, data);
    this.initLoadUnloadAddress(4, data);
    this.setOrg(data);
    // 找到平台需要的总重量合体积
    const weightVolumeData = this.platformWeightVolume();
    this.setFormData(31, weightVolumeData);
    this.setFormData(4, weightVolumeData);
    this.vaildLimitFail = false;
    this.cargoList = data.cargoList;
  }
  // 将获取到 所属组织 放入表单中
  setOrg(data: any) {
    data = {
      orgId: data?.orgId || null, // 所属组织 id
      orgName: data?.orgName || null, // 所属组织 名称
    };
    this.setFormData(1, data);
    this.setFormData(2, data);
    this.setFormData(30, data);
    this.setFormData(31, data);
    this.setFormData(4, data);
    this.getMybCompanyInfo(data?.orgId);
  }
  // 修改表单
  @action setFormData(type: number, data: any) {
    const formData = this[`formData_${type}`];
    return (this[`formData_${type}`] = {
      ...formData,
      ...data,
    });
  }

  @action trackPageView = () => {
    MBJournal.pageViewJournal({
      pageName: 'dispatch_create_edit',
      referPageName: this.referPageName || 'waybill_create_edit',
      extraDict: {},
    });
  };

  // 创建运单
  @action api_orderCreate(formData: any) {
    if (formData.id && formData.transOrderNo) {
      return API.orderUpdate(formData, false).then((res) => {
        return res;
      });
    } else {
      return API.orderCreate(formData, false).then((res) => {
        if (res.success) {
          MBJournal.tapJournal({
            elementId: 'create_success_waybill',
            pageName: 'dispatch_create_edit',
            referPageName: 'waybill_create_edit',
            extraDict: {
              waybill_id: res.data.id,
            },
          });
        }

        return res;
      });
    }
  }
  // 创建调度
  @action api_createDispatch(formData: any) {
    const data = {
      ...formData,
      loadTime: formData.loadTime.dateCode ? formData.loadTime : null,
      unloadTime: formData.unloadTime.dateCode ? formData.unloadTime : null,
      id: this.id,
      totalFee: this.totalFee,
      tmsLoadUnloads: formData.tmsLoadUnloads.map((item: any) => {
        const { layout, val, ...orther } = item;
        return orther;
      }),
    };
    if (data.dispatcherMode == 2) {
      data.taxWay = data.carrierInvoiceFlag == 1 ? data.taxWay : null; //
      data.taxRate = data.carrierInvoiceFlag == 1 ? data.taxRate : null; //
      data.taxFee = data.carrierInvoiceFlag == 1 ? filterFormat.moneyFormat(data.taxFee) : null; // 税金 单位分 只在承运商下显示
    } else if (data.dispatcherMode == 4) {
      data.serviceFee = data.invoiceFlag == 1 ? data.serviceFee : null; // 服务费,自动计算得出
      data.serviceFeeRate = data.invoiceFlag == 1 ? data.serviceFeeRate : null; // 服务费率
    }
    // 外调车-普票场景, 构造feeDetails数组
    if (data.invoiceFlag === 2 && data.dispatcherMode === 3) {
      data.feeDetails = [
        {
          feeCode: 40, // 技术服务费
          amount: data.technicalServiceFee,
        },
        {
          feeCode: 41, // 电子协议费
          amount: data.electronicContractFee,
        },
        {
          feeCode: 42, // 轨迹校验费
          amount: data.positionCheckFee,
        },
      ];
    }
    // 删除所有普票场景添加的几个费用项字段, 统一放到feeDetails数组
    delete data.technicalServiceFee;
    delete data.technicalServiceRate;
    delete data.electronicContractFee;
    delete data.positionCheckFee;
    // 普票且大额保价，则删除大额保价对应字段
    if (data.invoiceFlag === 2 && formData.insuranceType === 2) {
      delete data.insuranceType;
      delete data.goodsPrice;
      delete data.largeInsuranceCost;
      delete data.hasLargeInsurance;
    }
    return API.createDispatch(data).then((res) => {
      this.isRequestFail = false;
      return res;
    });
  }
  // 保存并使用
  @action createDispatch = async (type: number) => {
    const formData = this['formData_' + type];
    const loadLatitude = formData.tmsLoadUnloads[0]?.addressLatitude;
    const loadLongitude = formData.tmsLoadUnloads[0]?.addressLongitude;
    const unloadLatitude = formData.tmsLoadUnloads[1]?.addressLatitude;
    const unloadLongitude = formData.tmsLoadUnloads[1]?.addressLongitude;
    const { invoiceFlag } = formData;
    const { cargoInsuranceSelectItem, cargoInsurancePrice, cargoInsurance, largeInsurancePrice, largeInsuranceCost, hasLargeInsurance } =
      this;
    const minInsuranceAmount = cargoInsurance?.cargoInsuranceCheckAmountThreshold || 2;

    if (type === 4 || type === 31) {
      formData.version = '1.0';
      if (cargoInsurance?.remainTotalNum) {
        // 货运险
        if (
          (invoiceFlag && 0 < cargoInsurancePrice && cargoInsurancePrice <= minInsuranceAmount) ||
          (minInsuranceAmount < cargoInsurancePrice && cargoInsuranceSelectItem.companyName)
        ) {
          formData.goodsPrice = cargoInsurancePrice;
          formData.insuranceType = 1;
          formData.insureCompanyCode = cargoInsuranceSelectItem.companyName;
        } else {
          if (formData.goodsPrice) {
            delete formData.goodsPrice;
          }

          if (formData.insuranceType) {
            delete formData.insuranceType;
          }

          if (formData.insureCompanyCode) {
            delete formData.insureCompanyCode;
          }
        }
      } else {
        // 大额保价
        if (invoiceFlag && hasLargeInsurance) {
          formData.goodsPrice = largeInsurancePrice; // 大额保价货物价格
          formData.largeInsuranceCost = largeInsuranceCost; // 大额保价保费
          formData.hasLargeInsurance = hasLargeInsurance ? 1 : 0; // 是否勾选大额保价
          formData.insuranceType = 2;
        } else {
          if (formData.goodsPrice) {
            delete formData.goodsPrice;
          }

          if (formData.largeInsuranceCost) {
            delete formData.largeInsuranceCost;
          }
        }
      }
    }

    // 装卸货经纬度同时存在
    const loadLatiLongtudeFlag = loadLatitude && loadLatitude !== '0' && loadLongitude && loadLongitude !== '0';
    const unloadLatiLongtudeFlag = unloadLatitude && unloadLatitude !== '0' && unloadLongitude && unloadLongitude !== '0';

    MBBridge.ui.showLoading({});

    // 根据经纬度查询线路里程
    if (loadLatiLongtudeFlag && unloadLatiLongtudeFlag) {
      const costMileageparams = { loadLatitude, loadLongitude, unloadLatitude, unloadLongitude };
      await this.getCostMileage(type, costMileageparams);
    }

    // 调度前查询是否开启必须poi地址
    await this.getAddressConfig();
    const loadAddressConfig = this.addressRequiredConfig.loadAddressConfig;
    const unloadAddressConfig = this.addressRequiredConfig.unloadAddressConfig;

    if (
      ((type === 4 || type === 31) && !loadLatiLongtudeFlag) ||
      ((type === 1 || type === 2 || type === 30) && loadAddressConfig && !loadLatiLongtudeFlag)
    ) {
      MBBridge.ui.hideLoading({});
      MBToast.show('装货地址必须从搜索下拉框中选择');
      return Promise.resolve({ success: false });
    }

    if (
      ((type === 4 || type === 31) && !unloadLatiLongtudeFlag) ||
      ((type === 1 || type === 2 || type === 30) && unloadAddressConfig && !unloadLatiLongtudeFlag)
    ) {
      MBBridge.ui.hideLoading({});
      MBToast.show('卸货地址必须从搜索下拉框中选择');
      return Promise.resolve({ success: false });
    }

    formData.chargeMileage = formData.chargeMileage?.toString();
    // 看看有没有创建运单表单，有就调接口
    return new Promise((resolve, reject) => {
      if (!this.id) {
        const { dispatcherMode } = formData;
        const params = { ...this.formDataWaybill, dispatcherMode };
        this.api_orderCreate(params)
          .then((res) => {
            if (res.success) {
              this.id = res.data.id;
              this.transOrderNo = res.data.orderNo;
              this.getCreateOrganizeFail = false;

              this.api_createDispatch(formData)
                .then((res) => {
                  // 调度成功埋点
                  this.trackDispatchCreate();
                  resolve(res);
                })
                .catch((err) => {
                  // 强阻断
                  this.showBlockTip(err);
                  const msg = err.message || err.msg || err.reason;

                  if ((!err.data?.tips || !err.data?.tipType) && msg) {
                    MBToast.show(msg);
                  }

                  // 该调度单已经作废或删除直接返回到列表里
                  if (err.code == 20609 || err.code == 20610 || err.code === '900000') {
                    MBBridge.app.page.closeAndJump({
                      url: 'ymm://rn.tms/waybillmanage',
                    });
                    return;
                  }
                  this.isRequestFail = true;
                  if (err.code == 2600013) {
                    this.getBatchDispatchFlag(); // 查询是否在批量调度白名单中
                  }
                  reject(err);
                })
                .finally(() => {
                  MBBridge.ui.hideLoading({});
                });
            } else {
              reject(res);
              MBBridge.ui.hideLoading({});
            }
          })
          .catch((err) => {
            if (err.code === '4700001') {
              // 用户选择的组织无权限或者停用时，重新获取组织数据
              this.getCreateOrganizeFail = true;
            }
            if (err.code === '900001') {
              //MBToast.show('客户权限发生变化，请重新选择');
              this.vaildLimitFail = true;
              this.goBack();
            }
            MBLog.log({
              message: '运单创建失败',
              error: err,
            });
          })
          .finally(() => {
            MBBridge.ui.hideLoading({});
          });
      } else {
        this.api_createDispatch(formData)
          .then((res) => {
            // 调度成功埋点
            this.trackDispatchCreate();
            resolve(res);
          })
          .catch((err: any) => {
            // 强阻断
            this.showBlockTip(err);
            const msg = err.message || err.msg || err.reason;

            if ((!err.data?.tips || !err.data?.tipType) && msg) {
              MBToast.show(msg);
            }
            // 该调度单已经作废、删除、没有客户权限则直接返回到列表里
            if (err.code == 20609 || err.code == 20610 || err.code === '900000') {
              if (Platform.OS === 'android') {
                App.sendEvent('refreshWaybillListView', { isClose: true, currentIndex: 0 });
                MBBridge.app.ui.closeWindow({});
              } else {
                setTimeout(() => {
                  App.sendEvent('refreshWaybillListView', { isClose: true, currentIndex: 0 });
                }, 200);
                MBBridge.app.ui.closeWindow({});
              }
            } else if (err.code == 2600013) {
              this.getBatchDispatchFlag(); // 查询是否在批量调度白名单中
            } else if (err.code == 2600016) {
              this.cargoDealModeInit(true, true); // 重新查询 成交方式 默认值
            }
            reject(err);
          })
          .finally(() => {
            MBBridge.ui.hideLoading({});
          });
      }
    });
  };

  // 调度成功埋点
  @action
  trackDispatchCreate = () => {
    MBJournal.tapJournal({
      elementId: 'create_success_dispatch',
      pageName: 'dispatch_create_edit',
      referPageName: 'waybill_create_edit',
      extraDict: {
        waybill_id: this.id,
      },
    });
  };

  // 返回上一页
  @action goBack = () => {
    // 创建调度失败时
    if (this.isRequestFail) {
      MBBridge.rnruntime.handlebackResult({
        data: JSON.stringify({ id: this.id, transOrderNo: this.transOrderNo, vaildLimitFail: this.vaildLimitFail }),
      });
    }
    // 创建运单-组织权限校验失败,返回创建运单页，重新获取组织数据
    if (this.getCreateOrganizeFail) {
      MBBridge.rnruntime.handlebackResult({ data: JSON.stringify({ getCreateOrganizeFail: true }) });
    }
    if (this.vaildLimitFail) {
      MBBridge.rnruntime.handlebackResult({ data: JSON.stringify({ id: this.id, transOrderNo: this.transOrderNo, refresh: true }) });
    }

    MBBridge.rnruntime.handlebackResult({});

    if (Platform.OS === 'ios') {
      setTimeout(() => {
        MBBridge.app.ui.closeWindow({});
      }, 300);
    }
  };

  // 取得对应页面的备注
  @action getRemarks(type: number) {
    return this['formData_' + type] ? this['formData_' + type].remark : '';
  }
  // 取得备注值，超长字数隐藏
  @action remarksText(text: string, num = 15) {
    if (text && text.length > num) {
      return text.slice(0, num) + '...';
    } else {
      return text;
    }
  }

  // 获取满运宝企业信息-发票抬头
  @action
  getMybCompanyInfo = async (orgId: number) => {
    try {
      const res = await API.getMybCompanyInfo({ orgId });

      if (res.success && res.data) {
        const data = res.data;
        this.setFormData(31, data);
        this.setFormData(4, data);
      }
    } catch (error) {
      MBLog.log({
        message: '获取满运宝企业信息失败',
        error: error,
      });
    }
  };

  onConfirmTruckTypeModal = (val: any) => {
    this.formData_4.transType = val;
    this.changeTruckTypeModalVisible();
  };

  onConfirmTruckTypeModal1 = (val: any) => {
    this.formData_31.transType = val;
    this.changeTruckTypeModalVisible();
  };

  changeTruckTypeModalVisible = () => {
    this.truckTypeModalVisible = !this.truckTypeModalVisible;
  };
}
export default Store;
