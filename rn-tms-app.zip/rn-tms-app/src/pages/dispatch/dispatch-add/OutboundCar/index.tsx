import React from 'react';
import { View, StyleSheet } from 'react-native';
import Billing from './billing';
import NoBilling from './noBilling';

// 指派外调车
export interface OutboundCarProps {
  openTypeModal: any; // 打开调度方式选择弹窗
  navigation: any;
  screenProps?: any;
}
export default class OutboundCar extends React.Component<OutboundCarProps, any> {
  constructor(props: OutboundCarProps) {
    super(props);
    this.state = {
      invoiceFlag: 1, // 开票信息, 0不开票 1开专票
    };
  }
  handleChangeInvice = (val: any) => {
    this.setState({ invoiceFlag: val });
  };
  render() {
    const { invoiceFlag } = this.state;
    return (
      <View style={{ flex: 1 }}>
        {invoiceFlag === 0 ? (
          <NoBilling {...this.props} changeInvice={this.handleChangeInvice} />
        ) : (
          <Billing {...this.props} changeInvice={this.handleChangeInvice} />
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({});
