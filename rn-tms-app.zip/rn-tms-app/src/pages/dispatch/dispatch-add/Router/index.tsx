import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { Provider } from 'mobx-react';
import Store from '../store';

const RootStack = new RouterMap().getRouterMap(RouterPageName.DispatchList);

const CustomerSelector: React.FunctionComponent<any> = (props) => {
  const store = new Store();
  return (
    <Provider store={store}>
      <RootStack screenProps={props} />
    </Provider>
  );
};

export default CustomerSelector;
