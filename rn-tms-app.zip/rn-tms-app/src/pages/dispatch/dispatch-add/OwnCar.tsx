/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import React from 'react';
import { View, StyleSheet, Image, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { CellGroup, Whitespace, Button, MBText, Flex, RNElementsUtil } from '@ymm/rn-elements';
import Cell from '~/components/common/Cell';
import { MBBridge, HandleOnceUtil, App } from '@ymm/rn-lib';
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import ModalSelectCar from '../components/ModalSelectCar'; // 选择承运商车辆
import ModalSelectDriver from '../components/ModalSelectDriver'; // 选择承运商司机
import FootDetail from '../components/FootDetail'; // 底部明细
import xyMath from '~/extends/xyMath'; //
import filterFormat from '~/extends/filterFormat'; //格式化
import { inject, observer } from 'mobx-react';
import keyMap from '../keyMap'; // 枚举值
import images from '../../../../public/static/images/index';
import NativeBridge from '~/extends/NativeBridge';
import LoadUnloadAddress from '~/components/LoadUnloadAddress';
import ModalAddresslist from '~/pages/dispatch/ModalAddresslist';
import SelectOrganizeCell from '../../../components/SelectOrganize/SelectOrganizeCell';
import { PageProps } from '../PropTypes';
import CellCostInput from '../components/CellCostInput';

// 指派自有车
@inject('store')
@observer
export default class OwnCar extends React.Component<PageProps, any> {
  refSelectCar: React.RefObject<any>;
  refSelectDriver: React.RefObject<any>;
  timerApi: any;
  constructor(props: PageProps) {
    super(props);
    this.refSelectCar = React.createRef();
    this.refSelectDriver = React.createRef();
    this.state = {
      showModal: 0, //0 无弹窗 1 显示承运车辆弹窗 2 显示承运司机弹窗 3 显示应付油费弹窗
      showFoot: true, // 控制是否显示底部按钮，如果有软盘弹起就先隐藏起来,
      showDetail: false, // 是否显示明细
      isRulesTips: false,
      dispatchType: 1,
      dispatchTypeTopHeight: 0,
      loadunloadDomHeight: 0,
      feeMap: { 12: '油费', 1: '装卸费', 8: '保险费', 14: '路桥费', 16: '住宿费', 7: '其他费' },
      addressKeyWord: '',
    };
  }

  componentDidMount() {
    this.refSelectCar.current.api_queryTruckList(null);
    this.refSelectDriver.current.api_DriverList(null);
  }

  openTypeModal() {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }
  // 打开选择车辆弹窗
  openModal(val: number) {
    this.setState({ showModal: val, showDetail: false });
  }
  // 修改了时间
  changeDateTime(val: any, type: number) {
    this.setState({ showModal: 0 });
    console.log('修改了时间', type, val);
    if (type === 1) {
      const data = {
        loadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(1, data);
    } else if (type === 2) {
      const data = {
        unloadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(1, data);
    }
    const { loadTime, unloadTime } = this.props.store.formData_1;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
  }
  // 选择车辆弹窗返回
  handleCarModalChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        carId: val.carId, // 车辆id
        carNo: val.carNo, // 车牌
        carType: val.carType, // 车型
        carLength: val.carLength, // 车长
      };
      this.props.store.setFormData(1, data);
    }
  };
  // 选择司机弹窗返回
  handleDriverModalChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        driverId: val.driverId, // 司机id
        driverName: val.driverName, // 司机姓名
        driverPhone: val.driverPhone, // 司机电话
      };
      this.props.store.setFormData(1, data);
    }
  };
  // 到备注页面
  goRemarks = (val: number) => {
    const { navigation } = this.props;
    navigation.navigate('Remarks', {
      //其他参数透传
      type: val,
      from: 1, // 指派自有车
    });
  };
  // 打开明细
  openDetail() {
    this.setState((state: any) => ({ showDetail: !state.showDetail }));
  }
  isSubmit() {
    const formData = this.props.store.formData_1;
    const { tmsLoadUnloads, feeDetails } = formData;
    const loadText = tmsLoadUnloads[0].address;
    const unloadText = tmsLoadUnloads[1].address;
    const feeDetailsTip = feeDetails.find((item: any) => item.isRequired && !item.amount);
    return loadText && unloadText && !feeDetailsTip;
  }
  // 确定指派
  submit() {
    const pass = this.isSubmit();
    this.setState({ isRulesTips: !pass });
    if (!pass) {
      NativeBridge.toast('有必选项未填');
      return;
    }
    const { loadTime, unloadTime } = this.props.store.formData_1;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
    // 费用信息总额
    const feeDetailsTotal = this.props.store.formData_1.feeDetails?.reduce((total: string, item: any) => {
      return item.isDeductionFee ? xyMath.subtr(total, item.amount || 0) : xyMath.accAdd(total, item.amount || 0);
    }, '0');
    if (feeDetailsTotal < 0) {
      NativeBridge.toast('成本合计不可小于0');
      return;
    }
    this.api_createDispatch();
  }
  // 保存并使用
  api_createDispatch() {
    if (this.timerApi) {
      console.log('还在请求中');
      return;
    }
    this.timerApi = true;
    setTimeout(() => {
      this.timerApi = false;
    }, 1500);
    this.props.store
      .createDispatch(1)
      .then((res: any) => {
        if (res.success) {
          if (res.data?.tips || res.data?.tipType) {
            this.props.store.showBlockTip(res);
            setTimeout(() => {
              this.createSuccess(res);
            }, 2000);
          } else {
            this.createSuccess(res);
          }
        } else {
          // NativeBridge.toast(res.msg);
        }
      })
      .catch((err: any) => {
        console.log('createDispatch(1)错误数据', err);
      });
  }

  createSuccess = (res: any) => {
    const { source } = this.props.screenProps;
    NativeBridge.toast('指派自有车成功');

    // 来源创建并调度
    if (source === 'createdispatch') {
      MBBridge.app.page.closeAndJump({
        url: 'ymm://rn.tms/waybilldetail?source=createdispatch&id=' + this.props.store.id,
      });
    } else {
      // // 否则来自运单列表、详情 中的调度, 返回运单列表
      if (Platform.OS === 'android') {
        App.sendEvent('refreshWaybillListView', { isClose: true });
        MBBridge.app.ui.closeWindow({});
      } else {
        setTimeout(() => {
          App.sendEvent('refreshWaybillListView', { isClose: true });
        }, 200);
        MBBridge.app.ui.closeWindow({});
      }
    }
  };

  extraElement(text: string) {
    return (
      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {text}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }
  // 底部按钮
  footElement() {
    const { showDetail } = this.state;
    const formData = this.props.store.formData_1;
    const feeDetails = formData.feeDetails.filter((item: any) => item.amount);
    let total: string = '0'; // 合计
    const infoList = feeDetails.map((item: any) => {
      total = item.isDeductionFee ? xyMath.subtr(total, item.amount) : xyMath.accAdd(total, item.amount);
      return { text: item.feeCodeDesc, num: filterFormat.moneyDecFormat(item.amount) };
    });
    total = filterFormat.moneyDecFormat(total).toString();

    return (
      <View style={[styles.foot]}>
        <Image resizeMode={'stretch'} source={images.top_shadow} style={{ height: 10, width: '100%' }} />
        <View style={{ backgroundColor: '#FFFFFF' }}>
          {showDetail && FootDetail({ infoList: infoList })}
          {!!feeDetails.length && (
            <Flex direction="row" justify="center" align="center" style={{ margin: 10 }}>
              <MBText>成本费用合计</MBText>
              <MBText style={{ color: '#F54242' }}> ¥ {total} </MBText>
              <TouchableOpacity style={styles.flexRow} onPress={this.openDetail.bind(this)}>
                <MBText style={{ color: '#666666', marginLeft: 20 }}>明细</MBText>
                <Image style={[styles.icon, showDetail && styles.upturned]} source={images.icon_pull_down} />
              </TouchableOpacity>
            </Flex>
          )}
          <Button
            radius
            style={styles.btn}
            onPress={() => HandleOnceUtil.callOnceInInterval(this.submit.bind(this))}
            size="sm"
            type="primary"
          >
            确定调度
          </Button>
        </View>
      </View>
    );
  }

  // 保存检索值
  onHandleChangeAddress = (data: any) => {
    const { onChangeAddress } = this.props.store;
    this.setState({
      addressKeyWord: data.value,
    });
    onChangeAddress && onChangeAddress(data);
  };

  render() {
    const { showModal, isRulesTips, dispatchType, dispatchTypeTopHeight, loadunloadDomHeight, addressKeyWord } = this.state;
    const { store } = this.props;
    const {
      searchAddressLoading,
      addressRequiredConfig,
      addressAssociateList,
      isLoadAddressChanged,
      isUnloadAddressChanged,
      onSelectAddressAssociate,
      onFoucsAddress,
      onBlurAddress,
      showFooterBtn,
      addressType,
      sensitiveWordList,
    } = store;
    const formData = store.formData_1;
    const { driverName, driverPhone, carNo, carType, carLength, loadTime, unloadTime } = formData;
    const carrierVehicleList = [];
    !!carNo && !!carrierVehicleList.push(carNo);
    !!carType && !!keyMap.carTypeAll[carType] && carrierVehicleList.push(keyMap.carTypeAll[carType]);
    !!carLength && !!keyMap.carLengthAll[carLength] && carrierVehicleList.push(keyMap.carLengthAll[carLength] + '米');
    const carrierVehicle = carrierVehicleList.join(' '); // 承运车辆

    const CarrierDriver = driverName ? `${driverName} ${driverPhone ? '- ' + driverPhone : ''}` : ''; // 承运司机

    const notesText = formData.remark;
    const { tmsLoadUnloads } = formData;
    const loadText = tmsLoadUnloads[0].address;
    const unloadText = tmsLoadUnloads[1].address;
    return (
      <View style={styles.page}>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} alwaysBounceVertical={false}>
          <View>
            <View
              onLayout={(e) => {
                this.setState({ dispatchTypeTopHeight: e.nativeEvent.layout.height });
              }}
            >
              <SelectOrganizeCell from={1} />
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  name="type"
                  title="调度方式"
                  value="自有车"
                  align="right"
                  valueStyle={styles.valueStyle}
                  onPress={this.openTypeModal.bind(this)}
                />
              </CellGroup>
              <Whitespace vertical={10} />
            </View>
            <CellGroup withBottomLine style={styles.addressCellGroup}>
              <View
                onLayout={(e) => {
                  this.setState({ loadunloadDomHeight: e.nativeEvent.layout.height });
                }}
              >
                <LoadUnloadAddress
                  dispatchType={dispatchType}
                  addressValue={loadText}
                  addressType={0}
                  addressConfig={addressRequiredConfig.loadAddressConfig}
                  isRulesTips={isRulesTips}
                  isAddressChanged={isLoadAddressChanged}
                  searchLoading={searchAddressLoading}
                  addressList={addressAssociateList}
                  onChange={this.onHandleChangeAddress}
                  onSelect={onSelectAddressAssociate}
                  onFoucs={onFoucsAddress}
                  onBlur={onBlurAddress}
                />
              </View>

              <LoadUnloadAddress
                dispatchType={dispatchType}
                addressValue={unloadText}
                addressType={1}
                addressConfig={addressRequiredConfig.unloadAddressConfig}
                isRulesTips={isRulesTips}
                isAddressChanged={isUnloadAddressChanged}
                searchLoading={searchAddressLoading}
                addressList={addressAssociateList}
                onChange={this.onHandleChangeAddress}
                onSelect={onSelectAddressAssociate}
                onFoucs={onFoucsAddress}
                onBlur={onBlurAddress}
              />

              <Cell
                name="type"
                title="装货时间"
                value={loadTime.displayValue}
                align="right"
                placeholder="请选择"
                valueStyle={styles.valueStyle}
                onPress={this.openModal.bind(this, 4)}
              />
              <Cell
                name="type"
                title="卸货时间"
                value={unloadTime.displayValue}
                align="right"
                placeholder="请选择"
                valueStyle={styles.valueStyle}
                onPress={this.openModal.bind(this, 5)}
              />
            </CellGroup>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <Cell
                title="承运车辆"
                value={carrierVehicle}
                align="right"
                placeholder="请选择"
                numberOfLines={1}
                onPress={this.openModal.bind(this, 1)}
                valueStyle={styles.valueStyle}
              />
              <Cell
                title="承运司机"
                value={CarrierDriver}
                align="right"
                placeholder="请选择"
                numberOfLines={1}
                onPress={this.openModal.bind(this, 2)}
                valueStyle={styles.valueStyle}
              />
            </CellGroup>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <CellCostInput
                title="成本费用"
                from={1}
                isRulesTips={isRulesTips}
                navigation={this.props.navigation}
                pageCode="mainline_self_dispatch"
                $parent={this}
              />
            </CellGroup>
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <Cell
                title="备注"
                align="right"
                value={notesText}
                placeholder="请输入"
                numberOfLines={1}
                onPress={this.goRemarks.bind(this, 0)}
                valueStyle={styles.valueStyle}
              />
            </CellGroup>
          </View>
          <Whitespace vertical={220} />
        </ScrollView>
        {showFooterBtn ? this.footElement() : null}
        <ModalSelectCar ref={this.refSelectCar} visible={showModal === 1} from={1} onChange={this.handleCarModalChange} />
        <ModalSelectDriver ref={this.refSelectDriver} visible={showModal === 2} from={1} onChange={this.handleDriverModalChange} />
        <TimePickerModal
          key="start"
          type="loadTimeMonth"
          visible={showModal === 4}
          onChange={(val: any) => {
            this.changeDateTime(val, 1);
          }}
          onCancel={this.openModal.bind(this, 0)}
        />
        <TimePickerModal
          key="end"
          type="unloadTimeMonth"
          visible={showModal === 5}
          onChange={(val: any) => {
            this.changeDateTime(val, 2);
          }}
          onCancel={this.openModal.bind(this, 0)}
        />

        <ModalAddresslist
          dispatchType={dispatchType}
          dispatchTypeTopHeight={dispatchTypeTopHeight}
          loadunloadDomHeight={loadunloadDomHeight}
          addressValue={addressType ? unloadText : loadText}
          addressType={addressType}
          addressConfig={addressType ? addressRequiredConfig.unloadAddressConfig : addressRequiredConfig.loadAddressConfig}
          isAddressChanged={addressType ? isUnloadAddressChanged : isLoadAddressChanged}
          searchLoading={searchAddressLoading}
          addressList={addressAssociateList}
          addressKeyWord={addressKeyWord}
          onSelect={onSelectAddressAssociate}
          sensitiveWordList={sensitiveWordList}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    position: 'relative',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  foot: {
    // backgroundColor: '#FFFFFF',
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
  icon: {
    width: 15,
    height: 15,
  },
  notes: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingRight: 5,
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
  },
  addressCellGroup: {
    zIndex: 999,
  },
});
