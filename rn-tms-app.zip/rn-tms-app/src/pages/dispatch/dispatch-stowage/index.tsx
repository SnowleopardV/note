/* eslint-disable no-console */
import * as React from 'react';
import { Platform, View, ImageBackground, BackHandler, SafeAreaView } from 'react-native';
import { MBBridge } from '@ymm/rn-lib';
import { LayProvider } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import Images from '../../../../public/static/images';

import ModalShuntingMethod from '../components/ModalShuntingMethod'; // 调度方式
import OwnCar from './OwnCar'; // 指派自有车
import Carrier from './Carrier'; // 指派承运商
import OutboundCar from './OutboundCar'; // 指派外调车
import PlatformFind from './Platform'; // 满帮找车
import IndexBackground from './indexBackground'; // 背景 假页面
import { PageProps } from '../PropTypes';
import LoadingView from '../components/LoadingView';
@inject('store')
@observer
export default class DispatchList extends React.Component<PageProps, any> {
  backHandleListener: any = null;
  constructor(props: PageProps) {
    super(props);
    this.state = {
      showTypeModal: true, // 显示调度选择弹窗
      type: 0, // 当前选择的调度类型 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
      loadingNum: 0, // 有三种状态的车型车长，等都加载好再显示页面
    };
  }
  UNSAFE_componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.goBack();
        return true;
      });
    } else {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }

  componentDidMount() {
    const {
      initAddressInfo,
      getAddressConfig,
      getMybCompanyInfo,
      formData_1: { orgId },
      getlargeInsuranceRate,
      getSystemInit,
    } = this.props.store;
    getAddressConfig();
    initAddressInfo(); // 获取初始装卸货地址 时间最早的哪个
    getMybCompanyInfo(orgId);
    const list = [
      this.props.store.api_getTruckTypeList(),
      this.props.store.api_getTruckLengthList(),
      this.props.store.api_getTruckTypePlateList(),
      this.props.store.api_getTruckLengthPlateList(),
      this.props.store.api_getTruckTypeAllList(),
      this.props.store.api_getTruckLengthAllList(),
    ];

    Promise.all(list).finally(() => {
      this.setState({ loadingNum: this.state.loadingNum + 6 });
    });
    this.props.store.getBatchDispatchFlag(); // 查询是否在批量调度白名单中
    // 找到平台需要的总重量和体积
    this.props.store.fillWeightVolume();
    getlargeInsuranceRate(); // 获取大额保价费率
    // 系统配置接口（包含查询敏感词数据）
    getSystemInit();
  }

  openTypeModal = (val: boolean) => {
    // 兼容iOS无法在有蒙层的时候关闭loading
    if (Platform.OS === 'ios') {
      MBBridge.ui.hideLoading({});
    }
    this.setState({ showTypeModal: val });
  };
  // 调度方式改变
  handleTypeChange = (val: number) => {
    // 兼容iOS无法在有蒙层的时候关闭loading
    if (Platform.OS === 'ios') {
      MBBridge.ui.hideLoading({});
    }
    this.setState({ showTypeModal: false });
    if (this.state.type == 0 && !val) {
      val = 4;
    }

    // 处理地址显示
    this.handleDefaultAddress(val);

    val && this.setState({ type: val });
  };

  // 处理地址显示
  handleDefaultAddress = (val: number) => {
    const {
      store: {
        stowageSelectedList,
        initLoadUnloadAddress,
        isAddressChanged_1,
        isAddressChanged_2,
        isAddressChanged_30,
        isAddressChanged_31,
        isAddressChanged_4,
        firstTimeOrder,
      },
    } = this.props;
    // 切换调度方式时，展示装卸货默认值
    if (val) {
      const order = firstTimeOrder(stowageSelectedList);
      const isLoadAddressChanged = this.props.store.isLoadAddressChanged;
      const isUnloadAddressChanged = this.props.store.isUnloadAddressChanged;
      if (isLoadAddressChanged) {
        this.props.store.isLoadAddressChanged = false;
      }
      if (isUnloadAddressChanged) {
        this.props.store.isUnloadAddressChanged = false;
      }

      // 均未做更改时，将初始地址的值带入，遵循默认显示规则
      if (order && !isAddressChanged_1 && !isAddressChanged_2 && !isAddressChanged_30 && !isAddressChanged_31 && !isAddressChanged_4) {
        const tmsLoadUnloads = [
          { ...order.loadMessage, loadType: 1 },
          { ...order.unloadMessage, loadType: 2 },
        ];
        initLoadUnloadAddress(val, { tmsLoadUnloads });
      }
    }
  };
  // 左上角返回键
  goBack = () => {
    this.props.navigation?.goBack();
  };
  listBox(type: number) {
    const { navigation } = this.props;
    const { loadingNum } = this.state;
    if (loadingNum > 5) {
      switch (type) {
        case 1:
          return <OwnCar openTypeModal={this.openTypeModal} navigation={navigation} />;
        case 2:
          return <Carrier openTypeModal={this.openTypeModal} navigation={navigation} />;
        case 3:
          return <OutboundCar openTypeModal={this.openTypeModal} navigation={navigation} />;
        case 4:
          return <PlatformFind openTypeModal={this.openTypeModal} navigation={navigation} />;
        default:
          return <IndexBackground openTypeModal={this.openTypeModal} navigation={navigation} />;
      }
    } else {
      return <LoadingView />;
    }
  }
  public render() {
    const { showTypeModal, type } = this.state;
    return (
      <LayProvider theme="skyblue">
        <ImageBackground source={{ uri: Images.icon_bg_map }} style={{ flex: 1 }}>
          <NavBar title="调度" leftClick={this.goBack} />
          <View style={{ flex: 1 }}>{this.listBox(type)}</View>
          <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
          <ModalShuntingMethod visible={showTypeModal} onChange={this.handleTypeChange} />
        </ImageBackground>
      </LayProvider>
    );
  }
}
