import { observable, action, toJS } from 'mobx';
import { MBToast, MBBridge, MBLog } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';
import API from '../api';
import xyMath from '~/extends/xyMath';
import dayjs from 'dayjs';
import commonStore from '../commonStore'; // 公共stroe, 存放共有特性
import { NavigationScreenProp } from 'react-navigation';
import filterFormat from '~/extends/filterFormat';
class Store extends commonStore {
  constructor() {
    super();
  }
  @observable stowageList = []; // 配置列表
  @observable stowageSelectedList = []; // 已选择的配置列表
  @observable truckTypeModalVisible: boolean = false; // 用车类型

  // 修改 配载列表
  @action setStowageList(data: any) {
    this.stowageList = data;
    return toJS(this.stowageList);
  }
  // 修改 已选择配载列表
  @action setStowageSelectedList(data: any) {
    this.stowageSelectedList = data;
    return toJS(this.stowageList);
  }

  // 修改表单
  @action setFormData(type: number, data: any) {
    // eslint-disable-next-line no-console
    const formData = this[`formData_${type}`];
    return (this[`formData_${type}`] = {
      ...formData,
      ...data,
    });
  }

  // 取得对应页面的备注
  @action getRemarks(type: number) {
    return this['formData_' + type] ? this['formData_' + type].remark : '';
  }
  // 取得备注值，超长字数隐藏
  @action remarksText(text: string, num = 15) {
    if (text && text.length > num) {
      return text.slice(0, num) + '...';
    } else {
      return text;
    }
  }

  // 创建调度
  @action api_createDispatch(formData: any) {
    if (formData.allocationStrategy == 2) {
      const isNothas = this.stowageSelectedList.find((item: any) => !item.totalQuantity);
      if (isNothas) {
        NativeBridge.toast('运单里有无件数的，无法按件数分摊');
        return Promise.resolve({});
      }
    } else if (formData.allocationStrategy == 3) {
      const isNothas = this.stowageSelectedList.find((item: any) => !item.totalWeight);
      if (isNothas) {
        NativeBridge.toast('运单里有无重量的，无法按重量分摊');
        return Promise.resolve({});
      }
    } else if (formData.allocationStrategy == 4) {
      const isNothas = this.stowageSelectedList.find((item: any) => !item.totalVolume);
      if (isNothas) {
        NativeBridge.toast('运单里有无体积的，无法按体积分摊');
        return Promise.resolve({});
      }
    }
    const oilInfo = formData.settlementList.find((item: any) => item.settleType == 5);
    const totalQuantity = this.computesQuantity();
    const data = {
      ...formData,
      loadTime: formData.loadTime.dateCode ? formData.loadTime : null,
      unloadTime: formData.unloadTime.dateCode ? formData.unloadTime : null,
      oilInfo: oilInfo ? [{ id: oilInfo.oilCardId, recieveDeposit: oilInfo.recieveDeposit }] : null,
      ids: this.stowageSelectedList.map((item: any) => item.id),
      totalQuantity: totalQuantity?.toString() || null, // 总件数
      allocationStrategy: this.stowageSelectedList.length > 1 ? formData.allocationStrategy : null, // 分摊策略:分摊策略 1、按订单数分摊，2、按件数分摊，3、按重量分摊，4、按体积分摊
      totalFee: this.totalFee,
      tmsLoadUnloads: formData.tmsLoadUnloads.map((item: any) => {
        const { layout, val, ...orther } = item;
        return orther;
      }),
    };
    if (data.dispatcherMode == 2) {
      data.taxWay = data.carrierInvoiceFlag ? data.taxWay : null; //
      data.taxRate = data.carrierInvoiceFlag ? data.taxRate : null; //
      data.taxFee = data.carrierInvoiceFlag ? filterFormat.moneyFormat(data.taxFee) : null; // 税金 单位分 只在承运商下显示
    } else if (data.dispatcherMode == 4) {
      data.serviceFee = data.invoiceFlag == 1 ? data.serviceFee : null; // 服务费,自动计算得出
      data.serviceFeeRate = data.invoiceFlag == 1 ? data.serviceFeeRate : null; // 服务费率
    }
    // 外调车-普票场景, 构造feeDetails数组
    if (data.invoiceFlag === 2 && data.dispatcherMode === 3) {
      data.feeDetails = [
        {
          feeCode: 40, // 技术服务费
          amount: data.technicalServiceFee,
        },
        {
          feeCode: 41, // 电子协议费
          amount: data.electronicContractFee,
        },
        {
          feeCode: 42, // 轨迹校验费
          amount: data.positionCheckFee,
        },
      ];
    }
    // 删除所有普票场景添加的几个费用项字段, 统一放到feeDetails数组
    delete data.technicalServiceFee;
    delete data.technicalServiceRate;
    delete data.electronicContractFee;
    delete data.positionCheckFee;
    // 普票且大额保价，则删除大额保价对应字段
    if (data.invoiceFlag === 2 && formData.insuranceType === 2) {
      delete data.insuranceType;
      delete data.goodsPrice;
      delete data.largeInsuranceCost;
      delete data.hasLargeInsurance;
    }
    return API.createDispatch(data).then((res) => {
      // eslint-disable-next-line no-console
      console.log('创建调度', res);
      return res;
    });
  }
  // 保存并使用
  @action createDispatch = async (type: number, navigation: NavigationScreenProp<{ onVaildFail: () => void }>) => {
    const formData = this['formData_' + type];
    const loadLatitude = formData.tmsLoadUnloads[0]?.addressLatitude;
    const loadLongitude = formData.tmsLoadUnloads[0]?.addressLongitude;
    const unloadLatitude = formData.tmsLoadUnloads[1]?.addressLatitude;
    const unloadLongitude = formData.tmsLoadUnloads[1]?.addressLongitude;
    // 装货经纬度同时存在
    const loadLatiLongtudeFlag = loadLatitude && loadLatitude !== '0' && loadLongitude && loadLongitude !== '0';
    const unloadLatiLongtudeFlag = unloadLatitude && unloadLatitude !== '0' && unloadLongitude && unloadLongitude !== '0';
    const { invoiceFlag } = formData;
    const { cargoInsuranceSelectItem, cargoInsurancePrice, cargoInsurance, largeInsurancePrice, largeInsuranceCost, hasLargeInsurance } =
      this;
    const minInsuranceAmount = this.cargoInsurance?.cargoInsuranceCheckAmountThreshold || 2;

    if (type === 4 || type === 31) {
      formData.version = '1.0';
      if (cargoInsurance?.remainTotalNum) {
        // 货运险
        if (
          (invoiceFlag && 0 < cargoInsurancePrice && cargoInsurancePrice <= minInsuranceAmount) ||
          (minInsuranceAmount < cargoInsurancePrice && cargoInsuranceSelectItem.companyName)
        ) {
          formData.goodsPrice = cargoInsurancePrice;
          formData.insuranceType = 1;
          formData.insureCompanyCode = cargoInsuranceSelectItem.companyName;
        } else {
          if (formData.goodsPrice) {
            delete formData.goodsPrice;
          }

          if (formData.insuranceType) {
            delete formData.insuranceType;
          }

          if (formData.insureCompanyCode) {
            delete formData.insureCompanyCode;
          }
        }
      } else {
        // 大额报价
        if (invoiceFlag && hasLargeInsurance) {
          formData.goodsPrice = largeInsurancePrice; // 大额保价货物价格
          formData.largeInsuranceCost = largeInsuranceCost; // 大额保价保费
          formData.hasLargeInsurance = hasLargeInsurance ? 1 : 0; // 是否勾选大额保价
          formData.insuranceType = 2;
        } else {
          if (formData.goodsPrice) {
            delete formData.goodsPrice;
          }

          if (formData.largeInsuranceCost) {
            delete formData.largeInsuranceCost;
          }
        }
      }
    }
    MBBridge.ui.showLoading({});

    // 根据经纬度查询线路里程
    if (loadLatiLongtudeFlag && unloadLatiLongtudeFlag) {
      const costMileageparams = { loadLatitude, loadLongitude, unloadLatitude, unloadLongitude };
      await this.getCostMileage(type, costMileageparams);
    }

    // 调度前查询是否开启必须poi地址
    await this.getAddressConfig();
    const loadAddressConfig = this.addressRequiredConfig.loadAddressConfig;
    const unloadAddressConfig = this.addressRequiredConfig.unloadAddressConfig;

    if (
      ((type === 4 || type === 31) && !loadLatiLongtudeFlag) ||
      ((type === 1 || type === 2 || type === 30) && loadAddressConfig && !loadLatiLongtudeFlag)
    ) {
      MBToast.show('装货地址必须从搜索下拉框中选择');
      return Promise.resolve({ success: false });
    }

    if (
      ((type === 4 || type === 31) && !unloadLatiLongtudeFlag) ||
      ((type === 1 || type === 2 || type === 30) && unloadAddressConfig && !unloadLatiLongtudeFlag)
    ) {
      MBToast.show('卸货地址必须从搜索下拉框中选择');
      return Promise.resolve({ success: false });
    }

    formData.chargeMileage = formData.chargeMileage?.toString();
    // 看看有没有创建运单表单，有就调接口
    return new Promise((resolve, reject) => {
      this.api_createDispatch(formData)
        .then((res: any) => {
          resolve(res);
        })
        .catch((err: any) => {
          // 强阻断
          this.showBlockTip(err);
          const msg = err.message || err.msg || err.reason;

          if ((!err.data?.tips || !err.data?.tipType) && msg) {
            MBToast.show(msg);
          }
          if (err.code === '900000') {
            // MBToast.show('权限发生变化，请重新选择运单')
            navigation?.goBack();
            navigation?.state?.params?.onVaildFail();
          } else if (err.code == 2600013) {
            this.getBatchDispatchFlag(); // 查询是否在批量调度白名单中
          } else if (err.code == 2600016) {
            this.cargoDealModeInit(true, true); // 因为成交方式的调度失败， 重新查询 是否显示成交方式和成交方式默认值
          }
          reject(err);
        })
        .finally(() => {
          MBBridge.ui.hideLoading({});
        });
    });
  };

  // 计算 吨 合计
  @action computesWeight() {
    const totalWeight = this.stowageSelectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalWeight || 0));
    }, 0);
    return totalWeight;
  }
  // 计算 方 合计
  @action computesVolume() {
    const totalVolume = this.stowageSelectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalVolume || 0));
    }, 0);
    return totalVolume;
  }
  // 计算 总件数
  @action computesQuantity() {
    const totalQuantity = this.stowageSelectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalQuantity || 0));
    }, 0);
    return totalQuantity;
  }
  // 填充 总体积和重量
  @action fillWeightVolume(): void {
    // 找到平台需要的总重量和体积
    const weightVolumeData = this.platformWeightVolume();
    for (const index of [1, 2, 30, 31, 4]) {
      this.setFormData(index, {
        ...weightVolumeData,
        totalVolume: weightVolumeData.platformTotalWeightMin,
        totalWeight: weightVolumeData.platformTotalVolumeMin,
      });
    }
  }
  // 找到时间最早的单子, 用于获取 装卸地址
  @action firstTimeOrder(list: any) {
    const item = list.reduce((pre: any, cur: any) => {
      if (pre && dayjs(pre.createTime).valueOf() < dayjs(cur.createTime).valueOf()) {
        return pre;
      } else {
        return cur;
      }
    }, null);
    return item;
  }
  // 2021-0821 新版

  // 处理【调度详情】带过来的装卸货地址
  @action
  handleContactList = (type: number, contactList: any) => {
    const tmsLoadUnloads = contactList.map((item: any, index: number) => {
      const { loadType, addressLongitude, addressLatitude } = item;
      const { loadAddressConfig, unloadAddressConfig } = this.addressRequiredConfig;
      const addressConfig = loadType === 1 ? loadAddressConfig : unloadAddressConfig;
      // 经纬度同时存在判断
      const longlatitudeFlag = addressLongitude && addressLongitude !== '0' && addressLatitude && addressLatitude !== '0';

      // 默认带入地址信息
      let handleItem = { ...item };

      // 处理不带入地址，并初始化地址字段
      // 1、指派自有车/指派承运商/指派外调车-不开票
      if (type === 1 || type === 2 || type === 30) {
        // 地址无经纬度 且 后台设置必须经纬度
        if (!longlatitudeFlag && addressConfig) {
          handleItem = { ...this.defaultContact, loadType };
        }
      } else {
        // 2、指派外调车开票/平台找车
        // 地址无经纬度
        if (!longlatitudeFlag) {
          handleItem = { ...this.defaultContact, loadType };
        }
      }
      return handleItem;
    });

    return tmsLoadUnloads;
  };

  // 初始化装卸货货地址
  @action
  initLoadUnloadAddress = (type: number, data: any) => {
    const formData = this[`formData_${type}`];
    const tmsLoadUnloads = this.handleContactList(type, data.tmsLoadUnloads);

    this[`formData_${type}`] = { ...formData, ...{ tmsLoadUnloads } };
  };

  // 更新装卸货地址信息
  @action
  initAddressInfo = () => {
    // 取到 创建时间最早的单子，用其初始默认装卸货地址
    const order = this.firstTimeOrder(this.stowageSelectedList);
    if (order) {
      const tmsLoadUnloads = [
        { ...order.loadMessage, loadType: 1 },
        { ...order.unloadMessage, loadType: 2 },
      ];

      this.initLoadUnloadAddress(1, { tmsLoadUnloads });
      this.initLoadUnloadAddress(2, { tmsLoadUnloads });
      this.initLoadUnloadAddress(30, { tmsLoadUnloads });
      this.initLoadUnloadAddress(31, { tmsLoadUnloads });
      this.initLoadUnloadAddress(4, { tmsLoadUnloads });
    }
  };

  // 获取满运宝企业信息-发票抬头
  @action
  getMybCompanyInfo = async (orgId: number) => {
    try {
      const res = await API.getMybCompanyInfo({ orgId });

      if (res.success) {
        const data = res.data;
        this.setFormData(31, data);
        this.setFormData(4, data);
      }
    } catch (error) {
      MBLog.log({
        message: '获取满运宝企业信息失败',
        error: error,
      });
    }
  };

  onConfirmTruckTypeModal = (val: any) => {
    this.formData_4.transType = val;
    this.changeTruckTypeModalVisible();
  };

  onConfirmTruckTypeModal1 = (val: any) => {
    this.formData_31.transType = val;
    this.changeTruckTypeModalVisible();
  };

  changeTruckTypeModalVisible = () => {
    this.truckTypeModalVisible = !this.truckTypeModalVisible;
  };
}
export default Store;
