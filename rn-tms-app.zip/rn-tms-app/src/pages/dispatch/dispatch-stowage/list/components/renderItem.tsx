import React from 'react';
import PropTypes from 'prop-types';
import { Image, StyleProp, StyleSheet, TouchableOpacity, TouchableWithoutFeedback, View, ViewStyle } from 'react-native';
import { MBText, Splitline } from '@ymm/rn-elements';
import styles from '../styles';
import images from '../../../../../../public/static/images/index';
import { HandleOnceUtil, MBBridge } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';

// 调度详情
const goDetail = (id: any) => {
  NativeBridge.setOpenUrl({ url: 'ymm://rn.tms/waybilldetail?source=stowage&id=' + id });
};
const renderItem = (item: any, index: number, onSelect: any, stylesBox: StyleProp<ViewStyle> = null, isGoDetail: any): JSX.Element => {
  return (
    <TouchableWithoutFeedback
      key={item.id}
      onPress={() => {
        HandleOnceUtil.callOnceInInterval(() => {
          goDetail(item.id);
          isGoDetail && isGoDetail();
        }, 1000);
      }}
    >
      <View style={[styles.item, stylesBox]}>
        <View style={{ padding: 15 }}>
          <View style={[styles.flexRow, { justifyContent: 'space-between' }]}>
            <MBText color="#999999">{item.orderNo}</MBText>
            {!!item.orgName && (
              <MBText color="#999" numberOfLines={1} style={{ flex: 1, marginLeft: 20, textAlign: 'right', fontSize: 12 }}>
                {item.orgName}
              </MBText>
            )}
          </View>
          <View style={[styles.flexRow, { marginTop: 10, justifyContent: 'space-between', alignItems: 'flex-start' }]}>
            <MBText color="#333333" size="md" bold ellipsis="middle" style={{ flex: 1 }}>
              {item.custName}
            </MBText>
            {!!onSelect && (
              <View style={{}}>
                <TouchableOpacity
                  onPress={() => onSelect(index)}
                  style={{
                    height: 50,
                    width: 50,
                    justifyContent: 'center',
                    alignItems: 'center',
                    position: 'absolute',
                    top: -20,
                    right: -15,
                  }}
                >
                  <Image
                    style={{ height: 18, width: 18 }}
                    source={item.selected ? images.icon_circleSelectCheck : images.icon_circleSelect}
                  />
                </TouchableOpacity>
              </View>
            )}
          </View>
          <View style={{ marginVertical: 5 }}>
            <MBText color="#999999">{item.cargoInfoForDisplay}</MBText>
          </View>
          <View style={styles.flexRow}>
            <View style={[styles.point, { backgroundColor: '#4885FF' }]}></View>
            <MBText color="#333333" size="sm">
              {item.loadMessage?.address || '--'}
            </MBText>
          </View>
          <View style={styles.stepLine}>
            <Image style={{ height: 16, width: 0.8 }} source={images.line_vertical} />
          </View>
          <View style={styles.flexRow}>
            <View style={[styles.point, { backgroundColor: '#333333' }]}></View>
            <MBText color="#333333" size="sm">
              {item.unloadMessage?.address || '--'}
            </MBText>
          </View>
        </View>
        <Splitline color="#E8E8E8"></Splitline>
      </View>
    </TouchableWithoutFeedback>
  );
};

export default renderItem;
