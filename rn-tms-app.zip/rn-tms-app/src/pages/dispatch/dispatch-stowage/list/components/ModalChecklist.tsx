import * as React from 'react';
import { View, StyleSheet, ScrollView, Image, SafeAreaView, Platform, TouchableOpacity } from 'react-native';
import { Button, MBText, Modal, Whitespace } from '@ymm/rn-elements';
import renderItem from './renderItem';
import { HandleOnceUtil, PlatformKit } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import images from '../../../../../../public/static/images/index';
import xyMath from '~/extends/xyMath';

// 装车清单
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bottomBtnBox: {
    padding: 10,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  bottomBtn: {
    borderRadius: 50,
    flex: 1,
  },
  badge: {
    backgroundColor: '#F15F5F',
    color: '#FFFFFF',
    borderRadius: 50,
    paddingHorizontal: 5,
    position: 'absolute',
    height: autoFix(32),
    top: -9,
    left: 8,
    zIndex: 1000,
  },
  stylesBox: {
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 10, height: 10 },
    shadowRadius: 10,
    elevation: 4,
  },
});
interface Props {
  visible?: boolean;
  onChange?: any;
  onSelect?: any;
  list: Array<any>;
}

export default class SettlementModal extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
    this.state = {
      list: this.props.list,
      ModalHeight: Number(PlatformKit.Height * 0.8),
    };
  }
  componentWillReceiveProps(nextProps: any) {
    if (nextProps.visible) {
      this.setState({
        list: nextProps.list,
      });
    }
  }
  handleConfirm = () => {
    const { onChange } = this.props;
    const { list } = this.state;
    onChange && onChange(list);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  onSelect(index: number) {
    const { onSelect } = this.props;
    onSelect && onSelect(this.state.list[index]);
  }
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleCancel()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            关闭
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    if (!visible) {
      return null;
    }
    const { list, ModalHeight } = this.state;
    const selectedLength = list.length;
    let totalWeight = list.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalWeight || 0));
    }, 0);
    let totalVolume = list.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalVolume || 0));
    }, 0);
    let totalPieces = list.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalQuantity || 0));
    }, 0);
    totalWeight = totalWeight ? Math.round(totalWeight * 100) / 100 : 0;
    totalVolume = totalVolume ? Math.round(totalVolume * 100) / 100 : 0;
    totalPieces = totalPieces ? Math.round(totalPieces * 100) / 100 : 0;
    return (
      <Modal
        headerRight={this.rightElement()}
        title={`装车清单（${selectedLength}）`}
        position="bottom"
        visible={visible}
        headerLine={false}
        autoAdjustPosition={true}
        onConfirm={this.handleCancel}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
        contentStyle={{ paddingHorizontal: 0 }}
      >
        <View style={{ width: '100%', maxHeight: ModalHeight, paddingBottom: Platform.OS === 'ios' ? 35 : 0 }}>
          <ScrollView>
            {list.map((item: any, index: number) => {
              return renderItem(item, index, this.onSelect.bind(this), styles.stylesBox, () => {
                if (Platform.OS === 'ios') {
                  this.handleCancel();
                }
              });
            })}
            <Whitespace vertical={10} />
          </ScrollView>
          <View style={styles.bottomBtnBox}>
            <TouchableOpacity onPress={this.handleCancel.bind(this)}>
              <View style={[styles.flexRow, { height: 40, alignItems: 'center', marginBottom: 10 }]}>
                <View style={{ marginHorizontal: 10, position: 'relative' }}>
                  <View style={[styles.badge, { width: autoFix(selectedLength < 10 ? 32 : 48) }]}>
                    <MBText size="xs" color="#ffffff">
                      {selectedLength}
                    </MBText>
                  </View>
                  <Image style={{ height: 16, width: 16 }} source={images.icon_checklist} />
                </View>
                <MBText size="xs" color="#333333" style={{ marginLeft: 8 }}>
                  总件数：{totalPieces}件； 总体积：{totalVolume}方； 总重量：{totalWeight}吨
                </MBText>
              </View>
            </TouchableOpacity>
            <View style={styles.flexRow}>
              <Button
                radius
                style={styles.bottomBtn}
                onPress={() =>
                  HandleOnceUtil.callOnceInInterval(() => {
                    this.handleConfirm();
                  }, 1500)
                }
                size="sm"
                type="primary"
              >
                配载调度
              </Button>
            </View>
          </View>
        </View>
      </Modal>
    );
  }
}
