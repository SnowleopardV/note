import React from 'react';
import { View, SafeAreaView, Image, TouchableOpacity, Platform, BackHandler } from 'react-native';
import { Button, MBText, RefreshList } from '@ymm/rn-elements';
import { PlatformKit } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import styles from './styles';
import renderItem from './components/renderItem';
import { toJS } from 'mobx';
import images from '../../../../../public/static/images/index';
import NativeBridge from '~/extends/NativeBridge';
// 装车清单--移除

@inject('store')
@observer
export default class checkList extends React.Component<any, any> {
  backHandleListener: any;
  constructor(props: any) {
    super(props);
    this.state = {
      isEnd: true, // 是否加载结束
      loading: false,
      isTotal: false, // 是否全选
      list: toJS(this.props.store.stowageSelectedList).map((item: any) => {
        item.selected = false;
        return item;
      }),
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  isSubmit = () => {
    const val = this.state.list.find((item: any) => {
      return item.selected;
    });
    return !val;
  };
  // 提交
  submit() {
    const list = this.state.list.filter((item: any) => {
      return !item.selected;
    });
    if (!list.length) {
      const data = { orgId: null, orgName: null };
      this.props.store.setFormData(1, data);
      this.props.store.setFormData(2, data);
      this.props.store.setFormData(30, data);
      this.props.store.setFormData(31, data);
      this.props.store.setFormData(4, data);
    }
    this.props.store.setStowageSelectedList(list);
    this.props.navigation.state?.params?.onSuccess(); // 返回得到的地址信息
    this.props.navigation?.goBack();
    const num = this.state.list.length - list.length;
    NativeBridge.toast('成功移除' + num + '个运单');
    // 找到平台需要的总重量和体积
    this.props.store.fillWeightVolume();
  }
  // 下拉刷新
  onRefresh = () => {
    return new Promise((resolve: any) => {
      this.setState(
        {
          list: toJS(this.props.store.stowageSelectedList).map((item: any) => {
            item.selected = false;
            return item;
          }),
          isTotal: false,
        },
        () => resolve()
      );
    });
  };
  // 加载更多
  onLoadMore = () => {
    return Promise.resolve();
  };
  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <MBText bold color="#666" style={{ textAlign: 'center' }}>
          暂无数据
        </MBText>
      </View>
    );
  };
  onSelect = (index: number) => {
    const list = this.state.list.map((item: any, key: number) => {
      if (key === index) {
        item.selected = !item.selected;
      }
      return item;
    });
    this.setState({ list: JSON.parse(JSON.stringify(list)) });
  };
  // 全选
  onSelectTotal() {
    const list = this.state.list.map((item: any, key: number) => {
      item.selected = !this.state.isTotal;
      return item;
    });
    this.setState({ list: JSON.parse(JSON.stringify(list)), isTotal: !this.state.isTotal });
  }
  rightElement() {
    const { isTotal } = this.state;
    return (
      <View style={styles.flexRow}>
        <MBText size="xs" color="#7E7E7E">
          全选
        </MBText>
        <Image
          style={{ height: 18, width: 18, marginLeft: 5, marginRight: 10 }}
          source={isTotal ? images.icon_circleSelectCheck : images.icon_circleSelect}
        />
      </View>
    );
  }
  render() {
    const { list, isTotal } = this.state;
    return (
      <View style={{ flex: 1 }}>
        <NavBar
          title="移除"
          leftClick={() => {
            this.props.navigation?.goBack();
          }}
          rightElement={this.rightElement()}
          onRight={() => this.onSelectTotal()}
        />
        <View style={{ flex: 1 }}>
          <RefreshList
            isEnd={true}
            data={list}
            renderItem={(item: any, index: number) => renderItem(item, index, this.onSelect.bind(this), null, null)}
            emptyRender={this.renderEmpty}
            onRefresh={this.onRefresh}
            onLoadMore={this.onLoadMore}
            getLayoutTypeForIndex={() => 220}
            showsVerticalScrollIndicator={false}
          />
        </View>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}>
          <View style={[styles.bottomBtnBox, styles.flexRow]}>
            <Button disabled={this.isSubmit()} radius style={styles.bottomBtn} onPress={this.submit.bind(this)} size="sm" type="primary">
              移除
            </Button>
          </View>
        </SafeAreaView>
      </View>
    );
  }
}
