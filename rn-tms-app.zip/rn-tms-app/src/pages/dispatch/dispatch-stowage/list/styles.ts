import { StyleSheet, Platform } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  item: {
    flexDirection: 'column',
    flex: 1,
    marginTop: 10,
    marginHorizontal: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 2,
  },
  empty: {
    height: 600,
    width: '100%',
    justifyContent: 'center',
    textAlignVertical: 'center',
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
  },
  stepLine: {
    position: 'relative',
    top: -4,
    left: 3,
    height: 8,
  },
  point: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    marginRight: 8,
  },
  btn: {
    paddingVertical: 5,
    paddingHorizontal: 16,
    borderRadius: 15,
    borderWidth: 0.5,
    borderColor: '#4885FF',
    marginLeft: 6,
  },
  btnTxt: {
    fontSize: 14,
    // fontFamily: 'PingFangSC-Semibold, PingFang SC',
    fontWeight: 'bold',
    color: '#4885FF',
  },
  bottomBtnBox: {
    backgroundColor: '#FFFFFF',
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  bottomBtn: {
    borderRadius: 50,
    flex: 1,
  },
  badge: {
    backgroundColor: '#F15F5F',
    color: '#FFFFFF',
    borderRadius: 50,
    position: 'absolute',
    height: autoFix(32),
    top: -9,
    left: 8,
    zIndex: 1000,
    flexDirection: 'row',
    justifyContent: 'center',
  },
});
