import React from 'react';
import { View, SafeAreaView, Platform, BackHandler } from 'react-native';
import { MBText, RefreshList } from '@ymm/rn-elements';
import { PlatformKit } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import styles from './styles';
import renderItem from './components/renderItem';
import { toJS } from 'mobx';
import NativeBridge from '~/extends/NativeBridge';
// 装车清单

@inject('store')
@observer
export default class checkList extends React.Component<any, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      isEnd: true, // 是否加载结束
      loading: false,
      list: [],
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  // 提交
  submit() {
    const { navigation } = this.props;
    this.setSelectedList();
    navigation.navigate('DispatchList');
  }
  // 下拉刷新
  onRefresh = () => {
    return Promise.resolve();
  };
  // 加载更多
  onLoadMore = () => {
    return Promise.resolve();
  };
  // 保存已选择的
  setSelectedList() {
    this.props.store.setStowageSelectedList(this.state.selectedList);
  }
  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <MBText bold color="#666" style={{ textAlign: 'center' }}>
          暂无数据
        </MBText>
      </View>
    );
  };
  onChange = (val: any) => {
    this.setState({ visible: false });
    if (val) {
      this.submit();
    }
  };
  goDelete() {
    this.props.navigation.navigate('ChecklistDelete', {
      onSuccess: (val: any) => {
        this.props.navigation.state?.params?.onSuccess(); // 返回得到的地址信息
      },
    });
  }
  goAdd() {
    // console.log('新增');
    const { stowageSelectedList } = this.props.store;
    if (stowageSelectedList.length >= 20) {
      NativeBridge.toast('最多可选20条，请先移除再添加');
      return;
    }
    this.props.navigation.navigate('ChecklistAdd', {
      onSuccess: (val: any) => {
        this.props.navigation.state?.params?.onSuccess(); // 返回得到的地址信息
      },
    });
  }
  rightElement() {
    return (
      <View style={styles.flexRow}>
        <MBText color="primary" onPress={() => this.goDelete()}>
          移除
        </MBText>
        <MBText style={{ marginLeft: 20 }} color="primary" onPress={() => this.goAdd()}>
          新增
        </MBText>
      </View>
    );
  }
  render() {
    const { stowageSelectedList } = this.props.store;
    const list = toJS(stowageSelectedList);
    const length = list.length;
    return (
      <View style={{ flex: 1 }}>
        <NavBar
          title={`装车清单（${length}）`}
          leftClick={() => {
            this.props.navigation?.goBack();
          }}
          rightElement={this.rightElement()}
        />
        <View style={{ flex: 1 }}>
          <RefreshList
            isEnd={true}
            data={list}
            renderItem={(item: any, index: number) => renderItem(item, index, false, null, null)}
            emptyRender={this.renderEmpty}
            onRefresh={this.onRefresh}
            onLoadMore={this.onLoadMore}
            getLayoutTypeForIndex={() => 220}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </View>
    );
  }
}
