import React from 'react';
import { View, StyleSheet, SafeAreaView, Image, TouchableOpacity, Platform } from 'react-native';
import { LayProvider, Whitespace, Flex, MBText, RefreshList, Splitline, Input, Button } from '@ymm/rn-elements';
import { PlatformKit, MBBridge, HandleOnceUtil } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import images from '../../../../../public/static/images/index';
import NativeBridge from '~/extends/NativeBridge';
import xyMath from '~/extends/xyMath';
import API from '../../api';
import styles from './styles';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import renderItem from './components/renderItem';
import ModalChecklist from './components/ModalChecklist';
import { PageProps } from '../../PropTypes';
// 配置列表
@inject('store')
@observer
export default class stowageList extends React.Component<PageProps, any> {
  constructor(props: PageProps) {
    super(props);
    this.state = {
      visible: false, // 显示装车清单
      isEnd: false, // 是否加载结束
      loading: false,
      isTotalSelected: false, // 全选
      selectedList: [], // 选择的列表
      list: [],
      pageNo: 0,
      pageSize: 20,
      orgList: [], // 所属组织 [{orgId, orgName}]
    };
  }
  api_list(bool: boolean) {
    return new Promise((resolve, reject) => {
      const { pageSize, pageNo } = this.state;
      this.setState({ loading: true, pageNo: bool ? 1 : pageNo }, () => {
        API.dispatchList({ dispatchStatus: 0, pageSize: pageSize, pageNo: bool ? 1 : pageNo })
          .then((res: any) => {
            // console.log('配载调度列表', res.data);
            if (res.success) {
              let list = [];
              if (bool) {
                list = res.data.list;
              } else {
                list = this.state.list.concat(res.data.list);
              }
              this.setState(
                {
                  isEnd: !res.data.hasNextPage,
                  list: this.props.store.setStowageList(list),
                  pageNo: bool ? 2 : 1 + pageNo,
                },
                () => {
                  resolve();
                }
              );
            }
          })
          .catch(() => {
            reject();
          })
          .finally(() => {
            this.setState({ loading: false });
          });
      });
    });
  }
  isSubmit = () => {
    const val = this.state.selectedList.length;
    return !val;
  };
  // 提交
  submit() {
    const { navigation } = this.props;
    this.setSelectedList();
    navigation.navigate('DispatchList', {
      onVaildFail: () => {
        this.api_list(true); //重新请求数据
        //清空选择
        const list = this.state.list.map((item: any) => {
          item.selected = false;
          return item;
        });
        this.setState({
          list: this.props.store.setStowageList(list),
          selectedList: list.filter((item: any) => {
            return item.selected;
          }),
        });
      },
    });
  }
  // 下拉刷新
  onRefresh = () => {
    this.setState({
      isTotalSelected: false, // 全选
      selectedList: [], // 选择的列表
    });
    return this.api_list(true);
  };
  // 加载更多
  onLoadMore = () => {
    const { pageNo } = this.state;
    if (pageNo) {
      return this.api_list(false);
    } else {
      this.api_list(true);
      return Promise.resolve();
    }
  };
  // 保存已选择的
  setSelectedList() {
    const data = {
      orgId: this.state.selectedList[0].orgId || null,
      orgName: this.state.selectedList[0].orgName || null,
    };
    this.props.store.setFormData(1, data);
    this.props.store.setFormData(2, data);
    this.props.store.setFormData(30, data);
    this.props.store.setFormData(31, data);
    this.props.store.setFormData(4, data);
    this.props.store.setStowageSelectedList(this.state.selectedList);
  }
  onSelect(index: number) {
    if (!this.state.list[index].selected && this.state.selectedList.length >= 20) {
      NativeBridge.toast('最多可选20条，请先移除再添加');
      return;
    }
    if (!this.state.list[index].selected) {
      if (this.state.selectedList[0]?.orgId && this.state.selectedList[0]?.orgId !== this.state.list[index].orgId) {
        NativeBridge.toast('所选运单不属于同一个组织，必须选择同一组织的运单进行调度，请重新选择');
        return;
      }
    }

    this.state.list[index].selected = !this.state.list[index].selected;
    const list = this.props.store.setStowageList(this.state.list);
    this.setState({
      list: list,
      selectedList: list.filter((item: any) => {
        return item.selected;
      }),
    });
  }
  // 装车清单 取消选择项
  onModalSelect = (val: any) => {
    const list = this.state.list.map((item: any) => {
      if (item.id === val.id) {
        item.selected = false;
      }
      return item;
    });
    this.setState(
      {
        list: this.props.store.setStowageList(list),
        selectedList: list.filter((item: any) => {
          return item.selected;
        }),
      },
      () => {
        if (!this.state.selectedList.length) {
          this.setState({
            visible: false,
            isTotalSelected: false,
          });
        }
      }
    );
  };

  onSelectTotal() {
    this.setState(
      (state: any) => ({ isTotalSelected: !state.isTotalSelected }),
      () => {
        let list = [];
        const orgId = this.state.list[0]?.orgId || null; // 只选择相同的组织，全选以第一个为准
        if (this.state.isTotalSelected) {
          let num = 0;
          list = this.state.list.map((item: any, index: number) => {
            if (item.orgId === orgId && num < 20) {
              item.selected = true;
              num++;
            } else {
              item.selected = false;
            }
            return item;
          });
          if (list.length > 20) {
            NativeBridge.toast('列表已超出20条，最多可选20条，已帮您选择列表前20条');
          }
        } else {
          list = this.state.list.map((item: any) => {
            item.selected = false;
            return item;
          });
        }
        this.setState({
          list: this.props.store.setStowageList(list),
          selectedList: list.filter((item: any) => {
            return item.selected;
          }),
        });
      }
    );
  }
  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <MBText bold color="#666" style={{ textAlign: 'center' }}>
          暂无数据
        </MBText>
      </View>
    );
  };
  onChange = (val: any) => {
    this.setState({ visible: false });
    if (val) {
      this.submit();
    }
  };
  // 打开装车清单
  openModal() {
    const { selectedList } = this.state;
    if (selectedList && selectedList.length) {
      this.setState({ visible: true });
    } else {
      NativeBridge.toast('请选择需要配载调度的单子');
    }
  }
  rightElement() {
    const { isTotalSelected } = this.state;
    return (
      <View style={styles.flexRow}>
        <MBText size="xs" color="#7E7E7E">
          全选
        </MBText>
        <Image
          style={{ height: 18, width: 18, marginLeft: 5, marginRight: 10 }}
          source={isTotalSelected ? images.icon_circleSelectCheck : images.icon_circleSelect}
        />
      </View>
    );
  }
  render() {
    const { isEnd, list, selectedList, visible } = this.state;
    const selectedLength = selectedList.length;
    let totalWeight = selectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalWeight || 0));
    }, 0);
    let totalVolume = selectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalVolume || 0));
    }, 0);
    let totalPieces = selectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalQuantity || 0));
    }, 0);
    totalWeight = totalWeight ? Math.round(totalWeight * 100) / 100 : 0;
    totalVolume = totalVolume ? Math.round(totalVolume * 100) / 100 : 0;
    totalPieces = totalPieces ? Math.round(totalPieces * 100) / 100 : 0;
    return (
      <View style={{ flex: 1 }}>
        <NavBar title="配载调度" rightElement={this.rightElement()} onRight={() => this.onSelectTotal()} />
        <View style={{ flex: 1 }}>
          <RefreshList
            isEnd={isEnd}
            data={list}
            renderItem={(item: any, index: number) => renderItem(item, index, this.onSelect.bind(this), null, null)}
            emptyRender={this.renderEmpty}
            onRefresh={this.onRefresh}
            onLoadMore={this.onLoadMore}
            getLayoutTypeForIndex={() => 220}
            showsVerticalScrollIndicator={false}
          />
        </View>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}>
          <View style={styles.bottomBtnBox}>
            {!!selectedLength && (
              <TouchableOpacity onPress={this.openModal.bind(this)}>
                <View style={[styles.flexRow, { height: 40, alignItems: 'center', marginBottom: 10 }]}>
                  <View style={{ marginHorizontal: 10, position: 'relative' }}>
                    <View style={[styles.badge, { width: autoFix(selectedLength < 10 ? 32 : 48) }]}>
                      <MBText size="xs" color="#ffffff">
                        {selectedLength}
                      </MBText>
                    </View>
                    <Image style={{ height: 16, width: 16 }} source={images.icon_checklist} />
                  </View>
                  <MBText size="xs" color="#333333" style={{ marginLeft: 8 }}>
                    总件数：{totalPieces}件； 总体积：{totalVolume}方； 总重量：{totalWeight}吨
                  </MBText>
                </View>
              </TouchableOpacity>
            )}

            <View style={styles.flexRow}>
              <Button
                disabled={this.isSubmit()}
                radius
                style={styles.bottomBtn}
                onPress={() =>
                  HandleOnceUtil.callOnceInInterval(() => {
                    this.submit();
                  }, 1500)
                }
                size="sm"
                type="primary"
              >
                配载调度
              </Button>
            </View>
          </View>
        </SafeAreaView>
        <ModalChecklist
          visible={visible}
          onChange={this.onChange.bind(this)}
          onSelect={this.onModalSelect.bind(this)}
          list={selectedList}
        />
      </View>
    );
  }
}
