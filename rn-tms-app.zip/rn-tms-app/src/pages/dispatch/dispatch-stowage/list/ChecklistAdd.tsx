import React from 'react';
import { View, SafeAreaView, Image, TouchableOpacity, BackHandler, Platform } from 'react-native';
import { MBText, RefreshList, Button } from '@ymm/rn-elements';
import { PlatformKit } from '@ymm/rn-lib';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import images from '../../../../../public/static/images/index';
import NativeBridge from '~/extends/NativeBridge';
import xyMath from '~/extends/xyMath';
import API from '../../api';
import styles from './styles';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import renderItem from './components/renderItem';
// 配置列表 -- 新增

@inject('store')
@observer
export default class stowageList extends React.Component<any, any> {
  backHandleListener: any;
  constructor(props: any) {
    super(props);
    this.state = {
      isEnd: false, // 是否加载结束
      loading: false,
      isTotalSelected: false, // 全选
      selectedList: [], // 选择的列表
      list: [],
      pageNo: 0,
      pageSize: 20,
      orgId: this.props?.store?.formData_1?.orgId,
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  /**
   *
   * @param {boolean} bool 如果是下拉刷新就为 true
   * @return {*}
   */
  api_list(bool: boolean) {
    const { stowageSelectedList } = this.props.store;
    return new Promise((resolve, reject) => {
      const { pageSize, pageNo } = this.state;
      const excludeIds = stowageSelectedList.map((item: any) => {
        return item.orderId;
      }); // 需要排除的单子
      this.setState({ loading: true, pageNo: bool ? 1 : pageNo }, () => {
        const { orgId } = this.state;
        API.dispatchList({ dispatchStatus: 0, pageSize: pageSize, pageNo: bool ? 1 : pageNo, excludeIds: excludeIds, orgId: orgId })
          .then((res: any) => {
            // console.log('新增-配载调度列表', res.data);
            if (res.success) {
              let list = [];
              if (bool) {
                list = res.data.list || [];
              } else {
                list = this.state.list.concat(res.data.list || []);
              }
              console.log('=====================配载调度列表=========================');
              console.log(res.data);
              this.setState(
                {
                  isEnd: !res.data.hasNextPage,
                  list: this.props.store.setStowageList(list),
                  pageNo: bool ? 2 : 1 + pageNo,
                },
                () => {
                  resolve();
                }
              );
            }
          })
          .catch(() => {
            reject();
          })
          .finally(() => {
            this.setState({ loading: false });
          });
      });
    });
  }
  isSubmit = () => {
    const val = this.state.selectedList.length;
    return !val;
  };
  // 提交
  submit() {
    const { selectedList } = this.state;
    const { stowageSelectedList } = this.props.store;
    this.props.store.setStowageSelectedList([...selectedList, ...stowageSelectedList]);
    this.props.navigation.state?.params?.onSuccess(); // 返回得到的地址信息
    this.props.navigation?.goBack();
    const num = selectedList.length;
    NativeBridge.toast('成功添加' + num + '个运单');

    const data = {
      orgId: selectedList[0]?.orgId || null,
      orgName: selectedList[0]?.orgName || null,
    };
    this.props.store.setFormData(1, data);
    this.props.store.setFormData(2, data);
    this.props.store.setFormData(30, data);
    this.props.store.setFormData(31, data);
    this.props.store.setFormData(4, data);
    // 找到平台需要的总重量和体积
    this.props.store.fillWeightVolume();
  }
  // 下拉刷新
  onRefresh = () => {
    this.setState({
      isTotalSelected: false, // 全选
      selectedList: [], // 选择的列表
    });
    return this.api_list(true);
  };
  // 加载更多
  onLoadMore = () => {
    const { pageNo } = this.state;
    if (pageNo) {
      return this.api_list(false);
    } else {
      this.api_list(true);
      return Promise.resolve();
    }
  };
  // 保存已选择的
  setSelectedList() {
    this.props.store.setStowageSelectedList(this.state.selectedList);
  }
  onSelect(index: number) {
    const { stowageSelectedList } = this.props.store;
    const { selectedList } = this.state;

    if (!this.state.list[index].selected) {
      const totalNum = stowageSelectedList.length + selectedList.length;
      if (totalNum >= 20) {
        NativeBridge.toast('最多可选20条，请先移除再添加');
        return;
      }
    }
    if (!this.state.list[index].selected) {
      if (this.state.selectedList[0]?.orgId && this.state.selectedList[0]?.orgId !== this.state.list[index].orgId) {
        NativeBridge.toast('所选运单不属于同一个组织，必须选择同一组织的运单进行调度，请重新选择');
        return;
      }
    }
    this.state.list[index].selected = !this.state.list[index].selected;
    const list = JSON.parse(JSON.stringify(this.state.list));
    this.setState({
      list: list,
      selectedList: list.filter((item: any) => {
        return item.selected;
      }),
    });
  }

  onSelectTotal() {
    if (!this.state.list) return;
    const { stowageSelectedList } = this.props.store;
    const remainNum = 20 - stowageSelectedList.length; // 还可以新增的数量
    this.setState(
      (state: any) => ({ isTotalSelected: !!!state.isTotalSelected }),
      () => {
        let list = [];
        const orgId = this.state.list[0]?.orgId || null;
        if (this.state.isTotalSelected) {
          let num = 0;
          list = this.state.list.map((item: any, index: number) => {
            if (item.orgId === orgId && num < 20) {
              item.selected = true;
              num++;
            } else {
              item.selected = false;
            }
            return item;
          });
          if (list.length > remainNum) {
            NativeBridge.toast(`列表已超出20条，还可选${remainNum}条，已为您选择列表前${remainNum}条`);
          }
        } else {
          list = this.state.list.map((item: any) => {
            item.selected = false;
            return item;
          });
        }
        this.setState({
          list: this.props.store.setStowageList(list),
          selectedList: list.filter((item: any) => {
            return item.selected;
          }),
        });
      }
    );
  }
  renderEmpty = () => {
    return (
      <View style={styles.empty}>
        <MBText bold color="#666" style={{ textAlign: 'center' }}>
          暂无数据
        </MBText>
      </View>
    );
  };
  onChange = (val: any) => {
    this.setState({ visible: false });
    if (val) {
      this.submit();
    }
  };
  rightElement() {
    const { isTotalSelected } = this.state;
    return (
      <View style={styles.flexRow}>
        <MBText size="xs" color="#7E7E7E">
          全选
        </MBText>
        <Image
          style={{ height: 18, width: 18, marginLeft: 5, marginRight: 10 }}
          source={isTotalSelected ? images.icon_circleSelectCheck : images.icon_circleSelect}
        />
      </View>
    );
  }
  render() {
    const { isEnd, list, selectedList } = this.state;
    const selectedLength = selectedList.length;
    let totalWeight = selectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalWeight || 0));
    }, 0);
    let totalVolume = selectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalVolume || 0));
    }, 0);
    let totalPieces = selectedList.reduce((pre: number, cur: any) => {
      return Number(xyMath.accAdd(pre, cur?.totalQuantity || 0));
    }, 0);
    totalWeight = totalWeight ? Math.round(totalWeight * 100) / 100 : 0;
    totalVolume = totalVolume ? Math.round(totalVolume * 100) / 100 : 0;
    totalPieces = totalPieces ? Math.round(totalPieces * 100) / 100 : 0;
    return (
      <View style={{ flex: 1 }}>
        <NavBar
          title="新增"
          leftClick={() => {
            this.props.navigation?.goBack();
          }}
          rightElement={this.rightElement()}
          onRight={() => this.onSelectTotal()}
        />
        <View style={{ flex: 1 }}>
          <RefreshList
            isEnd={isEnd}
            data={list}
            renderItem={(item: any, index: number) => renderItem(item, index, this.onSelect.bind(this), null, null)}
            emptyRender={this.renderEmpty}
            onRefresh={this.onRefresh}
            onLoadMore={this.onLoadMore}
            getLayoutTypeForIndex={() => 220}
            showsVerticalScrollIndicator={false}
          />
        </View>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}>
          <View style={styles.bottomBtnBox}>
            {!!selectedLength && (
              <TouchableOpacity>
                <View style={[styles.flexRow, { height: 40, alignItems: 'center', marginBottom: 10 }]}>
                  <View style={{ marginHorizontal: 10, position: 'relative' }}>
                    <View style={[styles.badge, { width: autoFix(selectedLength < 10 ? 32 : 48) }]}>
                      <MBText size="xs" color="#ffffff">
                        {selectedLength}
                      </MBText>
                    </View>
                    <Image style={{ height: 16, width: 16 }} source={images.icon_checklist} />
                  </View>
                  <MBText size="xs" color="#333333" style={{ marginLeft: 8 }}>
                    总件数：{totalPieces}件； 总体积：{totalVolume}方； 总重量：{totalWeight}吨
                  </MBText>
                </View>
              </TouchableOpacity>
            )}
            <View style={styles.flexRow}>
              <Button disabled={this.isSubmit()} radius style={styles.bottomBtn} onPress={this.submit.bind(this)} size="sm" type="primary">
                新增
              </Button>
              {/* <TouchableOpacity onPress={() => this.onSelectTotal()} style={{ alignItems: 'center', width: 80 }}>
              <Image
                style={{ height: 18, width: 18 }}
                source={isTotalSelected ? images.icon_circleSelectCheck : images.icon_circleSelect}
              />
              <MBText color="disabled" size="xs">
                全选
              </MBText>
            </TouchableOpacity> */}
            </View>
          </View>
        </SafeAreaView>
      </View>
    );
  }
}
