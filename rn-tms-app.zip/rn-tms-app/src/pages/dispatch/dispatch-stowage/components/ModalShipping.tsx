import * as React from 'react';
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Flex, Modal, MBText, Whitespace, Selector } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import InputItem from '~/components/common/InputItem';
import verification from '~/extends/verification';
import NativeBridge from '~/extends/NativeBridge';
import filterFormat from '~/extends/filterFormat';
import xyMath from '~/extends/xyMath';
import keyMap from '../../keyMap';
import API from '../../api';

import images from '../../../../../public/static/images/index';
const FlexItem = Flex.Item;
// 输入运费 趟/吨/方 模态框
const styles = StyleSheet.create({
  from: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  item: {
    flex: 1,
    paddingLeft: 0,
  },
  select: {
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 50,
    backgroundColor: '#F5F5F5',
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleStyle: {
    width: 80,
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
  store?: any;
  from?: number; // 31 外调车 开票 4 满帮找车
  isCount?: boolean; // 是否计算计算服务费
  formData?: any; //
}
@inject('store')
@observer
export default class ModalShipping extends React.Component<Props, any> {
  refInput: React.RefObject<any>;
  static defaultProps = {
    isCount: true,
  };
  timerServiceFee: any = null; // 服务费计算防抖
  constructor(props: Props) {
    super(props);
    this.refInput = React.createRef();
    this.state = {
      freight: '', // 运费
      unitIndex: 0, // 当前选择的单位
      showUnit: false, // 显示单位选择框
      serviceFee: null, // 服务费
      generalInvoiceFee: [], // 普票费用项 - 字典
      technicalServiceFee: null, // 技术服务费
      electronicContractFee: null, // 电子协议费
      positionCheckFee: null, // 轨迹校验费
      selectUnitItem: {
        show: false,
      }, // 选择单位
      unitMap: Object.keys(keyMap.unitMap).map((key, index) => {
        return { text: keyMap.unitMap[key], id: key, index: index };
      }),
      loadingText: null, // 加载中提示
    };
  }
  componentWillReceiveProps(nextProps: any) {
    const { generalInvoiceFee } = this.state;
    const { dispatcherId, deliveryFee, deliveryUnit, serviceFee, technicalServiceFee, electronicContractFee, positionCheckFee, invoiceFlag, dispatcherMode } = nextProps.store['formData_' + nextProps.from];
    if (nextProps.visible) {
      this.setState({
        freight: filterFormat.moneyDecFormat(deliveryFee), // 运费
        unitIndex: deliveryUnit ? deliveryUnit - 1 : 0, // 当前选择的单位
        serviceFee: filterFormat.moneyDecFormat(serviceFee),
        technicalServiceFee: technicalServiceFee,
        electronicContractFee: electronicContractFee,
        positionCheckFee: positionCheckFee
      }, () => {
        nextProps.isCount && dispatcherId && this.api_serviceFee();
      });
    }
    // 获取普票新增三个费用项：技术服务费、电子协议费、轨迹校验费
    if (invoiceFlag === 2 && dispatcherMode === 3 && generalInvoiceFee.length === 0) {
      this.getGeneralInvoiceFee();
    }
  }
  /** 获取普票新增三个费用项 **/
  getGeneralInvoiceFee() {
    API.getFeeInputBoxes({ code: 'external_scheduling_no_invoicing' })
      .then((res: any) => {
        this.setState({ generalInvoiceFee: res.data && res.data.length > 0 ? res.data : [] });
      })
      .catch(() => {});
  }
  handleConfirm = () => {
    const { invoiceFlag, dispatcherMode } = this.props.store['formData_' + this.props.from];
    const { onChange } = this.props;
    const { unitIndex, freight, loadingText, serviceFee, technicalServiceFee, electronicContractFee, positionCheckFee } = this.state;
    if (!freight) {
      onChange && onChange(this.state);
      return;
    }
    if (invoiceFlag === 1) {
      if (!!loadingText || (this.props.isCount && !serviceFee)) {
        NativeBridge.toast('等待附加运费计算结果');
        return;
      }
    } else if (invoiceFlag === 2 && dispatcherMode === 3) {
      if (!!loadingText || (this.props.isCount && (!technicalServiceFee || !electronicContractFee || !positionCheckFee))) {
        NativeBridge.toast('等待技术服务费、电子协议费、轨迹校验费计算结果');
        return;
      }
    }
    switch (unitIndex) {
      case 0: // 趟
        if (freight < 50) {
          NativeBridge.toast('运费不能低于50');
          return;
        } else if (freight > 50000) {
          NativeBridge.toast('运费过高');
          return;
        }
        break;
      case 1: // 吨
        if (freight < 20) {
          NativeBridge.toast('运费不能低于20');
          return;
        } else if (freight > 1000) {
          NativeBridge.toast('运费过高');
          return;
        }
        break;
      case 2: // 方
        if (freight < 20) {
          NativeBridge.toast('运费不能低于20');
          return;
        } else if (freight > 400) {
          NativeBridge.toast('运费过高');
          return;
        }
        break;
      default:
        break;
    }

    onChange && onChange(this.state);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  changeMoney = (val: any) => {
    if (verification.number(val) || val === '') {
      this.setState({ freight: val }, () => {
        if (this.props.isCount) {
          clearTimeout(this.timerServiceFee);
          this.timerServiceFee = setTimeout(() => {
            this.api_serviceFee();
          }, 400);
        }
      });
    }
  };
  // 单位选择框
  handleUnitConfirm = () => {
    const { selectUnitItem } = this.state;
    if (selectUnitItem?.show) {
      this.setState({ showUnit: false, unitIndex: selectUnitItem.index }, () => {
        this.props.isCount && this.api_serviceFee();
      });
    } else if (selectUnitItem?.id === '2') {
      NativeBridge.toast('创建运单时未填写货物重量，需要有货物重量才可选择');
    } else if (selectUnitItem?.id === '3') {
      NativeBridge.toast('创建运单时未填写货物体积，需有货物体积才可选择');
    } else {
      this.setState({ showUnit: false });
    }
  };
  showUnitConfirm = () => {
    this.setState({ showUnit: !this.state.showUnit });
  };
  handleUnitChange = (val: any, item: any) => {
    console.log(item);
    if (item) {
      this.setState({ selectUnitItem: item });
    }
  };
  // 单位取消
  handleUnitCancel = () => {
    this.setState({ showUnit: !this.state.showUnit });
  };
  rightElement() {
    const { freight } = this.state;
    const { isCount } = this.props;
    const { dispatcherId } = this.props.store['formData_' + this.props.from];
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color={isCount && (!freight || !dispatcherId) ? 'primary' : 'primary'} size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  api_serviceFee() {
    const { freight, unitIndex } = this.state;
    const {
      dispatcherId,
      invoiceFlag,
      dispatcherMode,
      orgId,
      platformTotalVolumeMin,
      platformTotalWeightMin,
      platformTotalVolume,
      platformTotalWeight,
    } = this.props.store['formData_' + this.props.from];
    if (!dispatcherId || !freight || !invoiceFlag) return; // 如果不开票 ，不计算服务费
    if (invoiceFlag === 2 && dispatcherMode !== 3) return; // 普票场景，非外调车的话，不计算服务费
    let serviceFeeTotal = 0;
    if (unitIndex === 1) {
      // 吨
      const weight = Math.max(platformTotalWeightMin,platformTotalWeight)
      serviceFeeTotal = xyMath.accMul(freight, weight); // 运费
    } else if (unitIndex === 2) {
      // 方
      const volume = Math.max(platformTotalVolumeMin,platformTotalVolume)
      serviceFeeTotal = xyMath.accMul(freight, volume); // 运费
    } else {
      // 趟
      serviceFeeTotal = freight; // 运费
    }
    serviceFeeTotal = Number(Number(serviceFeeTotal).toFixed(2));
    const data = {
      freightFee: filterFormat.moneyFormat(serviceFeeTotal), // 运费（分）
      dispatcherId: dispatcherId, // 调度员ID
      orgId: orgId, // 所属组织
    };
    if (!serviceFeeTotal || !dispatcherId) return;
    this.setState({ loadingText: '计算中..' }, () => {
      if (invoiceFlag === 1) {
        API.serviceFee(data)
          .then((res: any) => {
            if (res.success) {
              this.setState({ serviceFee: res.data.serviceFee, loadingText: null });
            } else {
              this.setState({ loadingText: null });
            }
          })
          .catch(() => {
            this.setState({ loadingText: null });
          });
      } else if (invoiceFlag === 2) {
        API.calculateServiceFee({amount: data.freightFee})
          .then((res: any) => {
            this.setState({
              technicalServiceFee: res.success ? res?.data?.technicalServiceFee : null,
              electronicContractFee: res.success ? res?.data?.electronicContractFee : null,
              positionCheckFee: res.success ? res?.data?.positionCheckFee : null,
              loadingText: null
            });
          })
          .catch(() => {this.setState({ loadingText: null });});
      }
    });
  }
  render() {
    const { visible, store, isCount } = this.props;
    const { showUnit, unitIndex, unitMap, freight, serviceFee, loadingText, generalInvoiceFee, technicalServiceFee, electronicContractFee, positionCheckFee } = this.state;
    const cargoList = store.stowageSelectedList;
    const { dispatcherId, platformTotalVolumeMin, platformTotalWeightMin, platformTotalVolume, platformTotalWeight, invoiceFlag, dispatcherMode } = this.props.store['formData_' + this.props.from];
    if (visible) {
      setTimeout(() => {
        this.refInput.current?.focus();
      }, 250);
    }
    // 判断用户 是否显示 吨/方 单位
    let showVolume = false;
    let showWeight = false;

    for (const item of cargoList) {
      if (item.totalVolume || item.totalWeight) {
        showVolume = showVolume ? showVolume : !!item.totalVolume;
        showWeight = showWeight ? showWeight : !!item.totalWeight;
      }
    }
    const list = unitMap.map((item: any) => {
      let showUnit = true;
      if (item.id == 2) {
        showUnit = showWeight;
      } else if (item.id == 3) {
        showUnit = showVolume;
      }
      return {
        ...item,
        show: showUnit,
        content(selected: boolean) {
          return (
            <Flex direction="row" justify="center" align="center">
              <MBText bold={selected} color={selected ? (showUnit ? 'primary' : 'disabled') : 'base'} numberOfLines={1}>
                {item.text}
              </MBText>
            </Flex>
          );
        },
      };
    });
    let serviceFeeTotal = 0;
    let number = 0;
    if (unitIndex === 1) {
      // 吨
      const weight = Math.max(platformTotalWeightMin,platformTotalWeight)
      number = weight;
      serviceFeeTotal = xyMath.accMul(freight, number); // 运费
    } else if (unitIndex === 2) {
      // 方
      const volume = Math.max(platformTotalVolumeMin,platformTotalVolume)
      number = volume;
      serviceFeeTotal = xyMath.accMul(freight, number); // 运费
    } else {
      // 趟
      serviceFeeTotal = freight; // 运费
    }
    serviceFeeTotal = parseFloat(Number(serviceFeeTotal).toFixed(2));
    return (
      <View>
        <Modal
          animationType="slide"
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请输入费用"
          position="bottom"
          visible={visible}
          headerLine={false}
          autoAdjustPosition={true}
          // onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          <Flex direction="row">
            <FlexItem flex={1}>
              <Flex direction="row" justify="space-between">
                <InputItem
                  ref={this.refInput}
                  style={styles.item}
                  titleStyle={styles.titleStyle}
                  value={freight}
                  title="运费（元）"
                  onChangeText={this.changeMoney}
                  placeholder="请输入"
                  keyboardType="numeric"
                />
                <TouchableOpacity style={styles.select} onPress={this.showUnitConfirm.bind(this)}>
                  <MBText>{unitMap[unitIndex].text}</MBText>
                  <Image style={{ width: 10, height: 10, marginLeft: 5 }} source={images.icon_down} />
                </TouchableOpacity>
              </Flex>
              {isCount && !!freight && !!serviceFeeTotal && (
                <View style={{ marginVertical: 10 }}>
                  {unitIndex !== 0 && (
                    <MBText color="#999" style={{ marginBottom: 20 }}>
                      运费合计：{serviceFeeTotal} 元 = {freight}元/{unitMap[unitIndex].text} x {number}
                      {unitMap[unitIndex].text}
                    </MBText>
                  )}
                  {dispatcherId ? (
                    invoiceFlag === 1 ? (
                      <MBText color="#999">
                        附加运费：{serviceFee && !loadingText ? filterFormat.moneyDecFormat(serviceFee) + ' 元' : loadingText}
                      </MBText>
                    ) : invoiceFlag === 2 && dispatcherMode === 3 ? (
                      // 外调车，且发票类型为普票，才渲染；满帮找车不渲染
                      generalInvoiceFee?.map((item: any, index: any) => {
                        return (
                          <MBText color="#999" style={{ marginBottom: 10 }}>
                            {item.fieldTitle + '：'}
                            {
                              item.feeCode === 40 && technicalServiceFee && !loadingText ? filterFormat.moneyDecFormat(technicalServiceFee) + '元' :
                                item.feeCode === 41 && electronicContractFee && !loadingText ? filterFormat.moneyDecFormat(electronicContractFee) + '元' :
                                  item.feeCode === 42 && positionCheckFee && !loadingText ? filterFormat.moneyDecFormat(positionCheckFee) + '元' :
                                    loadingText
                            }
                          </MBText>
                        );
                      })
                    ) : null
                  ) : (
                    <MBText color="#999" size="xs">
                      附加运费：需先选择调度员才能计算出结果
                    </MBText>
                  )}
                </View>
              )}
            </FlexItem>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
        <Modal
          animationType="slide"
          headerRight="完成"
          headerLeft="取消"
          title="请选择单位"
          position="bottom"
          visible={showUnit}
          headerLine={false}
          onConfirm={this.handleUnitConfirm}
          onCancel={this.handleUnitCancel}
          onMaskClose={this.handleUnitCancel}
          onRequestClose={this.handleUnitCancel}
        >
          <Flex direction="row" justify="center" align="center">
            <Flex.Item key="time">
              <View style={{ flexDirection: 'column' }}>
                <Selector type={2} value={unitIndex} rowTitle="content" list={list} scaleFont={true} onChange={this.handleUnitChange} />
              </View>
            </Flex.Item>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
