import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { Provider } from 'mobx-react';
import Store from '../store';
import { LayProvider } from '@ymm/rn-elements';

const RootStack = new RouterMap().getRouterMap(RouterPageName.StowageList);

const CustomerSelector: React.FunctionComponent<any> = (props) => {
  const store = new Store();
  return (
    <Provider store={store}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
      </LayProvider>
    </Provider>
  );
};

export default CustomerSelector;
