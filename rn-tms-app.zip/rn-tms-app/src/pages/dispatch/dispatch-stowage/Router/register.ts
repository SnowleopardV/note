import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import CreatDispatchPage from '../index'; // 创建调度 主页
import RemarksPage from '../../Remarks'; // 备注
import CarrierDriverPage from '../../CarrierDriver'; // 承运司机 搜索列表页面
import StowageListPage from '../list/index'; // 配置列表
import ChecklistPage from '../list/Checklist'; // 装车清单列表
import ChecklistDeletePage from '../list/ChecklistDelete'; // 装车清单列表 -- 移除
import ChecklistAddPage from '../list/ChecklistAdd'; // 装车清单列表 -- 新增
import SelectAddressPage from '../../SelectAddress'; // 选择地址 装货地址 卸货地址
import CostInputsPage from '../../components/CellCostInput/CostInputsPage'; // 费用项输入页面
import updataCarInfo from '../../components/CellCarryingVehicle/updataCarInfo'; // 修改承运司机绑定的车长和车型
import CarBoardPage from '../../../task-manage/car-board/index'; // 找车看板
import FreightAssistant from '../../freight-assistant'; // 运价助手
/**
 * RN页面
 */
export enum RouterPageName {
  DispatchList = 'DispatchList',
  Remarks = 'Remarks',
  CarrierDriver = 'CarrierDriver', // 承运司机 搜索列表页面
  StowageList = 'StowageList', // 配载列表
  Checklist = 'Checklist', // 装车清单列表
  ChecklistDelete = 'ChecklistDelete', // 装车清单列表--移除
  ChecklistAdd = 'ChecklistAdd', // 装车清单列表--新增
  SelectAddress = 'SelectAddress', // 选择地址 装货地址 卸货地址
  CostInputsPage = 'CostInputsPage', // 费用项输入页面
  UpdataCarInfo = 'UpdataCarInfo', // 修改承运司机绑定的车长和车型
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        DispatchList: {
          // 创建调度
          screen: CreatDispatchPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        Remarks: {
          // 备注
          screen: RemarksPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        CarrierDriver: {
          // 承运司机
          screen: CarrierDriverPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        StowageList: {
          // 配载列表
          screen: StowageListPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        Checklist: {
          // 装车清单
          screen: ChecklistPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        ChecklistDelete: {
          // 装车清单 移除
          screen: ChecklistDeletePage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        ChecklistAdd: {
          // 装车清单 新增
          screen: ChecklistAddPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        SelectAddress: {
          // 选择地址 装货地址 卸货地址
          screen: SelectAddressPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        CostInputsPage: {
          // 费用项输入页面
          screen: CostInputsPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        UpdataCarInfo: {
          // 选择地址 装货地址 卸货地址
          screen: updataCarInfo,
          navigationOptions: () => ({
            header: null,
          }),
        },
        /** 找车看板 */
        CarBoard: {
          screen: CarBoardPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        // 运价助手
        FreightAssistant: {
          screen: FreightAssistant,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
