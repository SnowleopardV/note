import React from 'react';
import { View, TouchableOpacity, Image, Platform } from 'react-native';
import { CellGroup, Whitespace, Flex, MBText, Button, Checkbox, Splitline, RNElementsUtil } from '@ymm/rn-elements';
import { MBBridge, App, MBToast } from '@ymm/rn-lib';
import { inject, observer } from 'mobx-react';
import keyMap from '../../keyMap'; //
import xyMath from '~/extends/xyMath'; //
import filterFormat from '~/extends/filterFormat'; //格式化
import NativeBridge from '~/extends/NativeBridge'; // 枚举值
import API from '../../api';
import Cell from '~/components/common/Cell';
import ModalInvoiceType from '../../components/ModalInvoiceType'; // 选择发票类型
import ModalSelectDriver from '../../components/ModalSelectDriver'; // 承运司机
import ModalSelectCar from '../../components/ModalSelectCar'; // 承运车辆
import ModalShipping from '../components/ModalShipping'; // 应收费用-- 运费
import ModalFollowCar from '../../components/ModalFollowCar'; // 是否跟车
import ModalDeposit from '../../components/ModalDeposit'; // 输入订金
import ModalSettlement from './ModalSettlement'; // 付费方式
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import FootDetail from '../../components/FootDetail'; // 底部明细
import images from '../../../../../public/static/images/index';
import ModalStrategy from '../../components/ModalStrategy';
import ModalAllocationStrategy from '../../components/ModalAllocationStrategy';
import styles from '../styles';
import ModalAddresslist from '~/pages/dispatch/ModalAddresslist';
import { PageProps } from '../../PropTypes';
import SelectOrganizeCell from '../../../../components/SelectOrganize/SelectOrganizeCell';
import CellAddressloadUnload from '../../components/CellAddressloadUnload';
import CellCarryingVehicle from '../../components/CellCarryingVehicle';
import CellSelectdispatcher from '../../components/CellSelectdispatcher';
import CellPlatformWeightVolume from '../../components/CellPlatformWeightVolume';
import ModalCargoInsurance from '../../components/ModalCargoInsurance';
import ModalLargeInsured from '../../components/ModalLargeInsured';
import ModalTruckType from '~/pages/dispatch/components/ModalTruckType';

// 指派外调车 -- 开票
export interface OutboundCarProps extends PageProps {
  changeInvice: any; // 改变发票类型，用于切换组件
}
@inject('store')
@observer
export default class OutboundCar extends React.Component<OutboundCarProps, any> {
  refSelectCar: React.RefObject<any>;
  refSelectDriver: React.RefObject<any>;
  timerApi: any;
  WeightVolumeLayout: any;
  constructor(props: OutboundCarProps) {
    super(props);
    keyMap.tagData = []; // 初始化 备注快捷标签
    this.refSelectCar = React.createRef();
    this.refSelectDriver = React.createRef();
    this.state = {
      showModal: 0, // 0 无，1 发票 2 调度员 3 承运司机 4是否跟车 5 承运车辆 6应收运费 7司机订金
      showFoot: true, // 控制是否显示底部按钮，如果有软盘弹起就先隐藏起来,
      showDetail: false, // 是否显示明细
      invoiceMap: [], // 发票类型name集合
      deliverymanMap: ['不跟车', '1人跟车', '2人跟车'],
      isAgreedCheck: true, // 是否同意协议，
      isRulesTips: false, // 是否开启验证提醒
      dispatchType: 31,
      dispatchTypeTopHeight: 0,
      loadunloadDomHeight: 0,
      loadOrderDomHeight: 0,
      depositDetails: [],
      depositType: null,
      isMybAssignValid: 0,
      isGeneralInvoiceEnable: false, // 当前组织是否支持普票货源
      toastContent: null, // 校验当前组织是否支持普票货源的toast提示
      isMybAuth: false // 满运宝是否认证
    };
  }
  componentDidMount() {
    this.refSelectCar.current.api_queryTruckList(null);
    this.refSelectDriver.current.api_DriverList(null);
    this.getSettings();
    // 获取当前组织是否支持普票货源
    this.checkGeneralInvoiceEnable();
  }
  async getSettings() {
    const data = (await API.personalSet()).data;
    if (!data || Object.keys(data).length === 0) return;

    this.setState({
      depositType: data.depositType,
      isMybAssignValid: data.isMybAssignValid,
    });
    if (data.depositType === 0) {
      // 固定金额
      const val = {
        deposit: data.isMybAssignValid ? data.depositAmount / 100 : null,
        item: {
          id: data.depositRefund === 2 ? null : data.depositRefund,
        },
      };
      this.setDeposit(val);
    } else if (data.depositType === 1) {
      // 运费区间
      this.setState({ depositDetails: data.depositDetails });
    }
    const data1 = {
      refundDeposit: data.depositRefund === 2 ? null : data.depositRefund, // 定金是否退还，0:不退，1:退还
      shortcut: data.depositRefund === 1 && data.depositReceipt === 1 ? ['4'] : [],
      selectedText: data.depositRefund === 1 && data.depositReceipt === 1 ? ['需回单'] : [],
    };
    this.props.store.setFormData(31, data1);
  }
  /** 获取当前组织是否支持普票货源 */
  async checkGeneralInvoiceEnable(): Promise<void> {
    const data = await API.checkGeneralInvoiceEnable({ orgId: this.props.store.formData_31.orgId });
    this.setState({
      isGeneralInvoiceEnable: data.success ? data?.data?.enable : false,
      toastContent: data.success ? data?.data?.toastContent : null
    });
  }
  // 计算总运费
  computedTotal = () => {
    const formData = this.props.store.formData_31;
    let { deliveryFee } = formData;
    const { platformTotalWeightMin, platformTotalVolumeMin, platformTotalWeight, platformTotalVolume } = formData;
    deliveryFee = filterFormat.moneyDecFormat(deliveryFee);
    let copeTotal = 0;
    if (formData.deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      copeTotal = xyMath.accMul(deliveryFee, weight); // 运费
    } else if (formData.deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      copeTotal = xyMath.accMul(deliveryFee, volume); // 运费
    } else {
      // 趟
      copeTotal = deliveryFee; // 运费
    }
    copeTotal = parseFloat(Number(copeTotal).toFixed(2));
    return copeTotal;
  };

  // 计算运费区间的订金
  computeDeposite = (val: any) => {
    if (!val) return;
    const { depositDetails, isMybAssignValid } = this.state;
    if (!depositDetails) return;
    for (const item of depositDetails) {
      const { minFeeAmount, maxFeeAmount } = item;
      if (val * 100 >= minFeeAmount && val * 100 < maxFeeAmount) {
        const data = {
          deposit: isMybAssignValid ? item.depositAmount : null,
        };
        this.props.store.setFormData(31, data);
        return;
      }
    }
    const data = {
      deposit: null,
    };
    this.props.store.setFormData(31, data);
  };
  // 设置定金和是否退还
  setDeposit = (val: any) => {
    const data = {
      deposit: filterFormat.moneyFormat(val.deposit), // 订金
      refundDeposit: val.item.id, // 定金是否退还，0:不退，1:退还
    };
    this.props.store.setFormData(31, data);
  };
  openTypeModal() {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }
  openModal(val: number) {
    this.setState({ showModal: val, showDetail: false });
  }
  goPages(val: number) {
    switch (val) {
      case 1: // 装车清单
        this.props.navigation.navigate('Checklist', {
          onSuccess: (val: any) => {
            const data = {
              deliveryFee: null, // 运费
              serviceFee: null, // 服务费,自动计算得出
              deliveryUnit: 1, // 运费单位(吨方趟,// 趟1,吨2,方3,件4,个5,台6,桶7)
            };
            this.props.store.setFormData(31, data);
            this.setState({ showDetail: false }); //关闭详情弹出层
          },
        });
        break;
      default:
        break;
    }
  }
  // 修改了时间
  changeDateTime(val: any, type: number) {
    this.setState({ showModal: 0 });
    if (type === 1) {
      const data = {
        loadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(31, data);
    } else if (type === 2) {
      const data = {
        unloadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(31, data);
    }
    const { loadTime, unloadTime } = this.props.store.formData_31;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
  }
  // 跳转到承运司机选择页面
  goDriver = () => {
    const { navigation, store } = this.props;
    const { dispatcherId } = store.formData_31;
    if (!dispatcherId) {
      NativeBridge.toast('请先选择调度员');
      return;
    }
    navigation.navigate('CarrierDriver', {
      //其他参数透传
      from: 31, // 指派外调车 -开发票
      dispatcherId: dispatcherId, // 调度员id
    });
  };

  // 发票类型
  handleInviceChange = (val: number) => {
    this.setState({ showModal: 0 });
    if (typeof val === 'number') {
      const { changeInvice } = this.props;
      changeInvice && changeInvice(val);
      const data = {
        invoiceFlag: val // 发票类型id
      };
      this.props.store.setFormData(31, data);
    }
    this.getSettings();
  };
  // 设置发票类型name集合
  setInvoiceMap = (names: object): void => {
    this.setState({invoiceMap: names});
  };
  // 设置满运宝是否认证的state
  setMybAuthState = (state: boolean): void => {
    this.setState({ isMybAuth: state });
  };
  // 选择承运司机
  handleDriverChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        driverId: val.driverId, // 司机id
        driverName: val.driverName, // 司机姓名
        driverPhone: val.driverPhone, // 司机电话
      };
      this.props.store.setFormData(31, data);
    }
  };
  // 选择承运车辆
  handleCarChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        carId: val.carId || null, // 车辆id
        carNo: val.carNo || null, // 车牌
        carType: val.carType || null, // 车型
        carLength: val.carLength || null, // 车长
      };
      this.props.store.setFormData(31, data);
    }
  };
  // 应收运费
  handleShippingChange = (val: any) => {
    const { hasLargeInsurance } = this.props.store;
    const { invoiceFlag, platformTotalWeightMin, platformTotalWeight, platformTotalVolumeMin, platformTotalVolume } = this.props.store.formData_31;
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliveryFee: filterFormat.moneyFormat(val.freight), // 运费
        deliveryUnit: val.unitMap[val.unitIndex].id, // 运费单位(吨方趟,具体枚举待定)
        // serviceFee: val.serviceFee, // 服务费,自动计算得出
        technicalServiceFee: val.technicalServiceFee, // 技术服务费,自动计算得出
        electronicContractFee: val.electronicContractFee, // 电子协议费,自动计算得出
        positionCheckFee: val.positionCheckFee, // 轨迹校验费,自动计算得出
      };
      this.props.store.setFormData(31, data);
      this.props.store.api_serviceFee(31); // 重新计算一遍服务费
      const totalDeliveryFee = this.computedTotal();
      this.computeDeposite(totalDeliveryFee);

      // 运费大于等于500元可享受保价运输服务,否则取消勾选保险服务，清除保险价格
      if (hasLargeInsurance) {
        if (!!totalDeliveryFee && totalDeliveryFee < 500) {
          MBToast.show('运费大于等于500元可享受保价运输服务');
          this.props.store.largeInsuranceCost = null;
          this.props.store.hasLargeInsurance = false;
        }
      }
    }
    // 普票场景, 应付运费弹框点击确定后, 付费方式逻辑同步执行
    if (invoiceFlag === 2) {
      const settlementList = [];
      let unitText: any;
      if (val.unitMap[val.unitIndex].id == 2) {
        // 吨
        const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
        unitText = weight ? weight : 0;
      } else if (val.unitMap[val.unitIndex].id == 3) {
        // 方
        const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
        unitText = volume ? volume : 0;
      } else {
        // 趟
      }
      let finalAmount: any = filterFormat.moneyFormat(val.freight);
      if (val.unitMap[val.unitIndex].id == 2 || val.unitMap[val.unitIndex].id == 3) {
        finalAmount = filterFormat.moneyFormat(val.freight) * unitText;
      }
      val.freight && settlementList.push({ settleType: 2, amount: finalAmount }); // 到付
      this.props.store.setFormData(31, {
        settlementList: settlementList
      });
    }
  };
  // 是否跟车
  handleFollowCarChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliverymanType: val.id - 1, // 是否跟车, 0:不跟车 1:1人跟车 2:2人跟车
      };
      this.props.store.setFormData(31, data);
    }
  };
  // 付费方式
  handleSettlementChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const settlementList = [];
      val.payNow && settlementList.push({ settleType: 1, amount: filterFormat.moneyFormat(val.payNow) }); // 现付
      val.toPay && settlementList.push({ settleType: 2, amount: filterFormat.moneyFormat(val.toPay) }); // 到付
      val.payBack && settlementList.push({ settleType: 3, amount: filterFormat.moneyFormat(val.payBack) }); // 回付
      val.OilCard &&
        settlementList.push({
          settleType: 5,
          amount: filterFormat.moneyFormat(val.OilCard),
          oilCardId: val.oilCardId || null,
          recieveDeposit: filterFormat.moneyFormat(val.recieveDeposit) || null,
        }); // 油卡
      const data = {
        settlementList: settlementList, // 付费方式
      };
      this.props.store.setFormData(31, data);
    }
  };
  // 输入订金
  handleDepositChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) this.setDeposit(val);
  };
  //  获取快捷标签接口 服务要求备注里的
  api_queryRemarkTags(dispatcherId: string | number) {
    API.queryRemarkTags({ dispatcherId: dispatcherId }).then((res: any) => {
      if (res.success && res.data) {
        keyMap.tagData = res.data.map((item: any) => {
          return { id: item.tagId, name: item.content };
        });
      }
    });
  }
  // 打开明细
  openDetail() {
    this.setState((state: any) => ({ showDetail: !state.showDetail }));
  }
  // 分摊策略 返回值
  handleAllocationChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        allocationStrategy: val.id, //
      };
      this.props.store.setFormData(31, data);
    }
  };
  goRemarks = (val: number) => {
    const { navigation } = this.props;
    navigation.navigate('Remarks', {
      //其他参数透传
      type: val,
      from: 31, // 指派外调车 -开发票
    });
  };
  LicensePlate = () => {
    const formData = this.props.store.formData_31;
    const { carNo } = formData;
    MBBridge.app.ui.inputCarNumber(carNo).then((res) => {
      const val = res.data.value;
      const data = { carNo: val };
      this.props.store.setFormData(31, data);
    });
  };
  // 提交
  submit = () => {
    const { isGeneralInvoiceEnable, isMybAuth, toastContent } = this.state;
    const formData = this.props.store.formData_31;
    const { loadTime, unloadTime } = formData;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
    const { isAgreedCheck } = this.state;
    if (!isAgreedCheck) {
      NativeBridge.toast('请确认同意相关协议');
      return;
    }
    const pass = this.isSubmit();
    this.setState({ isRulesTips: !pass });
    if (!pass) {
      NativeBridge.toast('有必选项未填');
      return;
    }
    if (formData.deposit && formData.refundDeposit === null) {
      NativeBridge.toast('请填写订金退还方式');
      return;
    }
    // 外调车-普票场景，司机订金必填，包括订金金额 及 退还方式
    if (formData.invoiceFlag === 2) {
      if (formData.deposit === null) {
        NativeBridge.toast('请填写订金金额');
        return;
      }
      if (formData.refundDeposit === null) {
        NativeBridge.toast('请填写订金退还方式');
        return;
      }
    }
    if (formData.invoiceFlag === 2 && !isGeneralInvoiceEnable && isMybAuth) {
      NativeBridge.toast(toastContent);
      return;
    }
    const stowageSelectedList = this.props.store.stowageSelectedList;
    if (!stowageSelectedList.length) {
      NativeBridge.toast('装车清单至少要有1个运单');
      this.setState({ isRulesTips: true });
      return;
    }
    let settlementTotal: string = '0'; // 支付费用总额
    for (const item of formData.settlementList) {
      settlementTotal = xyMath.accAdd(settlementTotal, item.amount);
    }
    const copeTotal = filterFormat.moneyFormat(this.computedTotal()); // 计算总货物数量 单位 分
    if (Number(settlementTotal) != Number(copeTotal)) {
      NativeBridge.toast('应付运费与付费方式项不相等');
    } else {
      this.api_createDispatch(formData);
    }
  };

  // 保存并使用
  api_createDispatch(formData: any) {
    if (this.timerApi) {
      // eslint-disable-next-line no-console
      console.log('还在请求中');
      return;
    }
    this.timerApi = true;
    setTimeout(() => {
      this.timerApi = false;
    }, 1500);
    // 填入多装多卸 地址数组
    const { loadingList, unloadingList } = this.props.store;
    loadingList.forEach((item: any, index: number) => (item.sequence = index + 1));
    unloadingList.forEach((item: any, index: number) => (item.sequence = index + 1));
    const tmsLoadUnloads = loadingList.concat(unloadingList);
    this.props.store.setFormData(31, { tmsLoadUnloads: tmsLoadUnloads });

    this.props.store
      .createDispatch(31, this.props.navigation)
      .then((res: any) => {
        if (res.success) {
          if (res.data?.tips || res.data?.tipType) {
            this.props.store.showBlockTip(res);
            setTimeout(() => {
              this.createSuccess(res);
            }, 2000);
          } else {
            this.createSuccess(res);
          }
        }
      })
      .catch((err: any) => {
        console.log('stowage(31)错误数据', err);
      });
  }

  createSuccess = (res: any) => {
    NativeBridge.toast(res.data?.deductCountTips || '指派外调车成功');
    // 返回运单列表
    if (Platform.OS === 'android') {
      App.sendEvent('refreshWaybillListView', { isClose: true });
      MBBridge.app.ui.closeWindow({});
    } else {
      setTimeout(() => {
        App.sendEvent('refreshWaybillListView', { isClose: true });
      }, 200);
      MBBridge.app.ui.closeWindow({});
    }
  };

  // 是否可以提交
  isSubmit = () => {
    const { isAgreedCheck } = this.state;
    const formData = this.props.store.formData_31;
    const {
      dispatcherId,
      driverId,
      allocationStrategy,
      deliveryFee,
      settlementList,
      loadTime,
      carType,
      carLength,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalVolume,
      platformTotalWeight,
    } = formData;
    const stowageSelectedList = this.props.store.stowageSelectedList;
    const showStrategy = stowageSelectedList.length > 1 ? true : false;

    const { loadingList, unloadingList } = this.props.store;
    const loadText = loadingList.find((item: any) => !item.address);
    const unloadText = unloadingList.find((item: any) => !item.address);
    const goodsInfoNum = platformTotalWeightMin || platformTotalVolumeMin || platformTotalWeight || platformTotalVolume;
    return (
      goodsInfoNum &&
      carType &&
      carLength &&
      isAgreedCheck &&
      dispatcherId &&
      driverId &&
      (showStrategy ? allocationStrategy : true) &&
      deliveryFee &&
      settlementList.length &&
      loadTime.dateCode &&
      !loadText &&
      !unloadText
    );
  };
  // 底部按钮
  footElement() {
    const { showDetail } = this.state;
    const formData = this.props.store.formData_31;
    const { refundDeposit } = formData;
    let { deliveryFee, serviceFee, deposit, invoiceFlag, technicalServiceFee, electronicContractFee, positionCheckFee } = formData;
    deliveryFee = filterFormat.moneyDecFormat(deliveryFee); // 运费
    deposit = filterFormat.moneyDecFormat(deposit); // 订金
    serviceFee = filterFormat.moneyDecFormat(serviceFee);
    technicalServiceFee = filterFormat.moneyDecFormat(technicalServiceFee);
    electronicContractFee = filterFormat.moneyDecFormat(electronicContractFee);
    positionCheckFee = filterFormat.moneyDecFormat(positionCheckFee);
    const copeTotal = this.computedTotal(); // 计算总货物数量
    let serviceFeeTotal;
    if (invoiceFlag === 1) {
      serviceFeeTotal = xyMath.accAdd(copeTotal, serviceFee); // 运费
    } else if (invoiceFlag === 2) {
      let firstNum = xyMath.accAdd(copeTotal, technicalServiceFee);
      let secondNum = xyMath.accAdd(electronicContractFee, positionCheckFee);
      serviceFeeTotal = xyMath.accAdd(firstNum, secondNum);
    }
    this.props.store.setTotalFee(serviceFeeTotal); // 记录下合计费用
    if (!!refundDeposit || !deposit) {
      deposit = 0;
    }
    const total: any = copeTotal ? xyMath.subtr(copeTotal, deposit) : 0;
    // 专票的明细数据
    const infoList = [
      { text: '应付运费', num: copeTotal },
      { text: '附加运费', num: serviceFee },
    ];
    // 普票的明细数据
    const generalInvoiceInfoList = [
      { text: '应付运费', num: copeTotal },
      { text: '技术服务费', num: technicalServiceFee },
      { text: '电子协议费', num: electronicContractFee },
      { text: '轨迹校验费', num: positionCheckFee }
    ];
    return (
      <View style={[styles.foot]}>
        <Image resizeMode={'stretch'} source={images.top_shadow} style={{ height: 10, width: '100%' }} />
        <View style={{ backgroundColor: '#FFFFFF' }}>
          {showDetail && invoiceFlag === 1 && FootDetail({ infoList: infoList })}
          {showDetail && invoiceFlag === 2 && FootDetail({ infoList: generalInvoiceInfoList })}
          {!!total ? (
            <View>
              <Flex direction="row" justify="center" align="center" style={{ margin: 10 }}>
                <MBText size="md">应付费用合计</MBText>
                <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
                  <MBText bold style={{ marginLeft: 10, marginBottom: 2 }} size="xs" color="#F54242">
                    ¥
                  </MBText>
                  <MBText bold size="md" color="#F54242">
                    {serviceFeeTotal}
                  </MBText>
                  <TouchableOpacity style={styles.flexRow} onPress={this.openDetail.bind(this)}>
                    <MBText style={{ color: '#666666', marginLeft: 20 }}>明细</MBText>
                    <Image style={[styles.icon, showDetail && styles.upturned]} source={images.icon_pull_down} />
                  </TouchableOpacity>
                </View>
              </Flex>
              <Flex direction="row" justify="center" align="center">
                <MBText color="#999999" size="xs">
                  （司机净得{total} = 运费{copeTotal ? copeTotal : 0} {deposit ? '- 订金' + deposit : ''}）
                </MBText>
              </Flex>
              <Whitespace vertical={10} />
              <Splitline color="#E8E8E8" />
            </View>
          ) : null}
          <Whitespace vertical={5} />
          <Button radius style={styles.btn} onPress={this.submit.bind(this)} size="sm" type="primary">
            确定调度
          </Button>
        </View>
      </View>
    );
  }
  // 跳转协议
  goAgreement = (val: number) => {
    let url = '';
    switch (val) {
      case 1: // 《货物运输交易协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=311&categoryId=123';
        break;
      case 2: // 《满运宝保障条款（托运人版本）》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=328&categoryId=123';
        break;
      case 3: // 《关于满帮平台货物发布及承运规范的公告》
        url =
          'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=3601&categoryId=234&userAgreement=true';
        break;
      case 5: // 《货物运输技术服务协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2137&categoryId=234&userAgreement=true';
        break;
      case 6: // 《货物运输协议》- 开普票
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2138&categoryId=234&userAgreement=true';
        break;
      case 7: // 《满帮平台订金担保规则》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2276&categoryId=234&userAgreement=true';
        break;
      default:
        break;
    }
    if (url) {
      NativeBridge.openWebViewPage(url);
    }
  };
  // 点击协议
  handleAgreedCheck() {
    this.setState(({ isAgreedCheck }: any) => ({
      isAgreedCheck: !isAgreedCheck,
    }));
  }
  // 协议
  AgreedCheckbox() {
    const { invoiceFlag } = this.props.store.formData_31;
    const { isAgreedCheck } = this.state;
    return (
      <Flex direction="row" align="center" wrap="wrap" style={styles.checkbox}>
        <Checkbox
          type="primary"
          size="sm"
          checked={isAgreedCheck}
          onChange={this.handleAgreedCheck.bind(this)}
          style={{ alignItems: 'flex-start' }}
        >
          {invoiceFlag === 0 || invoiceFlag === 1 ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 1)}>
                《货物运输交易协议》
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 2)}>
                《满运宝保障条款（托运人版本）》
              </MBText>
            </MBText>
          ) : (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">我已经阅读并同意</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 7)}>《满帮平台订金担保规则》</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 5)}>《货物运输技术服务协议》</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 6)}>《货物运输协议》</MBText>
            </MBText>
          )}
        </Checkbox>
      </Flex>
    );
  }
  extraElement(text: string) {
    return (
      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {text}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }

  // 货运险
  handleCargoInsuranceChange = (val?: any, tipText?: string, cargoInsuranceSelectItem?: any): void => {
    this.setState({ showModal: 0 });
    this.props.store.cargoInsurancePrice = val;
    this.props.store.cargoInsuranceTipText = tipText;
    this.props.store.cargoInsuranceSelectItem = cargoInsuranceSelectItem;
  };

  // 大额保价
  handleLargeInsuranceChange = (item?: any): void => {
    this.setState({ showModal: 0 });
    if (item) {
      const { goodsPrice, largeInsuranceCost, hasLargeInsurance } = item;
      this.props.store.largeInsurancePrice = goodsPrice;
      this.props.store.largeInsuranceCost = largeInsuranceCost;
      this.props.store.hasLargeInsurance = hasLargeInsurance;
    }
  };

  checkLargeInsurance(params: any) {
    return new Promise((resolve, reject) => {
      API.getlargeInsuranceCheck(params)
        .then((res: any) => {
          if (res.success && res.data) {
            resolve(res.data);
          } else {
            reject(res);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }

  render() {
    const { invoiceMap, showModal, isRulesTips, dispatchType, dispatchTypeTopHeight, loadunloadDomHeight, loadOrderDomHeight, isGeneralInvoiceEnable, isMybAuth, toastContent } = this.state;
    const { store } = this.props;
    const {
      searchAddressLoading,
      addressRequiredConfig,
      addressAssociateList,
      isLoadAddressChanged,
      isUnloadAddressChanged,
      onSelectAddressAssociate,
      showFooterBtn,
      addressType,
      cargoInsurance,
      cargoInsuranceTipText,
      cargoInsurancePrice,
      cargoInsuranceSelectItem,
      largeInsurancePrice,
      largeInsuranceRate,
      largeInsuranceCost,
      hasLargeInsurance,
      sensitiveWordList,
      changeTruckTypeModalVisible,
      filterTransType,
      truckTypeModalVisible,
      onConfirmTruckTypeModal1
    } = store;
    const formData = store.formData_31;
    const {
      driverName,
      driverPhone,
      invoiceFlag,
      mybCompanyName,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
      dispatcherInfoList,
      transType
    } = formData;
    const { deliveryFee, deliveryUnit, refundDeposit, loadTime } = formData;
    const { unloadTime, selectedText, tmsLoadUnloads, allocationStrategy } = formData;
    const CarrierDriver = driverName ? `${driverName} ${driverPhone ? '- ' + driverPhone : ''}` : ''; // 承运司机
    // 应付运费
    const totalDeliveryFee = this.computedTotal();
    let unitText = '';
    if (formData.deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      unitText = `${weight ? weight : '0'}吨`;
    } else if (formData.deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      unitText = `${volume ? volume : '0'}方`;
    } else {
      // 趟
    }

    const deliveryFeeText = deliveryFee
      ? `¥ ${filterFormat.moneyDecFormat(deliveryFee)} / ${keyMap.unitMap[deliveryUnit]} ${unitText ? '× ' + unitText : ''}`
      : '';
    const depositText = formData.deposit
      ? `¥ ${filterFormat.moneyDecFormat(formData.deposit)} ${refundDeposit === 1 ? ' / 退还' : refundDeposit === 0 ? ' / 不退还' : ''}`
      : '';
    // 结算方式 1：现付；2：到付;3：回付 4:月结 5：油卡
    const settlementMap: any = { 1: '现付¥', 2: '到付¥', 3: '回付¥', 4: '月结¥', 5: '油卡¥' };
    const settlementList = formData.settlementList;
    const settlementText = settlementList
      .map((item: any) => {
        return settlementMap[item.settleType] + filterFormat.moneyDecFormat(item.amount);
      })
      .join('; ');

    let notesText = selectedText && selectedText.length ? selectedText.join(';') + ';' : '';
    notesText = (formData.remark ? formData.remark + ';' : '') + notesText; // 备注

    const stowageSelectedList = store.stowageSelectedList;
    const selectedLength = stowageSelectedList.length ? stowageSelectedList.length + '单' : '';
    const loadText = tmsLoadUnloads[0].address;
    const unloadText = tmsLoadUnloads[1].address;
    const allocationStrategyText = keyMap.allocationStrategyMap[allocationStrategy] ? keyMap.allocationStrategyMap[allocationStrategy] : ''; // 分摊策略
    const showStrategy = stowageSelectedList.length > 1 ? true : false; // 是否显示分摊策略

    const minInsuranceAmount = cargoInsurance?.cargoInsuranceCheckAmountThreshold || 2;

    // 显示货运险
    const showCargoInsurancePrice =
      (invoiceFlag && 0 < cargoInsurancePrice && cargoInsurancePrice <= minInsuranceAmount) ||
      (minInsuranceAmount < cargoInsurancePrice && cargoInsuranceSelectItem.companyName);

    return (
      <View style={styles.page}>
        <CellAddressloadUnload
          isRulesTips={isRulesTips}
          tmsLoadUnloads={tmsLoadUnloads}
          required={true}
          topNode={
            <>
              <SelectOrganizeCell from={31} />
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  title="调度方式"
                  align="right"
                  value="外调车"
                  onPress={this.openTypeModal.bind(this)}
                  valueStyle={styles.valueStyle}
                />
                <Cell
                  title="发票类型"
                  align="right"
                  value={invoiceMap[invoiceFlag]}
                  onPress={this.openModal.bind(this, 1)}
                  valueStyle={styles.valueStyle}
                />
                {mybCompanyName ? <Cell title="发票抬头" readonly={true} value={mybCompanyName} align="right" /> : null}
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="装车清单"
                  bottomLine
                  value={selectedLength}
                  align="right"
                  placeholder="请选择"
                  valueStyle={styles.valueStyle}
                  onPress={this.goPages.bind(this, 1)}
                  extra={this.state.isRulesTips && !selectedLength && this.extraElement('装车清单未选择')}
                />
              </CellGroup>
              <Whitespace vertical={10} />
            </>
          }
          otherNode={
            <>
              <Whitespace vertical={10} />
              <View onLayout={(el: any) => (this.WeightVolumeLayout = el.nativeEvent?.layout)} />
              <CellGroup withBottomLine style={styles.addressCellGroup}>
                <Cell
                  required
                  title="装货时间"
                  value={loadTime.displayValue}
                  align="right"
                  placeholder="请选择"
                  valueStyle={styles.valueStyle}
                  onPress={this.openModal.bind(this, 9)}
                  extra={this.state.isRulesTips && !loadTime.displayValue && this.extraElement('装货时间未选择')}
                />
                <Cell
                  title="卸货时间"
                  value={unloadTime.displayValue}
                  align="right"
                  placeholder="请选择"
                  valueStyle={styles.valueStyle}
                  onPress={this.openModal.bind(this, 10)}
                />
                <CellPlatformWeightVolume
                  title="满帮货物重量/体积"
                  WeightVolumeLayout={this.WeightVolumeLayout}
                  from={31}
                  isRulesTips={this.state.isRulesTips}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <CellSelectdispatcher title="调度员" required isSingleChoice isRulesTips={this.state.isRulesTips} from={31} setMybAuthState={this.setMybAuthState} />
                {invoiceFlag === 2 ? (
                  <Cell
                    name="transType"
                    title="用车类型"
                    align="right"
                    required
                    value={filterTransType(transType)}
                    placeholder="请选择"
                    onPress={changeTruckTypeModalVisible}
                  />
                ) : null}
                <Cell
                  title="承运司机"
                  value={CarrierDriver}
                  required
                  align="right"
                  placeholder="请选择"
                  numberOfLines={1}
                  onPress={this.goDriver.bind(this, 3)}
                  valueStyle={styles.valueStyle}
                  extra={
                    this.state.isRulesTips &&
                    !CarrierDriver && (
                      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                        <MBText size="xs" color="#F54242" align="right">
                          承运司机未选择
                        </MBText>
                        <Whitespace vertical={12} />
                      </View>
                    )
                  }
                />
                {!!driverName && (
                  <CellCarryingVehicle $parent={this} from={31} isRulesTips={isRulesTips} navigation={this.props.navigation} />
                )}
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  title="应付运费"
                  required
                  value={deliveryFeeText}
                  align="right"
                  placeholder="请输入"
                  onPress={this.openModal.bind(this, 6)}
                  valueStyle={styles.valueStyle}
                  extra={
                    this.state.isRulesTips &&
                    !deliveryFee && (
                      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                        <MBText size="xs" color="#F54242" align="right">
                          应付运费未填
                        </MBText>
                        <Whitespace vertical={12} />
                      </View>
                    )
                  }
                />
                <Cell
                  title="付费方式"
                  required
                  value={settlementText}
                  align="right"
                  placeholder="请输入"
                  numberOfLines={1}
                  onPress={this.openModal.bind(this, 7)}
                  valueStyle={styles.valueStyle}
                  extra={
                    this.state.isRulesTips &&
                    !settlementText && (
                      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                        <MBText size="xs" color="#F54242" align="right">
                          付费方式未填
                        </MBText>
                        <Whitespace vertical={12} />
                      </View>
                    )
                  }
                />
                <Cell
                  required={invoiceFlag === 2}
                  title="司机订金"
                  value={depositText}
                  align="right"
                  placeholder="请输入"
                  onPress={this.openModal.bind(this, 8)}
                  valueStyle={styles.valueStyle}
                />
                {showStrategy && (
                  <Cell
                    required
                    title="分摊策略"
                    tag={
                      <TouchableOpacity onPress={this.openModal.bind(this, 11)} style={{ height: 50, width: 50, justifyContent: 'center' }}>
                        <Image source={images.icon_warning} style={{ height: 15, width: 15 }} />
                      </TouchableOpacity>
                    }
                    align="right"
                    value={allocationStrategyText}
                    placeholder="请选择"
                    numberOfLines={1}
                    onPress={this.openModal.bind(this, 12)}
                    valueStyle={styles.valueStyle}
                    extra={this.state.isRulesTips && !allocationStrategyText && this.extraElement('分摊策略未选择')}
                  />
                )}
              </CellGroup>
              <Whitespace vertical={10} />
              {cargoInsurance && cargoInsurance.remainTotalNum ? (
                <CellGroup withBottomLine>
                  <Cell
                    title="货运险"
                    value={showCargoInsurancePrice && cargoInsurancePrice ? `${cargoInsurancePrice}万元` : ''}
                    align="right"
                    placeholder={`总计剩余${cargoInsurance?.remainTotalNum}万额度可用`}
                    numberOfLines={2}
                    onPress={this.openModal.bind(this, 13)}
                  />
                </CellGroup>
              ) : null}

              {cargoInsurance && cargoInsurance.remainTotalNum ? <Whitespace vertical={10} /> : null}

              {!cargoInsurance?.remainTotalNum && invoiceFlag === 1 ? (
                <CellGroup withBottomLine>
                  <Cell
                    title="保价"
                    value={largeInsuranceCost ? `保价费¥${largeInsuranceCost}` : ''}
                    align="right"
                    placeholder="未保价货物货损最多赔付2万"
                    numberOfLines={2}
                    onPress={this.openModal.bind(this, 14)}
                  />
                </CellGroup>
              ) : null}

              {!cargoInsurance?.remainTotalNum && invoiceFlag ? <Whitespace vertical={10} /> : null}

              <CellGroup withBottomLine>
                <Cell
                  title="服务要求与备注"
                  value={notesText}
                  align="right"
                  placeholder="请输入"
                  numberOfLines={1}
                  valueStyle={styles.valueStyle}
                  onPress={this.goRemarks.bind(this, 1)}
                />
              </CellGroup>
              {this.AgreedCheckbox()}
              <View style={[styles.flexRow, { paddingRight: 5, paddingLeft: 35, paddingVertical: 10, flexWrap: 'wrap' }]}>
                <MBText size="xs" color="#999999">
                  请勿发布及托运危险货物、违禁货物，限运货物需有相应证明文件。具体详见法律公告页：
                  <MBText size="xs" color="primary" onPress={this.goAgreement.bind(this, 3)}>
                    《关于满帮平台货物发布及承运规范的公告》
                  </MBText>
                </MBText>
              </View>
              <Whitespace vertical={220} />
            </>
          }
          sensitiveWordList={sensitiveWordList}
        />
        {showFooterBtn ? this.footElement() : null}
        <ModalInvoiceType visible={showModal === 1} onChange={this.handleInviceChange} id={formData.invoiceFlag} setInvoiceMap={this.setInvoiceMap} isGeneralInvoiceEnable={isGeneralInvoiceEnable} dispatcherMode={3} isMybAuth={isMybAuth} toastContent={toastContent} />
        <ModalSelectDriver ref={this.refSelectDriver} visible={showModal === 3} from={3} onChange={this.handleDriverChange} />
        <ModalFollowCar visible={showModal === 4} onChange={this.handleFollowCarChange} />
        <ModalSelectCar ref={this.refSelectCar} visible={showModal === 5} from={3} onChange={this.handleCarChange} />
        <ModalShipping visible={showModal === 6} from={31} onChange={this.handleShippingChange} />
        <ModalSettlement visible={showModal === 7} onChange={this.handleSettlementChange} formData={settlementList} />
        <ModalDeposit visible={showModal === 8} from={31} onChange={this.handleDepositChange} />
        <TimePickerModal
          key="start"
          type="loadTime"
          visible={showModal === 9}
          onChange={(val: any) => {
            this.changeDateTime(val, 1);
          }}
          onCancel={this.openModal.bind(this, 0)}
        />
        <TimePickerModal
          key="end"
          type="unloadTime"
          visible={showModal === 10}
          onChange={(val: any) => {
            this.changeDateTime(val, 2);
          }}
          onCancel={this.openModal.bind(this, 0)}
        />
        <ModalStrategy
          visible={showModal === 11}
          onChange={(val: any) => {
            this.setState({ showModal: 0 });
          }}
        />
        <ModalAllocationStrategy
          visible={showModal === 12}
          onChange={(val: any) => {
            this.handleAllocationChange(val);
          }}
          id={allocationStrategy}
        />

        <ModalAddresslist
          dispatchTypeTopHeight={dispatchTypeTopHeight}
          loadunloadDomHeight={loadunloadDomHeight}
          loadOrderDomHeight={loadOrderDomHeight}
          dispatchType={dispatchType}
          addressValue={addressType ? unloadText : loadText}
          addressType={addressType}
          addressConfig={addressType ? addressRequiredConfig.unloadAddressConfig : addressRequiredConfig.loadAddressConfig}
          isAddressChanged={addressType ? isUnloadAddressChanged : isLoadAddressChanged}
          searchLoading={searchAddressLoading}
          addressList={addressAssociateList}
          onSelect={onSelectAddressAssociate}
          sensitiveWordList={sensitiveWordList}
        />

        <ModalCargoInsurance
          visible={showModal === 13}
          cargoInsurance={cargoInsurance}
          invoiceFlag={invoiceFlag}
          goodsPrice={showCargoInsurancePrice ? cargoInsurancePrice : null}
          cargoInsuranceTipText={cargoInsuranceTipText}
          cargoInsuranceSelectItem={cargoInsuranceSelectItem}
          dispatcherInfoList={dispatcherInfoList}
          onChange={this.handleCargoInsuranceChange}
        />

        <ModalLargeInsured
          visible={showModal === 14}
          goodsPrice={largeInsurancePrice}
          largeInsuranceCost={largeInsuranceCost}
          largeInsuranceRate={largeInsuranceRate}
          hasLargeInsurance={hasLargeInsurance}
          cargoList={stowageSelectedList}
          totalDeliveryFee={totalDeliveryFee}
          checkLargeInsurance={this.checkLargeInsurance}
          onChange={this.handleLargeInsuranceChange}
        />
        <ModalTruckType
          visible={truckTypeModalVisible}
          transType={transType}
          onConfirm={onConfirmTruckTypeModal1}
          onCancel={changeTruckTypeModalVisible}
        />
      </View>
    );
  }
}
