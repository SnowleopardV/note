import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import { Modal, Splitline, Whitespace, MBText, Flex } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import images from '../../../../../public/static/images';
import ModalOilCardAssociated from '../../components/ModalOilCardAssociated';
import verification from '~/extends/verification';
import filterFormat from '~/extends/filterFormat';
import NativeBridge from '~/extends/NativeBridge';
import xyMath from '~/extends/xyMath';
import { inject, observer } from 'mobx-react';

// 结算方式 模态框
const styles = StyleSheet.create({
  from: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  item: {
    flex: 1,
    paddingLeft: 0,
  },
  oilItem: {},
  oilItemPadding: {
    paddingLeft: 0,
  },
  line: {
    width: 370,
  },
  icon: {
    width: 21,
    height: 17.5,
  },
  titleStyle: {
    width: 80,
  },
});

interface Props {
  visible?: boolean;
  onChange?: any;
  showOilCardInput?: boolean;
  store?: any;
  formData?: any;
}
@inject('store')
@observer
export default class SettlementModal extends React.Component<Props, any> {
  static defaultProps = {
    showOilCardInput: true,
  };
  refInput: Array<any>;
  constructor(props: any) {
    super(props);
    this.refInput = [];
    this.state = {
      showOilCard: false, // 显示油卡选择弹窗
      showTips: false, // 是否显示提示
      formData: {
        // monthlyEnd: null, // 月结
        payNow: null, // 现付
        toPay: null, // 到付
        payBack: null, // 回付
        OilCard: null, // 油卡
        oilCardId: null, // 油卡号
        recieveDeposit: null, // 油卡押金
      },
      editable: true // 输入框是否可编辑
    };
  }
  componentWillReceiveProps(nextProps: any) {
    const { visible, formData } = nextProps;
    const { invoiceFlag, deliveryFee } = this.props.store.formData_31;
    if (visible) {
      setTimeout(() => {
        this.refInput[1]?.focus();
      }, 300);
      // 普票场景, 到付直接赋值为应付司机运费, 且所有输入框不可编辑
      if (invoiceFlag === 2) {
        this.setState({
          formData: {
            payNow: null,
            toPay: filterFormat.moneyDecFormat(formData?.find((item: any) => item.settleType === 2)?.amount), // 到付
            payBack: null,
            OilCard: null
          },
          editable: false
        });
      } else {
        this.setState({
          formData: {
            payNow: filterFormat.moneyDecFormat(formData?.find((item: any) => item.settleType === 1)?.amount), // 现付
            toPay: filterFormat.moneyDecFormat(formData?.find((item: any) => item.settleType === 2)?.amount), // 到付
            payBack: filterFormat.moneyDecFormat(formData?.find((item: any) => item.settleType === 3)?.amount), // 回付
            OilCard: filterFormat.moneyDecFormat(formData?.find((item: any) => item.settleType === 5)?.amount), // 油卡
          },
          editable: true
        });
      }
    }
  }
  componentDidUpdate() {
    const { showTips } = this.state;
    const { visible } = this.props;
    if (!visible && showTips) {
      this.setState({ showTips: false });
    }
  }
  handleConfirm = () => {
    const { onChange, store } = this.props;
    const { formData } = this.state;
    const {
      deliveryFee,
      deliveryUnit,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalVolume,
      platformTotalWeight,
    } = store.formData_31;
    if (formData.OilCard > 0 && formData.OilCard < 100) {
      NativeBridge.toast('油卡金额不能低于100');
      return;
    }
    let serviceFeeTotal = 0;
    if (deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin,platformTotalWeight)
      serviceFeeTotal = xyMath.accMul(deliveryFee, weight); // 运费
    } else if (deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin,platformTotalVolume)
      serviceFeeTotal = xyMath.accMul(deliveryFee, volume); // 运费
    } else {
      // 趟
      serviceFeeTotal = deliveryFee; // 运费
    }
    const fee = xyMath.accMul(filterFormat.moneyDecFormat(serviceFeeTotal), 0.3);
    if (formData.OilCard && fee < formData.OilCard) {
      NativeBridge.toast('油卡金额不能高于运费的30%');
      return;
    }
    onChange && onChange(formData);
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  // 点击了油卡
  handleOilCard() {
    console.log('点击油卡');
    this.setState({ showOilCard: true });
  }
  // 油卡选择弹窗返回值
  handleOilCardChange = (val: any) => {
    console.log(val);
    this.setState({ showOilCard: false });
    if (val) {
      this.setState(({ formData }: any) => ({
        formData: {
          ...formData,
          recieveDeposit: val.recieveDeposit, // 押金
          oilCardId: val.oilCardId,
        },
      }));
    }
  };
  changeShowTips = () => {
    this.setState((state: any) => ({
      showTips: !state.showTips,
    }));
  };

  setRefInput(el: any, index: number) {
    this.refInput[index] = el;
  }
  // 下一步 光标到下一个输入框
  onSubmitEditing(index: number) {
    this.refInput[index].focus();
  }

  changeText = (val: string, type: number) => {
    if (verification.price(val) || val === '') {
      switch (type) {
        case 1:
          this.setState(({ formData }: any) => ({
            formData: { ...formData, monthlyEnd: val },
          }));
          break;
        // case 2:
        //   this.setState(({ formData }: any) => ({
        //     formData: { ...formData, OilCard: val },
        //   }));
        //   break;
        case 3:
          this.setState(({ formData }: any) => ({
            formData: { ...formData, payNow: val },
          }));
          break;
        case 4:
          this.setState(({ formData }: any) => ({
            formData: { ...formData, toPay: val },
          }));
          break;
        case 5:
          this.setState(({ formData }: any) => ({
            formData: { ...formData, payBack: val },
          }));
          break;
        case 6:
          this.setState(({ formData }: any) => ({
            formData: { ...formData, OilCard: val },
          }));
          break;
        default:
          break;
      }
    }
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText color="primary" size="md">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible, showOilCardInput } = this.props;
    const { showOilCard, showTips, formData, editable } = this.state;
    const { monthlyEnd, OilCard, payNow, toPay, payBack } = formData;
    const { deliveryFee, serviceFee } = this.props.store.formData_31;
    return (
      <View>
        <Modal
          headerLeft="取消"
          headerRight={this.rightElement()}
          title="请输入付费方式"
          position="bottom"
          visible={visible && !showOilCard}
          headerLine={false}
          autoAdjustPosition={true}
          onConfirm={this.handleConfirm}
          onCancel={this.handleCancel}
          onMaskClose={this.handleCancel}
          onRequestClose={this.handleCancel}
        >
          {/* <Flex direction="row">
            <InputItem
              ref={this.refInput}
              titleStyle={styles.titleStyle}
              style={styles.item}
              value={monthlyEnd}
              title="月结（元）"
              onChangeText={(text: string) => this.changeText(text, 1)}
              placeholder="请输入"
              keyboardType="numeric"
            />
          </Flex> */}
          <Flex direction="row">
            <InputItem
              ref={(el) => this.setRefInput(el, 1)}
              returnKeyType="next"
              blurOnSubmit={false}
              onSubmitEditing={() => this.onSubmitEditing(2)}
              style={styles.item}
              titleStyle={styles.titleStyle}
              value={payNow}
              title="现付（元）"
              placeholder="请输入"
              keyboardType="numeric"
              editable={editable}
              onChangeText={(text: string) => this.changeText(text, 3)}
            />
          </Flex>
          <Splitline style={styles.line} color="#D9D9D9" />
          <Flex direction="row">
            <InputItem
              ref={(el) => this.setRefInput(el, 2)}
              returnKeyType="next"
              blurOnSubmit={false}
              onSubmitEditing={() => this.onSubmitEditing(3)}
              onChangeText={(text: string) => this.changeText(text, 6)}
              style={styles.item}
              titleStyle={styles.titleStyle}
              value={OilCard}
              inputStyle={styles.oilItemPadding}
              title="油卡（元）"
              placeholder="请输入"
              keyboardType="numeric"
              editable={editable}
            />
            {/* <TouchableOpacity onPress={this.handleOilCard.bind(this)}>
              <Image style={styles.icon} source={images.icon_oil_card} />
            </TouchableOpacity> */}
          </Flex>
          <Splitline style={styles.line} color="#D9D9D9" />
          {showOilCardInput && (
            <View>
              {/* <Flex direction="row" style={{ marginHorizontal: 20 }}>
                <TouchableWithoutFeedback onPress={this.changeShowTips.bind(this)} style={{ flex: 1 }}>
                  {deliveryFee && serviceFee ? (
                    <MBText>
                      <MBText color="#4885FF" size="xs">
                        预计可返
                      </MBText>
                      <MBText color="red">{filterFormat.moneyDecFormat(serviceFee)}</MBText>
                      <MBText color="#4885FF" size="xs">
                        元服务费
                      </MBText>
                    </MBText>
                  ) : (
                    <MBText color="#4885FF" size="xs">
                      运费用油，最高可返2.7%的服务费
                    </MBText>
                  )}
                </TouchableWithoutFeedback>
                <View style={{ position: 'relative' }}>
                  {showTips && (
                    <View
                      style={{
                        position: 'absolute',
                        width: 174,
                        height: 60,
                        left: -60,
                        top: -70,
                        zIndex: 100,
                        backgroundColor: '#000000',
                        borderRadius: 5,
                        opacity: 0.7,
                        paddingHorizontal: 10,
                        paddingVertical: 5,
                      }}
                    >
                      <MBText color="#FFFFFF" size="xs" onPress={this.changeShowTips.bind(this)}>
                        每用油1%，可返总运费（含服务费）的0.09%，最高用油30%，返点2.7%
                      </MBText>
                      <View
                        style={{
                          position: 'absolute',
                          bottom: -4,
                          left: 66,
                          borderStyle: 'solid',
                          borderBottomColor: 'rgba(0, 0, 0, 0.8)',
                          borderBottomWidth: 8,
                          borderLeftWidth: 8,
                          borderLeftColor: 'transparent',
                          transform: [{ rotate: '45deg' }],
                        }}
                      ></View>
                    </View>
                  )}
                  <TouchableOpacity onPress={this.changeShowTips.bind(this)}>
                    <Image style={{ height: 12, width: 12, marginLeft: 5 }} source={images.icon_tips} />
                  </TouchableOpacity>
                </View>
              </Flex> */}
            </View>
          )}
          <Flex direction="row">
            <InputItem
              ref={(el) => this.setRefInput(el, 3)}
              returnKeyType="next"
              blurOnSubmit={false}
              onSubmitEditing={() => this.onSubmitEditing(4)}
              style={styles.item}
              titleStyle={styles.titleStyle}
              value={toPay}
              title="到付（元）"
              placeholder="请输入"
              keyboardType="numeric"
              editable={editable}
              onChangeText={(text: string) => this.changeText(text, 4)}
            />
          </Flex>
          <Splitline style={styles.line} color="#D9D9D9" />
          <Flex direction="row">
            <InputItem
              ref={(el) => this.setRefInput(el, 4)}
              style={styles.item}
              titleStyle={styles.titleStyle}
              value={payBack}
              title="回付（元）"
              placeholder="请输入"
              keyboardType="numeric"
              editable={editable}
              onChangeText={(text: string) => this.changeText(text, 5)}
            />
          </Flex>
          <Splitline style={styles.line} color="#D9D9D9" />
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
