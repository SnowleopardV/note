/* eslint-disable no-console */
import React from 'react';
import { View, StyleSheet, ScrollView, Image } from 'react-native';
import { CellGroup, Whitespace, Button, MBText, Flex, Checkbox } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';

import Cell from '~/components/common/Cell';
import keyMap from '../keyMap'; // 枚举值
import filterFormat from '~/extends/filterFormat'; //格式化
import API from '../api';
import images from '../../../../public/static/images/index';
import SelectOrganizeCell from '../../../components/SelectOrganize/SelectOrganizeCell';
import CellAddressloadUnload from '../components/CellAddressloadUnload';

// 进入调度后的背景 ，假页面
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  page: {
    flex: 1,
  },
  foot: {
    backgroundColor: '#FFFFFF',
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
  icon: {
    width: 15,
    height: 15,
  },
  notes: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingRight: 5,
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
  },
  checkbox: {
    marginTop: 27,
    marginLeft: 10,
    marginRight: 10,
  },
  bottomShadow: {
    borderTopColor: '#EEE',
    borderTopWidth: 2,
    // shadowColor: '#000',
    // shadowOpacity: 0.5,
    // shadowOffset: { width: 10, height: 50 },
    // shadowRadius: 5,
    // elevation: 2,
  },
});
export interface PlatformProps {
  openTypeModal?: any; // 打开调度方式选择弹窗
  store?: any;
  navigation?: any;
  orderDetail?: any; // 订单详情 获取重量和体积
}
@inject('store')
@observer
export default class Platform extends React.Component<PlatformProps, any> {
  timerApi: any;
  constructor(props: PlatformProps) {
    super(props);
    keyMap.tagData = []; // 初始化 备注快捷标签
    this.state = {
      showModal: 0, // 0 无，1 发票 2 调度员 3 车型车长 4是否跟车 5 应收运费 6 司机订金
      invoiceMap: ['不开票', '满帮专票'],
      deliverymanMap: ['不跟车', '1人跟车', '2人跟车'],
      isAgreedCheck: true, // 协议是否同意
    };
  }
  openTypeModal() {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }
  openModal(val: number) {
    this.setState({ showModal: val, showDetail: false });
  }
  // 发票类型 1 不开票 2 专票
  handleInviceChange = (val: number) => {
    this.setState({ showModal: 0 });
    if (typeof val === 'number') {
      const data = {
        invoiceFlag: val, // 开票信息, 0不开票 1开专票
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 修改了时间
  changeDateTime(val: any, type: number) {
    this.setState({ showModal: 0 });
    console.log('修改了时间', type, val);
    if (type === 1) {
      const data = {
        loadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(4, data);
    } else if (type === 2) {
      const data = {
        unloadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(4, data);
    }
  }
  // 调度员
  handleDispatcherChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val && val.dispatcherId) {
      const data = {
        dispatcherId: val.dispatcherId, // 调度员id
        dispatcherName: val.dispatcherName, // 调度员姓名
        dispatcherPhone: val.dispatcherPhone, // 调度员手机号
      };
      this.props.store.setFormData(4, data);
      this.api_queryRemarkTags(val.dispatcherId);
    }
  };
  // 选择承运司机
  handleDriverChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        driverId: val.driverId, // 司机id
        driverName: val.driverName, // 司机姓名
        driverPhone: val.driverPhone, // 司机电话
      };
      this.props.store.setFormData(31, data);
    }
  };
  // 选择承运车
  handleCarChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        platformCarType: val.carType.map((item: any) => item.id), // 车型
        platformCarLength: val.carLength.map((item: any) => item.id), // 车长
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 应收运费
  handleShippingChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliveryFee: filterFormat.moneyFormat(val.freight), // 运费
        deliveryUnit: val.unitMap[val.unitIndex].id, // 运费单位(吨方趟,具体枚举待定)
        serviceFee: val.serviceFee, // 服务费,自动计算得出
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 是否跟车
  handleCFollowCarChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliverymanType: val.id - 1, // 是否跟车, 0:不跟车 1:1人跟车 2:2人跟车
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 输入订金
  handleDepositChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deposit: filterFormat.moneyFormat(val.deposit), // 订金
        refundDeposit: val.item.id, // 定金是否退还，0:不退，1:退还
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 到备注页面
  goRemarks = (val: number) => {
    const { navigation } = this.props;
    navigation.navigate('Remarks', {
      //其他参数透传
      type: val,
      from: 4, // 满帮找车
    });
  };
  //  获取快捷标签接口 服务要求备注里的
  api_queryRemarkTags(dispatcherId: string | number) {
    API.queryRemarkTags({ dispatcherId: dispatcherId }).then((res: any) => {
      if (res.success && res.data) {
        keyMap.tagData = res.data.map((item: any) => {
          return { id: item.tagId, name: item.content };
        });
      }
    });
  }
  // TODO 暂时不用
  submit() {
    // console.log('智能议价');
  }
  goAgreement = (val: any) => {
    // console.log('跳转协议', val);
  };
  // 点击协议
  handleAgreedCheck = () => {};
  // 协议
  AgreedCheckbox() {
    const { invoiceFlag } = this.props.store.formData_4;
    const { isAgreedCheck } = this.state;
    return (
      <Flex direction="row" align="center" wrap="wrap" style={styles.checkbox}>
        <Checkbox
          type="primary"
          size="sm"
          checked={isAgreedCheck}
          onChange={this.handleAgreedCheck.bind(this)}
          style={{ alignItems: 'flex-start' }}
        >
          {invoiceFlag ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 1)}>
                《货物运输交易协议》
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 2)}>
                《满运宝保障条款（托运人版本）》
              </MBText>
            </MBText>
          ) : (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 3)}>
                《货物运输协议》
              </MBText>
            </MBText>
          )}
        </Checkbox>
      </Flex>
    );
  }
  // 电话找车 , 默认电话找车 （保存并使用）
  submitPhone() {
    console.log('（保存并使用）');
  }

  // 保存并使用
  api_createDispatch(formData: any) {
    if (this.timerApi) {
      // console.log('还在请求中');
      return;
    }
  }
  // 底部按钮
  footElement() {
    return (
      <View style={[styles.foot, styles.bottomShadow]}>
        <Whitespace vertical={5} />
        <Button radius style={styles.btn} onPress={this.submitPhone.bind(this)} size="sm" type="primary">
          确定调度
        </Button>
      </View>
    );
  }
  render() {
    const { invoiceMap } = this.state;
    const { invoiceFlag, tmsLoadUnloads } = this.props.store.formData_4;
    const stowageSelectedList = this.props.store.stowageSelectedList;
    const selectedLength = stowageSelectedList.length ? stowageSelectedList.length + '单' : '';
    const loadText = tmsLoadUnloads[0].address;
    const unloadText = tmsLoadUnloads[1].address;
    return (
      <View style={styles.page}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <SelectOrganizeCell from={4} />
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell title="调度方式" value="满帮找车" align="right" valueStyle={styles.valueStyle} onPress={this.openTypeModal.bind(this)} />
            <Cell title="发票类型" value={invoiceMap[invoiceFlag]} align="right" valueStyle={styles.valueStyle} />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell required title="装车清单" value={selectedLength} align="right" placeholder="请选择" valueStyle={styles.valueStyle} />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellAddressloadUnload tmsLoadUnloads={tmsLoadUnloads} required={true} />
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell required title="装货时间" value="" align="right" placeholder="请选择" valueStyle={styles.valueStyle} />
            <Cell title="卸货时间" value="" align="right" placeholder="请选择" valueStyle={styles.valueStyle} />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell title="调度员" value="" required align="right" placeholder="请选择" onPress={this.openModal.bind(this, 2)} />
            <Cell title="车型车长" value="" required align="right" placeholder="请选择" onPress={this.openModal.bind(this, 3)} />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell title="应付运费" value="" required name="freight" align="right" placeholder="请输入" numberOfLines={1} />
            <Cell title="司机订金" value="" required name="type" align="right" placeholder="请输入" numberOfLines={1} />
            <Cell
              required
              title="分摊策略"
              tag={<Image source={images.icon_warning} style={{ height: 15, width: 15 }} />}
              align="right"
              value=""
              placeholder="请输入"
              numberOfLines={1}
              valueStyle={styles.valueStyle}
            />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell value="" title="服务要求与备注" name="notes" align="right" placeholder="请输入" numberOfLines={1} />
          </CellGroup>
        </ScrollView>
      </View>
    );
  }
}
