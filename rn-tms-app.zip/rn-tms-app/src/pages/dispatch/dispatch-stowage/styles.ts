import { StyleSheet } from 'react-native';
// import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  page: {
    flex: 1,
    position: 'relative',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  foot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
  icon: {
    width: 15,
    height: 15,
  },
  notes: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingRight: 5,
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
    lineHeight: 20,
  },
  checkbox: {
    marginTop: 27,
    marginLeft: 10,
    marginRight: 10,
  },
  addressCellGroup: {
    zIndex: 999,
  },
});
