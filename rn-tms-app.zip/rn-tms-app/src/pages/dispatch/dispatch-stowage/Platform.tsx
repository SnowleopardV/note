import React from 'react';
import { View, TouchableOpacity, Image, Platform as Platforms } from 'react-native';
import { CellGroup, Whitespace, Button, MBText, Flex, Splitline, Checkbox, RNElementsUtil } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import Cell from '~/components/common/Cell';
import ModalInvoiceType from '../components/ModalInvoiceType'; // 选择发票类型
import ModalCarTypeLength from '../components/ModalCarTypeLength'; // 车型车长
import ModalFollowCar from '../components/ModalFollowCar'; // 是否跟车
import ModalShipping from './components/ModalShipping'; // 应收费用-- 运费
import ModalDeposit from '../components/ModalDeposit'; // 输入订金
import FootDetail from '../components/FootDetail'; // 底部明细
import keyMap from '../keyMap'; // 枚举值
import xyMath from '~/extends/xyMath';
import filterFormat from '~/extends/filterFormat'; //格式化
import API from '../api';
import NativeBridge from '~/extends/NativeBridge';
import { MBBridge, App, MBToast } from '@ymm/rn-lib';
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import images from '../../../../public/static/images/index';
import ModalStrategy from '../components/ModalStrategy';
import ModalAllocationStrategy from '../components/ModalAllocationStrategy';
import styles from './styles';
import { PageProps } from '../PropTypes';
import SelectOrganizeCell from '../../../components/SelectOrganize/SelectOrganizeCell';
import CellAddressloadUnload from '../components/CellAddressloadUnload';
import CellSelectdispatcher from '../components/CellSelectdispatcher';
import commonData from '~/pages/commonData';
import OpenDispatchResultModal from '~/components/OpenDispatchResultModal';
import CellPlatformWeightVolume from '../components/CellPlatformWeightVolume';
import CellCargoDealMode from '../components/CellCargoDealMode';
import ModalCargoInsurance from '../components/ModalCargoInsurance';
import ModalLargeInsured from '../components/ModalLargeInsured';
import { goFreightAssistantPage } from '~/pages/dispatch/freight-assistant';
import ModalTruckType from '../components/ModalTruckType';
import { BaseReturnData } from '~/server';
// 满帮找车
@inject('store')
@observer
export default class Platform extends React.Component<PageProps, any> {
  timerApi: any;
  refOpenDispatchResult: any;
  WeightVolumeLayout: any;
  constructor(props: PageProps) {
    super(props);
    keyMap.tagData = []; // 初始化 备注快捷标签
    this.state = {
      showModal: 0, // 0 无，1 发票 2 调度员 3 车型车长 4是否跟车 5 应收运费 6 司机订金
      invoiceMap: [], // 发票类型name集合
      deliverymanMap: ['不跟车', '1人跟车', '2人跟车'],
      isAgreedCheck: true, // 协议是否同意
      showDetail: false, // 是否显示明细
      dispatchType: 4,
      dispatchTypeTopHeight: 0,
      loadunloadDomHeight: 0,
      loadOrderDomHeight: 0,
      depositDetails: [],
      depositType: null,
      isShowFreightAssistant: false, // 是否显示运价助手
      isGeneralInvoiceEnable: false, // 当前组织是否支持普票货源
      toastContent: null, // 校验当前组织是否支持普票货源的toast提示
      isMybAuth: false // 满运宝是否认证
    };
  }
  componentDidMount(): void {
    this.getSettings();
    this.props.store.getRemainNumber();
    // 查询是否有运价助手权限
    this.fetchSupportFreightAssistant();
    // 获取当前组织是否支持普票货源
    this.checkGeneralInvoiceEnable();
  }
  /** 运价助手权限查询 */
  async fetchSupportFreightAssistant(): Promise<void> {
    const data = await API.supportFreightAssistant();
    this.setState({
      isShowFreightAssistant: (data as BaseReturnData).data || false,
    });
  }
  /** 获取当前组织是否支持普票货源 */
  async checkGeneralInvoiceEnable(): Promise<void> {
    const data = await API.checkGeneralInvoiceEnable({ orgId: this.props.store.formData_4.orgId });
    this.setState({
      isGeneralInvoiceEnable: data.success ? data?.data?.enable : false,
      toastContent: data.success ? data?.data?.toastContent : null
    });
  }
  async getSettings(): Promise<void> {
    const data = (await API.personalSet()).data;
    if (!data || Object.keys(data).length === 0) return;

    this.setState({
      depositType: data.depositType,
    });
    if (data.depositType === 0) {
      // 固定金额
      const val = {
        deposit: data.depositAmount / 100,
        item: {
          id: data.depositRefund === 2 ? null : data.depositRefund,
        },
      };
      this.setDeposit(val);
    } else if (data.depositType === 1) {
      // 运费区间
      this.setState({ depositDetails: data.depositDetails });
    }
    const data1 = {
      refundDeposit: data.depositRefund === 2 ? null : data.depositRefund, // 定金是否退还，0:不退，1:退还
      shortcut: data.depositRefund === 1 && data.depositReceipt === 1 ? ['4'] : [],
      selectedText: data.depositRefund === 1 && data.depositReceipt === 1 ? ['需回单'] : [],
    };
    this.props.store.setFormData(4, data1);
  }
  // 计算总运费
  computedTotal = () => {
    const formData = this.props.store.formData_4;
    const { platformTotalWeightMin, platformTotalVolumeMin, platformTotalWeight, platformTotalVolume } = formData;
    let { deliveryFee } = formData;
    deliveryFee = filterFormat.moneyDecFormat(deliveryFee);
    let copeTotal = 0;
    if (formData.deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      copeTotal = xyMath.accMul(deliveryFee, weight); // 运费
    } else if (formData.deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      copeTotal = xyMath.accMul(deliveryFee, volume); // 运费
    } else {
      // 趟
      copeTotal = deliveryFee; // 运费
    }
    copeTotal = parseFloat(Number(copeTotal).toFixed(2));
    return copeTotal;
  };

  // 计算运费区间的订金
  computeDeposite = (val: any) => {
    if (!val) return;
    const { depositDetails } = this.state;
    if (!depositDetails) return;
    for (const item of depositDetails) {
      const { minFeeAmount, maxFeeAmount } = item;
      console.log(245, val, minFeeAmount, maxFeeAmount);
      if (val * 100 >= minFeeAmount && val * 100 < maxFeeAmount) {
        const data = {
          deposit: item.depositAmount,
        };
        this.props.store.setFormData(4, data);
        return;
      }
    }
    const data = {
      deposit: null,
    };
    this.props.store.setFormData(4, data);
  };
  // 设置定金和是否退还
  setDeposit = (val: any) => {
    const data = {
      deposit: filterFormat.moneyFormat(val.deposit), // 订金
      refundDeposit: val.item.id, // 定金是否退还，0:不退，1:退还
    };
    this.props.store.setFormData(4, data);
  };
  openTypeModal() {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }
  openModal(val: number) {
    this.setState({ showModal: val, showDetail: false });
  }
  goPages(val: number) {
    switch (val) {
      case 1: // 装车清单
        this.props.navigation.navigate('Checklist', {
          onSuccess: (val: any) => {
            const data = {
              deliveryFee: null, // 运费
              serviceFee: null, // 服务费,自动计算得出
              deliveryUnit: 1, // 运费单位(吨方趟,// 趟1,吨2,方3,件4,个5,台6,桶7)
            };
            this.props.store.setFormData(4, data);
            this.setState({ showDetail: false }); //关闭详情弹出层
          },
        });
        break;
      default:
        break;
    }
  }
  // 发票类型
  handleInviceChange = (val: number) => {
    this.setState({ showModal: 0 });
    if (typeof val === 'number') {
      const data = {
        invoiceFlag: val, // 发票类型id
        deliveryFee: null, // 运费
        deliveryUnit: 1, // 运费单位(吨方趟,// 趟1,吨2,方3,件4,个5,台6,桶7)
        serviceFee: null, // 服务费,自动计算得出
        deposit: null, // 定金
        refundDeposit: null, // 定金是否退还，0:不退，1:退还
        isRefresh: false, // 用来刷新组件
        platformTotalWeight: null, // 用于承载发往平台的货源的重量体积；
        platformTotalVolume: null, // 用于承载发往平台的货源的重量体积；
        platformTotalWeightMin: null, // 满帮货物最小重量
        platformTotalVolumeMin: null, // 满帮货物最小体积
      };
      this.props.store.setFormData(4, data);
      this.setState({ isRefresh: true, showDetail: false }, () => {
        this.setState({ isRefresh: false });
      });
    }
    this.getSettings();
  };
  // 设置发票类型name集合
  setInvoiceMap = (names: object): void => {
    this.setState({invoiceMap: names});
  };
  // 设置满运宝是否认证的state
  setMybAuthState = (state: boolean): void => {
    this.setState({ isMybAuth: state });
  };
  // 修改了时间
  changeDateTime(val: any, type: number) {
    this.setState({ showModal: 0 });
    if (type === 1) {
      const data = {
        loadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(4, data);
    } else if (type === 2) {
      const data = {
        unloadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(4, data);
    }
    const { loadTime, unloadTime } = this.props.store.formData_4;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
  }
  // 选择承运司机
  handleDriverChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        driverId: val.driverId, // 司机id
        driverName: val.driverName, // 司机姓名
        driverPhone: val.driverPhone, // 司机电话
      };
      this.props.store.setFormData(31, data);
    }
  };
  // 选择承运车
  handleCarChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        platformCarType: val.carType.map((item: any) => item.id), // 车型
        platformCarLength: val.carLength.map((item: any) => item.id), // 车长
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 应收运费
  handleShippingChange = (val: any) => {
    const { hasLargeInsurance } = this.props.store;
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliveryFee: val.freight ? filterFormat.moneyFormat(val.freight) : null, // 运费
        deliveryUnit: val.unitIndex && val.unitMap[val.unitIndex] ? val.unitMap[val.unitIndex].id : 1, // 运费单位(吨方趟,具体枚举待定)
        // serviceFee: val.serviceFee || null, // 服务费,自动计算得出
      };
      this.props.store.setFormData(4, data);
      const { invoiceFlag } = this.props.store.formData_4;
      if (!!invoiceFlag) {
        this.props.store.api_serviceFee(4);
      }
      const totalDeliveryFee = this.computedTotal();
      this.computeDeposite(totalDeliveryFee);

      // 运费大于等于500元可享受保价运输服务,否则取消勾选保险服务，清除保险价格
      if (hasLargeInsurance) {
        if (!!totalDeliveryFee && totalDeliveryFee < 500) {
          MBToast.show('运费大于等于500元可享受保价运输服务');
          this.props.store.largeInsuranceCost = null;
          this.props.store.hasLargeInsurance = false;
        }
      }
    }
  };
  // 是否跟车
  handleCFollowCarChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliverymanType: val.id - 1, // 是否跟车, 0:不跟车 1:1人跟车 2:2人跟车
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 输入订金
  handleDepositChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) this.setDeposit(val);
  };
  // 到备注页面
  goRemarks = (val: number) => {
    const { navigation } = this.props;
    navigation.navigate('Remarks', {
      //其他参数透传
      type: val,
      from: 4, // 满帮找车
    });
  };
  //  获取快捷标签接口 服务要求备注里的
  api_queryRemarkTags(dispatcherId: string | number) {
    API.queryRemarkTags({ dispatcherId: dispatcherId }).then((res: any) => {
      // console.log('获取快捷标签接口', res);
      if (res.success && res.data) {
        keyMap.tagData = res.data.map((item: any) => {
          return { id: item.tagId, name: item.content };
        });
      }
    });
  }
  // TODO 暂时不用
  submit() {
    // console.log('智能议价');
  }
  goAgreement = (val: any) => {
    let url = '';
    switch (val) {
      case 1: // 《货物运输交易协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=311&categoryId=123';
        break;
      case 2: // 《满运宝保障条款（托运人版本）》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=328&categoryId=123';
        break;
      case 3: // 《货物运输协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=330&categoryId=123';
        break;
      case 4: // 《关于满帮平台货物发布及承运规范的公告》
        url =
          'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=3601&categoryId=234&userAgreement=true';
        break;
      case 5: // 《货物运输技术服务协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2137&categoryId=234&userAgreement=true';
        break;
      case 6: // 《货物运输协议》- 开普票
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2138&categoryId=234&userAgreement=true';
        break;
      case 7: // 《满帮平台订金担保规则》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2276&categoryId=234&userAgreement=true';
        break;
      default:
        break;
    }
    if (url) {
      NativeBridge.openWebViewPage(url);
    }
  };
  // 点击协议
  handleAgreedCheck = () => {
    this.setState(({ isAgreedCheck }: any) => {
      return { isAgreedCheck: !isAgreedCheck };
    });
  };
  // 协议
  AgreedCheckbox() {
    const { invoiceFlag } = this.props.store.formData_4;
    const { isAgreedCheck } = this.state;
    return (
      <Flex direction="row" align="center" wrap="wrap" style={styles.checkbox}>
        <Checkbox
          type="primary"
          size="sm"
          checked={isAgreedCheck}
          onChange={this.handleAgreedCheck.bind(this)}
          style={{ alignItems: 'flex-start' }}
        >
          {invoiceFlag === 1 ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 1)}>
                《货物运输交易协议》
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 2)}>
                《满运宝保障条款（托运人版本）》
              </MBText>
            </MBText>
          ) : invoiceFlag === 2 ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">我已经阅读并同意</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 7)}>《满帮平台订金担保规则》</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 5)}>《货物运输技术服务协议》</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 6)}>《货物运输协议》</MBText>
            </MBText>
          ) : (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 3)}>
                《货物运输协议》
              </MBText>
            </MBText>
          )}
        </Checkbox>
      </Flex>
    );
  }
  // 分摊策略 返回值
  handleAllocationChange = (val: any) => {
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        allocationStrategy: val.id, //
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 电话找车 , 默认电话找车 （保存并使用）
  submitPhone() {
    const { isGeneralInvoiceEnable, isMybAuth, toastContent } = this.state;
    const formData = this.props.store.formData_4;
    const { loadTime, unloadTime } = formData;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
    const { isAgreedCheck } = this.state;
    if (!isAgreedCheck) {
      NativeBridge.toast('请确认同意相关协议');
      return;
    }
    const pass = this.isSubmit();
    this.setState({ isRulesTips: !pass });
    if (!pass) {
      NativeBridge.toast('有必选项未填');
      return;
    }
    if (formData.deposit === null) {
      NativeBridge.toast('请填写订金金额');
      return;
    }
    if (formData.refundDeposit === null) {
      NativeBridge.toast('请填写订金退还方式');
      return;
    }
    if (formData.invoiceFlag === 2 && !isGeneralInvoiceEnable && isMybAuth) {
      NativeBridge.toast(toastContent);
      return;
    }
    const stowageSelectedList = this.props.store.stowageSelectedList;
    if (!stowageSelectedList.length) {
      NativeBridge.toast('装车清单至少要有1个运单');
      this.setState({ isRulesTips: true });
      return;
    }
    const data = {
      auctionMode: false, //
    };
    this.props.store.setFormData(4, data);
    this.api_createDispatch(this.props.store.formData_4);
  }

  // 保存并使用
  api_createDispatch(formData: any) {
    if (this.timerApi) {
      return;
    }
    this.timerApi = true;
    setTimeout(() => {
      this.timerApi = false;
    }, 1500);

    // 填入多装多卸 地址数组
    const { loadingList, unloadingList } = this.props.store;
    loadingList.forEach((item: any, index: number) => (item.sequence = index + 1));
    unloadingList.forEach((item: any, index: number) => (item.sequence = index + 1));
    const tmsLoadUnloads = loadingList.concat(unloadingList);
    this.props.store.setFormData(4, { tmsLoadUnloads: tmsLoadUnloads });
    this.props.store
      .createDispatch(4, this.props.navigation)
      .then((res: any) => {
        if (res.success) {
          commonData.cargoRespList = res?.data?.cargoRespList;
          commonData.gotoId = { id: res?.data?.id, type: 'task' };
          if (res?.data?.allFailure && commonData.cargoRespList?.length) {
            this.refOpenDispatchResult?.openModal(); // 显示发货结果弹窗
            return;
          }
          if (res.data?.tips || res.data?.tipType) {
            this.props.store.showBlockTip(res);
            setTimeout(() => {
              this.createSuccess(res);
            }, 2000);
          } else {
            this.createSuccess(res);
          }
        }
      })
      .catch((err: any) => {
        console.log('stowage(4)错误数据', err);
      });
  }
  createSuccess = (res: any) => {
    NativeBridge.toast(res.data?.deductCountTips || '已发至满帮平台找车中');
    // 返回运单列表
    if (Platforms.OS === 'android') {
      App.sendEvent('refreshWaybillListView', { isClose: true });
      MBBridge.app.ui.closeWindow({});
    } else {
      setTimeout(() => {
        App.sendEvent('refreshWaybillListView', { isClose: true });
      }, 200);
      MBBridge.app.ui.closeWindow({});
    }
  };

  isSubmit() {
    const { isAgreedCheck } = this.state;
    const formData = this.props.store.formData_4;
    const {
      dispatcherId,
      allocationStrategy,
      platformCarType,
      deposit,
      loadTime,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
      deliveryFee,
    } = formData;
    const stowageSelectedList = this.props.store.stowageSelectedList;
    const showStrategy = stowageSelectedList.length > 1 ? true : false;
    const { loadingList, unloadingList } = this.props.store;
    const loadText = loadingList.find((item: any) => !item.address);
    const unloadText = unloadingList.find((item: any) => !item.address);
    const goodsInfoNum = platformTotalWeightMin || platformTotalVolumeMin || platformTotalWeight || platformTotalVolume;
    return (
      (this.deliveryFeeRequired ? deliveryFee : true) &&
      goodsInfoNum &&
      isAgreedCheck &&
      dispatcherId &&
      (showStrategy ? allocationStrategy : true) &&
      platformCarType.length &&
      deposit &&
      loadTime.dateCode &&
      !loadText &&
      !unloadText
    );
  }
  // 打开明细
  openDetail() {
    this.setState((state: any) => ({ showDetail: !state.showDetail }));
  }
  // 成交方式选择一口价，运费必填
  get deliveryFeeRequired(): boolean {
    const formData = this.props.store.formData_4;
    const { cargoDealMode } = formData;
    return cargoDealMode === 'BUYOUT';
  }
  // 底部按钮
  footElement() {
    const { showDetail } = this.state;
    const formData = this.props.store.formData_4;
    const { refundDeposit, invoiceFlag } = formData;
    let { deliveryFee, deposit, serviceFee } = formData;
    deliveryFee = filterFormat.moneyDecFormat(deliveryFee);
    deposit = filterFormat.moneyDecFormat(deposit);
    serviceFee = filterFormat.moneyDecFormat(serviceFee);
    const copeTotal = this.computedTotal(); // 计算总货物数量
    const serviceFeeTotal = xyMath.accAdd(copeTotal, serviceFee); // 运费
    this.props.store.setTotalFee(serviceFeeTotal); // 记录下合计费用
    if (!!refundDeposit || !deposit) {
      deposit = 0;
    }
    const total: any = copeTotal ? xyMath.subtr(copeTotal, deposit) : 0;
    // 专票的明细数据
    const infoList = [
      { text: '应付运费', num: copeTotal },
      { text: '附加运费', num: serviceFee },
    ];
    // 普票的明细数据
    const generalInvoiceInfoList = [
      { text: '应付运费', num: copeTotal }
    ];
    return (
      <View style={[styles.foot]}>
        <Image resizeMode={'stretch'} source={images.top_shadow} style={{ height: 10, width: '100%' }} />
        <View style={{ backgroundColor: '#FFFFFF' }}>
          {deliveryFee > 0 && showDetail && invoiceFlag === 1 && FootDetail({ infoList: infoList })}
          {deliveryFee > 0 && showDetail && invoiceFlag === 2 && FootDetail({ infoList: generalInvoiceInfoList })}
          {!!total && (
            <View>
              <Flex direction="row" justify="center" align="center" style={{ margin: 10 }}>
                <MBText size="md">应付费用合计</MBText>
                <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
                  <MBText bold style={{ marginLeft: 10, marginBottom: 2 }} size="xs" color="#F54242">
                    ¥
                  </MBText>
                  <MBText bold size="md" color="#F54242">
                    {serviceFeeTotal}
                  </MBText>
                  {!!invoiceFlag && (
                    <TouchableOpacity style={styles.flexRow} onPress={this.openDetail.bind(this)}>
                      <MBText style={{ color: '#666666', marginLeft: 20 }}>明细</MBText>
                      <Image style={[styles.icon, showDetail && styles.upturned]} source={images.icon_pull_down} />
                    </TouchableOpacity>
                  )}
                </View>
              </Flex>
              <Flex direction="row" justify="center" align="center">
                <MBText color="#999999" size="xs">
                  （司机净得{total} = 应付运费¥{copeTotal ? copeTotal : 0} {deposit ? '- 订金¥' + deposit : ''}）
                </MBText>
              </Flex>
              <Whitespace vertical={10} />
              <Splitline color="#E8E8E8" />
            </View>
          )}
          <Whitespace vertical={5} />
          <Button radius style={styles.btn} onPress={this.submitPhone.bind(this)} size="sm" type="primary">
            确定调度
          </Button>
        </View>
      </View>
    );
  }
  extraElement(text: string) {
    return (
      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {text}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }

  // 货运险
  handleCargoInsuranceChange = (val?: any, tipText?: string, cargoInsuranceSelectItem?: any): void => {
    this.setState({ showModal: 0 });
    this.props.store.cargoInsurancePrice = val;
    this.props.store.cargoInsuranceTipText = tipText;
    this.props.store.cargoInsuranceSelectItem = cargoInsuranceSelectItem;
  };

  // 大额保价
  handleLargeInsuranceChange = (item?: any): void => {
    this.setState({ showModal: 0 });
    if (item) {
      const { goodsPrice, largeInsuranceCost, hasLargeInsurance } = item;
      this.props.store.largeInsurancePrice = goodsPrice;
      this.props.store.largeInsuranceCost = largeInsuranceCost;
      this.props.store.hasLargeInsurance = hasLargeInsurance;
    }
  };

  checkLargeInsurance(params: any) {
    return new Promise((resolve, reject) => {
      API.getlargeInsuranceCheck(params)
        .then((res: any) => {
          if (res.success && res.data) {
            resolve(res.data);
          } else {
            reject(res);
          }
        })
        .catch((err: any) => {
          reject(err);
        });
    });
  }

  // 到运价助手页面
  goFreightAssistantPage = (): void => {
    goFreightAssistantPage(this, 'dispatchStowage');
  };

  render() {
    const { invoiceMap, showModal, isRefresh, isRulesTips, isGeneralInvoiceEnable, isMybAuth, toastContent } = this.state;
    const { store } = this.props;
    const {
      showFooterBtn,
      remainNumberInfo,
      cargoInsurance,
      cargoInsuranceTipText,
      cargoInsurancePrice,
      cargoInsuranceSelectItem,
      largeInsurancePrice,
      largeInsuranceRate,
      largeInsuranceCost,
      hasLargeInsurance,
      sensitiveWordList,
      truckTypeModalVisible,
      onConfirmTruckTypeModal,
      changeTruckTypeModalVisible,
      filterTransType,
    } = store;
    const formData = store.formData_4;
    const {
      deliveryFee,
      deliveryUnit,
      platformCarType,
      platformCarLength,
      invoiceFlag,
      mybCompanyName,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
      dispatcherInfoList,
      transType,
    } = formData;
    // 应付运费
    const totalDeliveryFee = this.computedTotal();
    const { refundDeposit, loadTime, unloadTime, selectedText, tmsLoadUnloads, allocationStrategy } = formData;
    const carTypeText = platformCarType.map((item: string) => keyMap.carTypePlate[item]).join('、');
    const carLengthText = platformCarLength.map((item: string) => keyMap.carLengthPlate[item]).join('、');

    const carTypeLength = carTypeText + (carTypeText ? ' / ' + carLengthText : carLengthText); // 车型 车长
    let unitText = '';
    if (formData.deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      unitText = `${weight ? weight : '0'}吨`;
    } else if (formData.deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      unitText = `${volume ? volume : '0'}方`;
    } else {
      // 趟
    }

    const deliveryFeeText = deliveryFee
      ? `¥ ${filterFormat.moneyDecFormat(deliveryFee)} / ${keyMap.unitMap[deliveryUnit]} ${unitText ? '× ' + unitText : ''}`
      : '';
    const depositText = formData.deposit
      ? `¥ ${filterFormat.moneyDecFormat(formData.deposit)} ${refundDeposit === 1 ? ' / 退还' : refundDeposit === 0 ? ' / 不退还' : ''}`
      : '';
    let notesText = selectedText && selectedText.length ? selectedText.join(';') + ';' : '';
    notesText = (formData.remark ? formData.remark + ';' : '') + notesText; // 备注
    const stowageSelectedList = store.stowageSelectedList;
    const selectedLength = stowageSelectedList.length ? stowageSelectedList.length + '单' : '';
    const allocationStrategyText = keyMap.allocationStrategyMap[allocationStrategy] ? keyMap.allocationStrategyMap[allocationStrategy] : ''; // 分摊策略
    const showStrategy = stowageSelectedList.length > 1 ? true : false; // 是否显示分摊策略

    const minInsuranceAmount = cargoInsurance?.cargoInsuranceCheckAmountThreshold || 2;

    // 显示货运险
    const showCargoInsurancePrice =
      (invoiceFlag && 0 < cargoInsurancePrice && cargoInsurancePrice <= minInsuranceAmount) ||
      (minInsuranceAmount < cargoInsurancePrice && cargoInsuranceSelectItem.companyName);

    return (
      <View style={styles.page}>
        <CellAddressloadUnload
          isRulesTips={isRulesTips}
          tmsLoadUnloads={tmsLoadUnloads}
          required={true}
          topNode={
            <>
              <SelectOrganizeCell from={4} />
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  title="调度方式"
                  value="满帮找车"
                  align="right"
                  valueStyle={styles.valueStyle}
                  onPress={this.openTypeModal.bind(this)}
                />
                {remainNumberInfo.remainDeliveryNumber && (
                  <Cell title={remainNumberInfo.appTip} value={`${remainNumberInfo.remainDeliveryNumber}次`} align="right" isLink={false} />
                )}
                <Cell
                  title="发票类型"
                  value={invoiceMap[invoiceFlag]}
                  align="right"
                  valueStyle={styles.valueStyle}
                  onPress={this.openModal.bind(this, 1)}
                />
                {mybCompanyName && invoiceFlag ? <Cell title="发票抬头" readonly={true} value={mybCompanyName} align="right" /> : null}
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  required
                  title="装车清单"
                  bottomLine
                  value={selectedLength}
                  align="right"
                  placeholder="请选择"
                  valueStyle={styles.valueStyle}
                  onPress={this.goPages.bind(this, 1)}
                  extra={this.state.isRulesTips && !selectedLength && this.extraElement('装车清单未选择')}
                />
              </CellGroup>
              <Whitespace vertical={10} />
            </>
          }
          otherNode={
            <>
              <Whitespace vertical={10} />
              <View onLayout={(el: any) => (this.WeightVolumeLayout = el.nativeEvent?.layout)} />
              <CellGroup withBottomLine style={styles.addressCellGroup}>
                <Cell
                  required
                  title="装货时间"
                  value={loadTime.displayValue}
                  align="right"
                  placeholder="请选择"
                  valueStyle={styles.valueStyle}
                  onPress={this.openModal.bind(this, 7)}
                  extra={this.state.isRulesTips && !loadTime.displayValue && this.extraElement('装货时间未选择')}
                />
                <Cell
                  title="卸货时间"
                  value={unloadTime.displayValue}
                  align="right"
                  placeholder="请选择"
                  valueStyle={styles.valueStyle}
                  onPress={this.openModal.bind(this, 8)}
                />
                <CellPlatformWeightVolume
                  title="满帮货物重量/体积"
                  WeightVolumeLayout={this.WeightVolumeLayout}
                  from={4}
                  isRulesTips={this.state.isRulesTips}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <CellSelectdispatcher
                  title="调度员"
                  isSingleChoice={this.props.store.batchDispatchFlag == 1}
                  required
                  isRulesTips={this.state.isRulesTips}
                  from={4}
                  showPhoneNumber={true}
                  setMybAuthState={this.setMybAuthState}
                />
                {invoiceFlag === 0 || invoiceFlag === 2 ? (
                  <Cell
                    name="transType"
                    title="用车类型"
                    align="right"
                    required
                    value={filterTransType(transType)}
                    placeholder="请选择"
                    onPress={changeTruckTypeModalVisible}
                  />
                ) : null}
                <Cell
                  title="车型车长"
                  value={carTypeLength}
                  required
                  align="right"
                  placeholder="请选择"
                  numberOfLines={2}
                  onPress={this.openModal.bind(this, 3)}
                  extra={this.state.isRulesTips && !carTypeLength && this.extraElement('车型车长未选择')}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <CellCargoDealMode title="成交方式" from={4} />
                {this.state.isShowFreightAssistant ? (
                  <Cell
                    title="运价助手"
                    value={'查看相似线路货源价格，辅助合理定价'}
                    align="right"
                    onPress={this.goFreightAssistantPage}
                    valueStyle={{ color: '#4885ff', fontSize: 13 }}
                  />
                ) : null}
                <Cell
                  title="应付运费"
                  value={deliveryFeeText}
                  name="freight"
                  align="right"
                  placeholder="请输入"
                  numberOfLines={1}
                  onPress={this.openModal.bind(this, 5)}
                  required={this.deliveryFeeRequired}
                  extra={this.deliveryFeeRequired && this.state.isRulesTips && !deliveryFeeText && this.extraElement('应付运费未选择')}
                />
                <Cell
                  title="司机订金"
                  value={depositText}
                  required
                  name="type"
                  align="right"
                  placeholder="请输入"
                  onPress={this.openModal.bind(this, 6)}
                  numberOfLines={1}
                  extra={this.state.isRulesTips && !formData.deposit && this.extraElement('司机订金未填')}
                />
                {showStrategy && (
                  <Cell
                    required
                    title="分摊策略"
                    tag={
                      <TouchableOpacity onPress={this.openModal.bind(this, 9)} style={{ height: 50, width: 50, justifyContent: 'center' }}>
                        <Image source={images.icon_warning} style={{ height: 15, width: 15 }} />
                      </TouchableOpacity>
                    }
                    align="right"
                    value={allocationStrategyText}
                    placeholder="请选择"
                    numberOfLines={1}
                    onPress={this.openModal.bind(this, 10)}
                    valueStyle={styles.valueStyle}
                    extra={this.state.isRulesTips && !allocationStrategyText && this.extraElement('分摊策略未选择')}
                  />
                )}
              </CellGroup>
              <Whitespace vertical={10} />
              {cargoInsurance && cargoInsurance.remainTotalNum ? (
                <CellGroup withBottomLine>
                  <Cell
                    title="货运险"
                    value={showCargoInsurancePrice && cargoInsurancePrice ? `${cargoInsurancePrice}万元` : ''}
                    align="right"
                    placeholder={`总计剩余${cargoInsurance?.remainTotalNum}万额度可用`}
                    numberOfLines={2}
                    onPress={this.openModal.bind(this, 13)}
                  />
                </CellGroup>
              ) : null}

              {cargoInsurance && cargoInsurance.remainTotalNum ? <Whitespace vertical={10} /> : null}

              {!cargoInsurance?.remainTotalNum && invoiceFlag === 1 ? (
                <CellGroup withBottomLine>
                  <Cell
                    title="保价"
                    value={largeInsuranceCost ? `保价费¥${largeInsuranceCost}` : ''}
                    align="right"
                    placeholder="未保价货物货损最多赔付2万"
                    numberOfLines={2}
                    onPress={this.openModal.bind(this, 14)}
                  />
                </CellGroup>
              ) : null}

              {!cargoInsurance?.remainTotalNum && invoiceFlag ? <Whitespace vertical={10} /> : null}

              <CellGroup withBottomLine>
                <Cell
                  value={notesText}
                  title="服务要求与备注"
                  name="notes"
                  align="right"
                  placeholder="请输入"
                  numberOfLines={1}
                  onPress={this.goRemarks.bind(this, 1)}
                />
              </CellGroup>
              {this.AgreedCheckbox()}
              <MBText style={{ marginTop: 20, paddingLeft: 35, paddingRight: 10, flexWrap: 'wrap' }}>
                <MBText size="xs" color="#999999">
                  请勿发布及托运危险货物、违禁货物，限运货物需有相应证明文件。具体详见法律公告页：
                </MBText>
                <MBText size="xs" color="primary" onPress={this.goAgreement.bind(this, 4)}>
                  《关于满帮平台货物发布及承运规范的公告》
                </MBText>
              </MBText>
              <Whitespace vertical={300} />
            </>
          }
          sensitiveWordList={sensitiveWordList}
        />
        {showFooterBtn ? this.footElement() : null}
        <ModalInvoiceType visible={showModal === 1} onChange={this.handleInviceChange} id={invoiceFlag} setInvoiceMap={this.setInvoiceMap} isGeneralInvoiceEnable={isGeneralInvoiceEnable} dispatcherMode={4} isMybAuth={isMybAuth} toastContent={toastContent} />
        <ModalCarTypeLength visible={showModal === 3} multiple={true} onChange={this.handleCarChange} />
        <ModalFollowCar visible={showModal === 4} onChange={this.handleCFollowCarChange} />
        {!isRefresh && <ModalShipping visible={showModal === 5} from={4} isCount={!!invoiceFlag} onChange={this.handleShippingChange} />}
        {!isRefresh && <ModalDeposit visible={showModal === 6} from={4} onChange={this.handleDepositChange} />}
        <TimePickerModal
          key="start"
          type="loadTime"
          visible={showModal === 7}
          onChange={(val: any) => this.changeDateTime(val, 1)}
          onCancel={this.openModal.bind(this, 0)}
        />
        <TimePickerModal
          key="end"
          type="unloadTime"
          visible={showModal === 8}
          onChange={(val: any) => this.changeDateTime(val, 2)}
          onCancel={this.openModal.bind(this, 0)}
        />
        <ModalStrategy visible={showModal === 9} onChange={(val: any) => this.setState({ showModal: 0 })} />
        <ModalAllocationStrategy
          visible={showModal === 10}
          onChange={(val: any) => this.handleAllocationChange(val)}
          id={allocationStrategy}
        />
        <OpenDispatchResultModal navigation={this.props.navigation} allFailure={true} ref={(el) => (this.refOpenDispatchResult = el)} />
        <ModalCargoInsurance
          visible={showModal === 13}
          cargoInsurance={cargoInsurance}
          invoiceFlag={invoiceFlag}
          goodsPrice={showCargoInsurancePrice ? cargoInsurancePrice : null}
          cargoInsuranceTipText={cargoInsuranceTipText}
          dispatcherInfoList={dispatcherInfoList}
          cargoInsuranceSelectItem={cargoInsuranceSelectItem}
          onChange={this.handleCargoInsuranceChange}
        />

        <ModalLargeInsured
          visible={showModal === 14}
          goodsPrice={largeInsurancePrice}
          largeInsuranceCost={largeInsuranceCost}
          largeInsuranceRate={largeInsuranceRate}
          hasLargeInsurance={hasLargeInsurance}
          cargoList={stowageSelectedList}
          totalDeliveryFee={totalDeliveryFee}
          checkLargeInsurance={this.checkLargeInsurance}
          onChange={this.handleLargeInsuranceChange}
        />

        <ModalTruckType
          visible={truckTypeModalVisible}
          transType={transType}
          onConfirm={onConfirmTruckTypeModal}
          onCancel={changeTruckTypeModalVisible}
        />
      </View>
    );
  }
}
