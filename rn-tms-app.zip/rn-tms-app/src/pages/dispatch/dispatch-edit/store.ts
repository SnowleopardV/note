import { observable, action } from 'mobx';
import { MBToast, MBBridge } from '@ymm/rn-lib';
import NativeBridge from '~/extends/NativeBridge';
import filterFormat from '~/extends/filterFormat';
import API from '../api';
import commonStore from '../commonStore'; // 公共stroe, 存放共有特性
import { Platform } from 'react-native';

class Store extends commonStore {
  // 货物信息 -- 任务详情里取得
  @observable TaskDetail: any = {
    cargoList: [
      // {
      //   cargoName: '', // 货物名称
      //   volume: '100', // 货物体积，单位方
      //   weight: '2000000', //  货物重量，单位克
      //   cargoUnit: '', // 包装
      //   quantity: '', // 件数
      //   remark: '', // 备注
      // },
    ],
    financialFlag: 0, // 生成财务数据状态 0:否 1:是（修改判断用）
    platformCarSearched: 0, // 平台是否已找到车 0:否 1:是（是否成交）
    taskState: '', // 任务状态
  };
  @observable id: any = null; // 运单id
  @observable transOrderNo: any = null; // 运单号
  @observable formDataWaybill: any = null; // 创建运单表单
  @observable isRequestFail: boolean = false; // 请求创建运单是否失败
  @observable truckTypeModalVisible: boolean = false; // 用车类型
  // 修改 创建运单表单
  @action setformDataWaybill(data: any) {
    this.formDataWaybill = data;
  }
  // 修改 运单表主键
  @action setOrderId(data: any) {
    this.id = data;
  }

  // 修改 任务详情
  @action setTaskDetail(data: any) {
    this.TaskDetail = data;
    const initFormData: any = {
      dispatcherMode: data.dispatcherMode,
      driverId: data.driverId,
      driverName: data.majorityDriverName,
      driverPhone: data.majorityDriverPhone,
      carId: data.carId,
      carNo: data.carNo,
      carType: data.carType,
      carLength: data.carLength,
      feeDetails: data.feeDetailList
        ? data.feeDetailList.map((item: any) => {
            const amount = filterFormat.moneyFormat(item.feeAmount);
            // 调整费用：37， 可正可负, 其他费用填写时只能是正数
            return {
              ...item,
              isDeductionFee: amount < 0,
              amount: item.feeCode == 37 ? amount : Math.abs(amount), // 调整费用
            };
          })
        : [],
      remark: data.remark,
      carrierId: data.carrierId,
      carrierName: data.carrierName,
      settlementList: data.settlementList
        ? data.settlementList.map((item: any) => {
            return {
              ...item,
              amount: filterFormat.moneyFormat(item.amount), // 结算方式
            };
          })
        : [],
      invoiceFlag: data.invoiceFlag ? Number(data.invoiceFlag) : 0,
      dispatcherId: data.dispatcherId,
      dispatcherName: data.dispatcherName,
      dispatcherPhone: data.dispatcherPhone,
      remainDispatchNumber: data.remainDispatchNumber,
      deliverymanType: data.deliverymanType,
      shortcut: data.shortcut,
      deliveryFee: data.deliveryFee,
      deliveryUnit: data.deliveryUnit,
      serviceFee: filterFormat.moneyFormat(data.serviceFee),
      deposit: data.deposit,
      refundDeposit: data.isRefundDeposit ? Number(data.isRefundDeposit) : 0,
      paymentCircle: data.paymentCircle,
      platformCarType: data.platformCarType || [],
      platformCarLength: data.platformCarLength || [],
      auctionMode: data.auctionMode,
      id: data.id,
      taskNo: data.taskNo,
      loadTime: data.loadTime || {},
      unloadTime: data.unloadTime || {},
      loadList: data.loadList || [],
      unloadList: data.unloadList || [],
      chargeMileage: null,
      boundMybCompanyId: data.boundMybCompanyId,
      authorizedMybCompanyId: data.authorizedMybCompanyId,
      mybCompanyName: data.mybCompanyName, // 发票抬头
      carrierInvoiceFlag: data.carrierInvoiceFlag, // 承运商是否开票标识，0：不开票；1：开票 只在承运商下显示
      taxWay: data.taxWay, // 计税方式 0：不计税 1：含税价 2：不含税价 只在承运商下显示
      taxRate: data.taxRate, // 税率 两位小数 只在承运商下显示
      taxFee: filterFormat.moneyDecFormat(data.taxFee), // 税金 单位分 只在承运商下显示
      dispatcherInfoList: data.dispatcherListInfo, // 多选调度员列表
      platformTotalWeightMin: parseFloat(Number(data.platformTotalWeightMin || 0).toFixed(2)) || null, //
      platformTotalVolumeMin: parseFloat(Number(data.platformTotalVolumeMin || 0).toFixed(2)) || null, //
      platformTotalWeight: parseFloat(Number(data.platformTotalWeight || 0).toFixed(2)) || null, // 用于承载发往平台的货源的重量体积；
      platformTotalVolume: parseFloat(Number(data.platformTotalVolume || 0).toFixed(2)) || null, // 用于承载发往平台的货源的重量体积；
      orgId: data.orgId, // 所属组织 id
      orgName: data.orgName, // 所属组织 名称
      mybOrderId: data.mybOrderId,
    };
    data.feeDetailList?.map((item: any) => {
      if (item.feeCode === 40) {
        initFormData.technicalServiceFee = filterFormat.moneyFormat(item.feeAmount); // 技术服务费
      } else if (item.feeCode === 41) {
        initFormData.electronicContractFee = filterFormat.moneyFormat(item.feeAmount); // 电子协议费
      } else if (item.feeCode === 42) {
        initFormData.positionCheckFee = filterFormat.moneyFormat(item.feeAmount); // 轨迹校验费
      }
    });
    switch (Number(data.dispatcherMode)) {
      case 1:
        // 指派自有车 -- 表单
        this.formData_1 = { ...initFormData, dispatcherMode: 1 };
        break;
      case 2:
        // 指派承运商 -- 表单
        this.formData_2 = { ...initFormData, dispatcherMode: 2 };
        break;
      case 3:
        // 指派外调车 -- 表单
        this.formData_30 = { ...initFormData, dispatcherMode: 3, invoiceFlag: 0 }; // 不开票
        // this.formData_31 = { ...initFormData, dispatcherMode: 3, invoiceFlag: 1 }; // 专票
        break;
      case 4:
        // 指派满帮找车 -- 表单
        this.formData_4 = {
          ...initFormData,
          dispatcherMode: 4,
          cargoDealMode: data.cargoDealMode || 'TEL',
          transType: Number(data.transType),
        }; // 成交模式 BUYOUT = 一口价; TEL = 电议}; // 不开票 / 专票
        break;
      default:
        break;
    }
    // 装卸货地址初始化
    const tmsLoadUnloads = [initFormData.loadList[0] || {}, initFormData.unloadList[0] || {}];
    this.initLoadUnloadAddress(1, { tmsLoadUnloads });
    this.initLoadUnloadAddress(2, { tmsLoadUnloads });
    this.initLoadUnloadAddress(30, { tmsLoadUnloads });
    // this.initLoadUnloadAddress(31, { tmsLoadUnloads });
    this.initLoadUnloadAddress(4, { tmsLoadUnloads });
  }

  // 修改表单
  @action setFormData(type: number, data: any) {
    const formData = this[`formData_${type}`];
    return (this[`formData_${type}`] = {
      ...formData,
      ...data,
    });
  }

  // 取得对应页面的备注
  @action getRemarks(type: number) {
    return this['formData_' + type] ? this['formData_' + type].remark : '';
  }
  // 取得备注值，超长字数隐藏
  @action remarksText(text: string, num = 15) {
    if (text && text.length > num) {
      return text.slice(0, num) + '...';
    } else {
      return text;
    }
  }

  // 修改调度
  @action api_editDispatch(formData: any) {
    const data = {
      ...formData,
      loadTime: formData.loadTime && formData.loadTime.dateCode ? formData.loadTime : null,
      unloadTime: formData.unloadTime && formData.unloadTime.dateCode ? formData.unloadTime : null,
      totalFee: this.totalFee, // 合计费用
      tmsLoadUnloads: formData.tmsLoadUnloads.map((item: any) => {
        const { layout, val, ...orther } = item;
        return orther;
      }),
    };
    if (data.dispatcherMode == 4) {
      data.version = '1.0';
      if (!data.deliveryFee) {
        data.serviceFee = null;
        data.serviceFeeRate = null;
        data.totalFee = null;
        data.feeDetails = null;
      } else if (data.invoiceFlag != 1) {
        data.serviceFee = null; // 服务费,自动计算得出
        data.serviceFeeRate = null; // 服务费率
      }
    }
    return API.editDispatch(data, false);
  }
  // 保存并使用
  @action editDispatch = async (formData: any) => {
    formData.id = this.TaskDetail.id;
    const type = formData.dispatcherMode;
    const loadLatitude = formData.tmsLoadUnloads[0]?.addressLatitude;
    const loadLongitude = formData.tmsLoadUnloads[0]?.addressLongitude;
    const unloadLatitude = formData.tmsLoadUnloads[1]?.addressLatitude;
    const unloadLongitude = formData.tmsLoadUnloads[1]?.addressLongitude;
    // 装卸货经纬度同时存在
    const loadLatiLongtudeFlag = loadLatitude && loadLatitude !== '0' && loadLongitude && loadLongitude !== '0';
    const unloadLatiLongtudeFlag = unloadLatitude && unloadLatitude !== '0' && unloadLongitude && unloadLongitude !== '0';

    MBBridge.ui.showLoading({});

    // 根据经纬度查询线路里程
    if (loadLatiLongtudeFlag && unloadLatiLongtudeFlag) {
      const costMileageparams = { loadLatitude, loadLongitude, unloadLatitude, unloadLongitude };
      await this.getCostMileage(type, costMileageparams);
    }
    // 调度前查询是否开启必须poi地址
    await this.getAddressConfig(false);

    const loadAddressConfig = this.addressRequiredConfig.loadAddressConfig;
    const unloadAddressConfig = this.addressRequiredConfig.unloadAddressConfig;

    if (
      ((type === 4 || (type === 3 && formData.invoiceFlag)) && !loadLatiLongtudeFlag) ||
      ((type === 1 || type === 2 || (type === 3 && !formData.invoiceFlag)) && loadAddressConfig && !loadLatiLongtudeFlag)
    ) {
      MBToast.show('装货地址必须从搜索下拉框中选择');
      return Promise.resolve({ success: false });
    }

    if (
      ((type === 4 || (type === 3 && formData.invoiceFlag)) && !unloadLatiLongtudeFlag) ||
      ((type === 1 || type === 2 || (type === 3 && !formData.invoiceFlag)) && unloadAddressConfig && !unloadLatiLongtudeFlag)
    ) {
      MBToast.show('卸货地址必须从搜索下拉框中选择');
      return Promise.resolve({ success: false });
    }

    formData.chargeMileage = formData.chargeMileage?.toString();
    if (formData.dispatcherMode == 2) {
      formData.taxWay = formData.carrierInvoiceFlag ? formData.taxWay : null; //
      formData.taxRate = formData.carrierInvoiceFlag ? formData.taxRate : null; //
      formData.taxFee = formData.carrierInvoiceFlag ? filterFormat.moneyFormat(formData.taxFee) : null; // 税金 单位分 只在承运商下显示
    } else if (formData.dispatcherMode == 3) {
      formData.taxFee = formData.invoiceFlag ? filterFormat.moneyFormat(formData.taxFee) : null; // 税金 单位分 只在承运商下显示
    } else if (formData.dispatcherMode == 4) {
      formData.taxFee = filterFormat.moneyFormat(formData.taxFee); // 税金 单位分 只在承运商下显示
    } else {
      formData.taxFee = null; // 税金 单位分 只在承运商下显示
    }
    return this.api_editDispatch(formData)
      .catch((err: any) => {
        console.log('保存并使用请求错误', err);
        // 失败重新请求详情
        if (err.code == 270001 || err?.data?.code == 270001) {
          this.api_taskDetail(formData.id);
        }
        return err;
      })
      .finally(() => {
        MBBridge.ui.hideLoading({});
      });
  };
  // 返回上一页
  @action goBack = () => {
    MBBridge.rnruntime.handlebackResult({ data: '1' });
    MBBridge.app.ui.closeWindow({});
  };

  @action toastNotEdit = (text: string) => {
    NativeBridge.toast(`不支持修改#${text}#`);
  };

  // 获取运单任务详情
  @action api_taskDetail(id: string) {
    API.taskDetail({ id: id })
      .then((res: any) => {
        if (res.success && res.data) {
          this.setTaskDetail(res.data);
        }
      })
      .catch((er) => {
        if (er?.code === '900002') {
          MBBridge.rnruntime.handlebackResult({});
          if (Platform.OS == 'ios') {
            setTimeout(() => {
              MBBridge.app.ui.closeWindow({});
            }, 300);
          }
        }
      });
  }

  // 0821 新修改
  // 处理任务单带过来的装卸货地址
  @action
  handleContactList = (type: number, contactList: any) => {
    const tmsLoadUnloads = contactList.map((item: any, index: number) => {
      const { loadType, addressLongitude, addressLatitude } = item;
      const { loadAddressConfig, unloadAddressConfig } = this.addressRequiredConfig;
      const addressConfig = loadType === 1 ? loadAddressConfig : unloadAddressConfig;
      // 经纬度同时存在判断
      const longlatitudeFlag = addressLongitude && addressLongitude !== '0' && addressLatitude && addressLatitude !== '0';
      // 默认带入地址信息
      let handleItem = { ...item };
      // 处理不带入地址，并初始化地址字段
      // 1、指派自有车/指派承运商/指派外调车-不开票
      if (type === 1 || type === 2 || type === 30) {
        // 地址无经纬度 且 后台设置必须经纬度
        if (!longlatitudeFlag && addressConfig) {
          handleItem = { ...this.defaultContact, loadType };
        }
      }
      return handleItem;
    });

    return tmsLoadUnloads;
  };
  // 初始化装卸货货地址
  @action
  initLoadUnloadAddress = (type: number, data: any) => {
    const tmsLoadUnloads = this.handleContactList(type, data.tmsLoadUnloads);
    this.setFormData(type, { tmsLoadUnloads: tmsLoadUnloads });
  };

  onConfirmTruckTypeModal = (val: any) => {
    this.formData_4.transType = val;
    this.changeTruckTypeModalVisible();
  };

  changeTruckTypeModalVisible = () => {
    this.truckTypeModalVisible = !this.truckTypeModalVisible;
  };
}
export default Store;
