import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import EditDispatchPage from '../index'; // 修改调度 主页
import RemarksPage from '../../Remarks'; // 备注
import CarrierDriverPage from '../../CarrierDriver'; // 承运司机 搜索列表页面
import CostInputsPage from '../../components/CellCostInput/CostInputsPage'; // 费用项输入页面
/**
 * RN页面
 */
export enum RouterPageName {
  EditDispatch = 'EditDispatch',
  Remarks = 'Remarks',
  CarrierDriver = 'CarrierDriver', // 承运司机 搜索列表页面
  CostInputsPage = 'CostInputsPage', // 费用项输入页面
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        EditDispatch: {
          // 创建调度
          screen: EditDispatchPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        Remarks: {
          // 备注
          screen: RemarksPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        CarrierDriver: {
          // 承运司机
          screen: CarrierDriverPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
        CostInputsPage: {
          // 费用项输入页面
          screen: CostInputsPage,
          navigationOptions: () => ({
            header: null,
          }),
        },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
