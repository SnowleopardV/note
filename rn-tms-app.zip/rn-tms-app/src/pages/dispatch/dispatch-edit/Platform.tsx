import React from 'react';
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { CellGroup, Whitespace, Button, MBText, Flex, Splitline, Checkbox, RNElementsUtil } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';

import Cell from '~/components/common/Cell';
import ModalInvoiceType from '../components/ModalInvoiceType'; // 选择发票类型
import ModalCarTypeLength from '../components/ModalCarTypeLength'; // 车型车长
import ModalFollowCar from '../components/ModalFollowCar'; // 是否跟车
import ModalShipping from '../components/ModalShipping'; // 应收费用-- 运费
import ModalDeposit from '../components/ModalDeposit'; // 输入订金
import FootDetail from '../components/FootDetail'; // 底部明细
import ModalSelectCar from '../components/ModalSelectCar'; // 选择承运商车辆
import ModalSelectDriver from '../components/ModalSelectDriver'; // 选择承运商司机
import keyMap from '../keyMap'; // 枚举值
import xyMath from '~/extends/xyMath';
import filterFormat from '~/extends/filterFormat'; //格式化
import API from '../api';
import NativeBridge from '~/extends/NativeBridge';
import { MBBridge } from '@ymm/rn-lib';
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import images from '../../../../public/static/images/index';
import threeTimeformat from '~/extends/threeTimeformat';
import { PageProps } from '../PropTypes';
import SelectOrganizeCell from '../../../components/SelectOrganize/SelectOrganizeCell';
import CellAddressloadUnload from '../components/CellAddressloadUnload';
import CellSelectdispatcher from '../components/CellSelectdispatcher';
import CellPlatformWeightVolume from '../components/CellPlatformWeightVolume';
import CellCargoDealMode from '../components/CellCargoDealMode';
import ModalTruckType from '../components/ModalTruckType';

// 满帮找车
@inject('store')
@observer
export default class Platform extends React.Component<PageProps, any> {
  timerApi: any;
  refSelectCar: React.RefObject<any>;
  refSelectDriver: React.RefObject<any>;
  WeightVolumeLayout: any;
  constructor(props: PageProps) {
    super(props);
    this.refSelectCar = React.createRef();
    this.refSelectDriver = React.createRef();
    keyMap.tagData = []; // 初始化 备注快捷标签
    this.state = {
      showModal: 0, // 0 无，1 发票 2 调度员 3 车型车长 4是否跟车 5 应收运费 6 司机订金
      invoiceMap: [], // 发票类型name集合
      deliverymanMap: ['不跟车', '1人跟车', '2人跟车'],
      isAgreedCheck: true, // 协议是否同意
      showDetail: false, // 是否显示明细
      dispatchType: 4,
      dispatchTypeTopHeight: 0,
      loadunloadDomHeight: 0,
      isGeneralInvoiceEnable: false, // 当前组织是否支持普票货源
      toastContent: null, // 校验当前组织是否支持普票货源的toast提示
      isMybAuth: false // 满运宝是否认证
    };
  }
  componentWillMount() {
    const { loadTime } = this.props.store.formData_4;
    const isDeal: boolean = !!Number(this.props.store.TaskDetail.platformCarSearched); // 是否成交
    if (!isDeal) {
      const data = {
        loadTime: threeTimeformat(loadTime), // 开票信息, 0不开票 1开专票
      };
      this.props.store.setFormData(4, data);
    }
  }
  componentDidMount() {
    const { dispatcherId, invoiceFlag } = this.props.store.formData_4;
    if (dispatcherId) {
      this.api_queryRemarkTags(dispatcherId);
    }
    const financialFlag: boolean = !!Number(this.props.store.TaskDetail.financialFlag); // 是否生成财务数据
    const isDeal: boolean = !!Number(this.props.store.TaskDetail.platformCarSearched); // 是否成交
    if (isDeal && !financialFlag) {
      this.refSelectCar?.current.api_queryTruckList(null);
      this.refSelectDriver?.current.api_DriverList(null);
    }
    this.props.store.api_serviceFee(4);
    // 获取当前组织是否支持普票货源
    this.checkGeneralInvoiceEnable();
  }
  /** 获取当前组织是否支持普票货源 */
  async checkGeneralInvoiceEnable(): Promise<void> {
    const data = await API.checkGeneralInvoiceEnable({ orgId: this.props.store.formData_4.orgId });
    this.setState({
      isGeneralInvoiceEnable: data.success ? data?.data?.enable : false,
      toastContent: data.success ? data?.data?.toastContent : null
    });
  }
  openTypeModal() {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }
  openModal(val: number) {
    this.setState({ showModal: val, showDetail: false });
  }
  // 发票类型
  handleInviceChange = (val: number) => {
    this.setState({ showModal: 0 });
    if (typeof val === 'number') {
      const data = {
        invoiceFlag: val, // 发票类型id
        deliveryFee: null, // 运费
        deliveryUnit: 1, // 运费单位(吨方趟,// 趟1,吨2,方3,件4,个5,台6,桶7)
        serviceFee: null, // 服务费,自动计算得出
        deposit: null, // 定金
        refundDeposit: null, // 定金是否退还，0:不退，1:退还
        isRefresh: false, // 用来刷新组件
      };
      this.props.store.setFormData(4, data);
      this.setState({ isRefresh: true, showDetail: false }, () => {
        this.setState({ isRefresh: false });
      });
    }
  };
  // 设置发票类型name集合
  setInvoiceMap = (names: object): void => {
    this.setState({invoiceMap: names});
  };
  // 设置满运宝是否认证的state
  setMybAuthState = (state: boolean): void => {
    this.setState({ isMybAuth: state });
  };
  // 修改了时间
  changeDateTime(val: any, type: number) {
    this.setState({ showModal: 0 });
    console.log('修改了时间', type, val);
    if (type === 1) {
      const data = {
        loadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(4, data);
    } else if (type === 2) {
      const data = {
        unloadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(4, data);
    }
    const { loadTime, unloadTime } = this.props.store.formData_4;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
  }
  // 调度员
  handleDispatcherChange = (val: any) => {
    console.log('调度员', val);
    this.setState({ showModal: 0 });
    if (val && val.dispatcherId) {
      const data = {
        dispatcherId: val.dispatcherId, // 调度员id
        dispatcherName: val.dispatcherName, // 调度员姓名
        dispatcherPhone: val.dispatcherPhone, // 调度员手机号
        remainDispatchNumber: val.remainDispatchNumber, // 调度员扣减次数
      };
      this.props.store.setFormData(4, data);
      this.api_queryRemarkTags(val.dispatcherId);
    }
  };
  // 选择承运车
  handleCarTypeLengthChange = (val: any) => {
    console.log('选择承运车', val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        platformCarType: val.carType.map((item: any) => item.id), // 车型
        platformCarLength: val.carLength.map((item: any) => item.id), // 车长
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 应收运费
  handleShippingChange = (val: any) => {
    console.log('应收运费', val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliveryFee: val.freight ? filterFormat.moneyFormat(val.freight) : null, // 运费
        deliveryUnit: val.unitMap[val.unitIndex].id, // 运费单位(吨方趟,具体枚举待定)
      };
      this.props.store.setFormData(4, data);
      const { invoiceFlag } = this.props.store.formData_4;
      if (!!invoiceFlag) {
        this.props.store.api_serviceFee(4); // 重新计算服务费
      }
    }
  };
  // 选择承运车 弹窗返回值
  handleCarChange = (val: any) => {
    // console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        carId: val.carId || null, // 车辆id
        carNo: val.carNo || null, // 车牌
        carType: val.carType || null, // 车型
        carLength: val.carLength || null, // 车长
        driverId: val.majorityDriverId || null, // 主驾司机id
        driverName: val.majorityDriverName || null, // 主驾司机姓名
        driverPhone: val.majorityDriverPhone || null, // 主驾司机电话
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 选择承运司机 弹窗返回值
  handleDriverChange = (val: any) => {
    // console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        driverId: val.driverId, // 司机id
        driverName: val.driverName, // 司机姓名
        driverPhone: val.driverPhone, // 司机电话
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 是否跟车
  handleCFollowCarChange = (val: any) => {
    console.log('是否跟车', val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deliverymanType: val.id - 1, // 是否跟车, 0:不跟车 1:1人跟车 2:2人跟车
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 输入订金
  handleDepositChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        deposit: filterFormat.moneyFormat(val.deposit), // 订金
        refundDeposit: val.item.id, // 定金是否退还，0:不退，1:退还
      };
      this.props.store.setFormData(4, data);
    }
  };
  // 到备注页面
  goRemarks = (val: number) => {
    const { navigation } = this.props;
    navigation.navigate('Remarks', {
      //其他参数透传
      type: val,
      from: 4, // 满帮找车
      disabled: true, // 禁止选择快捷标签
    });
  };
  //  获取快捷标签接口 服务要求备注里的
  api_queryRemarkTags(dispatcherId: string | number) {
    API.queryRemarkTags({ dispatcherId: dispatcherId }).then((res: any) => {
      if (res.success && res.data) {
        keyMap.tagData = res.data.map((item: any) => {
          return { id: item.tagId, name: item.content };
        });
        // 设置调度备注
        const { shortcut } = this.props.store.formData_4;
        this.props.store.setFormData(4, {
          selectedText:
            shortcut?.length > 0
              ? shortcut.map((selectTag: string) => {
                  const temp = keyMap.tagData.filter(
                    (item: { id: string; name: string }) => item.id === selectTag || item.name === selectTag
                  );
                  if (temp?.length > 0) {
                    return temp[0].name;
                  }
                })
              : [],
        });
      }
    });
  }
  // TODO 暂时不用
  submit() {
    console.log('智能议价');
  }
  goAgreement = (val: any) => {
    let url = '';
    switch (val) {
      case 1: // 《货物运输交易协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=311&categoryId=123';
        break;
      case 2: // 《满运宝保障条款（托运人版本）》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=328&categoryId=123';
        break;
      case 3: // 《货物运输协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=330&categoryId=123';
        break;
      case 4: // 《关于满帮平台货物发布及承运规范的公告》
        url =
          'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=3601&categoryId=234&userAgreement=true';
        break;
      case 5: // 《货物运输技术服务协议》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2137&categoryId=234&userAgreement=true';
        break;
      case 6: // 《货物运输协议》- 开普票
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2138&categoryId=234&userAgreement=true';
        break;
      case 7: // 《满帮平台订金担保规则》
        url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2276&categoryId=234&userAgreement=true';
        break;
      default:
        break;
    }
    if (url) {
      NativeBridge.openWebViewPage(url);
    }
  };
  // 点击协议
  handleAgreedCheck = () => {
    this.setState(({ isAgreedCheck }: any) => {
      return { isAgreedCheck: !isAgreedCheck };
    });
  };
  // 协议
  AgreedCheckbox() {
    const { invoiceFlag } = this.props.store.formData_4;
    const { isAgreedCheck } = this.state;
    return (
      <Flex direction="row" align="center" wrap="wrap" style={styles.checkbox}>
        <Checkbox
          type="primary"
          size="sm"
          checked={isAgreedCheck}
          onChange={this.handleAgreedCheck.bind(this)}
          style={{ alignItems: 'flex-start' }}
        >
          {invoiceFlag === 1 ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 1)}>
                《货物运输交易协议》
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 2)}>
                《满运宝保障条款（托运人版本）》
              </MBText>
            </MBText>
          ) : invoiceFlag === 2 ? (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">我已经阅读并同意</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 7)}>《满帮平台订金担保规则》</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 5)}>《货物运输技术服务协议》</MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 6)}>《货物运输协议》</MBText>
            </MBText>
          ) : (
            <MBText style={{ paddingRight: 30 }}>
              <MBText color="#666666" size="sm">
                我已经阅读并同意
              </MBText>
              <MBText size="sm" color="primary" onPress={this.goAgreement.bind(this, 3)}>
                《货物运输协议》
              </MBText>
            </MBText>
          )}
        </Checkbox>
      </Flex>
    );
  }
  // 电话找车 , 默认电话找车 （保存并使用）
  submitPhone() {
    const { isGeneralInvoiceEnable, isMybAuth, toastContent } = this.state;
    const formData = this.props.store.formData_4;
    const { loadTime, unloadTime, carId, driverId } = formData;
    const isDeal: boolean = !!Number(this.props.store.TaskDetail.platformCarSearched); // 是否成交
    const financialFlag: boolean = !!Number(this.props.store.TaskDetail.financialFlag); // 是否生成财务数据
    if (!isDeal && loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
    const { isAgreedCheck } = this.state;
    if (!isAgreedCheck) {
      NativeBridge.toast('请确认同意相关协议');
      return;
    }
    const pass = this.isSubmit();
    this.setState({ isRulesTips: !pass });
    if (!isDeal && !pass) {
      NativeBridge.toast('有必选项未填');
      return;
    } else if (isDeal && !financialFlag && !carId && !driverId) {
      NativeBridge.toast('有必选项未填');
      return;
    }
    if (formData.invoiceFlag === 2 && !isGeneralInvoiceEnable && isMybAuth) {
      NativeBridge.toast(toastContent);
      return;
    }
    console.log('满帮找车开始');
    this.api_editDispatch(this.props.store.formData_4);
  }

  // 保存并使用
  api_editDispatch(formData: any) {
    if (this.timerApi) {
      console.log('还在请求中');
      return;
    }
    this.timerApi = true;
    setTimeout(() => {
      this.timerApi = false;
    }, 1500);
    // const financialFlag: boolean = !!Number(this.props.store.TaskDetail.financialFlag); // 是否生成财务数据
    const isDeal: boolean = !!Number(this.props.store.TaskDetail.platformCarSearched); // 是否成交
    const form = JSON.parse(JSON.stringify(formData));
    this.props.store
      .editDispatch(form)
      .then((res: any) => {
        if (res.success) {
          if (isDeal) {
            NativeBridge.toast(res.msg || '修改任务单成功');
          } else {
            NativeBridge.toast(res.msg || '修改成功信息已同步至平台');
          }
          this.props.store.goBack();
        }
      })
      .catch((err: any) => {
        console.log('editDispatch(4)错误数据', err);
      });
  }
  isSubmit() {
    const { isAgreedCheck } = this.state;
    const formData = this.props.store.formData_4;
    const {
      dispatcherId,
      platformCarType,
      deposit,
      loadTime,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
      deliveryFee,
    } = formData;
    const goodsInfoNum = platformTotalWeight || platformTotalVolume || platformTotalWeightMin || platformTotalVolumeMin;
    return (
      (this.deliveryFeeRequired ? deliveryFee : true) &&
      goodsInfoNum &&
      isAgreedCheck &&
      dispatcherId &&
      platformCarType.length &&
      // deliveryFee &&
      deposit &&
      loadTime.dateCode
    );
  }
  // 计算总运费
  computedTotal = () => {
    const formData = this.props.store.formData_4;
    const { platformTotalWeightMin, platformTotalVolumeMin, platformTotalWeight, platformTotalVolume } = formData;
    let { deliveryFee } = formData;
    deliveryFee = filterFormat.moneyDecFormat(deliveryFee);
    let copeTotal = 0;
    if (formData.deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      copeTotal = xyMath.accMul(deliveryFee, weight); // 运费
    } else if (formData.deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      copeTotal = xyMath.accMul(deliveryFee, volume); // 运费
    } else {
      // 趟
      copeTotal = deliveryFee; // 运费
    }
    copeTotal = parseFloat(Number(copeTotal).toFixed(2));
    return copeTotal;
  };
  // 打开明细
  openDetail() {
    this.setState((state: any) => ({ showDetail: !state.showDetail }));
  }
  extraElement(text: string) {
    return (
      <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {text}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }
  // 成交方式选择一口价，运费必填
  get deliveryFeeRequired(): boolean {
    const formData = this.props.store.formData_4;
    const { cargoDealMode } = formData;
    return cargoDealMode === 'BUYOUT';
  }
  // 底部按钮
  footElement() {
    const { showDetail } = this.state;
    const formData = this.props.store.formData_4;
    const { refundDeposit, invoiceFlag } = formData;
    let { deliveryFee, deposit, serviceFee, technicalServiceFee, electronicContractFee, positionCheckFee } = formData;
    deliveryFee = filterFormat.moneyDecFormat(deliveryFee);
    deposit = filterFormat.moneyDecFormat(deposit);
    serviceFee = filterFormat.moneyDecFormat(serviceFee);
    technicalServiceFee = filterFormat.moneyDecFormat(technicalServiceFee);
    electronicContractFee = filterFormat.moneyDecFormat(electronicContractFee);
    positionCheckFee = filterFormat.moneyDecFormat(positionCheckFee);
    const copeTotal = this.computedTotal(); // 计算总货物数量
    let serviceFeeTotal: any = copeTotal;
    if (invoiceFlag === 1) {
      serviceFeeTotal = Number(xyMath.accAdd(copeTotal, serviceFee)); // 运费
    } else if (invoiceFlag === 2) {
      let firstNum = xyMath.accAdd(copeTotal, technicalServiceFee);
      let secondNum = xyMath.accAdd(electronicContractFee, positionCheckFee);
      serviceFeeTotal = xyMath.accAdd(firstNum, secondNum);
    }
    if (!!refundDeposit || !deposit) {
      deposit = 0;
    }
    const total: any = copeTotal ? xyMath.subtr(copeTotal, deposit) : 0;
    // 专票的明细数据
    const infoList = [
      { text: '应付运费', num: copeTotal },
      { text: '附加运费', num: serviceFee },
    ];
    // 普票的明细数据
    const generalInvoiceInfoList = [
      { text: '应付运费', num: copeTotal },
      { text: '技术服务费', num: technicalServiceFee },
      { text: '电子协议费', num: electronicContractFee },
      { text: '轨迹校验费', num: positionCheckFee }
    ];
    this.props.store.setTotalFee(filterFormat.moneyFormat(serviceFeeTotal)); // 记录下合计费用
    return (
      <View style={[styles.foot]}>
        <Image resizeMode={'stretch'} source={images.top_shadow} style={{ height: 10, width: '100%' }} />
        <View style={{ backgroundColor: '#FFFFFF' }}>
          {deliveryFee > 0 && showDetail && invoiceFlag === 1 && FootDetail({ infoList: infoList })}
          {deliveryFee > 0 && showDetail && invoiceFlag === 2 && FootDetail({ infoList: generalInvoiceInfoList })}
          {!!total && (
            <View>
              <Flex direction="row" justify="center" align="center" style={{ margin: 10 }}>
                <MBText size="md">应付费用合计</MBText>
                <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
                  <MBText bold style={{ marginLeft: 10, marginBottom: 2 }} size="xs" color="#F54242">
                    ¥
                  </MBText>
                  <MBText bold size="md" color="#F54242">
                    {serviceFeeTotal}
                  </MBText>
                  {!!invoiceFlag && (
                    <TouchableOpacity style={styles.flexRow} onPress={this.openDetail.bind(this)}>
                      <MBText style={{ color: '#666666', marginLeft: 20 }}>明细</MBText>
                      <Image style={[styles.icon, showDetail && styles.upturned]} source={images.icon_pull_down} />
                    </TouchableOpacity>
                  )}
                </View>
              </Flex>
              <Flex direction="row" justify="center" align="center">
                <MBText color="#999999" size="xs">
                  （司机净得{total} = 应付运费¥{copeTotal ? copeTotal : 0} {deposit ? '- 订金¥' + deposit : ''}）
                </MBText>
              </Flex>
              <Whitespace vertical={10} />
              <Splitline color="#E8E8E8" />
            </View>
          )}
          <Whitespace vertical={5} />
          <Button radius style={styles.btn} onPress={this.submitPhone.bind(this)} size="sm" type="primary">
            确定修改
          </Button>
        </View>
      </View>
    );
  }
  render() {
    const financialFlag: boolean = !!Number(this.props.store.TaskDetail.financialFlag); // 是否生成财务数据
    const isDeal: boolean = !!Number(this.props.store.TaskDetail.platformCarSearched); // 是否成交
    const { taskState } = this.props.store?.TaskDetail;

    const { invoiceMap, showModal, isRefresh, isRulesTips, isGeneralInvoiceEnable, isMybAuth, toastContent } = this.state;
    const { store } = this.props;
    const {
      showFooterBtn,
      sensitiveWordList,
      truckTypeModalVisible,
      onConfirmTruckTypeModal,
      changeTruckTypeModalVisible,
      filterTransType,
    } = store;
    const formData = store.formData_4;
    const {
      deliveryFee,
      deliveryUnit,
      platformCarType,
      platformCarLength,
      invoiceFlag,
      refundDeposit,
      loadTime,
      unloadTime,
      selectedText,
      driverName,
      driverPhone,
      carNo,
      carType,
      carLength,
      mybCompanyName,
      platformTotalWeightMin,
      platformTotalVolumeMin,
      platformTotalWeight,
      platformTotalVolume,
      tmsLoadUnloads,
      transType,
      mybOrderId,
    } = formData;

    const carTypeText = platformCarType.map((item: string) => keyMap.carTypePlate[item]).join('、');
    const carLengthText = platformCarLength.map((item: string) => keyMap.carLengthPlate[item]).join('、');

    const carTypeLength = carTypeText + (carTypeText ? ' / ' + carLengthText : carLengthText); // 车型 车长
    const carrierVehicle = carNo
      ? `${carNo} ${carType && keyMap.carType[carType] ? keyMap.carType[carType] : ''} ${
          carLength && keyMap.carLength[carLength] ? keyMap.carLength[carLength] + '米' : ''
        }`
      : ''; // 承运车辆
    const CarrierDriver = driverName ? `${driverName} ${driverPhone ? '- ' + driverPhone : ''}` : ''; // 承运司机

    let unitText = '';
    if (formData.deliveryUnit == 2) {
      // 吨
      const weight = Math.max(platformTotalWeightMin, platformTotalWeight);
      unitText = `${weight ? weight : '0'}吨`;
    } else if (formData.deliveryUnit == 3) {
      // 方
      const volume = Math.max(platformTotalVolumeMin, platformTotalVolume);
      unitText = `${volume ? volume : '0'}方`;
    } else {
      // 趟
    }
    const deliveryFeeText = deliveryFee
      ? `¥ ${filterFormat.moneyDecFormat(deliveryFee)} / ${keyMap.unitMap[deliveryUnit]} ${unitText ? '× ' + unitText : ''}`
      : '';
    const depositText = formData.deposit
      ? `¥ ${filterFormat.moneyDecFormat(formData.deposit)} ${refundDeposit ? ' / 退还' : ' / 不退还'}`
      : '';
    let notesText = selectedText && selectedText.length ? selectedText.join(';') + ';' : '';
    notesText = (formData.remark ? formData.remark + ';' : '') + notesText; // 备注
    return (
      <View style={styles.page}>
        <CellAddressloadUnload
          isRulesTips={isRulesTips}
          tmsLoadUnloads={tmsLoadUnloads}
          readonly={true}
          topNode={
            <>
              <SelectOrganizeCell from={4} />
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  title="调度方式"
                  value="满帮找车"
                  align="right"
                  onPress={this.openTypeModal.bind(this)}
                  readonly={true}
                  onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '调度方式')}
                />
                <Cell
                  title="发票类型"
                  value={invoiceMap[invoiceFlag]}
                  align="right"
                  onPress={this.openModal.bind(this, 1)}
                  readonly={true}
                  onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '发票类型')}
                />
                {mybCompanyName && invoiceFlag ? <Cell title="发票抬头" readonly={true} value={mybCompanyName} align="right" /> : null}
              </CellGroup>
              <Whitespace vertical={10} />
            </>
          }
          otherNode={
            <>
              <Whitespace vertical={10} />
              <View onLayout={(el: any) => (this.WeightVolumeLayout = el.nativeEvent?.layout)} />
              <CellGroup withBottomLine style={styles.addressCellGroup}>
                <Cell
                  required
                  title="装货时间"
                  value={loadTime.displayValue}
                  align="right"
                  placeholder="请选择"
                  onPress={this.openModal.bind(this, 7)}
                  readonly={isDeal}
                  onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '装货时间')}
                  extra={this.state.isRulesTips && !loadTime.displayValue && this.extraElement('装货时间未选择')}
                />
                <Cell
                  title="卸货时间"
                  value={unloadTime.displayValue}
                  align="right"
                  placeholder="请选择"
                  onPress={this.openModal.bind(this, 8)}
                  readonly={isDeal}
                  onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '卸货时间')}
                />
                {/* 任务状态找车中才能修改重量和体积 */}
                <CellPlatformWeightVolume
                  title="满帮货物重量/体积"
                  WeightVolumeLayout={this.WeightVolumeLayout}
                  readonly={taskState != 'LOOKING_CAR'}
                  from={4}
                  isRulesTips={this.state.isRulesTips}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <CellSelectdispatcher
                  title="调度员"
                  isSingleChoice={this.props.store.batchDispatchFlag == 1}
                  readonly
                  required
                  isRulesTips={this.state.isRulesTips}
                  from={4}
                  setMybAuthState={this.setMybAuthState}
                />
                {invoiceFlag === 0 || invoiceFlag === 2 ? (
                  <Cell
                    name="transType"
                    title="用车类型"
                    align="right"
                    required
                    readonly={((!!invoiceFlag || mybOrderId) && invoiceFlag !== 2) || isDeal}
                    value={filterTransType(transType)}
                    placeholder="请选择"
                    onPress={changeTruckTypeModalVisible}
                  />
                ) : null}
                {!isDeal && (
                  <Cell
                    title="车型车长"
                    value={carTypeLength}
                    required
                    align="right"
                    placeholder="请选择"
                    numberOfLines={2}
                    onPress={this.openModal.bind(this, 3)}
                    extra={this.state.isRulesTips && !carTypeLength && this.extraElement('车型车长未选择')}
                  />
                )}
                {isDeal && (
                  <Cell
                    required={true}
                    title="承运车辆"
                    value={carrierVehicle}
                    align="right"
                    placeholder="请选择"
                    numberOfLines={1}
                    onPress={this.openModal.bind(this, 9)}
                    readonly={financialFlag}
                    onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '承运车辆')}
                    extra={this.state.isRulesTips && !financialFlag && !carrierVehicle && this.extraElement('承运车辆未选择')}
                  />
                )}
                {isDeal && (
                  <Cell
                    required={true}
                    title="承运司机"
                    value={CarrierDriver}
                    align="right"
                    placeholder="请选择"
                    numberOfLines={1}
                    onPress={this.openModal.bind(this, 10)}
                    readonly={financialFlag}
                    onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '承运司机')}
                    extra={this.state.isRulesTips && !financialFlag && !CarrierDriver && this.extraElement('承运司机未选择')}
                  />
                )}
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <CellCargoDealMode title="成交方式" from={4} readonly readonlyNotDusty />
                <Cell
                  title="应付运费"
                  value={deliveryFeeText}
                  name="freight"
                  align="right"
                  placeholder="请输入"
                  numberOfLines={1}
                  readonly={isDeal}
                  onPress={this.openModal.bind(this, 5)}
                  onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '应付运费')}
                  required={this.deliveryFeeRequired}
                  extra={this.deliveryFeeRequired && this.state.isRulesTips && !deliveryFeeText && this.extraElement('应付运费未选择')}
                />
                <Cell
                  title="司机订金"
                  value={depositText}
                  required
                  name="type"
                  align="right"
                  placeholder="请输入"
                  onPress={this.openModal.bind(this, 6)}
                  numberOfLines={1}
                  readonly={isDeal}
                  onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '司机订金')}
                  extra={this.state.isRulesTips && !formData.deposit && this.extraElement('司机订金未填')}
                />
              </CellGroup>
              <Whitespace vertical={10} />
              <CellGroup withBottomLine>
                <Cell
                  value={notesText}
                  title="服务要求与备注"
                  name="notes"
                  align="right"
                  placeholder="请输入"
                  numberOfLines={1}
                  onPress={this.goRemarks.bind(this, 1)}
                />
              </CellGroup>
              {this.AgreedCheckbox()}
              <MBText style={{ marginTop: 20, paddingLeft: 35, paddingRight: 10, flexWrap: 'wrap' }}>
                <MBText size="xs" color="#999999">
                  请勿发布及托运危险货物、违禁货物，限运货物需有相应证明文件。具体详见法律公告页：
                </MBText>
                <MBText size="xs" color="primary" onPress={this.goAgreement.bind(this, 4)}>
                  《关于满帮平台货物发布及承运规范的公告》
                </MBText>
              </MBText>
              <Whitespace vertical={300} />
            </>
          }
          sensitiveWordList={sensitiveWordList}
        />
        {showFooterBtn ? this.footElement() : null}
        <ModalInvoiceType visible={showModal === 1} onChange={this.handleInviceChange} id={invoiceFlag} setInvoiceMap={this.setInvoiceMap} isGeneralInvoiceEnable={isGeneralInvoiceEnable} dispatcherMode={4} isMybAuth={isMybAuth} toastContent={toastContent} />
        {/* <ModalSelectDispatcher visible={showModal === 2} isEdit onChange={this.handleDispatcherChange} orgId={orgId} /> */}
        <ModalCarTypeLength
          visible={showModal === 3}
          multiple={true}
          onChange={this.handleCarTypeLengthChange}
          item={{ platformCarType: platformCarType, platformCarLength: platformCarLength }}
        />
        <ModalFollowCar visible={showModal === 4} onChange={this.handleCFollowCarChange} />
        {!isRefresh && <ModalShipping visible={showModal === 5} from={4} isCount={!!invoiceFlag} onChange={this.handleShippingChange} />}
        {!isRefresh && <ModalDeposit visible={showModal === 6} from={4} onChange={this.handleDepositChange} />}
        <TimePickerModal
          key="start"
          type="loadTime"
          visible={showModal === 7}
          onChange={(val: any) => this.changeDateTime(val, 1)}
          defaultTime={loadTime}
          onCancel={this.openModal.bind(this, 0)}
        />
        <TimePickerModal
          key="end"
          type="unloadTime"
          visible={showModal === 8}
          onChange={(val: any) => this.changeDateTime(val, 2)}
          defaultTime={unloadTime}
          onCancel={this.openModal.bind(this, 0)}
        />
        <ModalSelectCar
          noData="该承运商下无车辆"
          ref={this.refSelectCar}
          visible={showModal === 9}
          from={3}
          onChange={this.handleCarChange}
        />
        <ModalSelectDriver
          noData="该承运商下无司机"
          ref={this.refSelectDriver}
          visible={showModal === 10}
          from={3}
          onChange={this.handleDriverChange}
        />
        <ModalTruckType
          visible={truckTypeModalVisible}
          transType={transType}
          onConfirm={onConfirmTruckTypeModal}
          onCancel={changeTruckTypeModalVisible}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  page: {
    flex: 1,
    position: 'relative',
  },
  foot: {
    // backgroundColor: '#FFFFFF',
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
  icon: {
    width: 15,
    height: 15,
  },
  notes: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingRight: 5,
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
  },
  checkbox: {
    marginTop: 27,
    marginLeft: 10,
    marginRight: 10,
  },
  addressCellGroup: {
    zIndex: 999,
  },
});
