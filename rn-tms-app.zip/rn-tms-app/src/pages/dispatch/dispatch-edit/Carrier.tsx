import React from 'react';
import { View, ScrollView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { CellGroup, Whitespace, Flex, MBText, Button, RNElementsUtil } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NativeBridge from '~/extends/NativeBridge';
import xyMath from '~/extends/xyMath'; // 计算
import filterFormat from '~/extends/filterFormat'; //格式化
import FootDetail from '../components/FootDetail'; // 底部明细
import keyMap from '../keyMap'; // 枚举值

import Cell from '~/components/common/Cell';

import API from '../api';

import images from '../../../../public/static/images/index';

import ModalSelectCarrier from '../components/ModalSelectCarrier'; // 选择承运商
import ModalSelectCar from '../components/ModalSelectCar'; // 选择承运商车辆
import ModalSelectDriver from '../components/ModalSelectDriver'; // 选择承运商司机
import ModalSettlement from '../components/ModalSettlement'; // 结算方式
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import LoadUnloadAddress from '~/components/LoadUnloadAddress';
import ModalAddresslist from '~/pages/dispatch/ModalAddresslist';
import { PageProps } from '../PropTypes';
import SelectOrganizeCell from '../../../components/SelectOrganize/SelectOrganizeCell';
import CellCostInput from '../components/CellCostInput';
import CellInvoice from '../components/CellInvoice';
// 指派承运商
@inject('store')
@observer
export default class Carrier extends React.Component<PageProps, any> {
  refSelectCar: React.RefObject<any>;
  refSelectDriver: React.RefObject<any>;
  timerApi: boolean | undefined;
  constructor(props: PageProps) {
    super(props);
    this.refSelectCar = React.createRef();
    this.refSelectDriver = React.createRef();
    this.state = {
      showModal: 0, // 0 无，1 选择承运商 2 承运商车辆 3 承运商司机 4 应付费用 5结算方式
      showFoot: true, // 控制是否显示底部按钮，如果有软盘弹起就先隐藏起来,
      showDetail: false, // 是否显示明细
      isRulesTips: false, // 是否开启验证提醒
      dispatchType: 2,
      dispatchTypeTopHeight: 0,
      loadunloadDomHeight: 0,
      feeMap: { 0: '运输费', 1: '装卸费', 8: '保险费', 14: '路桥费', 7: '其他费', 37: '调整费用' },
      addressKeyWord: '',
    };
  }
  componentDidMount() {
    const { carrierId } = this.props.store.formData_2;
    if (carrierId) {
      this.refSelectCar.current.api_queryTruckList(carrierId);
      this.refSelectDriver.current.api_DriverList(carrierId); // 司机列表
    }
  }
  openTypeModal() {
    const { openTypeModal } = this.props;
    openTypeModal && openTypeModal(true);
  }

  openModal(val: any) {
    // eslint-disable-next-line no-console
    this.setState({ showModal: val, showDetail: false });
  }
  // 修改了时间
  changeDateTime(val: any, type: number) {
    this.setState({ showModal: 0 });
    console.log('修改了时间', type, val);
    if (type === 1) {
      const data = {
        loadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(2, data);
    } else if (type === 2) {
      const data = {
        unloadTime: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
      };
      this.props.store.setFormData(2, data);
    }
    const { loadTime, unloadTime } = this.props.store.formData_2;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
  }
  // 选择承运商弹窗返回值
  handleCarrierChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      API.lastCarrierTaskInfo({ carrierId: val.carrierId })
        .then((resData: any) => {
          if (resData.data && resData.data.truckInfo && resData.data.truckInfo.carId) {
            resData = resData.data;
            const data = {
              carId: resData.truckInfo?.carId || null, // 车辆id
              carNo: resData.truckInfo?.carNo || null, // 车牌
              carType: resData.truckInfo?.carType || null, // 车型
              carLength: resData.truckInfo?.carLength || null, // 车长
              driverId: resData.driverInfo?.driverId || null, // 司机id
              driverName: resData.driverInfo?.driverName || null, // 司机姓名
              driverPhone: resData.driverInfo?.driverPhone || null, // 司机电话
            };
            this.props.store.setFormData(2, data);
            this.refSelectCar.current.api_queryTruckList(val.carrierId);
            this.refSelectDriver.current.api_DriverList(val.carrierId); // 司机列表
          } else {
            this.api_carsLengthList(val);
          }
        })
        .catch(() => {
          this.api_carsLengthList(val);
        });
      const data = {
        carrierId: val.carrierId, // 承运商id
        carrierName: val.carrierName, // 承运商名称
      };
      this.props.store.setFormData(2, data);
    }
  };
  // 请求车辆和司机列表
  api_carsLengthList(val: any) {
    this.refSelectCar.current.api_queryTruckList(val.carrierId).then((res: any) => {
      const item = res[0];
      let data = {};
      data = {
        carId: item?.carId || null, // 车辆id
        carNo: item?.carNo || null, // 车牌
        carType: item?.carType || null, // 车型
        carLength: item?.carLength || null, // 车长
        driverId: item?.majorityDriverId || null, // 司机id
        driverName: item?.majorityDriverName || null, // 司机姓名
        driverPhone: item?.majorityDriverPhone || null, // 司机电话
      };
      this.props.store.setFormData(2, data);
      this.refSelectDriver.current.api_DriverList(val.carrierId); // 司机列表
    });
  }
  // 选择承运车 弹窗返回值
  handleCarChange = (val: any) => {
    // console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        carId: val.carId, // 车辆id
        carNo: val.carNo, // 车牌
        carType: val.carType, // 车型
        carLength: val.carLength, // 车长
        driverId: val.majorityDriverId ? val.majorityDriverId : null, // 司机id
        driverName: val.majorityDriverName ? val.majorityDriverName : null, // 司机姓名
        driverPhone: val.majorityDriverPhone ? val.majorityDriverPhone : null, // 司机电话
      };
      this.props.store.setFormData(2, data);
    }
  };
  // 选择承运司机 弹窗返回值
  handleDriverChange = (val: any) => {
    // console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const data = {
        driverId: val.driverId, // 司机id
        driverName: val.driverName, // 司机姓名
        driverPhone: val.driverPhone, // 司机电话
      };
      this.props.store.setFormData(2, data);
    }
  };
  // 结算方式返回值
  handleSettlementChange = (val: any) => {
    console.log(val);
    this.setState({ showModal: 0 });
    if (val) {
      const settlementList = [];
      val.payNow && settlementList.push({ settleType: 1, amount: filterFormat.moneyFormat(val.payNow) }); // 现付
      val.toPay && settlementList.push({ settleType: 2, amount: filterFormat.moneyFormat(val.toPay) }); // 到付
      val.payBack && settlementList.push({ settleType: 3, amount: filterFormat.moneyFormat(val.payBack) }); // 回付
      val.monthlyEnd && settlementList.push({ settleType: 4, amount: filterFormat.moneyFormat(val.monthlyEnd) }); // 月结
      val.OilCard &&
        settlementList.push({
          settleType: 5,
          amount: filterFormat.moneyFormat(val.OilCard),
          oilCardId: val.oilCardId || null,
          recieveDeposit: filterFormat.moneyFormat(val.recieveDeposit) || null,
        }); // 油卡
      const data = {
        settlementList: settlementList, // 结算方式
      };
      this.props.store.setFormData(2, data);
    }
  };
  isSubmit() {
    const {
      formData_2: { tmsLoadUnloads, feeDetails },
    } = this.props.store;
    const loadText = tmsLoadUnloads[0]?.address;
    const unloadText = tmsLoadUnloads[1]?.address;
    const feeDetailsTip = feeDetails.find((item: any) => item.isRequired && !item.amount);
    return loadText && unloadText && !feeDetailsTip;
  }
  // 确定承运商
  submit() {
    const formData = this.props.store.formData_2;
    const { loadTime, unloadTime } = formData;
    if (loadTime.endTimestamp && unloadTime.endTimestamp) {
      if (loadTime.endTimestamp > unloadTime.endTimestamp) {
        NativeBridge.toast('卸货时间不能小于装货时间');
        return;
      }
    }
    const pass = this.isSubmit();
    this.setState({ isRulesTips: !pass });
    if (!pass) {
      NativeBridge.toast('有必选项未填');
      return;
    }

    this.setState({ isRulesTips: !formData.carrierId });
    if (!formData.carrierId) {
      NativeBridge.toast('有必选项未填');
      return;
    }

    console.log('确定承运商', formData);
    // 支付费用总额
    const settlementTotal = formData.settlementList?.reduce((total: string, item: any) => {
      return xyMath.accAdd(total, item.amount || 0);
    }, '0');
    // 费用信息总额
    const feeDetailsTotal = this.props.store.totalFee;
    if (feeDetailsTotal < 0) {
      NativeBridge.toast('应付合计不可小于0');
      return;
    }
    if (settlementTotal !== feeDetailsTotal) {
      NativeBridge.toast('应付运费项与结算方式项不相等');
    } else {
      this.api_editDispatch(formData);
    }
  }
  // 保存并使用
  api_editDispatch(formData: any) {
    if (this.timerApi) {
      console.log('还在请求中');
      return;
    }
    this.timerApi = true;
    setTimeout(() => {
      this.timerApi = false;
    }, 1500);
    // const financialFlag: boolean = !!Number(this.props.store.TaskDetail.financialFlag); // 是否生成财务数据
    const form = JSON.parse(JSON.stringify(formData));
    this.props.store
      .editDispatch(form)
      .then((res: any) => {
        if (res.success) {
          NativeBridge.toast(res.msg || '修改任务单成功');
          this.props.store.goBack();
        }
      })
      .catch((err: any) => {
        console.log('editDispatch(2)错误数据', err);
      });
  }
  // 到备注页面
  goRemarks = (val: number) => {
    const { navigation } = this.props;
    navigation.navigate('Remarks', {
      //其他参数透传
      type: val,
      from: 2, // 指派承运商
    });
  };
  openDetail() {
    this.setState((state: any) => ({ showDetail: !state.showDetail }));
  }
  // 底部按钮
  footElement() {
    const { showDetail } = this.state;
    const formData = this.props.store.formData_2;
    const feeDetails = formData.feeDetails.filter((item: any) => item.amount);
    let total: string = '0'; // 合计
    const infoList = feeDetails.map((item: any) => {
      total = item.isDeductionFee ? xyMath.subtr(total, item.amount) : xyMath.accAdd(total, item.amount);
      return { text: item.feeCodeDesc, num: filterFormat.moneyDecFormat(item.amount) };
    });
    if (formData.taxWay == 2) {
      total = xyMath.accAdd(total, filterFormat.moneyFormat(formData.taxFee)).toString();
      !!Number(formData.taxFee) && infoList.push({ text: '税费', num: formData.taxFee });
    }
    this.props.store.setTotalFee(total); // 记录下合计费用
    total = filterFormat.moneyDecFormat(total).toString();
    return (
      <View style={[styles.foot]}>
        <Image resizeMode={'stretch'} source={images.top_shadow} style={{ height: 10, width: '100%' }} />
        <View style={{ backgroundColor: '#FFFFFF' }}>
          {showDetail && FootDetail({ infoList: infoList })}
          {!!feeDetails.length && (
            <Flex direction="row" justify="center" align="center" style={{ margin: 10 }}>
              <MBText>应付费用合计</MBText>
              <Flex direction="row" justify="center" align="flex-end" style={{ margin: 5 }}>
                <MBText color="#F54242" size="xs" bold style={{ marginBottom: 2 }}>
                  ¥
                </MBText>
                <MBText color="#F54242" size="md" bold>
                  {total}
                </MBText>
              </Flex>
              <TouchableOpacity style={styles.flexRow} onPress={this.openDetail.bind(this)}>
                <MBText style={{ color: '#666666', marginLeft: 20 }}>明细</MBText>
                <Image style={[styles.icon, showDetail && styles.upturned]} source={images.icon_pull_down} />
              </TouchableOpacity>
            </Flex>
          )}
          <Button radius style={styles.btn} onPress={this.submit.bind(this)} size="sm" type="primary">
            确定修改
          </Button>
        </View>
      </View>
    );
  }
  // 保存检索值
  onHandleChangeAddress = (data: any) => {
    const { onChangeAddress } = this.props.store;
    this.setState({
      addressKeyWord: data.value,
    });
    onChangeAddress && onChangeAddress(data);
  };

  render() {
    const financialFlag: boolean = !!Number(this.props.store.TaskDetail.financialFlag); // 是否生成财务数据
    const { showModal, isRulesTips, dispatchType, dispatchTypeTopHeight, loadunloadDomHeight, addressKeyWord } = this.state;
    const { store } = this.props;
    const {
      searchAddressLoading,
      addressRequiredConfig,
      addressAssociateList,
      isLoadAddressChanged,
      isUnloadAddressChanged,
      onSelectAddressAssociate,
      onFoucsAddress,
      onBlurAddress,
      showFooterBtn,
      addressType,
      sensitiveWordList,
    } = store;
    const formData = store.formData_2;

    const { driverName, driverPhone, carNo, carType, carLength, loadTime, unloadTime } = formData;
    const carrierVehicle = carNo
      ? `${carNo} ${carType && keyMap.carTypeAll[carType] ? keyMap.carTypeAll[carType] : ''} ${
          carLength && keyMap.carLengthAll[carLength] ? keyMap.carLengthAll[carLength] + '米' : ''
        }`
      : ''; // 承运车辆
    const CarrierDriver = driverName ? `${driverName} ${driverPhone ? '- ' + driverPhone : ''}` : ''; // 承运司机
    const notesText = store.remarksText(formData.remark, 25);
    // 结算方式 1：现付；2：到付;3：回付 4:月结 5：油卡
    const settlementMap: any = { 1: '现付¥', 2: '到付¥', 3: '回付¥', 4: '月结¥', 5: '油卡¥' };
    const settlementList = formData.settlementList;
    const settlementText = settlementList
      .map((item: any) => {
        return settlementMap[item.settleType] + filterFormat.moneyDecFormat(item.amount);
      })
      .join('; ');
    const { tmsLoadUnloads } = formData;
    const loadText = tmsLoadUnloads[0].address;
    const unloadText = tmsLoadUnloads[1].address;
    return (
      <View style={styles.page}>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} alwaysBounceVertical={false}>
          <View
            onLayout={(e) => {
              this.setState({ dispatchTypeTopHeight: e.nativeEvent.layout.height });
            }}
          >
            <SelectOrganizeCell from={2} />
            <Whitespace vertical={10} />
            <CellGroup withBottomLine>
              <Cell
                title="调度方式"
                align="right"
                value="承运商"
                onPress={this.openTypeModal.bind(this)}
                readonly={financialFlag}
                onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '调度方式')}
              />
            </CellGroup>
            <Whitespace vertical={10} />
          </View>
          <CellGroup withBottomLine style={styles.addressCellGroup}>
            <View
              onLayout={(e) => {
                this.setState({ loadunloadDomHeight: e.nativeEvent.layout.height });
              }}
            >
              <LoadUnloadAddress
                dispatchType={dispatchType}
                addressValue={loadText}
                addressType={0}
                addressConfig={addressRequiredConfig.loadAddressConfig}
                isRulesTips={isRulesTips}
                isAddressChanged={isLoadAddressChanged}
                searchLoading={searchAddressLoading}
                addressList={addressAssociateList}
                onChange={this.onHandleChangeAddress}
                onSelect={onSelectAddressAssociate}
                onFoucs={onFoucsAddress}
                onBlur={onBlurAddress}
              />
            </View>

            <LoadUnloadAddress
              dispatchType={dispatchType}
              addressValue={unloadText}
              addressType={1}
              addressConfig={addressRequiredConfig.unloadAddressConfig}
              isRulesTips={isRulesTips}
              isAddressChanged={isUnloadAddressChanged}
              searchLoading={searchAddressLoading}
              addressList={addressAssociateList}
              onChange={this.onHandleChangeAddress}
              onSelect={onSelectAddressAssociate}
              onFoucs={onFoucsAddress}
              onBlur={onBlurAddress}
            />
            <Cell
              name="type"
              title="装货时间"
              value={loadTime.displayValue}
              align="right"
              placeholder="请选择"
              valueStyle={styles.valueStyle}
              onPress={this.openModal.bind(this, 6)}
            />
            <Cell
              name="type"
              title="卸货时间"
              value={unloadTime.displayValue}
              align="right"
              placeholder="请选择"
              valueStyle={styles.valueStyle}
              onPress={this.openModal.bind(this, 7)}
            />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell
              title="承运商"
              align="right"
              placeholder="请选择"
              value={formData.carrierName}
              required
              onPress={this.openModal.bind(this, 1)}
              readonly={financialFlag}
              onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '承运商')}
              extra={
                this.state.isRulesTips &&
                !formData.carrierName && (
                  <View style={{ paddingRight: RNElementsUtil.autoFix(28) }}>
                    <MBText size="xs" color="#F54242" align="right">
                      承运商未选择
                    </MBText>
                    <Whitespace vertical={12} />
                  </View>
                )
              }
            />
            {formData.carrierId && (
              <Cell
                title="承运车辆"
                value={carrierVehicle}
                align="right"
                placeholder="请选择"
                numberOfLines={1}
                onPress={this.openModal.bind(this, 2)}
                readonly={financialFlag}
                onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '承运车辆')}
              />
            )}
            {formData.carrierId && (
              <Cell
                title="承运司机"
                value={CarrierDriver}
                align="right"
                placeholder="请选择"
                numberOfLines={1}
                onPress={this.openModal.bind(this, 3)}
                readonly={financialFlag}
                onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '承运司机')}
              />
            )}
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <CellCostInput
              title="应付运费"
              from={2}
              isRulesTips={isRulesTips}
              navigation={this.props.navigation}
              pageCode="mainline_outTrans_detail"
              readonly={financialFlag}
              $parent={this}
            />
            <CellInvoice title="是否开票" from={2} navigation={this.props.navigation} $parent={this} readonly={financialFlag} />
            <Cell
              title="结算方式"
              value={settlementText}
              name="type"
              align="right"
              placeholder="请输入"
              numberOfLines={1}
              onPress={this.openModal.bind(this, 5)}
              readonly={financialFlag}
              onReadOnlyPress={this.props.store.toastNotEdit.bind(this, '结算方式')}
            />
          </CellGroup>
          <Whitespace vertical={10} />
          <CellGroup withBottomLine>
            <Cell
              title="备注"
              align="right"
              value={notesText}
              placeholder="请输入"
              numberOfLines={1}
              onPress={this.goRemarks.bind(this, 0)}
              valueStyle={styles.valueStyle}
            />
          </CellGroup>
          <Whitespace vertical={220} />
        </ScrollView>
        {showFooterBtn ? this.footElement() : null}
        <ModalSelectCarrier visible={showModal === 1} onChange={this.handleCarrierChange} />
        <ModalSelectCar
          noData="该承运商下无车辆"
          ref={this.refSelectCar}
          visible={showModal === 2}
          from={2}
          onChange={this.handleCarChange}
        />
        <ModalSelectDriver
          noData="该承运商下无司机"
          ref={this.refSelectDriver}
          visible={showModal === 3}
          from={2}
          onChange={this.handleDriverChange}
        />
        <ModalSettlement visible={showModal === 5} onChange={this.handleSettlementChange} formData={settlementList} />
        <TimePickerModal
          key="start"
          type="loadTimeMonth"
          visible={showModal === 6}
          onChange={(val: any) => {
            this.changeDateTime(val, 1);
          }}
          defaultTime={loadTime}
          onCancel={this.openModal.bind(this, 0)}
        />
        <TimePickerModal
          key="end"
          type="unloadTimeMonth"
          visible={showModal === 7}
          onChange={(val: any) => {
            this.changeDateTime(val, 2);
          }}
          defaultTime={unloadTime}
          onCancel={this.openModal.bind(this, 0)}
        />

        <ModalAddresslist
          dispatchTypeTopHeight={dispatchTypeTopHeight}
          loadunloadDomHeight={loadunloadDomHeight}
          dispatchType={dispatchType}
          addressValue={addressType ? unloadText : loadText}
          addressType={addressType}
          addressConfig={addressType ? addressRequiredConfig.unloadAddressConfig : addressRequiredConfig.loadAddressConfig}
          isAddressChanged={addressType ? isUnloadAddressChanged : isLoadAddressChanged}
          searchLoading={searchAddressLoading}
          addressList={addressAssociateList}
          addressKeyWord={addressKeyWord}
          onSelect={onSelectAddressAssociate}
          sensitiveWordList={sensitiveWordList}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  page: {
    flex: 1,
    position: 'relative',
  },
  foot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
  icon: {
    width: 15,
    height: 15,
  },
  notes: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingRight: 5,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 40,
    paddingHorizontal: 20,
  },
  upturned: {
    transform: [{ rotateZ: '180deg' }], // 详情箭头旋转朝上
  },
  valueStyle: {
    color: '#666',
    fontWeight: '400',
  },
  addressCellGroup: {
    zIndex: 999,
  },
});
