import * as React from 'react';
import { View, Platform, SafeAreaView, ImageBackground, BackHandler } from 'react-native';
import { MBBridge, MBLog } from '@ymm/rn-lib';
import { LayProvider } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import Images from '../../../../public/static/images';
import API from '../api';

import ModalShuntingMethod from '../components/ModalShuntingMethod'; // 调度方式
import OwnCar from './OwnCar'; // 指派自有车
import Carrier from './Carrier'; // 指派承运商
import OutboundCar from './OutboundCar'; // 指派外调车
import PlatformFind from './Platform'; // 满帮找车
import IndexBackground from '../indexBackground'; // 背景 假页面
import LoadingView from '../components/LoadingView';

export interface Props {
  navigation?: any;
  screenProps?: any;
  store?: any;
}
@inject('store')
@observer
export default class DispatchList extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: Props) {
    super(props);
    this.state = {
      showTypeModal: false, // 显示调度选择弹窗
      type: 1, // 当前选择的调度类型 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
      loadingNum: 0, // 要等待车长和车型加载好，加载好就加1 到2就说明两个加载好了
    };
  }
  UNSAFE_componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.goBack();
        return true;
      });
    }

    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  }

  componentDidMount() {
    const { id } = this.props.screenProps;
    const { getAddressConfig, getSystemInit } = this.props.store;
    this.props.store.setOrderId(id);
    this.api_taskDetail(id); // 获取运单任务详情
    getAddressConfig();
    // 获取车型车长 三种状态的下的枚举值
    const list = [
      this.props.store.api_getTruckTypeList(),
      this.props.store.api_getTruckLengthList(),
      this.props.store.api_getTruckTypePlateList(),
      this.props.store.api_getTruckLengthPlateList(),
      this.props.store.api_getTruckTypeAllList(),
      this.props.store.api_getTruckLengthAllList(),
    ];
    Promise.all(list).finally(() => {
      this.setState({ loadingNum: 6 + this.state.loadingNum });
    });

    // 系统配置接口（包含查询敏感词数据）
    getSystemInit();
  }

  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  openTypeModal = (val: boolean) => {
    // 兼容iOS无法在有蒙层的时候关闭loading
    if (Platform.OS === 'ios') {
      MBBridge.ui.hideLoading({});
    }
    this.setState({ showTypeModal: val });
  };
  // 调度方式改变
  handleTypeChange = (val: number) => {
    // 兼容iOS无法在有蒙层的时候关闭loading
    if (Platform.OS === 'ios') {
      MBBridge.ui.hideLoading({});
    }
    this.setState({ showTypeModal: false });
    if (this.state.type === 0 && !val) {
      val = 4;
    }

    // 处理地址显示
    this.handleDefaultAddress(val);

    val && this.setState({ type: val });
  };

  // 处理地址显示
  handleDefaultAddress = (val: number) => {
    const {
      store: {
        TaskDetail,
        initLoadUnloadAddress,
        isAddressChanged_1,
        isAddressChanged_2,
        isAddressChanged_30,
        isAddressChanged_31,
        isAddressChanged_4,
      },
    } = this.props;
    // 切换调度方式时，展示装卸货默认值
    if (val) {
      const isLoadAddressChanged = this.props.store.isLoadAddressChanged;
      const isUnloadAddressChanged = this.props.store.isUnloadAddressChanged;
      if (isLoadAddressChanged) {
        this.props.store.isLoadAddressChanged = false;
      }
      if (isUnloadAddressChanged) {
        this.props.store.isUnloadAddressChanged = false;
      }

      // 均未做更改时，将初始地址的值带入，遵循默认显示规则
      if (!isAddressChanged_1 && !isAddressChanged_2 && !isAddressChanged_30 && !isAddressChanged_31 && !isAddressChanged_4) {
        const tmsLoadUnloads = [TaskDetail.loadList[0] || {}, TaskDetail.unloadList[0] || {}];
        // 装卸货改变后，不初始化装卸货默认值
        if (val !== 31 && val !== 4) {
          initLoadUnloadAddress(val, { tmsLoadUnloads });
        }
      }
    }
  };
  // 获取运单任务详情
  api_taskDetail(id: string) {
    if (!id) {
      MBLog.log('没有运单id');
      return;
    }
    API.taskDetail({ id: id })
      .then((res: any) => {
        console.log( '--------------获取运单任务详情--------------');
        if (res.success && res.data) {
          this.props.store.setTaskDetail(res.data);
          this.setState((state: any) => ({
            loadingNum: state.loadingNum + 1,
            type: Number(res.data.dispatcherMode),
          }));
        }
      })
      .catch((er) => {
        if (er?.code === '900003' || er?.code === '900002') {
          MBBridge.rnruntime.handlebackResult({});
          if (Platform.OS == 'ios') {
            setTimeout(() => {
              MBBridge.app.ui.closeWindow({});
            }, 300);
          }
        }
        MBLog.error(er);
      });
  }
  // 左上角返回键
  goBack = () => {
    this.props.store?.goBack();
  };
  listBox(type: number) {
    const { navigation } = this.props;
    const { loadingNum } = this.state;
    if (loadingNum > 6) {
      switch (type) {
        case 1:
          return <OwnCar openTypeModal={this.openTypeModal} navigation={navigation} />;
        case 2:
          return <Carrier openTypeModal={this.openTypeModal} navigation={navigation} />;
        case 3:
          return <OutboundCar openTypeModal={this.openTypeModal} navigation={navigation} />;
        case 4:
          return <PlatformFind openTypeModal={this.openTypeModal} navigation={navigation} />;
        default:
          return <IndexBackground />;
      }
    } else {
      return <LoadingView />;
    }
  }
  public render() {
    const { showTypeModal, type } = this.state;
    return (
      <LayProvider theme="skyblue">
        <ImageBackground source={{ uri: Images.icon_bg_map }} style={{ flex: 1 }}>
          <NavBar title="修改" leftClick={this.goBack} />
          <View style={{ flex: 1 }}>{this.listBox(type)}</View>
        </ImageBackground>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
        <ModalShuntingMethod visible={showTypeModal} onChange={this.handleTypeChange} disabledList={[4]} />
      </LayProvider>
    );
  }
}
