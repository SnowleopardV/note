import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { MBText, Whitespace } from '@ymm/rn-elements';
import AddressList from '~/components/AddressList';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

/**
 * 装卸货地址组件
 */

export interface StateAddressModel {
  districtCode: 0; // 区code
  districtName: ''; // 区名称
  provinceCode: 0; // 省code
  provinceName: ''; // 省名称
  cityCode: 0; // 市code
  cityName: ''; // 市名称
  address: ''; // 地址
  addressLongitude: '0'; // 经度
  addressLatitude: '0'; // 纬度
  addressMapType: 2; // 地图类型：1-百度 2-高德
}

interface ModalAddresslistProps {
  dispatchTypeTopHeight: number;
  loadunloadDomHeight: number;
  loadOrderDomHeight?: number;
  dispatchType?: number;
  addressValue?: string;
  addressType?: number; // 0 装货，1 卸货
  addressConfig?: boolean;
  isAddressChanged?: boolean;
  searchLoading?: boolean;
  addressList: StateAddressModel[];
  addressKeyWord?: string;
  onSelect: (data: any) => void;
  sensitiveWordList: any;
}

const ModalAddresslist: React.FunctionComponent<ModalAddresslistProps> = (props) => {
  const {
    dispatchTypeTopHeight,
    loadunloadDomHeight,
    loadOrderDomHeight = 0,
    dispatchType,
    addressValue,
    addressType,
    addressConfig,
    addressList,
    isAddressChanged,
    searchLoading,
    addressKeyWord,
    onSelect,
    sensitiveWordList,
  } = props;

  let diffAddressAssociateStyle;
  // 装货
  if (!addressType) {
    diffAddressAssociateStyle = { top: dispatchTypeTopHeight + loadunloadDomHeight + loadOrderDomHeight };
  } else {
    diffAddressAssociateStyle = { top: dispatchTypeTopHeight + loadunloadDomHeight + loadunloadDomHeight + loadOrderDomHeight };
  }

  const onAddressSelect = (data: any) => {
    const { item, addressType, dispatchType } = data;
    const { address, poiName } = item;

    let handleAddress = '';
    let isSensitiveWordpoiName = false;
    let isSensitiveWordAddress = false;
    if (poiName) {
      isSensitiveWordpoiName = sensitiveWordList.some((item: any) => {
        return poiName.includes(item);
      });
    }

    isSensitiveWordAddress = sensitiveWordList.some((item: any) => {
      return address.includes(item);
    });

    if (isSensitiveWordpoiName) {
      handleAddress = address;
    }

    if (isSensitiveWordAddress) {
      handleAddress = poiName;
    }

    if (!isSensitiveWordpoiName && !isSensitiveWordAddress) {
      /**
       * 1、poiName中包含检索值keyWord，选中值 = address + poiName
       * 2、poiName和detailAddress中都包含检索值keyWord，选中值 = detailAddress
       * 3、poiName中不包含检索值keyWord，选中值 = detailAddress
       */
      handleAddress = address;
      if (addressKeyWord && poiName && poiName.includes(addressKeyWord) && !address.includes(addressKeyWord)) {
        handleAddress = address + poiName;
      }
    }

    const handleData = { item: { ...item, address: handleAddress }, addressType, dispatchType };

    onSelect && onSelect(handleData);
  };

  return (
    <>
      {addressList.length && isAddressChanged && addressValue ? (
        <View style={[styles.addressAssociate, diffAddressAssociateStyle]}>
          <AddressList
            inputText={addressValue}
            addressList={addressList}
            onSelect={(item) => onAddressSelect({ item, addressType, dispatchType })}
          />
        </View>
      ) : addressConfig && !searchLoading && isAddressChanged && addressValue ? (
        <View style={[styles.addressAssociate, diffAddressAssociateStyle]}>
          <Whitespace vertical={14} />
          <MBText align="center" color="#ccc">
            无搜索结果
          </MBText>
        </View>
      ) : null}
    </>
  );
};

const styles = StyleSheet.create({
  addressAssociate: {
    position: 'absolute',
    left: autoFix(160),
    top: autoFix(320),
    width: autoFix(540),
    minHeight: autoFix(132),
    maxHeight: autoFix(532),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 5, height: 5 },
    shadowRadius: autoFix(20),
    elevation: 20,
    borderRadius: autoFix(8),
  },

  // loadDispatchType12Style: {
  //   top: autoFix(230),
  // },

  // loadDispatchType34Style: {
  //   top: autoFix(320),
  // },

  // unloadDispatchType12Style: {
  //   top: autoFix(330),
  // },

  // unloadDispatchType34Style: {
  //   top: autoFix(420),
  // },
});

export default ModalAddresslist;
