import React from 'react';
import { View, StyleSheet, SafeAreaView, Platform, BackHandler } from 'react-native';
import { LayProvider, Flex, MBText, TagGroup, Tag, Button } from '@ymm/rn-elements';
import InputItem from '~/components/common/InputItem';
import NavBar from '~/components/common/NavBar';
import { inject, observer } from 'mobx-react';
import NativeBridge from '~/extends/NativeBridge';
import RegTest from '~/utils/RegTest';
import keyMap from './keyMap'; // 枚举值

// 备注
const styles = StyleSheet.create({
  box: {
    backgroundColor: '#FFFFFF',
    margin: 10,
    position: 'relative',
    // shadowColor: '#000',
    // shadowOpacity: 0.03,
    // shadowOffset: { width: 10, height: 0 },
    // shadowRadius: 10,
    // elevation: 20,
    minHeight: 140,
  },
  editBox: {
    flexDirection: 'row',
  },
  lable: {
    paddingTop: Platform.OS === 'ios' ? 20 : 15,
    paddingLeft: 20,
    color: '#333333',
  },
  inputItem: {
    flex: 1,
  },
  fontNum: {
    position: 'absolute',
    bottom: 10,
    right: 10,
  },
  foot: {
    backgroundColor: '#FFFFFF',
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
  },
  btn: {
    margin: 10,
  },
});

@inject('store')
@observer
export default class Remarks extends React.Component<any, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    const from = props.navigation.state.params.from;
    console.log(from);
    this.state = {
      type: props.navigation.state.params.type, // 0备注 1服务要求与备注
      from: from, // 来自哪个页面 1-指派自有车 2-指派承运商 3-指派外调车 4-满帮找车
      notes: this.props.store.getRemarks(from), //
      tagData: keyMap.tagData || [],
      selected: [],
      selectedText: [],
      isHiddenBtn: false, // 是否隐藏底部按钮
      disabled: props.navigation.state.params?.disabled || false,
    };
  }
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  componentDidMount() {
    const { from } = this.state;
    // eslint-disable-next-line prefer-const
    let { shortcut, selectedText, remark } = this.props.store['formData_' + from];
    // remark中包含了自定义的标签并用，分隔；需剔除处理
    if (remark) {
      const customRemarkArray = remark.split('，');
      const realRemark: string[] = [];
      let selectCustomRemarkName: string[] = [];
      let selectCustomRemark = customRemarkArray
        .map((item: string) => {
          const selectTag = this.state.tagData.find((tag: { name: string }) => tag.name === item);
          if (selectTag) {
            selectCustomRemarkName.push(item);
            if (selectTag.id) {
              return selectTag.id;
            }
            return item;
          }
          realRemark.push(item);
          return false;
        })
        .filter(Boolean);
      selectCustomRemark = Array.from(new Set(selectCustomRemark)); // 去重
      selectCustomRemarkName = Array.from(new Set(selectCustomRemarkName)); // 去重
      this.setState({
        notes: realRemark.join('，'),
      });
      if (selectCustomRemark.length > 0) {
        if (shortcut && shortcut.length > 0) {
          shortcut = Array.from(new Set(shortcut.concat(selectCustomRemark))); // 去重
        } else {
          shortcut = selectCustomRemark;
        }
        if (selectedText && selectedText.length > 0) {
          selectedText = Array.from(new Set(selectedText.concat(selectCustomRemarkName))); // 去重
        } else {
          selectedText = selectCustomRemarkName;
        }
      }
    }
    !!shortcut && this.setState({ selected: shortcut });
    !!selectedText && this.setState({ selectedText: selectedText });
  }
  handleText = (val: string): void => {
    val = val.replace(/\n/gm, ''); // 禁止换行
    if (val.length > 100) {
      NativeBridge.toast('已达到输入上限100个字符');
      this.setState({ notes: val.slice(0, 100) });
    } else {
      if (!RegTest.emoji(val)) {
        this.setState({ notes: val });
      }
    }
  };
  onItemClick = (val: any): void => {
    let { selected, selectedText } = this.state;
    if (selected.includes(val.id || val.name)) {
      selected = selected.filter((id: number) => id !== val.id && id !== val.name);
      this.setState({ selected: selected });
    } else {
      selected.push(val.id || val.name);
      this.setState({ selected: selected });
    }
    if (selectedText.includes(val.name)) {
      selectedText = selectedText.filter((name: string) => name !== val.name); // 文本
      this.setState({ selectedText: selectedText });
    } else {
      selectedText.push(val.name);
      this.setState({ selectedText: selectedText });
    }
  };
  submit() {
    const { from, notes, selected, selectedText } = this.state;
    const data = {
      remark: notes,
      shortcut: selected,
      selectedText: selectedText,
    };
    this.props.store.setFormData(from, data);
    this.props.navigation?.goBack();
  }
  // 底部按钮
  footElement() {
    const { notes, selected, isHiddenBtn } = this.state;
    return (
      <SafeAreaView style={isHiddenBtn ? { display: 'none' } : styles.foot}>
        <Button radius disabled={!notes && !selected.length} style={styles.btn} onPress={this.submit.bind(this)} size="sm" type="primary">
          确定
        </Button>
      </SafeAreaView>
    );
  }
  hiddenButton(val: boolean) {
    this.setState({ isHiddenBtn: val });
  }
  render() {
    const textNum = this.state.notes ? this.state.notes.length : 0;
    const { tagData, selected, type, notes, disabled } = this.state;
    return (
      <LayProvider theme="skyblue">
        <View style={{ flex: 1 }}>
          <NavBar
            title="备注"
            leftClick={() => {
              this.props.navigation?.goBack();
            }}
          />
          <SafeAreaView style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
            <View style={styles.box}>
              <View style={styles.editBox}>
                <MBText style={styles.lable}>备注</MBText>
                <InputItem
                  value={notes}
                  placeholder="请输入备注信息"
                  onChangeText={this.handleText}
                  style={styles.inputItem}
                  inputStyle={{ marginLeft: 0 }}
                  maxLength={101}
                  multiline={true}
                  blurOnSubmit
                  onFocus={() => this.hiddenButton(true)}
                  onBlur={() => this.hiddenButton(false)}
                />
              </View>
              <View style={{ height: 20 }}></View>
              <View style={styles.fontNum}>
                <MBText color="#CCCCCC">{textNum}/100</MBText>
              </View>
            </View>
            {type === 1 && (
              <Flex direction="row" justify="space-between" align="center" style={{ paddingHorizontal: 10 }}>
                <TagGroup
                  defaultSelected={tagData.filter((item: any) => selected.includes(item.id || item.name)).map((_i: any) => _i.name)}
                  rowId="name"
                  space={12}
                  rowSize={4}
                  multiple={true}
                  maxNumber={tagData.length}
                  onPress={this.onItemClick.bind(this)}
                  disabled={disabled}
                  onDisabledPress={() => {
                    NativeBridge.toast('不支持修改快捷标签');
                  }}
                  style={disabled ? { opacity: 0.4 } : {}}
                >
                  {tagData.map((item: any) => {
                    return (
                      <Tag key={item.id || item.name} item={item} style={{ marginTop: 10 }} size="sm">
                        {item.name}
                      </Tag>
                    );
                  })}
                </TagGroup>
              </Flex>
            )}
          </SafeAreaView>
          {this.footElement()}
        </View>
      </LayProvider>
    );
  }
}
