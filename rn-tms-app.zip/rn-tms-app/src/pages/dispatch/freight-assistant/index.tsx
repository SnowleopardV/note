import React from 'react';
import { View, ImageBackground, Image, SafeAreaView, TouchableOpacity, Platform, BackHandler } from 'react-native';
import { LayProvider, MBText, Whitespace } from '@ymm/rn-elements';
import NavBar from '~/components/common/NavBar';
import styles from './styles';
import Images from '~public/static/images';
import OrderDetailCard from './OrderDetailCard';
import Api from '../api';
import OrderBox from '~/components/common/OrderBox';
import NativeBridge from '~/extends/NativeBridge';
import { BaseReturnData, ServerReallyData } from '~/server';

interface FreightAssistantProps {
  navigation?: any;
}
interface FreightAssistantState {
  pageNo: number;
  list: Array<any>;
  isEnd: boolean;
  freightDetail: any;
}
// 根据不同source进行字段映射
const keyMap = {
  dispatchAdd: ['weight', 'volume'],
  dispatchStowage: ['cargoWeight', 'cargoVolume'],
};
function getCargoName(cargoList: Array<any>, source: string) {
  if (!cargoList) return '';
  let cargoName = cargoList[0].cargoName;
  if (cargoList.length === 1) return cargoName;
  // 货名传参：若有多个货名，则取重量最大的货名做为传参货名，若货名的重量都相等，则取最大体积的作为传参货名；
  // 如果以上两种还是对比不出结果，默认取上面两步比较结果的第一条数据
  // eslint-disable-next-line no-extra-boolean-cast
  const maxWeight = Math.max(...cargoList.map((val) => (val[keyMap[source][0]] ? val[keyMap[source][0]] : 0)));
  const maxWList = cargoList.filter((v) => Number(v[keyMap[source][0]]) === maxWeight);
  // 默认取重量最大值list的第一个
  if (maxWList[0]) cargoName = maxWList[0].cargoName;
  if (maxWList.length > 1) {
    // 重量最大值多个，再比较多个最大值对应的体积
    // eslint-disable-next-line no-extra-boolean-cast
    const maxVolume = Math.max(...maxWList.map((val) => (val[keyMap[source][1]] ? val[keyMap[source][1]] : 0)));
    const maxVList = cargoList.filter((v) => Number(v[keyMap[source][1]]) === maxVolume);
    // 始终取体积最大值list的第一个
    if (maxVList[0]) cargoName = maxVList[0].cargoName;
  }
  return cargoName;
}
/**
 * 调度页面跳转到运价助手页面
 * @param that: 调用该方法的组件对象
 * @param source: 调用该方法的组件标识，用于过滤如何做某些校验判断
 */
export function goFreightAssistantPage(that: any, source: string): void {
  const { navigation, store } = that.props;
  const {
    platformCarType,
    platformCarLength,
    platformTotalWeightMin,
    platformTotalVolumeMin,
    platformTotalWeight,
    platformTotalVolume,
    invoiceFlag,
    dispatcherId,
    deliveryUnit,
  } = store.formData_4;
  const { loadingList, unloadingList, cargoList } = store;
  let cargoName = '';
  if (loadingList.length === 0 || !loadingList[0]?.address) {
    NativeBridge.toast('请先填写装货地址');
    return;
  }
  if (unloadingList.length === 0 || !unloadingList[unloadingList.length - 1]?.address) {
    NativeBridge.toast('请先填写卸货地址');
    return;
  }
  if (platformCarType.length === 0 || platformCarLength.length === 0) {
    NativeBridge.toast('请先选择车型车长');
    return;
  }
  if (source === 'dispatchStowage') {
    if (!store.stowageSelectedList || store.stowageSelectedList.length === 0) {
      NativeBridge.toast('装车清单至少要有1个运单');
      return;
    }
    cargoName = getCargoName(store.stowageSelectedList, source);
  } else if (source === 'dispatchAdd') {
    if (cargoList.length === 0 || !cargoList[0].cargoName) {
      NativeBridge.toast('请先填写货物名称');
      return;
    }
    cargoName = getCargoName(cargoList, source);
  }
  if (!platformTotalWeightMin && !platformTotalWeight && !platformTotalVolumeMin && !platformTotalVolume) {
    NativeBridge.toast('货物重量和体积必须至少填写一个大于0的值');
    return;
  }
  const cargoInfo = {
    isInvoice: invoiceFlag === 1 || invoiceFlag === 2 ? 1 : 0,
    start: loadingList[0].districtCode,
    end: unloadingList[unloadingList.length - 1].districtCode,
    startLatitude: loadingList[0].addressLatitude,
    startLongitude: loadingList[0].addressLongitude,
    endLatitude: unloadingList[unloadingList.length - 1].addressLatitude,
    endLongitude: unloadingList[unloadingList.length - 1].addressLongitude,
    truckTypeList: platformCarType.join(','),
    truckLength: platformCarLength.join(','),
    minTruckWeight: platformTotalWeightMin ? Number(platformTotalWeightMin) : null,
    maxTruckWeight: platformTotalWeight ? Number(platformTotalWeight) : null,
    minCargoCapacipy: platformTotalVolumeMin ? Number(platformTotalVolumeMin) : null,
    maxCargoCapacipy: platformTotalVolume ? Number(platformTotalVolume) : null,
    loadAddress: loadingList[0].address,
    estimateDistance: 0,
    cargoUserId: dispatcherId,
    cargoName,
    priceType: deliveryUnit,
  };
  navigation.navigate('FreightAssistant', { cargoInfo });
}
export default class FreightAssistant extends React.Component<FreightAssistantProps, FreightAssistantState> {
  backHandleListener: any;
  constructor(props: FreightAssistantProps) {
    super(props);
    this.state = {
      pageNo: 0,
      list: [],
      isEnd: true,
      freightDetail: {
        maxDealPrice: null, // 最大成交价格
        minDealPrice: null, // 最小成交价格
        averageDealPrice: null, // 平均成交价格
        priceType: null, // 成交价单位（趟吨方）
      },
    };
  }
  orderBoxRef = React.createRef<any>();
  orderList = [
    { key: '1', title: '运费参考价' },
    { key: '2', title: '运输里程' },
    { key: '3', title: '成交时间' },
  ];
  componentWillMount() {
    if (Platform.OS === 'android') {
      this.backHandleListener = BackHandler.addEventListener('hardwareBackPress', () => {
        this.props.navigation?.goBack();
        return true;
      });
    }
  }
  componentWillUnmount(): void {
    this.backHandleListener?.remove();
  }
  componentDidMount(): void {
    this.fetchFreightAssistantList();
  }
  // 获取历史运单信息
  fetchFreightAssistantList = async (isRefresh = false): Promise<void> => {
    let data: ServerReallyData = {};
    const pageParams = {
      pageNo: isRefresh ? 1 : this.state.pageNo + 1,
      pageSize: 10,
    };
    if (this.props.navigation.state.params.transOrderNo) {
      // 运单管理-已调度和未调度进入
      data = (
        (await Api.freightRateAssistant(
          { transOrderNo: this.props.navigation.state.params.transOrderNo, ...pageParams },
          !isRefresh
        )) as BaseReturnData
      ).data as ServerReallyData;
    } else {
      // 开单调度和配载调度进入
      data = (
        (await Api.freightAssistantWithoutOrder(
          { cargoInfo: this.props.navigation.state.params.cargoInfo ?? null, ...pageParams },
          !isRefresh
        )) as BaseReturnData
      ).data as ServerReallyData;
    }
    const newFreightDetail = {};
    !data.list && (data.list = []);
    Object.keys(this.state.freightDetail).forEach((k) => {
      newFreightDetail[k] = data[k];
    });
    this.setState((prevState) => ({
      freightDetail: newFreightDetail,
      isEnd: !data.hasNextPage,
      list: isRefresh ? data.list ?? [] : [...prevState.list, ...data.list] ?? [],
      pageNo: isRefresh ? 1 : prevState.pageNo + 1,
    }));
    this.orderBoxRef.current.cancelOrderState();
  };
  // 左上角返回键
  goBack = (): void => {
    this.props.navigation.goBack();
  };
  handleOrderChange = (orderType: string, orderByAsc: boolean): void => {
    const myCargoList = this.state.list.filter((item) => item.currentCargoFlag);
    const noMyCargoList = this.state.list.filter((item) => !item.currentCargoFlag);
    noMyCargoList.sort(function (m1, m2) {
      if (orderType === '1') {
        // 按运费参考价
        if (Number(m1.dealPrice) < Number(m2.dealPrice)) {
          return orderByAsc ? -1 : 1;
        } else if (Number(m1.dealPrice) > Number(m2.dealPrice)) {
          return orderByAsc ? 1 : -1;
        } else {
          return 0;
        }
      } else if (orderType === '2') {
        // 按运输里程
        if (Number(m1.carryDistance) < Number(m2.carryDistance)) {
          return orderByAsc ? -1 : 1;
        } else if (Number(m1.carryDistance) > Number(m2.carryDistance)) {
          return orderByAsc ? 1 : -1;
        } else {
          return 0;
        }
      } else if (orderType === '3') {
        // 按成交时间
        if (Number(m1.dealTimeSortValue) < Number(m2.dealTimeSortValue)) {
          return orderByAsc ? -1 : 1;
        } else if (Number(m1.dealTimeSortValue) > Number(m2.dealTimeSortValue)) {
          return orderByAsc ? 1 : -1;
        } else {
          return 0;
        }
      } else {
        return 0;
      }
    });
    this.setState({
      list: [...myCargoList, ...noMyCargoList],
    });
  };
  render(): React.ReactNode {
    const { maxDealPrice, minDealPrice, averageDealPrice, priceType } = this.state.freightDetail;
    return (
      <LayProvider theme="skyblue">
        <ImageBackground source={{ uri: Images.icon_bg_map }} style={styles.flexing}>
          <NavBar title="运价助手" leftClick={this.goBack} />
          <View style={styles.tips}>
            <View style={styles.tipsContain}>
              <Image style={styles.tipsIcon} source={Images.icon_warning_yellow}></Image>
              <MBText style={styles.tipText}>以下为类似货物、线路的部分历史成交价，仅供您参考，具体出价以您和司机协商一致为准</MBText>
            </View>
          </View>
          <Whitespace vertical={10} />
          <View style={[styles.card, styles.priceCard]}>
            <View style={[styles.priceCardCell, styles.divisiion]}>
              <MBText style={styles.priceCardCellText}>价格区间(元)</MBText>
              <View style={styles.priceCardCellPriceBox}>
                <MBText style={styles.priceCardCellPrice}>
                  {!minDealPrice && !maxDealPrice ? '—' : `${minDealPrice ?? '—'}-${maxDealPrice ?? '—'}`}
                </MBText>
                <MBText style={styles.priceCardCellPriceUnit}>{priceType ? '/' + priceType : ''}</MBText>
              </View>
            </View>
            <View style={styles.priceCardCell}>
              <MBText style={styles.priceCardCellText}>平均运费参考价(元)</MBText>
              <View style={styles.priceCardCellPriceBox}>
                <MBText style={styles.priceCardCellPrice}>{averageDealPrice ?? '—'}</MBText>
                <MBText style={styles.priceCardCellPriceUnit}>{priceType ? '/' + priceType : ''}</MBText>
              </View>
            </View>
          </View>
          <Whitespace vertical={10} />
          <OrderBox ref={this.orderBoxRef} list={this.orderList} handleOrderChange={this.handleOrderChange}></OrderBox>
          <Whitespace vertical={10} />
          {/* 运单明细Card */}
          <OrderDetailCard
            isEnd={this.state.isEnd}
            list={this.state.list}
            priceType={priceType}
            fetchFreightAssistantList={this.fetchFreightAssistantList}
          ></OrderDetailCard>
          <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
        </ImageBackground>
      </LayProvider>
    );
  }
}
