import { MBText, RefreshList, Whitespace } from '@ymm/rn-elements';
import React from 'react';
import { View, Image } from 'react-native';
import Images from '~public/static/images';
import styles from './styles';
export interface OrderDetailCardProps {
  list: Array<any>;
  isEnd: boolean;
  priceType: string;
  fetchFreightAssistantList: (isRefresh?: boolean) => void;
}
class OrderDetailCard extends React.Component<OrderDetailCardProps> {
  constructor(props: OrderDetailCardProps) {
    super(props);
  }
  // 单个运单信息
  renderItem = (item: any): JSX.Element => {
    const carTypeLength = `${item.truckTypeName ?? ''}${
      item.truckTypeName && item.dealTruckLength ? ',' + item.dealTruckLength : item.dealTruckLength ?? ''
    }`;
    let truckWeight = '';
    if (item.minTruckWeight && item.maxTruckWeight) {
      truckWeight = `${item.minTruckWeight}-${item.maxTruckWeight}`;
    } else if (item.minTruckWeight) {
      truckWeight = item.minTruckWeight;
    } else if (item.maxTruckWeight) {
      truckWeight = item.maxTruckWeight;
    } else {
      truckWeight = '-';
    }
    let cargoCapacity = '';
    if (item.minCargoCapacity && item.maxCargoCapacity) {
      cargoCapacity = `${item.minCargoCapacity}-${item.maxCargoCapacity}`;
    } else if (item.minCargoCapacity) {
      cargoCapacity = item.minCargoCapacity;
    } else if (item.maxCargoCapacity) {
      cargoCapacity = item.maxCargoCapacity;
    } else {
      cargoCapacity = '-';
    }
    return (
      <View style={[styles.card, styles.orderDetailCard]}>
        {item.currentCargoFlag ? (
          <View style={styles.mySourceOfGood}>
            <MBText style={styles.searchBoxSelectText}>我的货源</MBText>
          </View>
        ) : (
          <Whitespace vertical={20} />
        )}
        <View style={styles.loadUnloadInfo}>
          <View style={[styles.flexRow, styles.city]}>
            <Image style={styles.tipsIcon} source={{ uri: Images.icon_shipper }}></Image>
            <MBText style={styles.orderCardCityText}>{item.startCityName ?? ''}</MBText>
          </View>
          <View style={styles.orderCardTransport}>
            <MBText>{item.carryDistance ?? '0'}公里</MBText>
            <Image style={styles.arrow} source={Images.icon_long_gray_arrow}></Image>
            <MBText style={{ textAlign: 'center' }}>{carTypeLength}</MBText>
          </View>
          <View style={[styles.flexRow, styles.city]}>
            <Image style={styles.tipsIcon} source={{ uri: Images.icon_consignee }}></Image>
            <MBText style={styles.orderCardCityText}>{item.endCityName ?? ''}</MBText>
          </View>
          <View style={styles.orderCardPriceBox}>
            <View style={[styles.flexRow, { alignItems: 'flex-end' }]}>
              <MBText style={styles.orderCardCellSymbol}>￥</MBText>
              <MBText style={styles.orderCardCellPrice}>{item.dealPrice ?? '-'}</MBText>
            </View>
            <MBText style={styles.priceCardCellText}>/{this.props.priceType}</MBText>
          </View>
        </View>
        <View style={styles.cargoBox}>
          <View style={styles.cargoInfoBox}>
            <View style={styles.cargoInfo}>
              <MBText style={styles.priceCardCellText}>{`${item.cargoName ?? ''} | ${truckWeight}吨 | ${cargoCapacity}方`}</MBText>
            </View>
          </View>
          <View style={styles.cargoDealTimeBox}>
            <MBText style={[styles.priceCardCellText, { textAlign: 'right' }]}>{item.dealTime ?? ''}</MBText>
          </View>
        </View>
      </View>
    );
  };
  renderEmpty = (): JSX.Element => {
    return (
      <View style={styles.empty}>
        <Image source={{ uri: Images.icon_no_data }} style={styles.emptyIcon}></Image>
        <MBText style={styles.emptyText}>暂无数据</MBText>
      </View>
    );
  };
  // 下拉刷新
  onRefresh = (): Promise<Response> => {
    return new Promise(async (resolve) => {
      await this.props.fetchFreightAssistantList(true);
      resolve();
    });
  };
  // 上拉获取数据
  onLoadMore = (): Promise<Response> => {
    return new Promise(async (resolve) => {
      await this.props.fetchFreightAssistantList();
      resolve();
    });
  };
  render(): React.ReactNode {
    return (
      <View style={{ flex: 1 }}>
        <RefreshList
          isEnd={this.props.isEnd}
          data={this.props.list}
          renderItem={(item: any) => {
            return this.renderItem(item);
          }}
          emptyRender={this.renderEmpty}
          onRefresh={this.onRefresh}
          onLoadMore={this.onLoadMore}
        />
      </View>
    );
  }
}

export default OrderDetailCard;
