import { StyleSheet } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  flexing: {
    flex: 1,
  },
  flexRow: {
    flexDirection: 'row',
  },
  tips: {
    height: autoFix(97),
    backgroundColor: 'rgba(255, 251, 230, 1)',
    fontSize: autoFix(26),
    paddingVertical: autoFix(12),
    paddingHorizontal: autoFix(52),
    justifyContent: 'center',
  },
  tipsContain: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  tipsIcon: {
    width: autoFix(32),
    height: autoFix(32),
    marginRight: 2,
  },
  tipText: {
    color: '#ffbb44',
  },
  card: {
    backgroundColor: '#ffffff',
    marginHorizontal: 10,
    borderRadius: 2,
  },
  priceCard: {
    flexDirection: 'row',
    flexBasis: autoFix(166),
    paddingVertical: autoFix(30),
  },
  priceCardCell: {
    width: '49%',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  divisiion: {
    borderRightWidth: autoFix(1),
    borderRightColor: 'rgba(153, 153, 153, 0.5)',
  },
  priceCardCellText: {
    fontSize: autoFix(26),
    color: 'rgba(153, 153, 153, 1)',
  },
  priceCardCellPriceBox: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    width: '90%',
  },
  priceCardCellPrice: {
    fontSize: autoFix(40),
    color: 'rgba(51, 51, 51, 1)',
  },
  priceCardCellPriceUnit: {
    fontSize: autoFix(20),
    color: 'rgba(51, 51, 51, 1)',
    lineHeight: autoFix(40),
  },
  orderDetailCard: {
    minHeight: autoFix(280),
    marginBottom: autoFix(20),
  },
  searchBoxSelectText: {
    color: 'rgba(72, 133, 255, 1)',
  },
  mySourceOfGood: {
    width: autoFix(150),
    height: autoFix(50),
    backgroundColor: 'rgba(72, 133, 255, 0.12)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadUnloadInfo: {
    minHeight: autoFix(150),
    borderBottomWidth: autoFix(1),
    borderBottomColor: 'rgba(232, 232, 232, 1)',
    flexDirection: 'row',
    paddingTop: autoFix(10),
  },
  city: {
    width: '25%',
    height: autoFix(80),
    justifyContent: 'center',
    fontFamily: 'PingFangSC-Semibold',
    alignItems: 'center',
  },
  orderCardCityText: {
    color: 'rgba(51, 51, 51, 1)',
    maxWidth: '80%',
  },
  orderCardTransport: {
    width: '30%',
    alignItems: 'center',
  },
  arrow: {
    width: autoFix(140),
    height: autoFix(5),
  },
  orderCardPriceBox: {
    width: '20%',
    alignItems: 'flex-end',
    paddingRight: autoFix(10),
  },
  orderCardCellSymbol: {
    fontSize: autoFix(26),
    color: 'rgba(255, 105, 105, 1)',
    lineHeight: autoFix(40),
  },
  orderCardCellPrice: {
    fontSize: autoFix(40),
    color: 'rgba(255, 105, 105, 1)',
    lineHeight: autoFix(50),
    maxWidth: '95%',
  },
  cargoBox: {
    flexDirection: 'row',
    paddingHorizontal: autoFix(12),
    paddingVertical: autoFix(20),
    justifyContent: 'space-between',
  },
  cargoInfoBox: {
    width: '70%',
  },
  cargoInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cargoDealTimeBox: {
    width: '25%',
  },
  emptyIcon: {
    width: autoFix(287),
    height: autoFix(272),
  },
  empty: {
    height: 600,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
  },
});
