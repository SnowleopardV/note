import { Platform } from 'react-native';
import server, { BaseReturnData } from '~/server';

// 文档 http://yapi.1111.com/#/project/2532/interface/api/183549
const Api = {
  // 创建调度-查询司机列表
  queryDriverList(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/queryDriverList',
      data: { ...params },
    });
  },
  // 创建调度-查询承运商列表
  queryCarrierList(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/queryCarrierList',
      data: { ...params },
    });
  },
  // 创建调度-查询车辆列表
  queryTruckList(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/queryTruckList',
      data: { ...params },
    });
  },
  // 创建调度-获取油卡列表
  queryOilCardList(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/queryOilCardList',
      data: { ...params },
    });
  },
  // 创建调度-查询调度员列表
  queryDispatcherList(params: any = {}): Promise<any> {
    return server(
      {
        // url: '/saas-tms-trans/yzgApp/capacity/queryDispatcherList',
        url: '/saas-permission-app/yzgApp/companyAuth/dispatchList',
        data: { ...params },
      },
      { toastError: false, showLoading: false }
    );
  },
  // 创建调度 -- 保存并使用 也是 配载调度
  createDispatch(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/create',
        data: { ...params },
      },
      { toastError: false, showLoading: true }
    );
  },

  // 调度管理-调度详情 -- 主要为了看看创建运单时是否填写了 体积或是重量
  dispatchDetail(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/dispatch/dispatchDetail',
        data: { ...params },
      },
      { showLoading: false }
    );
  },

  // 创建调度-搜索承运司机
  searchDriver(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/task/query/outside/driver',
      data: { ...params },
    });
  },

  // 创建调度-查询开票费率 -- 废弃
  billingrate(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/crm/query/billingrate',
      data: { ...params },
    });
  },
  // 创建调度-根据企业id查询用油比例限制 http://yapi.1111.com/#/project/2532/interface/api/196093
  oilrestriction(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/task/query/oilrestriction',
      data: { ...params },
    });
  },
  // 创建调度-查询服务费 http://yapi.1111.com/#/project/2532/interface/api/194021
  serviceFee(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/query/service/fee',
        data: { ...params, version: 1 },
      },
      { showLoading: false }
    );
  },
  // 创建运单 http://yapi.1111.com/#/project/2532/interface/api/181877
  orderCreate(params: any = {}, showLoading: boolean = true): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/order/create',
        data: { ...params },
      },
      { showLoading }
    );
  },
  // 创建调度-获取快捷标签接口 http://yapi.1111.com/#/project/2532/interface/api/196005
  queryRemarkTags(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/capacity/queryRemarkTags',
      data: { ...params, version: '1.0' },
    });
  },
  // 创建调度-获取车长接口 http://yapi.1111.com/#/project/2532/interface/api/195989
  getTruckLengthList(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/getTruckLengths',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  // 创建调度-查询车型列表 http://yapi.1111.com/#/project/2532/interface/api/195997
  getTruckTypeList(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/getTruckTypes',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  // 创建调度-最近一次指派承运商的信息 http://yapi.1111.com/#/project/2532/interface/api/183685
  lastCarrierTaskInfo(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/lastCarrierTaskInfo',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  // 编辑运单  http://yapi.1111.com/#/project/2532/interface/api/198037
  orderUpdate(params: any = {}, showLoading: boolean = true): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/order/update',
        data: { ...params },
      },
      { showLoading }
    );
  },
  // 调度修改-任务详情  http://yapi.1111.com/#/project/2532/interface/api/183261
  taskDetail(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/task/detail',
      data: { ...params },
    });
  },

  // 调度修改  http://yapi.1111.com/#/project/2532/interface/api/183741
  editDispatch(params: any = {}, showLoading: boolean = false): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/modify',
        data: { ...params },
      },
      { showLoading }
    );
  },
  // 配载调度列表 -- 待调度 列表  http://yapi.1111.com/#/project/2532/interface/api/183829
  dispatchList(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/dispatch/dispatchList',
      data: { ...params },
    });
  },
  // 获取里程
  addressDistance(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/address/distance',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  personalSet(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/personalSet/search',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  /** 查询组织是否有满运宝认证 */
  mybAuth(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/org/mybAuth',
      data: { ...params },
    });
  },

  // 获取满运宝企业信息-发票抬头
  getMybCompanyInfo(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/org/getMybCompanyInfo',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  /** 获取当前组织是否支持普票货源 */
  checkGeneralInvoiceEnable(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/tenant/config/checkGeneralEnable',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  /** 获取发票类型 */
  getInvoiceType(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/tenant/config/getInvoices',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  /** 普票服务费计算接口 **/
  calculateServiceFee(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/contract/getServiceFee',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  /** 获取用户自定义费用内容 */
  getFeeInputBoxes(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/tenant/config/getTaskFeeInputBoxes',
      data: { ...params },
    });
  },
  /** 获取地址联想 */
  addressAssociate(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/address/associate',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  /** 查询用户的业务配置信息 获取白名单，不再白名单中使用单选 */
  getAppBusinessConfig(loading: boolean = true): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/user/config/getAppBusinessConfig',
        data: {},
      },
      { showLoading: loading }
    );
  },
  /** 获取默认调度员列表 */
  defaultDispatcherList(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/task/defaultDispatcherList',
      data: { ...params },
    });
  },
  /** 获取一口价露出开关配置 */
  cargoDealModeInit(showLoading: boolean = false, toastError: boolean = false): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/task/cargoDealMode/init',
        data: {},
      },
      { showLoading: showLoading, toastError: toastError }
    );
  },
  /** 查询重量体积区间约束 */
  cargoIntervalConfig(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/platform/cargo/intervalConfig',
        data: { ...params },
      },
      { showLoading: false, toastError: false }
    );
  },

  /** 查询货运险 */
  getCargoInsuranceList(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/order/dispatch/insurance/list',
        data: { ...params },
      },
      { showLoading: false, toastError: false }
    );
  } /** 是否可选接听号码 0否 1是 */,
  systemShowPhoneNumber(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/trans/system/init',
        data: { ...params },
      },
      { showLoading: false, toastError: false }
    );
  },
  /** 调度员设置默认接听号码 */
  dispacherContactDefault(params: any = {}): Promise<any> {
    return server({
      url: '/saas-tms-trans/yzgApp/platform/dispatcher/contact/default',
      data: { ...params },
    });
  },
  /** 校验大额保价内容 */
  getlargeInsuranceCheck(params: any): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/insurance/large/check',
        data: { ...params },
      },
      { showLoading: false, toastError: false }
    );
  },
  /** 查询开单时和配载时的运价助手信息 */
  freightAssistantWithoutOrder(params: any, showLoading: boolean): Promise<void | BaseReturnData> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/tmsFarm/freightAssistantWithoutOrder',
        data: { ...params },
      },
      { showLoading }
    );
  },
  /** 查询运单列表待调度和已调度的运价助手信息 */
  freightRateAssistant(params: any, showLoading: boolean): Promise<void | BaseReturnData> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/tmsFarm/freightRateAssistant',
        data: { ...params },
      },
      { showLoading }
    );
  },
  /** 查询当前用户是否有运价助手权限 */
  supportFreightAssistant(): Promise<void | BaseReturnData> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/tmsFarm/supportFreightAssistant',
        data: {},
      },
      { showLoading: true, toastError: false }
    );
  },
};

export default Api;
