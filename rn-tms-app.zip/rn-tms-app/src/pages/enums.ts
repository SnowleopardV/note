/** 枚举集合 */
export const transTypeEnum = [
  { label: '公路整车', value: 'FULL_TRUCKLOAD' },
  { label: '公路零担', value: 'LESS_THAN_TRUCKLOAD' },
  { label: '公路整车往返', value: 'FULL_TRUCKLOAD_TWO' },
  { label: '公路整车单边', value: 'FULL_TRUCKLOAD_ONE' },
];
