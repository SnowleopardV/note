import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import CustomerList from '../List';
import CustomerAdd from '../Add';

/**
 * RN页面
 */
export enum RouterPageName {
  /** 客户管理列表 */
  List = 'List',
  /** 新增客户 */
  Add = 'Add',
  /** 客户详情 */
  Detail = 'Detail',
}

/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        List: { screen: CustomerList, navigationOptions: () => ({ header: null }) },
        Add: { screen: CustomerAdd, navigationOptions: () => ({ header: null }) },
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
