import React from 'react';
import { Platform } from 'react-native';
import { LayProvider } from '@ymm/rn-elements';
import { JsonParse } from '@ymm/rn-lib/src/utils';
import { Provider } from 'mobx-react';
import RouterMap, { RouterPageName } from './register';
import CustomerStore from '~/pages/waybill/customer/Store/Customer';
import CustomerAddStore from '~/pages/waybill/customer/Store/CustomerAdd';
import WaybillCreateStore from '~/pages/waybill/create/store';

/**
 * @param name 路由简写名
 * 列表：ymm://rn.tms/customermanagement
 * 新增：ymm://rn.tms/customermanagement?routername=add
 * 详情：ymm://rn.tms/customermanagement?routername=detail
 */
function routerNameMap(name: string) {
  let routerName = '';
  switch (name) {
    case 'add':
      routerName = 'Add';
      break;
    case 'detail':
      routerName = 'detail';
      break;
    default:
      routerName = 'List';
      break;
  }
  return routerName;
}

const CustomerManagement: React.FunctionComponent<any> = (props) => {
  const routerName = routerNameMap(props.routername);
  const RootStack = new RouterMap().getRouterMap(RouterPageName[routerName]);

  const { contacttype, customerid, customername, contactlist } = props;

  let handlecontactlist = contactlist;
  if (Platform.OS === 'android') {
    handlecontactlist = JsonParse.parse(contactlist);
  }

  const customerStore = new CustomerStore(Number(contacttype), customerid, customername, 'true', handlecontactlist);
  const customerAddStore = new CustomerAddStore(Number(contacttype));
  const waybillCreateStore = new WaybillCreateStore(null);

  return (
    <Provider customerStore={customerStore} customerAddStore={customerAddStore} waybillCreateStore={waybillCreateStore}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
      </LayProvider>
    </Provider>
  );
};

export default CustomerManagement;
