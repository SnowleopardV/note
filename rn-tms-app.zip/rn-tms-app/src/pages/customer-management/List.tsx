import React from 'react';
import { SafeAreaView, View, StyleSheet, Platform, BackHandler, TouchableOpacity } from 'react-native';
import { MBText } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import { MBBridge } from '@ymm/rn-lib';
import { RouterPageName } from './Router/register';
import NavBar from '~/components/common/NavBar';
import CustomerStore from '~/pages/waybill/customer/Store/Customer';
import ChooseContent from '~/pages/waybill/customer/components/ChooseContent';

/**
 * 选择客户页
 * @param props
 * @returns
 */

export interface CustomerChooseIndexProps {
  screenProps: any;
  customerStore: CustomerStore;
  navigation: any;
}

@inject('customerStore')
@observer
export default class CustomerList extends React.Component<CustomerChooseIndexProps, any> {
  state = {
    showFooterBtn: true,
  };

  constructor(props: CustomerChooseIndexProps) {
    super(props);
  }

  /**
   * 底部按钮 不能被键盘顶起
   */
  onCommonBlurFocus = (val: boolean) => {
    this.setState({ showFooterBtn: val });
  };

  /**
   * 选中客户后回调，暂无操作
   */
  confirmSelect = (user: any) => {
    return true;
  };

  /**
   * 点击：新增客户，跳转到新增客户页
   */
  onCustomerAdd = () => {
    const customerStore = this.props.customerStore;
    this.props.navigation.navigate(RouterPageName.Add, {
      onSuccess: () => {
        customerStore.fetcAllCustomer();
      },
    });
  };

  /**
   * 右侧新增客户按钮，目前是没有权限控制，只要进入，都可以进行新增操作；后期如果存在权限时，在此处加即可
   */
  rightElement() {
    return (
      <TouchableOpacity
        onPress={() => {
          this.onCustomerAdd();
        }}
      >
        <MBText color="primary" size="sm">
          新增客户
        </MBText>
      </TouchableOpacity>
    );
  }

  render() {
    const { customerStore } = this.props;

    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', () => {
        MBBridge.app.ui.closeWindow({});
        return true;
      });
    }

    return (
      <View style={styles.container}>
        <NavBar title="客户管理" rightElement={this.rightElement()} key="customer" />
        <View style={styles.flexStyle}>
          <View style={styles.flexStyle}>
            <ChooseContent
              customerStore={customerStore}
              onSelect={this.confirmSelect}
              onCommonFocus={() => this.onCommonBlurFocus(false)}
              onCommonBlur={() => this.onCommonBlurFocus(true)}
            />
          </View>
        </View>
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },

  flexStyle: {
    flex: 1,
  },

  headTitle: {
    fontSize: 18,
    color: '#333',
  },
});
