import React from 'react';
import { observer } from 'mobx-react';
import CustomerAddStore from '~/pages/waybill/customer/Store/CustomerAdd';
import CustomerAddPage from '~/pages/waybill/customer/Add';

interface CustomerAddProps {
  customerAddStore: CustomerAddStore;
  navigation: any;
  screenProps: any;
}

@observer
export default class CustomerAdd extends React.Component<CustomerAddProps, any> {
  constructor(props: CustomerAddProps) {
    super(props);
  }
  render() {
    return <CustomerAddPage {...this.props} />;
  }
}
