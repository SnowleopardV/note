import { MBBridge, MBLog } from '@ymm/rn-lib';
import keyMap from './dispatch/keyMap';
import API from './networkProtocol/api';

// 用于解决跨页面之前的数据状态的传递
const commonData: any = {
  /**
   * 满帮找车发货结果 弹窗数据
   * "deductCountTips": "发货成功，本次扣减发货次数",
      "dispatcherId": "965006065497104509",
      "dispatcherPhone": "15001346729",
      "dispatcherName": "架构平台_郭浩宇",
      "successFlag": true,
      "failErrorMsg": null,
      "remainDispatchNumber": 10507
   */
  cargoRespList: [],
  gotoId: { id: null, type: null }, // 用于跳转到 看板页面中 type: task: 任务看板 waybill: 运单看板
  cargoIntervalConfig: {}, // 重量体积区间
};

export default commonData;

/** 判断跳转到网络协议页面 */
export const goNetworkProtocol = ({ mybOrderId, invoiceFlag }: any) => {
  console.log('判断跳转方向');
  API.queryContractUser({ mybOrderId: mybOrderId })
    .then((res: any) => {
      if (res.data) {
        const { status, companyId, cargoUserId } = res.data;
        let page = 'agreeToDeal'; // 查看协议-协议详情
        // status： 1: 待发起 0:待确认,1:已签署,2:已拒绝,3:已取消
        if (status === -1 || status === undefined || status === null) {
          page = 'createAgreement'; // 创建协议
        }
        const params = {
          showPage: page,
          companyId: companyId,
          userId: cargoUserId,
          orderId: mybOrderId,
          invoiceFlag,
        };
        const url = `ymm://rn.tms/networkprotocol?schemeurl=${encodeURIComponent(JSON.stringify(params))}`;
        MBBridge.app.base.openSchema({ url: url });
      }
    })
    .catch((err) => {
      console.log('判断跳转到网络协议页面', err);
    });
};

// 获取平台车型
export const api_getTruckTypePlateList = () => {
  if (Object.keys(keyMap.carTypePlate).length) {
    return Promise.resolve();
  }
  return API.getTruckTypeList({ toPlatform: true, queryType: 1 })
    .then((res: any) => {
      console.log('----------------获取平台车型-------------------');
      if (res.success && res.data) {
        const carType: any = {};
        for (const item of res.data) {
          carType[item.typeId] = item.typeName;
        }
        keyMap.carTypePlate = carType; // 修改 枚举里的值
      }
    })
    .catch((er) => MBLog.error(er));
};

// 获取平台车长
export const api_getTruckLengthPlateList = () => {
  if (Object.keys(keyMap.carLengthPlate).length) {
    return Promise.resolve();
  }
  return API.getTruckLengthList({ toPlatform: true, queryType: 1 })
    .then((res: any) => {
      console.log('----------------获取平台车长-------------------');
      if (res.success && res.data) {
        const carLength: any = {};
        for (const item of res.data) {
          carLength[item.lengthId] = item.lengthName;
        }
        keyMap.carLengthPlate = carLength; // 修改 枚举里的值
      }
    })
    .catch((er) => MBLog.error(er));
};
