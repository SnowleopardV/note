import * as React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { Carousel, MBText, Flex } from '@ymm/rn-elements';
import { MBLog, MBBridge } from '@ymm/rn-lib';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NavBar from '~/components/common/NavBar';
import TouchableThrottle from '~/components/TouchableThrottle';
import server from '~/server/index';
import EmptyPage from '~/components/common/EmptyPage';
import NativeBridge from '~/extends/NativeBridge';

class Home extends React.Component<any> {
  constructor(props: any) {
    super(props);
  }

  state = {
    detailInfo: {
      company: {},
      bannerList: [],
      functionList: [],
    },
    isLoading: false,
    errorData: {},
    showPermissionVisible: false,
    pageTitle: '',
  };

  componentDidMount() {
    this.fetchHomeDetail();
  }

  fetchHomeDetail = async () => {
    try {
      const url = '/saas-permission-app/yzgApp/user/queryHomepageInfo';
      const res = await server({ url, data: {} });
      if (res.success) {
        this.setState({
          pageTitle: res.data?.company?.companyName,
          detailInfo: res.data,
        });
      }
      // 系统鉴权，单独处理
      if (res.code === '710012' || res.code === '710013') {
        this.setState({
          pageTitle: '企业服务',
          errorData: {
            image: 'https://image.ymm56.com/ymmfile/saas-tms-pub/detail.png',
            msg: res.msg,
          },
          showPermissionVisible: true,
        });
      }
    } catch (error) {
      MBLog.log({
        message: '查询首页信息失败',
        error,
      });
    }
  };

  onClickImg = (url: string) => {
    NativeBridge.openWebViewPage(url);
  };

  onClickCategory = (url: string) => {
    // 判断是否是H5页面
    var reg=/(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?/;
    if(reg.test(url)){
      NativeBridge.openWebViewPage(url);
    } else {
      MBBridge.app.base.openSchema({ url });
    }
  };

  render(): JSX.Element {
    const {
      detailInfo: { bannerList, functionList },
      isLoading,
      showPermissionVisible,
      errorData,
      pageTitle,
    } = this.state;

    return (
      <View style={styles.homePage}>
        <NavBar title={pageTitle} />
        {!isLoading ? (
          showPermissionVisible ? (
            <EmptyPage errorData={errorData} />
          ) : (
            <View style={styles.content}>
              {bannerList.length ? (
                <View style={styles.carouselWrapper}>
                  <Carousel
                    index={0}
                    autoplay
                    autoplayTimeout={3}
                    showsPagination={true}
                    dotStyle={styles.dotStyle}
                    activeDotColor="#fff"
                    activeDotStyle={styles.activeDotStyle}
                    paginationStyle={styles.paginationStyle}
                  >
                    {bannerList.map((item, index) => {
                      return (
                        <TouchableThrottle
                          activeOpacity={0.8}
                          onPress={() => {
                            this.onClickImg(item.directUrl);
                          }}
                          key={index}
                        >
                          <Image style={styles.slideImg} source={{ uri: item.picUrl }} />
                        </TouchableThrottle>
                      );
                    })}
                  </Carousel>
                </View>
              ) : null}

              {functionList.length ? (
                <Flex direction="row" wrap="wrap" style={styles.category}>
                  {functionList.map((item, index) => {
                    return (
                      <TouchableThrottle
                        activeOpacity={0.8}
                        onPress={() => {
                          this.onClickCategory(item.protocol);
                        }}
                        key={index}
                      >
                        <View style={styles.categoryItem} key={index}>
                          <View style={styles.iconWrapper}>
                            <Image style={styles.itemIcon} source={{ uri: item.icon }} />
                          </View>
                          <MBText style={styles.textStyle}>{item.name}</MBText>
                        </View>
                      </TouchableThrottle>
                    );
                  })}
                </Flex>
              ) : null}
            </View>
          )
        ) : null}
      </View>
    );
  }
}

const styles = StyleSheet.create<any>({
  homePage: {
    flex: 1,
    backgroundColor: '#F7F7F7',
  },

  content: {
    backgroundColor: '#fff',
    paddingBottom: autoFix(10),
  },

  carouselWrapper: {
    marginTop: autoFix(60),
    height: autoFix(232),
    paddingHorizontal: autoFix(32),
  },

  dotStyle: {
    width: autoFix(12),
    height: autoFix(12),
  },

  activeDotStyle: {
    width: autoFix(12),
    height: autoFix(12),
  },

  paginationStyle: {
    bottom: autoFix(16),
  },

  slideImg: {
    width: '100%',
    height: autoFix(240),
  },

  category: {
    paddingHorizontal: autoFix(40),
    marginRight: autoFix(-40),
    marginTop: autoFix(35),
  },

  categoryItem: {
    width: autoFix(125),
    marginRight: autoFix(40),
    marginTop: autoFix(40),
    alignItems: 'center',
  },

  itemIcon: {
    width: autoFix(125),
    height: autoFix(125),
  },

  textStyle: {
    color: '#333',
    fontSize: autoFix(28),
    marginTop: autoFix(16),
  },
});

export default Home;
