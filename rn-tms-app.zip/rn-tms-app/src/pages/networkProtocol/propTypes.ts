import xyMath from '~/extends/xyMath';

export type CityClickName = 'City' | 'Address';
export interface pageProps {
  navigation?: any;
  screenProps?: any; // 路由地址参数
  store?: any;
}

/** 创建协议(主协议) 入参 */
export interface submitFormProps {
  start?: null | string; // 	始发地id,三级地址
  startAddressLatitude?: null | string; // 起始地纬度
  startAddressLongitude?: null | string; // 起始地经度
  end?: null | string; // 	目的地id,三级地址
  endAddressLatitude?: null | string; // 目的地纬度
  endAddressLongitude?: null | string; // 目的地经度
  loadAddress?: null | string; // 装货地点详细地址
  unloadAddress?: null | string; // 卸货地点详细地址
  orderId?: null | string; // 订单编号
  companyId?: null | string; // 公司ID
  loadTime?: null | string; // 装货时间时间戳
  unloadTime?: null | string; // 卸货截止时间时间戳
  truckTypeList?: null | string; // 车型
  truckLength?: null | string; // 车长，多个用英文逗号分隔，单位：米
  truckWeight?: null | string; // 货物重量，单位：吨
  cargoCapacipy?: null | string; // 货物体积，单位：方
  truckNumber?: null | string; // 车牌号
  prepaidMoney?: null | string; // 预付运费，单位分
  preCashMoney?: null | string; // 预付现金，单位分
  preOilMoney?: null | string; // 预付油卡，单位分
  receiptMoney?: null | string; // 回单付，单位分
  arriveMoney?: null | string; // 到付 单位分
  payMoney?: null | string; // 总运费，单位分  预付+到付+回单付的总运费，不包含服务费
  totalMoney?: null | string; // 总运费，单位分 包含服务费
  settlementUnit?: null | string | number; // 结算单位，  1：趟，2：吨 ； 3：方
  freightUnitPrice?: null | string; // 运费单位，单位分
  payDelayDays?: null | string; // 最晚付款延迟时间
  deposit?: null | string; // 定金金额，单位：分
  note?: null | string; // 补充约定
  cargoUserId?: null | string; // 货主Id
  driverUserId?: null | string; // 司机ID
  serviceChargeRate?: null | string; // 附加服务费率
  serviceFeeRateFeatures?: null | string; // 费率拓展字段
  largeInsuranceInfo?: null | largeInsuranceInfoProps; // 大额保价信息
  hasLargeInsurance?: number; // 是否勾选大额保价保障 0/null:未勾选 1：已勾选
  largeInsuranceCost?: null | string; // 保价费用 单位:元
  minTruckWeight?: number; // 最小重量
  maxTruckWeight?: number; // 最大重量
  minCargoCapacity?: number; // 最小体积
  maxCargoCapacity?: number; // 最大体积
  carLength?: any[]; // [{ id: '15', name: '13.7' }],
  carType?: any[]; // [{ id: '3', name: '厢式' }],
  oilRestrictionRatio?: number; // 油卡比例配置， 小计的30%≥油卡金额≥100
}
export interface largeInsuranceInfoProps {
  largeInsuranceCharge: string; // 大额保单保险费用，单位：元
  rate: string; // 保费费率：0.02%
}
/** 协议详情 */
export interface DetailProps {
  contractID?: null | string; // 合同ID
  contractNo?: null | string; // 合同编号
  createTime?: null | number; // 创建时间
  updateTime?: null | number; // 修改时间
  status?: null | number; // 见证状态
  note?: null | string; // 约定
  orderId?: null | string; // 订单ID
  startPlace?: null | number; // 出发地
  endPlace?: null | number; // 目的地
  truckNumber?: null | string; // 车牌号
  truckLength?: null | string; // 车长
  loadType?: null | string; // 几装几卸
  goodsName?: null | string; // 货物名称
  goodsVolume?: null | string; // 体积
  goodsWeight?: null | string; // 重量

  prepaidMoney?: null | number; //预付运费
  preEtcMoney?: null | number; //预付 ETC
  preOilMoney?: null | number; //预付 油
  preOilServiceCharge?: null | number; //预付油卡服务费
  prepaidServiceCharge?: null | number; //预付运费服务费
  payMoney?: null | number; //支付运费
  totalMoney?: null | number; //总运费
  receiptMoney?: null | number; //回单付运费
  arriveOilMoney?: null | number; //到付 油
  arriveOilServiceCharge?: null | number; //到付 油卡服务费
  arriveOilPayBackMoney?: null | number; //到付油返点金额
  payServiceCharge?: null | number; //到付服务费
  receiveServiceCharge?: null | number; //回单服务费
  serviceChargeRate?: null | number; //无车承运平台服务费率:例6.2%在lion中配置为620000

  loadTime?: null | number; // 装货时间
  unloadTime?: null | number; // 卸货时间
  loadAddress?: null | string; // 装货地址
  unloadAddress?: null | string; // 卸货地址
  startAddressLatitude?: null | number; // 起始地详细地址纬度
  startAddressLongitude?: null | number; // 起始地详细地址经度

  endAddressLatitude?: null | string; // 到达地地详细地址经度
  endAddressLongitude?: null | string; // 到达地详细地址纬度

  activeSupplement?: null | string; // 当前生效的增补协议
  offerSupplement?: null | string; // 当前待确认的增补协议
  supplements?: null | string; // 增补协议历史列表(包含offer，active的)
  allSupplements?: null | []; // 增补协议历史列表
  deposit?: null | number; // 定金

  proposerId?: null | number; // 发起人ID
  proposerName?: null | number; // 发起人姓名
  proposerTelephone?: null | number; // 发起人手机号
  proposerRole?: null | number; // 发起人角色
  proposeTime?: null | number; // 发起时间
  signerId?: null | number; // 签署人ID
  signerName?: null | number; // 签署人姓名
  signerTelephone?: null | number; // 签署人手机号
  signedTime?: null | number; // 签署时间

  oldStatus?: null | string; //
  oldSecondStatus?: null | string; //
  version?: null | string; //
  oldVersion?: null | string; //
  attachments?: null | string; //
  disputeCount?: null | string; //
  startProvinceId?: null | string; //
  startProvinceName?: null | string; //
  startCityId?: null | string; //
  startCityName?: null | string; //
  startDistrictId?: null | string; //
  startDistrictName?: null | string; //
  endProvinceId?: null | string; //
  endProvinceName?: null | string; //
  endCityId?: null | string; //
  endCityName?: null | string; //
  endDistrictId?: null | string; //
  endDistrictName?: null | string; //
  truckType?: null | string; //
  extraOilMoney?: null | string; //
  serviceFeeRateFeatures?: null | string; //
  payBeforeStart?: null | string; //
  payAfterArrival?: null | string; //
  payAfterReceipt?: null | string; //
  prePayMethod?: null | string; //
  arrivalPayDeadline?: null | string; //
  receiptPayDeadline?: null | string; //
  startAddressAccurateFlag?: null | string; //
  endAddressAccurateFlag?: null | string; //
  contractType?: null | string; //
  protocolType?: null | string; //
  protocolMix?: null | string; //
  payDelayDays?: null | string; //
  protocolAuxiliaryId?: null | string; //
  shareTruckTip?: null | string; //
  collectUserId?: null | string; //
  collectUserSource?: null | string; //
  bargainId?: null | string; //
  consumerFlag?: null | string; //
  commission?: null | string; //
  agentFlag?: null | string; //
  secondSignerId?: null | string; //
  secondSignerName?: null | string; //
  secondSignerTelephone?: null | string; //
  secondSignerTime?: null | string; //
  secondStatus?: null | string; //
  mergeStatus?: null | string; //
  taxRate?: null | string; //
  tax?: null | string; //
  autoPayPrepayDays?: null | string; //
  autoPayArrivalDays?: null | string; //
  autoPayReceiptDays?: null | string; //
  closeOrderTime?: null | string; //
  lcl?: null | string; //
  truckTypeList?: null | string; //
  checkLargeInsurance?: null | string; //
  largeInsuranceCost?: null | string; //
  signSubjectName?: null | string; //
  signSubjectId?: null | string; //
  etcAuth?: null | string; //
  lastPayTimeTxt?: null | string; //
  autoUnloadTime?: null | string; //
  collectToShiper?: null | string; //
  settlementUnit?: null | string | number; //
  outTradeNo?: null | string; //
  goodsType?: null | string; //
  cargoNumber?: null | string; //
  technicalServiceDiscountType?: null | string; //
  autoAgreeFlag?: null | string; //
  autoAgreeTime?: null | string; //
  loadTimeStart?: null | string; //
  unloadTimeStart?: null | string; //
  riskLoadTimeBegin?: null | string; //
  riskLoadTimeEnd?: null | string; //
  riskUnloadTimeBegin?: null | string; //
  riskUnloadTimeEnd?: null | string; //
  entrust?: null | string; //
  useOilRole?: null | string; //
  freightUnitPrice?: null | string; //
  newOilOrder?: null | string; //
  oilPayBackCoefficient?: null | string; //
  optimisticLock?: null | string; //
  oilRestrictionRatio?: null | string; //
  driverUserId?: null | string; //
  driverName?: null | string; //
  vehicleLicenseUrl?: null | string; //
  cargoUserId?: null | string; //
  activeReceiptMoney?: null | string; //
  activeServiceCharge?: null | string; //
  activePayMoney?: null | string; //
  activeReceiveServiceCharge?: null | string; //
  activeTotalMoney?: null | string; //
  activeArrivedServiceCharge?: null | string; //
  activeArrivedCashMoney?: null | string; //
  activeReceiptCashMoney?: null | string; //
  activeReceiptAdvanceOilMoney?: null | string; //
  activeCommission?: null | string; //
  activePrepaidMoney?: null | string; //
  activePrepaidOilMoney?: null | string; //
  activeArrivedOilMoney?: null | string; //
  activeServiceChargeRate?: null | string; //
  activeUseOilRole?: null | string; //
  activePrepaidServiceCharge?: null | string; //
  activePrepaidETCMoney?: null | string; //
  truckTypeName?: null | string; // 车型显示值
  truckLengthDesc?: null | string; // 车长显示值
  feeItemNewList?: any;
}

/** 平台订单状态 */
export const orderStatusMap = {
  TRANSPORING: '运输中',
  LOADED: '已确认装货',
  ARRIVED: '已确认收货',
  RECEIPTED: '已确认回单',
  COMPLETED: '已完成',
  CANCELED: '已取消',
  DEALED: '已成交',
};
/**
 * @param TRANSPORING : '运输中',
 * @param LOADED: '已确认装货',
 * @param ARRIVED: '已确认收货',
 * @param RECEIPTED: '已确认回单',
 * @param COMPLETED: '已完成',
 * @param CANCELED: '已取消',
 * @param DEALED: '已成交',
 */
export declare type orderStatusEnum = 'TRANSPORING' | 'LOADED' | 'ARRIVED' | 'RECEIPTED' | 'COMPLETED' | 'CANCELED' | 'DEALED';

export const UnitMap = {
  1: '趟',
  2: '吨',
  3: '方',
};
export const KeyUnitMap = {
  1: 'freightUnitPrice', // 趟
  2: 'truckWeight', // 吨
  3: 'cargoCapacipy', // 体积
};
/** 发起人角色 */
export const proposerRoleMap = {
  1: 'DRIVER', // 司机
  2: 'SHIPPER', // 货主
};

/** 金额值提交的时候要从 元 转换成 分 */
export const moneyDataMap = {
  prepaidMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 预付运费，单位分
  preCashMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 预付现金，单位分
  preOilMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 预付油卡，单位分
  receiptMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 回单付，单位分
  arriveMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 到付 单位分
  payMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 总运费，单位分  预付+到付+回单付的总运费，不包含服务费
  totalMoney: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 总运费，单位分 包含服务费
  freightUnitPrice: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 运费单位，单位分
  largeInsuranceCost: (val: string | number, type: 'accDiv' | 'accMul') => xyMath[type](val, 100), // 运费单位，单位分
};
