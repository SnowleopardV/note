import * as React from 'react';
import { View, StyleSheet, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Modal, Whitespace, TagGroup, Tag, MBText, Flex } from '@ymm/rn-elements';
import NativeBridge from '~/extends/NativeBridge';
import keyMap from '~/pages/dispatch/keyMap';

const FlexItem = Flex.Item;
const { height } = Dimensions.get('window');
// 选择车型和车长 模态框
const styles = StyleSheet.create({
  from: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  modalheight: {
    maxHeight: Number((height * 0.9).toFixed(0)),
  },
});

interface FollowCarProps {
  visible?: boolean;
  onChange?: any;
  item?: any;
}

export default class ModalCarTypeLength extends React.Component<FollowCarProps, any> {
  constructor(props: FollowCarProps) {
    super(props);
    const carTypeList = Object.keys(keyMap.carTypePlate).map((key: string) => {
      return { id: key, name: keyMap.carTypePlate[key] };
    });
    const carLengthList = Object.keys(keyMap.carLengthPlate).map((key: string) => {
      return { id: key, name: keyMap.carLengthPlate[key].toString() };
    });
    this.state = {
      carTypeList: carTypeList,
      carLengthList: carLengthList,
      carLengthSelected: this.props?.item?.platformCarLength || [],
      carTypeSelected: this.props?.item?.platformCarType || [],
    };
  }

  handleConfirm = () => {
    const { onChange } = this.props;
    const { carTypeList, carLengthList, carLengthSelected, carTypeSelected } = this.state;
    if (carLengthSelected.length == 1 && carTypeSelected.length == 0) {
      NativeBridge.toast(`请选择车型`);
    } else if (carLengthSelected.length == 0 && carTypeSelected.length == 1) {
      NativeBridge.toast(`请选择车长`);
    } else if (onChange) {
      onChange({
        carLength: carLengthList.filter((item: any) => carLengthSelected.includes(item.id)),
        carType: carTypeList.filter((item: any) => carTypeSelected.includes(item.id)),
      });
    }
  };
  handleCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  // 改变车长选择
  onLengthClick = (val: any) => {
    let { carLengthSelected } = this.state;
    if (carLengthSelected.includes(val.id)) {
      carLengthSelected = carLengthSelected.filter((id: number) => id !== val.id);
      this.setState({ carLengthSelected: carLengthSelected });
    } else if (carLengthSelected.length < 1) {
      carLengthSelected.push(val.id);
      this.setState({ carLengthSelected: carLengthSelected });
    } else {
      NativeBridge.toast(`最多选择1种车长`);
    }
  };
  // 改变车型选择
  onTypeClick = (val: any) => {
    let { carTypeSelected } = this.state;
    if (carTypeSelected.includes(val.id)) {
      carTypeSelected = carTypeSelected.filter((id: number) => id !== val.id);
      this.setState({ carTypeSelected: carTypeSelected });
    } else if (carTypeSelected.length < 1) {
      carTypeSelected.push(val.id);
      this.setState({ carTypeSelected: carTypeSelected });
    } else {
      NativeBridge.toast(`最多选择1种车型`);
    }
  };
  rightElement() {
    return (
      <TouchableOpacity onPress={() => this.handleConfirm()}>
        <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'flex-end' }}>
          <MBText size="md" color="primary">
            确定
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const { visible } = this.props;
    const { carTypeList, carLengthList, carLengthSelected, carTypeSelected } = this.state;
    console.log('this.props?.item?.platformCarType', carLengthSelected);
    console.log('carLengthList', carLengthList);

    return (
      <Modal
        headerLeft="取消"
        headerLine={false}
        headerRight={this.rightElement()}
        title="请选择车长/车型"
        position="bottom"
        visible={visible}
        onConfirm={this.handleConfirm}
        onCancel={this.handleCancel}
        onMaskClose={this.handleCancel}
        onRequestClose={this.handleCancel}
      >
        <ScrollView style={styles.modalheight}>
          <Flex direction="row" justify="space-between" align="center">
            <FlexItem style={styles.flexRow}>
              <MBText>车长</MBText>
              <MBText color="#999999">（非必选，最多1项）</MBText>
            </FlexItem>
          </Flex>
          <Flex direction="row" justify="space-between" align="center">
            <TagGroup
              defaultSelected={carLengthSelected}
              rowId="id"
              space={12}
              rowSize={4}
              multiple={true}
              maxNumber={1}
              onPress={this.onLengthClick}
            >
              {carLengthList.map((item: any) => {
                return (
                  <Tag key={item.id} item={item}>
                    {item.name}
                  </Tag>
                );
              })}
            </TagGroup>
          </Flex>
          <Whitespace vertical={20} />
          <Flex direction="row" justify="space-between" align="center">
            <FlexItem style={styles.flexRow}>
              <MBText>车型</MBText>
              <MBText color="#999999">（非必选，最多1项）</MBText>
            </FlexItem>
          </Flex>
          <Flex direction="row" justify="space-between" align="center">
            <TagGroup
              defaultSelected={carTypeSelected}
              rowId="id"
              space={12}
              rowSize={4}
              multiple={true}
              maxNumber={1}
              onPress={this.onTypeClick}
            >
              {carTypeList.map((item: any) => {
                return (
                  <Tag key={item.id} item={item}>
                    {item.name}
                  </Tag>
                );
              })}
            </TagGroup>
          </Flex>
          <Whitespace vertical={50} />
        </ScrollView>
      </Modal>
    );
  }
}
