import * as React from 'react';
import { View } from 'react-native';
import { Flex, Modal, MBText, Whitespace, Selector } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';

interface Props {
  visible?: boolean;
  onChange?: any;
  store?: any;
  default: number;
}
@inject('store')
@observer
export default class ModalSettlementMethod extends React.Component<Props, any> {
  constructor(props: Props) {
    super(props);
    this.state = {
      index: 1,
    };
  }
  componentDidMount() {
    this.setState({ index: this.props.default || 1 });
  }
  handleUnitConfirm = () => {
    const { onChange } = this.props;
    onChange && onChange(this.state.index);
  };
  handleUnitCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleUnitChange = (index: number) => {
    this.setState({ index: index + 1 });
  };
  get unitList() {
    const list = ['按趟结算', '按吨结算', '按方结算'];
    return list.map((item: string, index: number) => {
      return {
        id: index,
        content(selected: boolean) {
          return (
            <Flex direction="row" justify="center" align="center">
              <MBText bold={selected} size={selected ? 'md' : 'sm'} color={selected ? 'primary' : 'base'} numberOfLines={1}>
                {item}
              </MBText>
            </Flex>
          );
        },
      };
    });
  }
  render() {
    const { visible } = this.props;
    const { index } = this.state;
    return (
      <View>
        <Modal
          headerRight="确定"
          headerLeft="取消"
          title="请选择结算方式"
          position="bottom"
          visible={visible}
          headerLine={false}
          onConfirm={this.handleUnitConfirm}
          onCancel={this.handleUnitCancel}
          onMaskClose={this.handleUnitCancel}
          onRequestClose={this.handleUnitCancel}
        >
          <Flex direction="row" justify="center" align="center">
            <Flex.Item key="time">
              <View style={{ flexDirection: 'column' }}>
                <Selector
                  type={2}
                  value={index - 1}
                  rowTitle="content"
                  list={this.unitList}
                  scaleFont={true}
                  onChange={this.handleUnitChange}
                />
              </View>
            </Flex.Item>
          </Flex>
          <Whitespace vertical={20} />
        </Modal>
      </View>
    );
  }
}
