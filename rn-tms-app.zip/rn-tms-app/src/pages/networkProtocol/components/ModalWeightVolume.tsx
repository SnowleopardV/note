import * as React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { Modal, MBText, Whitespace, Splitline } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import InputItem from '~/components/common/InputItem';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import RegTest from '~/utils/RegTest';
import { MBBridge } from '@ymm/rn-lib';

interface Props {
  visible?: boolean;
  onChange?: any;
  store?: any;
  defaultData?: any;
}
const valKeys = {
  1: 'weight',
  2: 'volume',
};
@inject('store')
@observer
export default class ModalWeightVolume extends React.Component<Props, any> {
  name = '体积和重量';
  refInput: any;
  constructor(props: Props) {
    super(props);
    const { weight, volume } = this.props.defaultData;
    this.state = {
      index: 1,
      weight: { min: weight.min || '', max: weight.max || '' },
      volume: { min: volume.min || '', max: volume.max || '' },
      showTips: false,
    };
  }
  componentDidMount() {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: false });
    }
  }
  componentWillUnmount() {
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }
  handleUnitConfirm = () => {
    const { onChange } = this.props;
    const { weight, volume } = this.state;
    if (Number(weight.min) <= Number(weight.max) && Number(volume.min) <= Number(volume.max)) {
      onChange && onChange({ weight, volume });
    }
  };
  handleUnitCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleUnitChange = (index: number) => {
    this.setState({ index: index + 1 });
  };
  changeText = (val: any, index: number, type: string) => {
    this.setState({ showTips: true });
    if ((val <= 1000 && RegTest.numPrecision(val, 3)) || val === '') {
      if (index == 1) {
        this.state.weight[type] = val;
        this.setState({ weight: this.state.weight });
      } else {
        this.state.volume[type] = val;
        this.setState({ volume: this.state.volume });
      }
    }
  };
  itemRowElement(title: string, index: number, valueMin: string, value: string, placeholder: string): JSX.Element {
    const { settlementUnit } = this.props.store.submitForm;
    return (
      <View style={styles.itemRow}>
        <MBText>{title}</MBText>
        <View style={styles.valueBox}>
          {settlementUnit == 1 && (
            <>
              <InputItem
                textAlign="center"
                style={{ flex: 1, maxWidth: autoFix(300) }}
                inputStyle={{ textAlign: 'center' }}
                value={valueMin || ''}
                styleItem={{ paddingRight: 0 }}
                onChangeText={(text: string) => this.changeText(text, index, 'min')}
                placeholder={placeholder}
                keyboardType="numeric"
                blurOnSubmit={false}
                onBlur={() => {
                  this.state[valKeys[index]].min = valueMin ? String(Number(valueMin)) : null;
                  this.props.store.setSubmitForm({ [valKeys[index]]: this.state[valKeys[index]] });
                }}
              />
              <MBText style={{ marginTop: autoFix(10) }}>至</MBText>
            </>
          )}
          <InputItem
            ref={(el) => (this.refInput = this.refInput ? this.refInput : el)}
            textAlign="center"
            style={{ flex: 1, maxWidth: autoFix(300) }}
            inputStyle={{ textAlign: settlementUnit == 1 ? 'center' : 'right' }}
            styleItem={{ paddingRight: 0 }}
            value={value || ''}
            onChangeText={(text: string) => this.changeText(text, index, 'max')}
            placeholder={placeholder}
            keyboardType="numeric"
            blurOnSubmit={false}
            onBlur={() => {
              this.state[valKeys[index]].max = value ? String(Number(value)) : null;
              this.props.store.setSubmitForm({ [valKeys[index]]: this.state[valKeys[index]] });
            }}
          />
        </View>
      </View>
    );
  }
  extraElement(text: string): React.ReactNode {
    return (
      <View style={{ paddingRight: autoFix(28) }}>
        <MBText size="xs" color="#F54242" align="right">
          {text}
        </MBText>
        <Whitespace vertical={12} />
      </View>
    );
  }
  get weightLimitTip() {
    const { weight } = this.state;
    if (weight.min > 1000 || weight.max > 1000) {
      return '重量不能大于1000';
    } else if (Number(weight.min) > Number(weight.max)) {
      return '最小重量不能大于最大重量';
    } else {
      return null;
    }
  }
  get volumeLimitTip() {
    const { volume } = this.state;
    if (volume.min > 1000 || volume.max > 1000) {
      return '体积不能大于1000';
    } else if (volume.min > volume.max) {
      return '最小重量不能大于最大重量';
    } else {
      return null;
    }
  }
  render() {
    const { visible } = this.props;
    const { weight, volume, showTips } = this.state;
    return (
      <View>
        <Modal
          headerRight="确定"
          headerLeft="取消"
          title="请输入重量/体积"
          position="bottom"
          visible={visible}
          headerLine={false}
          autoAdjustPosition={true}
          onConfirm={this.handleUnitConfirm}
          onCancel={this.handleUnitCancel}
          onMaskClose={this.handleUnitCancel}
          onRequestClose={this.handleUnitCancel}
          contentStyle={{ paddingHorizontal: 0 }}
        >
          <View style={{ width: '100%' }}>
            {this.itemRowElement('重量(吨)', 1, weight['min'], weight['max'], '0-1000')}
            {this.weightLimitTip && this.extraElement(this.weightLimitTip)}
            <View style={{ paddingLeft: autoFix(28) }}>
              <Splitline dashWidth={1} />
            </View>
            {this.itemRowElement('体积(方)', 2, volume['min'], volume['max'], '0-1000')}
            {this.volumeLimitTip && this.extraElement(this.volumeLimitTip)}
            {showTips &&
              !Number(weight.min) &&
              !Number(weight.max) &&
              !Number(volume.min) &&
              !Number(volume.max) &&
              this.extraElement('重量体积不能同时为空')}
            <Whitespace vertical={50} />
          </View>
        </Modal>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: autoFix(28),
  },
  valueBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
});
