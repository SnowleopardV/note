import React from 'react';
import { Platform, View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import InputItem from '~/components/common/InputItem';

type Props = pageProps;

@inject('store')
@observer
export default class PayTime extends React.Component<Props, any> {
  backHandleListener: any = null;

  constructor(props: any) {
    super(props);
  }

  /**
   * 只能输入1-30的整数
   */
  setPayDelayDays = (value: any) => {
    let newVal = value ? Number(value) : 0;
    if (newVal > 30) {
      newVal = Number(String(newVal).slice(0, 2));
    } else if (newVal < 1) {
      newVal = 0;
    }
    this.props.store.setSubmitForm({
      payDelayDays: newVal < 1 ? null : String(newVal).split('.')[0],
    });
  };

  render() {
    const submitForm = this.props.store.submitForm;
    const { payDelayDays } = submitForm;
    return (
      <View style={{ marginTop: autoFix(20) }}>
        <CellGroup withBottomLine style={{ borderRadius: autoFix(5), paddingBottom: autoFix(14) }}>
          <MBText style={{ marginTop: autoFix(28), marginLeft: autoFix(28) }} color="#999999" size="xs">
            付款时间
          </MBText>
          <InputItem
            title="最晚卸货后"
            textAlign="right"
            value={payDelayDays}
            placeholder="请输入1-30"
            keyboardType="numeric"
            blurOnSubmit={false}
            onChangeText={this.setPayDelayDays}
            onFocus={() => this.props.store.setShowFootBtn(false)}
            onBlur={() => {
              this.props.store.setShowFootBtn(true);
              this.props.store.setSubmitForm({
                payDelayDays: submitForm['payDelayDays'] ? String(Number(submitForm['payDelayDays'])) : null,
              });
            }}
            inputStyle={{ paddingBottom: Platform.OS == 'ios' ? autoFix(8) : 0 }}
            extraNode={<MBText style={{ marginLeft: autoFix(10) }}>天付款</MBText>}
          />
        </CellGroup>
      </View>
    );
  }
}
