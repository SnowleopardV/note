import React from 'react';
import { inject, observer } from 'mobx-react';
import { MBText } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import NativeBridge from '~/extends/NativeBridge';

type Props = pageProps;

@inject('store')
@observer
export default class Agreement extends React.Component<Props, any> {
  constructor(props: any) {
    super(props);
  }

  render() {
    const invoiceFlagIsGeneralTicket = this.props.store.invoiceFlagIsGeneralTicket;
    return (
      <MBText style={{ paddingRight: 30 }}>
        <MBText color="#666666" size="sm">
          我已经阅读并同意
        </MBText>
        {invoiceFlagIsGeneralTicket ? (
          <>
            <MBText
              size="sm"
              color="primary"
              onPress={() => {
                NativeBridge.openWebViewPage(
                  'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2137&categoryId=324'
                );
              }}
            >
              《货物运输技术服务协议》
            </MBText>
            <MBText
              size="sm"
              color="primary"
              onPress={() => {
                NativeBridge.openWebViewPage(
                  'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=2138&categoryId=324'
                );
              }}
            >
              《货物运输协议》
            </MBText>
          </>
        ) : (
          <MBText size="sm" color="primary" onPress={() => this.props.store.goAgreement()}>
            《货物运输交易协议》
          </MBText>
        )}
      </MBText>
    );
  }
}
