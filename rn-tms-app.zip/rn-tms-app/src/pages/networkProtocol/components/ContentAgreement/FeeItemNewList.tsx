import React from 'react';
import { TouchableOpacity, Image, View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText, Modal } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Cell from '~/components/common/Cell';
import xyMath from '~/extends/xyMath';
import images from '~public/static/images';
import styles from '../../styles';

interface Props extends pageProps {
  type: 'create' | 'edit' | 'detail';
}
@inject('store')
@observer
export default class TransFee extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      otherFeeTipsVisible: false, // 其他费用提示语展示
      curTipsInfo: {
        feeName: '',
        descriptionDocument: '',
      },
    };
  }
  otherFeeElementTip = () => {
    const { feeName, descriptionDocument } = this.state.curTipsInfo;
    return (
      <Modal
        autoAdjustPosition
        headerRight="关闭"
        title={feeName}
        position="bottom"
        visible={this.state.otherFeeTipsVisible}
        onMaskClose={() => {
          this.setState({ otherFeeTipsVisible: false });
        }}
        onConfirm={() => {
          this.setState({ otherFeeTipsVisible: false });
        }}
      >
        <MBText style={{ paddingTop: autoFix(20), paddingBottom: autoFix(100), lineHeight: autoFix(45), minHeight: autoFix(450) }}>
          {descriptionDocument}
        </MBText>
      </Modal>
    );
  };
  otherFeeElement = (feeItemNewList: any) => {
    const renderLeftTip = (item: any) => {
      return (
        <TouchableOpacity
          onPress={() =>
            this.setState({
              curTipsInfo: {
                feeName: item.feeName,
                descriptionDocument: item.descriptionDocument,
              },
              otherFeeTipsVisible: true,
            })
          }
        >
          <Image source={images.icon_warning} style={{ height: 15, width: 15 }} />
        </TouchableOpacity>
      );
    };
    return feeItemNewList.map((item: any) => {
      if (this.props.type === 'detail') {
        return (
          <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(20), paddingHorizontal: autoFix(20) }]}>
            <MBText>{item.feeName}</MBText>
            <MBText>￥{xyMath.accDiv(item.amount, 100).toFixed(2)}</MBText>
          </View>
        );
      } else {
        return (
          <Cell
            name={item.feeCode}
            bottomLine
            title={item.feeName}
            value={xyMath.accDiv(item.amount, 100).toFixed(2)}
            align="right"
            rightElement={<MBText>元</MBText>}
            tag={renderLeftTip(item)}
          />
        );
      }
    });
  };
  render() {
    const { otherFeeTipsVisible } = this.state;
    const invoiceFlagIsGeneralTicket = this.props.store.invoiceFlagIsGeneralTicket;
    let feeItemNewList = [];
    if (this.props.type === 'detail') {
      feeItemNewList = this.props.store.serviceFeeDetailData.feeItemNewList ?? [];
    } else {
      feeItemNewList = this.props.store.serviceFeeData.feeItemNewList ?? [];
    }
    /** 只有普票展示 */
    if (!invoiceFlagIsGeneralTicket) return null;

    return (
      <>
        {feeItemNewList && feeItemNewList.length ? this.otherFeeElement(feeItemNewList) : null}
        {otherFeeTipsVisible ? this.otherFeeElementTip() : null}
      </>
    );
  }
}
