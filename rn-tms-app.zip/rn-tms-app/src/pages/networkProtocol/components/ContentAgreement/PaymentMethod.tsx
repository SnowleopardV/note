import React from 'react';
import { View, StyleSheet, Platform, BackHandler } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import InputItem from '~/components/common/InputItem';
import validator from '~/extends/verification';
interface Props extends pageProps {
  type: 'create' | 'edit';
}
@inject('store')
@observer
export default class PaymentMethod extends React.Component<Props, any> {
  backHandleListener: any = null;
  refInput: any[];
  timerFocusBlus: NodeJS.Timeout | null;
  constructor(props: any) {
    super(props);
    this.refInput = [];
    this.state = {
      showModal: false,
      showTips: true,
      inputList: [
        { label: '现金', key: 'preCashMoney' },
        { label: '油卡', key: 'preOilMoney' },
        { label: '到付', key: 'arriveMoney', readonly: true },
        { label: '回单', key: 'receiptMoney' },
      ],
    };
  }
  changeText = (val: string, index: number) => {
    if (validator.price(val) || val == '') {
      const { inputList } = this.state;
      const data = { [inputList[index].key]: val };
      this.props.store?.setSubmitForm(data);
      this.props.store.computeSubtotal(); // 计算小计 和 到付
      this.props.store.computePrepaidMoney(); // 计算 预付运费
    }
  };
  setRefInput(el: any, index: number) {
    this.refInput[index] = el;
  }
  onFocus(index: number) {
    this.props.store.setShowFootBtn(false);
    if (this.timerFocusBlus) {
      clearTimeout(this.timerFocusBlus);
    }
    this.timerFocusBlus = setTimeout(() => {
      this.setState({ showTips: false });
    }, 500);
  }
  onBlur(index: number) {
    this.props.store.setShowFootBtn(true);
    if (this.timerFocusBlus) {
      clearTimeout(this.timerFocusBlus);
    }
    this.timerFocusBlus = setTimeout(() => {
      this.setState({ showTips: true });
    }, 500);
  }
  onSubmitEditing(index: number) {
    if (Platform.OS == 'ios') {
      this.refInput[index]?.blur();
    } else {
      this.refInput[index + 1]?.focus() || this.refInput[index + 2]?.focus() || this.refInput[index]?.blur();
    }
  }
  tipsElement(key: string) {
    const { submitForm } = this.props.store;
    const { payMoney, oilRestrictionRatio } = submitForm;
    const { showTips } = this.state;
    if (showTips) {
      // 小计的30%≥油卡金额≥100，30%读配置。油卡金额填写后，文本框失去焦点后实时校验，不在区间内时，提示：油卡金额必须大于等于100且不超过小计的30%。
      const maxVal = (payMoney * oilRestrictionRatio) / 100 || 0;
      if (key == 'preOilMoney' && submitForm[key] > 0) {
        if ((maxVal > 100 && submitForm[key] > maxVal) || submitForm[key] < 100) {
          return (
            <MBText style={{ textAlign: 'right', paddingRight: autoFix(20) }} color="#FF6969" size="xs">
              油卡金额必须大于等于100且不超过小计的{oilRestrictionRatio}%
            </MBText>
          );
        } else {
          return null;
        }
      }
    } else {
      return null;
    }
  }
  render() {
    const { inputList } = this.state;
    const { submitForm } = this.props.store;
    return (
      <View style={{ marginTop: autoFix(20) }}>
        <CellGroup withBottomLine style={{ borderRadius: autoFix(5), paddingBottom: autoFix(14) }}>
          <MBText style={{ marginTop: autoFix(28), marginLeft: autoFix(28) }} color="#999999" size="xs">
            付款方式
          </MBText>
          {inputList.map((item: any, index: number) => {
            return (
              <InputItem
                readonly={item.readonly}
                ref={(el) => this.setRefInput(el, index)}
                title={item.label}
                textAlign="right"
                value={submitForm[item.key]}
                onChangeText={(text: string) => this.changeText(text, index)}
                onSubmitEditing={() => this.onSubmitEditing(index)}
                placeholder="请输入"
                keyboardType="numeric"
                blurOnSubmit={false}
                onFocus={() => this.onFocus(index)}
                onBlur={() => {
                  this.onBlur(index);
                  this.props.store.setSubmitForm({
                    [inputList[index].key]: submitForm[item.key] ? String(Number(submitForm[item.key])) : null,
                  });
                }}
                returnKeyType={index === 3 || Platform.OS == 'ios' ? 'done' : 'next'}
                inputStyle={{ paddingBottom: !item.readonly ? (Platform.OS == 'ios' ? autoFix(8) : 0) : 0 }}
                extraNode={
                  <MBText color={item.readonly ? 'disabled' : ''} style={{ marginLeft: autoFix(10) }}>
                    元
                  </MBText>
                }
                extra={this.tipsElement(item.key)}
              />
            );
          })}
        </CellGroup>
      </View>
    );
  }
}
