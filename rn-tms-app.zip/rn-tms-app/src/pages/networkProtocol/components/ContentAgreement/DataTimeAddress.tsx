import React from 'react';
import { Image, StyleProp, TouchableOpacity, View, ViewStyle } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText, Whitespace } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Cell from '~/components/common/Cell';
import styles from '../../styles';
import images from '~public/static/images';
import dayjs from 'dayjs';
import { stringTime } from '~/extends/threeTimeformat';
import TimePickerModal from '~/components/common/MBDatetimePicker/TimePickerModal';
import NativeBridge from '~/extends/NativeBridge';
interface Props extends pageProps {
  isDetail?: boolean;
  boxStyle?: StyleProp<ViewStyle>;
  type?: 'create' | 'edit';
}
@inject('store')
@observer
export default class DataTimeAddress extends React.Component<Props, any> {
  static defaultProps = {
    isDetail: false,
  };
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      layoutAddressHeight: 0,
      showTimeModal: 0, // 1 装货 2 卸货
    };
  }
  goCityPages = (type: number) => {
    const { isDetail } = this.props;
    if (isDetail) {
      return;
    }
    console.log('--------------选择城市------------------', this.props);
    const {
      loadAddress, // 装货地址
      unloadAddress, // 卸货地址
      startAddressLatitude, // 起始地纬度
      startAddressLongitude, // 起始地经度
      endAddressLatitude, // 目的地纬度
      endAddressLongitude, // 目的地经度
      startPlace, // 出发地三级地址code
      startProvinceId, // 省编码
      startProvinceName, // 省名称
      startCityId, // 城市编码
      startCityName, // 城市名称
      startDistrictId, // 区县编码
      startDistrictName, // 区县名称
      endPlace, // 目的地三级地址code
      endProvinceId, // 省编码
      endProvinceName, // 省名称
      endCityId, // 城市编码
      endCityName, // 城市名称
      endDistrictId, // 区县编码
      endDistrictName, // 区县名称
    } = this.props.store.submitForm;
    this.props.navigation?.navigate('selectAddress', {
      title: type === 1 ? '装货地址' : '卸货地址',
      readonlyCity: this.props.type === 'edit',
      data: {
        districtCode: type === 1 ? startDistrictId : endDistrictId, // 区code
        districtName: type === 1 ? startDistrictName : endDistrictName, // 区名称
        provinceCode: type === 1 ? startProvinceId : endProvinceId, // 省code
        provinceName: type === 1 ? startProvinceName : endProvinceName, // 省名称
        cityCode: type === 1 ? startCityId : endCityId, // 市code
        cityName: type === 1 ? startCityName : endCityName, // 市名称
        address: type === 1 ? loadAddress : unloadAddress, // 地址
        addressLongitude: type === 1 ? startAddressLongitude : endAddressLongitude, // 纬度
        addressLatitude: type === 1 ? startAddressLatitude : endAddressLatitude, // 经度
      },
      onSuccess: (val: any) => {
        console.log('---------------地址-------------------', val);
        if (type === 1) {
          this.props.store.setSubmitForm({
            startProvinceId: val.provinceCode, // 省编码
            startProvinceName: val.provinceName, // 省名称
            startCityId: val.cityCode, // 城市编码
            startCityName: val.cityName, // 城市名称
            startDistrictId: val.districtCode, // 区县编码
            startDistrictName: val.districtName, // 区县名称
            startAddressLongitude: val.addressLongitude,
            startAddressLatitude: val.addressLatitude,
            loadAddress: val.address,
            start: val.districtCode,
            loads: {
              cityName: val.cityName,
              provinceName: val.provinceName,
              districtName: val.districtName,
              provinceCode: val.provinceCode,
              cityCode: val.cityCode,
              districtCode: val.districtCode,
              fullName: val.address,
            },
          });
          console.log('------------setSubmitForm---------------------');
        } else {
          this.props.store.setSubmitForm({
            endProvinceId: val.provinceCode, // 省编码
            endProvinceName: val.provinceName, // 省名称
            endCityId: val.cityCode, // 城市编码
            endCityName: val.cityName, // 城市名称
            endDistrictId: val.districtCode, // 区县编码
            endDistrictName: val.districtName, // 区县名称
            endAddressLongitude: val.addressLongitude,
            endAddressLatitude: val.addressLatitude,
            unloadAddress: val.address,
            end: val.districtCode,
            unloads: {
              cityName: val.cityName,
              provinceName: val.provinceName,
              districtName: val.districtName,
              provinceCode: val.provinceCode,
              cityCode: val.cityCode,
              districtCode: val.districtCode,
              fullName: val.address,
            },
          });
        }
      },
    });
  };
  openTimeModal(val: number) {
    const { isDetail } = this.props;
    // 详情里用这个组件不打开弹窗
    this.setState({ showTimeModal: isDetail ? 0 : val });
  }
  changeDateTime(val: any, type: number) {
    this.setState({ showTimeModal: 0 });
    console.log('-----------------时间---------------------', val);
    if (type === 1) {
      const data = {
        loadTimeObj: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
        loadTime: val.endTimestamp,
      };
      this.props.store.setSubmitForm(data);
    } else if (type === 2) {
      const data = {
        unloadTimeObj: {
          // 预计装货时间
          startTimestamp: val.startTimestamp,
          endTimestamp: val.endTimestamp,
          dateCode: val.dateCode,
          timeInterval: val.timeInterval,
          hourPeriod: val.hourPeriod,
          displayValue: val.displayValue,
        },
        unloadTime: val.endTimestamp,
      };
      this.props.store.setSubmitForm(data);
    }
    const { loadTime, unloadTime } = this.props.store.submitForm;
    if (loadTime && unloadTime && loadTime >= unloadTime) {
      NativeBridge.toast('卸货时间不能小于装货时间');
      return;
    }
  }
  /**
   *
   * @param tape 1装 0卸
   * @returns
   */
  addressTitleElement(type: number) {
    const { isDetail } = this.props;
    const { detailData, submitForm } = this.props.store;
    const loadUnload = {
      0: () => {
        const address = isDetail ? detailData : submitForm;
        if (address?.unloads?.cityName || address?.unloads?.provinceName || address?.unloads?.districtName) {
          return `${address?.unloads.provinceName || '-'}/${address?.unloads.cityName || '-'}${
            address?.unloads?.districtName ? '/' + address?.unloads?.districtName : ''
          }`;
        } else {
          return '-';
        }
      },
      1: () => {
        const address = isDetail ? detailData : submitForm;
        if (address?.loads?.cityName || address?.loads?.provinceName || address?.loads?.districtName) {
          return `${address?.loads?.provinceName || '-'}/${address?.loads?.cityName || '-'}${
            address?.loads?.districtName ? '/' + address?.loads?.districtName : ''
          }`;
        } else {
          return '-';
        }
      },
    };
    return (
      <View style={styles.flexRow}>
        {type === 1 ? (
          <Image style={{ width: autoFix(42), height: autoFix(42) }} source={{ uri: images.icon_shipper }}></Image>
        ) : (
          <Image style={{ width: autoFix(42), height: autoFix(42) }} source={{ uri: images.icon_consignee }}></Image>
        )}
        <MBText style={{ paddingLeft: autoFix(34) }}>{loadUnload[type]()}</MBText>
      </View>
    );
  }
  addressDetailElement(val?: string) {
    return (
      <MBText color="#666666" size="xs" style={{ marginLeft: autoFix(75) }}>
        {val || '-'}
      </MBText>
    );
  }
  onLayoutAddress = (val: any) => {
    this.setState({ layoutAddressHeight: val?.nativeEvent?.layout?.height ?? 0 });
  };
  timeTipsElement() {
    const { isDetail } = this.props;
    const { submitForm } = this.props.store;
    const loadDateTime = submitForm?.loadTime;
    const unloadDateTime = submitForm?.unloadTime;
    if (!isDetail && loadDateTime >= unloadDateTime) {
      return (
        <View style={{ backgroundColor: '#ffffff', paddingHorizontal: autoFix(28), marginHorizontal: autoFix(17) }}>
          <MBText color="#FF6969" size="xs">
            卸货时间必须晚于装货时间
          </MBText>
        </View>
      );
    } else {
      return null;
    }
  }
  render() {
    const { boxStyle, isDetail } = this.props;
    const { detailData, submitForm } = this.props.store;
    const { layoutAddressHeight, showTimeModal } = this.state;
    const lineHeight = layoutAddressHeight / 2 - 36;
    const loadAddress = isDetail ? detailData.loadAddress : submitForm?.loadAddress;
    const unloadAddress = isDetail ? detailData.unloadAddress : submitForm?.unloadAddress;
    const loadDateTime = isDetail ? detailData.loadTime : submitForm?.loadTime;
    const unloadDateTime = isDetail ? detailData.unloadTime : submitForm?.unloadTime;
    const loadDate = loadDateTime ? dayjs(loadDateTime).format('MM月DD日') : '--月--日';
    const unloadDate = unloadDateTime ? dayjs(unloadDateTime).format('MM月DD日') : '--月--日';
    const loadTime = loadDateTime ? stringTime(loadDateTime) + '前' : null;
    const unloadTime = unloadDateTime ? stringTime(unloadDateTime) + '前' : null;
    return (
      <View style={[{ marginTop: autoFix(20) }, boxStyle]}>
        <View style={[styles.cellGroupBox, styles.flexRow, { borderBottomEndRadius: 0, borderBottomStartRadius: 0, flex: 1 }]}>
          <TouchableOpacity onPress={() => this.openTimeModal(1)} style={{ flex: 1 }} activeOpacity={isDetail ? 1 : 0.2}>
            <View style={[styles.flexColumn, { flex: 1 }]}>
              <MBText>{loadDate}</MBText>
              <View style={styles.flexRow}>
                <MBText color="#666666" size="xs">
                  {loadTime || '请选择'}
                </MBText>
                {!isDetail && <Image style={styles.sortArrows} source={{ uri: images.sortArrows }}></Image>}
              </View>
            </View>
          </TouchableOpacity>
          <View style={styles.points}>
            <View style={[styles.point]}></View>
            <View style={[styles.point, { backgroundColor: '#8CBDFD' }]}></View>
            <View style={[styles.point, { backgroundColor: '#4988FD' }]}></View>
          </View>
          <TouchableOpacity onPress={() => this.openTimeModal(2)} style={{ flex: 1 }} activeOpacity={isDetail ? 1 : 0.2}>
            <View style={[styles.flexColumn, { flex: 1 }]}>
              <MBText>{unloadDate}</MBText>
              <View style={styles.flexRow}>
                <MBText color="#666666" size="xs">
                  {unloadTime || '请选择'}
                </MBText>
                {!isDetail && <Image style={styles.sortArrows} source={{ uri: images.sortArrows }}></Image>}
              </View>
            </View>
          </TouchableOpacity>
        </View>
        {this.timeTipsElement()}
        <View onLayout={(el) => this.onLayoutAddress(el)}>
          <CellGroup
            withBottomLine={false}
            style={{
              borderRadius: 0,
              borderBottomLeftRadius: autoFix(5),
              borderBottomRightRadius: autoFix(5),
              paddingBottom: autoFix(20),
              position: 'relative',
            }}
          >
            {/* 装货地点 */}
            <TouchableOpacity onPress={() => this.goCityPages(1)} activeOpacity={isDetail ? 1 : 0.2}>
              <Cell
                tag={this.addressTitleElement(1)}
                extra={this.addressDetailElement(loadAddress)}
                onPress={() => this.goCityPages(1)}
                isLink={!isDetail}
              />
            </TouchableOpacity>
            {isDetail && <Whitespace vertical={20} />}
            {/* 卸货地点 */}
            <TouchableOpacity onPress={() => this.goCityPages(2)} activeOpacity={isDetail ? 1 : 0.2}>
              <Cell
                tag={this.addressTitleElement(0)}
                extra={this.addressDetailElement(unloadAddress)}
                onPress={() => this.goCityPages(2)}
                isLink={!isDetail}
              />
            </TouchableOpacity>
            {!!layoutAddressHeight && (
              <View style={styles.stepLine}>
                <Image
                  fadeDuration={0}
                  resizeMode="repeat"
                  style={{ height: lineHeight, width: autoFix(2) }}
                  source={images.line_vertical}
                />
              </View>
            )}
          </CellGroup>
        </View>
        {!isDetail && (
          <>
            <TimePickerModal
              key="start"
              type="loadTime"
              visible={showTimeModal === 1}
              onChange={(val: any) => this.changeDateTime(val, 1)}
              onCancel={() => this.openTimeModal(0)}
              defaultTime={loadTime}
            />
            <TimePickerModal
              key="end"
              type="unloadTime"
              visible={showTimeModal === 2}
              onChange={(val: any) => this.changeDateTime(val, 2)}
              onCancel={() => this.openTimeModal(1)}
              defaultTime={unloadTime}
            />
          </>
        )}
      </View>
    );
  }
}
