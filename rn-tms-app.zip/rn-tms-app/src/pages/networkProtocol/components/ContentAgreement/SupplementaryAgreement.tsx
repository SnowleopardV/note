import React from 'react';
import { View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Cell from '~/components/common/Cell';
import ModalAppoint from '../ModalAppoint';
type Props = pageProps;
@inject('store')
@observer
export default class SupplementaryAgreement extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      showModal: false,
    };
  }
  openModal = (val: boolean) => {
    this.setState({ showModal: val });
  };
  render() {
    const { note } = this.props.store.submitForm;
    const { showModal } = this.state;
    return (
      <View style={{ marginTop: autoFix(20) }}>
        <CellGroup withBottomLine style={{ borderRadius: autoFix(5), paddingBottom: autoFix(14) }}>
          <MBText style={{ marginTop: autoFix(28), marginLeft: autoFix(28) }} color="#999999" size="xs">
            补充约定
          </MBText>
          <Cell title="补充约定" value={note} align="right" placeholder="请输入" onPress={() => this.openModal(true)} />
        </CellGroup>
        {showModal && <ModalAppoint visible={true} onChange={() => this.openModal(false)} />}
      </View>
    );
  }
}
