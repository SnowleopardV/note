import React from 'react';
import { View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Cell from '~/components/common/Cell';
import ModalCargoInsurance from '~/pages/dispatch/components/ModalLargeInsured';
import API from '../../api';
type Props = pageProps;
@inject('store')
@observer
export default class InsuredPrice extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      showModal: false,
    };
  }
  componentDidMount() {
    this.api_insuranceInfo();
  }
  openModal = (val: boolean) => {
    this.setState({ showModal: val });
  };
  onChange = (val: any) => {
    this.openModal(false);
    if (val) {
      this.props.store.setSubmitForm({
        hasLargeInsurance: val.hasLargeInsurance, // 是否勾选大额保价保障 0/null:未勾选 1：已勾选
        largeInsuranceCost: val.largeInsuranceCost, // 保价费用 单位:元
      });
    }
  };
  api_insuranceInfo() {
    const { orderId, userId, companyId } = this.props.store.getFrom;
    API.insuranceInfo({ orderId, userId, companyId }).then((res: any) => {
      console.log('获取大额保价信息', res);
      if (res.data) {
        this.props.store.setSubmitForm({
          largeInsuranceInfo: res.data?.largeInsuranceInfo,
          hasLargeInsurance: res.data?.largeInsuranceInfo ? 1 : 0, // 如果有大额保价信息默认勾选
          largeInsuranceCost: res.data?.largeInsuranceInfo ? res.data.largeInsuranceInfo?.largeInsuranceCharge : null, // 如果有大额保价信息默认勾选
        });
      }
    });
  }
  render() {
    const { hasLargeInsurance, largeInsuranceCost, largeInsuranceInfo } = this.props.store.submitForm;
    const { showModal } = this.state;
    const value = largeInsuranceCost ? `保价费 ¥${largeInsuranceCost} ` : null;
    if (largeInsuranceInfo) {
      return (
        <View style={{ marginTop: autoFix(20) }}>
          <CellGroup withBottomLine style={{ borderRadius: autoFix(5) }}>
            <Cell title="保价" value={value} align="right" placeholder="未保价货物货损最多赔付2万" onPress={() => this.openModal(true)} />
          </CellGroup>
          <ModalCargoInsurance
            readonly
            visible={showModal}
            onChange={this.onChange}
            largeInsuranceCost={largeInsuranceInfo?.largeInsuranceCharge}
            largeInsuranceRate={largeInsuranceInfo?.rate}
            hasLargeInsurance={hasLargeInsurance}
          />
        </View>
      );
    } else {
      return null;
    }
  }
}
