import React from 'react';
import { Image, TouchableOpacity, View } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Cell from '~/components/common/Cell';
import ModalCarTypeLength from '../ModalCarTypeLength';
import ImageView from '~/components/common/ImageView';
import styles from '../../styles';
import images from '~public/static/images';
import ModalWeightVolume from '../ModalWeightVolume';
type Props = pageProps;
@inject('store')
@observer
export default class CarrierInfo extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      showModal: 0, // 1 重量体积， 2 车型车长
    };
  }
  openModal = (val: number) => {
    this.setState({ showModal: val });
  };
  onChangeTypeLength = (val: any) => {
    console.log('选择车型车长', val);
    this.setState({ showModal: 0 });
    if (val) {
      this.props.store.setSubmitForm(val);
    }
  };
  onChangeWeightVolume = (val: any) => {
    console.log('选择重量体积', val);
    this.setState({ showModal: 0 });
    if (val) {
      const { settlementUnit } = this.props.store.submitForm;
      if (settlementUnit == 1) {
        this.props.store.setSubmitForm({
          minTruckWeight: val.weight.min,
          maxTruckWeight: val.weight.max,
          minCargoCapacity: val.volume.min,
          maxCargoCapacity: val.volume.max,
        });
      } else {
        this.props.store.setSubmitForm({
          truckWeight: val.weight.max,
          cargoCapacipy: val.volume.max,
        });
        this.props.store.computeSubtotal();
      }
    }
  };

  driverNameElement() {
    const { vehicleLicenseUrl, driverName } = this.props.store.submitForm;
    return (
      <TouchableOpacity onPress={() => this.setState({ showModal: 3 })} style={{ flex: 1, alignItems: 'flex-end' }}>
        <View style={styles.flexRow}>
          {!!vehicleLicenseUrl && (
            <Image style={{ width: autoFix(40), height: autoFix(40), marginRight: autoFix(10) }} source={images.iconDriverLicense} />
          )}
          <MBText style={{ marginRight: autoFix(10) }} color={driverName ? '' : '#ccc'}>
            {driverName || '-'}
          </MBText>
        </View>
      </TouchableOpacity>
    );
  }
  render() {
    const {
      truckWeight,
      cargoCapacipy,
      carLength,
      carType,
      settlementUnit,
      vehicleLicenseUrl,
      truckNumber,
      minTruckWeight,
      maxTruckWeight,
      minCargoCapacity,
      maxCargoCapacity,
      goodsName,
    } = this.props.store.submitForm;
    const { showModal } = this.state;
    const truckTypeName = carType.map((item: any) => item.name).join('，');
    const truckLengthName = carLength.map((item: any) => item.name).join('，');
    const weightText =
      settlementUnit === 1 ? (minTruckWeight && maxTruckWeight ? `${minTruckWeight || 0} - ${maxTruckWeight || 0}` : '') : truckWeight;
    const volumeText =
      settlementUnit === 1
        ? minCargoCapacity && maxCargoCapacity
          ? `${minCargoCapacity || 0} - ${maxCargoCapacity || 0}`
          : ''
        : cargoCapacipy;
    let weightVolumeData = null;
    if (settlementUnit === 1) {
      weightVolumeData = { weight: { min: minTruckWeight, max: maxTruckWeight }, volume: { min: minCargoCapacity, max: maxCargoCapacity } };
    } else {
      weightVolumeData = { weight: { min: '', max: truckWeight }, volume: { min: '', max: cargoCapacipy } };
    }
    return (
      <View style={{ marginTop: autoFix(20) }}>
        <CellGroup withBottomLine style={{ borderRadius: autoFix(5), paddingBottom: autoFix(14) }}>
          <MBText style={{ marginTop: autoFix(28), marginLeft: autoFix(28) }} color="#999999" size="xs">
            承运信息
          </MBText>
          <Cell title="货物名称" readonly value={goodsName} align="right" />
          {settlementUnit == 1 && (
            <Cell
              title="重量/体积"
              value={
                weightText || volumeText
                  ? `${weightText ? weightText + '吨' + (volumeText ? '，' : '') : ''}${volumeText ? volumeText + '方' : ''}`
                  : ''
              }
              align="right"
              placeholder="请输入"
              onPress={() => this.openModal(1)}
            />
          )}
          <Cell
            title="车型/车长"
            value={truckTypeName && truckLengthName ? `${truckTypeName || '-'} / ${truckLengthName || '-'}` : ''}
            align="right"
            placeholder="请输入"
            onPress={() => this.openModal(2)}
          />
          <Cell title="承运车牌" readonly value={truckNumber || '-'} align="right" isLink={false} />
          <Cell title="承运司机" readonly rightTag={this.driverNameElement()} align="right" isLink={false} />
        </CellGroup>
        {showModal == 1 && <ModalWeightVolume visible={true} onChange={this.onChangeWeightVolume} defaultData={weightVolumeData} />}
        {showModal == 2 && (
          <ModalCarTypeLength
            visible={true}
            onChange={this.onChangeTypeLength}
            item={{ platformCarLength: carLength.map((item: any) => item.id), platformCarType: carType.map((item: any) => item.id) }}
          />
        )}
        {/* 驾驶证预览 */}
        {!!vehicleLicenseUrl && (
          <ImageView
            visible={showModal == 3}
            onCancel={() => this.setState({ showModal: 0 })}
            imageUrls={[{ url: vehicleLicenseUrl || null }]}
            index={0}
          />
        )}
      </View>
    );
  }
}
