import React from 'react';
import { View, Platform } from 'react-native';
import { inject, observer } from 'mobx-react';
import { CellGroup, MBText } from '@ymm/rn-elements';
import { KeyUnitMap, pageProps, UnitMap } from '../../propTypes';
import { autoFix } from '@ymm/rn-lib/src/Extends/MBStyleSheet';
import Cell from '~/components/common/Cell';
import InputItem from '~/components/common/InputItem';
import validator from '~/extends/verification';
import RegTest from '~/utils/RegTest';
import ModalSettlementMethod from '../ModalSettlementMethod';
import FeeItemNewList from './FeeItemNewList';

interface Props extends pageProps {
  type: 'create' | 'edit';
}
@inject('store')
@observer
export default class TransFee extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    this.state = {
      showModal: 0, // 1 结算方式弹窗
    };
  }
  openModal = (val: number) => {
    this.setState({ showModal: val });
  };
  onChangeMethod = (val: number | null) => {
    this.setState({ showModal: 0 });
    const { settlementUnit } = this.props.store.submitForm;
    if (settlementUnit != val) {
      this.props.store.setSubmitForm({ [KeyUnitMap[settlementUnit]]: '' });
      if (val) {
        this.props.store.setSubmitForm({ settlementUnit: val });
        this.props.store.computeSubtotal();
      }
    }
  };
  totalValueElement(): React.ReactNode {
    const { totalMoney } = this.props.store.submitForm;
    return (
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <MBText color="#FF6969" size="md">
          {totalMoney || '0.00'}
        </MBText>
        <MBText size="md" style={{ marginLeft: autoFix(10) }}>
          元
        </MBText>
      </View>
    );
  }
  changeText(text: string, unit: number) {
    if (text === '' || (unit === 1 && validator.price(text)) || ((unit === 2 || unit === 3) && RegTest.numPrecision(text, 3))) {
      this.props.store.setSubmitForm({ [KeyUnitMap[unit]]: text });
      this.props.store.computeSubtotal(); // 计算出小计
    }
  }
  unitElementMap(unit: number) {
    const { submitForm } = this.props.store;
    const value = submitForm[KeyUnitMap[unit]];
    const labelMap = {
      1: '运费单价',
      2: '货物重量',
      3: '货物体积',
    };
    return (
      <InputItem
        title={labelMap[unit]}
        textAlign="right"
        value={value}
        onChangeText={(text: string) => this.changeText(text, unit)}
        placeholder="请输入"
        keyboardType="numeric"
        blurOnSubmit={false}
        onFocus={() => this.props.store.setShowFootBtn(false)}
        onBlur={() => {
          this.props.store.setShowFootBtn(true);
          this.props.store.setSubmitForm({ [KeyUnitMap[unit]]: value ? String(Number(value)) : null });
        }}
        extraNode={<MBText style={{ marginLeft: autoFix(20), marginTop: Platform.OS == 'ios' ? autoFix(10) : 0 }}>{UnitMap[unit]}</MBText>}
      />
    );
  }
  render() {
    const { showModal } = this.state;
    const { settlementUnit, payMoney, freightUnitPrice } = this.props.store.submitForm;
    const { serviceFee, companyServiceRate } = this.props.store.serviceFeeData || {};
    const settlementMethod = `按${UnitMap[settlementUnit] || '趟'}结算`;
    const invoiceFlagIsGeneralTicket = this.props.store.invoiceFlagIsGeneralTicket;

    return (
      <View style={{ marginTop: autoFix(20) }}>
        <CellGroup withBottomLine style={{ borderRadius: autoFix(5), paddingBottom: autoFix(14) }}>
          <MBText style={{ marginTop: autoFix(28), marginLeft: autoFix(28) }} color="#999999" size="xs">
            运费
          </MBText>
          <Cell
            readonly={this.props.type === 'edit'}
            title="结算方式"
            value={settlementMethod}
            align="right"
            placeholder="请选择"
            onPress={() => this.openModal(1)}
          />
          {settlementUnit != 1 && this.unitElementMap(settlementUnit)}
          <InputItem
            title="运单单价"
            textAlign="right"
            value={freightUnitPrice}
            onChangeText={(text: string) => this.changeText(text, 1)}
            placeholder="请输入"
            keyboardType="numeric"
            blurOnSubmit={false}
            onFocus={() => this.props.store.setShowFootBtn(false)}
            onBlur={() => {
              this.props.store.setShowFootBtn(true);
              this.props.store.setSubmitForm({ [KeyUnitMap[1]]: freightUnitPrice ? String(Number(freightUnitPrice)) : null });
            }}
            extraNode={
              <MBText style={{ marginLeft: autoFix(20), marginTop: Platform.OS == 'ios' ? autoFix(10) : 0 }}>
                {UnitMap[settlementUnit]}/元
              </MBText>
            }
          />
          {!!payMoney && (
            <Cell title="小计" readonly value={payMoney || '0.00'} align="right" isLink={false} rightElement={<MBText>元</MBText>} />
          )}
          <FeeItemNewList {...this.props} />
          <Cell
            title="总运费"
            titleStyle={{ fontSize: autoFix(32), fontWeight: 'bold' }}
            rightElement={this.totalValueElement()}
            align="right"
            extra={
              invoiceFlagIsGeneralTicket ? null : (
                <MBText style={{ position: 'absolute', top: -autoFix(28), fontSize: autoFix(24) }} size="xs" color="#999999">
                  (附加费率{companyServiceRate ? companyServiceRate : '0.00'}%，附加运费
                  {serviceFee ? serviceFee : '0.00'}元)
                </MBText>
              )
            }
          />
        </CellGroup>
        {showModal === 1 && <ModalSettlementMethod onChange={this.onChangeMethod} visible={true} default={settlementUnit} />}
      </View>
    );
  }
}
