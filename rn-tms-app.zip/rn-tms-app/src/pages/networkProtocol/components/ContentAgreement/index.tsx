import React from 'react';
import { View, Platform, ScrollView, RefreshControl } from 'react-native';
import { inject, observer } from 'mobx-react';
import { MBText, Whitespace } from '@ymm/rn-elements';
import { pageProps } from '../../propTypes';
import styles from '../../styles';
import TransFee from './TransFee';
import PaymentMethod from './PaymentMethod';
import CarrierInfo from './CarrierInfo';
import SupplementaryAgreement from './SupplementaryAgreement';
import InsuredPrice from './InsuredPrice';
import DataTimeAddress from './DataTimeAddress';
import PayTime from './PayTime';
import { MBBridge } from '@ymm/rn-lib';
interface Props extends pageProps {
  type: 'create' | 'edit';
}
@inject('store')
@observer
export default class ContentAgreement extends React.Component<Props, any> {
  backHandleListener: any = null;
  constructor(props: any) {
    super(props);
    if (Platform.OS == 'ios') {
      MBBridge.rnruntime.IQKeyboard({ enable: true });
    }
  }
  render() {
    const { type } = this.props;
    const invoiceFlagIsGeneralTicket = this.props.store.invoiceFlagIsGeneralTicket;
    return (
      <ScrollView
        style={{ flex: 1 }}
        keyboardShouldPersistTaps="never"
        showsVerticalScrollIndicator={false}
        alwaysBounceVertical={false}
        nestedScrollEnabled={true}
      >
        <View style={{ flex: 1 }}>
          {/* 运费 */}
          <TransFee {...this.props} />
          {/* 付款方式 - 普票是2不显示*/}
          {invoiceFlagIsGeneralTicket ? null : <PaymentMethod {...this.props} />}
          {/* 时间 - 装卸货地址 */}
          <DataTimeAddress {...this.props} />
          {/* 承运信息 */}
          <CarrierInfo {...this.props} />
          {/*付款时间 - 普票才会显示*/}
          {invoiceFlagIsGeneralTicket ? <PayTime {...this.props} /> : null}
          {/* 补充约定 */}
          <SupplementaryAgreement />
          {/* 保价 只有在创建协议的时候显示*/}
          {type === 'create' && <InsuredPrice />}
          <Whitespace vertical={20} />
        </View>
      </ScrollView>
    );
  }
}
