import * as React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { Flex, Modal, MBText, Whitespace, Selector } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import InputItem from '~/components/common/InputItem';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import NativeBridge from '~/extends/NativeBridge';
import RegTest from '~/utils/RegTest';

interface Props {
  visible?: boolean;
  onChange?: any;
  store?: any;
}
@inject('store')
@observer
export default class ModalAppoint extends React.Component<Props, any> {
  name = '弹窗-补充约定';
  constructor(props: Props) {
    super(props);
    this.state = {
      index: 1,
    };
  }
  handleUnitConfirm = () => {
    const { onChange } = this.props;
    onChange && onChange(this.state.index);
  };
  handleUnitCancel = () => {
    const { onChange } = this.props;
    onChange && onChange();
  };
  handleUnitChange = (index: number) => {
    this.setState({ index: index + 1 });
  };
  handleText = (val: any) => {
    val = val.replace(/\n/gm, ''); // 禁止换行
    const maxLen = 1000;
    if (val.length > maxLen) {
      NativeBridge.toast(`已达到输入上限${maxLen}个字符`);
      this.props.store.setSubmitForm({ note: val.slice(0, maxLen) });
    } else if (!RegTest.emoji(val)) {
      this.props.store.setSubmitForm({ note: val });
    }
  };
  render() {
    const { visible } = this.props;
    const { note } = this.props.store.submitForm;
    const textNum = note?.length || 0;
    return (
      <Modal
        headerRight="确定"
        headerLeft="取消"
        title="补充约定"
        position="bottom"
        visible={visible}
        headerLine={false}
        onConfirm={this.handleUnitConfirm}
        onCancel={this.handleUnitCancel}
        onMaskClose={this.handleUnitCancel}
        onRequestClose={this.handleUnitCancel}
      >
        <View style={styles.box}>
          <Whitespace vertical={10} />
          <View style={styles.editBox}>
            <InputItem
              value={note}
              placeholder="请输入"
              onChangeText={this.handleText}
              style={styles.inputItem}
              inputStyle={{ marginLeft: 0, height: Platform.OS == 'ios' ? autoFix(300) : null }}
              maxLength={1001}
              multiline={true}
              blurOnSubmit
              extraNode={<MBText></MBText>}
            />
            <View style={styles.fontNum}>
              <MBText color="#CCCCCC">{textNum}/1000</MBText>
            </View>
          </View>
          <Whitespace vertical={40} />
        </View>
      </Modal>
    );
  }
}
const styles = StyleSheet.create({
  box: {
    position: 'relative',
  },
  editBox: {
    backgroundColor: '#F6F6F6',
    borderRadius: autoFix(10),
    width: autoFix(686),
    height: autoFix(340),
  },
  lable: {
    paddingTop: Platform.OS === 'ios' ? 20 : 15,
    paddingLeft: 20,
    color: '#333333',
  },
  inputItem: {
    flex: 1,
  },
  fontNum: {
    position: 'absolute',
    bottom: autoFix(20),
    right: autoFix(20),
  },
});
