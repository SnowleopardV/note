import * as React from 'react';
import { View, SafeAreaView, Platform, Image } from 'react-native';
import { Button, LayProvider, MBText, Modal } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import { moneyDataMap, pageProps } from '../propTypes';
import styles from '../styles';
import ContentAgreement from '../components/ContentAgreement';
import Agreement from '../components/ContentAgreement/Agreement';
import API from '../api';
import keyMap from '~/pages/dispatch/keyMap';
import NativeBridge from '~/extends/NativeBridge';
import images from '~public/static/images';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

@inject('store')
@observer
export default class DispatchList extends React.Component<pageProps, any> {
  backHandleListener: any = null;
  hasSubmit: boolean;
  constructor(props: pageProps) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    this.api_init();
  }
  async api_init() {
    const { orderId, userId, companyId } = this.props.store.getFrom;
    await this.props.store.api_TypeLengthPlateList(); // 等待加载好车型车长
    API.protocolInitSupplement({ orderId, userId, companyId })
      .then((res: any) => {
        console.log('----------------修改协议（增补协议）---------------------');
        if (res.data) {
          const { loads, unloads, truckTypeList, truckLength } = res.data;
          // 车长/车型 如果有多个值 就置空，否则只显示一个值
          const truckTypeListData = truckTypeList ? (String(truckTypeList).includes(',') ? null : truckTypeList) : null;
          const truckLengthData = truckLength ? truckLength : null;
          const carLength = truckLengthData
            ? [
                {
                  id: Object.keys(keyMap.carLengthPlate).find((key: string) => truckLengthData == keyMap.carLengthPlate[key]),
                  name: truckLengthData,
                },
              ]
            : []; // 车长直接返回了 值
          const carType = truckTypeListData ? [{ id: truckTypeListData, name: keyMap.carTypePlate[truckTypeListData] }] : []; // 车型返回的是 键
          // 金额转换成元
          const moneyData = {};
          Object.keys(moneyDataMap).forEach((key: string) => {
            moneyData[key] = moneyDataMap[key](res.data[key], 'accDiv');
          });
          const data = {
            ...res.data,
            ...moneyData,
            settlementUnit: res.data.settlementUnit || 1,
            startProvinceId: loads?.provinceCode, // 省编码
            startProvinceName: loads?.provinceName, // 省名称
            startCityId: loads?.cityCode, // 城市编码
            startCityName: loads?.cityName, // 城市名称
            startDistrictId: loads?.districtCode, // 区县编码
            startDistrictName: loads?.districtName, // 区县名称
            endProvinceId: unloads?.provinceCode, // 省编码
            endProvinceName: unloads?.provinceName, // 省名称
            endCityId: unloads?.cityCode, // 城市编码
            endCityName: unloads?.cityName, // 城市名称
            endDistrictId: unloads?.districtCode, // 区县编码
            endDistrictName: unloads?.districtName, // 区县名称
            start: loads?.districtCode ? loads?.districtCode : loads?.cityCode || null, // 区县code,没有区号用市号
            end: unloads?.districtCode ? unloads?.districtCode : unloads?.cityCode || null, // 区县code,没有区号用市号
            truckTypeList: truckTypeListData,
            truckLength: truckLengthData,
            carLength: carLength.filter((item: any) => item.id && item.name), // [{ id: '15', name: '13.7' }],
            carType: carType.filter((item: any) => item.id && item.name), // [{ id: '3', name: '厢式' }],
            cargoCapacipy: String(res.data.cargoCapacipy),
            minCargoCapacity: String(res.data.minCargoCapacity),
            maxCargoCapacity: String(res.data.maxCargoCapacity),
            maxTruckWeight: String(res.data.maxTruckWeight),
            minTruckWeight: String(res.data.minTruckWeight),
            truckWeight: String(res.data.truckWeight),
            cargoCapacity: String(res.data.cargoCapacipy),
            startAddressLatitude: String(res.data.startAddressLatitude),
            startAddressLongitude: String(res.data.startAddressLongitude),
          };
          this.props.store.setSubmitForm(data);
          if (res.data.payMoney) {
            this.props.store.api_protocolGetServiceFee(res.data.payMoney);
          } else {
            this.props.store.setServiceFeeData({ serviceFee: null, companyServiceRate: null });
          }
        }
      })
      .catch((err: any) => {
        console.log('修改协议（增补协议）错误', err);
      });
  }
  submit = () => {
    if (this.hasSubmit) {
      return;
    }
    this.hasSubmit = true;
    const { payMoney, preCashMoney, preOilMoney, receiptMoney, freightUnitPrice } = this.props.store.submitForm;
    const { settlementUnit, minTruckWeight, maxTruckWeight, minCargoCapacity, maxCargoCapacity, truckWeight, cargoCapacipy } =
      this.props.store.submitForm;
    if (payMoney < Number(preCashMoney) + Number(preOilMoney) + Number(receiptMoney)) {
      NativeBridge.toast('结算方式之和不能大于小计金额');
      this.hasSubmit = false;
      return;
    } else if (!Number(freightUnitPrice)) {
      NativeBridge.toast('运费单价必填');
      this.hasSubmit = false;
      return;
    } else {
      if (
        settlementUnit == 1 &&
        !Number(minTruckWeight) &&
        !Number(maxTruckWeight) &&
        !Number(minCargoCapacity) &&
        !Number(maxCargoCapacity)
      ) {
        NativeBridge.toast('重量和体积至少填写一个大于0的值');
        this.hasSubmit = false;
        return;
      } else if (settlementUnit != 1 && !Number(truckWeight) && !Number(cargoCapacipy)) {
        NativeBridge.toast('重量和体积至少填写一个大于0的值');
        this.hasSubmit = false;
        return;
      }
    }
    Modal.Confirm({
      title: '提示', // 可以传null隐藏头部
      headerLine: false, // 隐藏头部分割线
      content: '确认提交修改？',
      cancelText: '取消',
      confirmText: '确定',
      onConfirm: () => {
        this.hasSubmit = false;
        setTimeout(() => this.api_protocolSubmitSupplement(), 650);
      },
      onCancel: () => {
        this.hasSubmit = false;
      },
    });
  };
  api_protocolSubmitSupplement() {
    const { submitForm, invoiceFlagIsGeneralTicket, serviceFeeData } = this.props.store;
    // 金额转换成分
    const moneyData = {};
    Object.keys(moneyDataMap).forEach((key: string) => {
      moneyData[key] = moneyDataMap[key](submitForm[key], 'accMul');
    });
    const { minTruckWeight, maxTruckWeight, minCargoCapacity, maxCargoCapacity, truckWeight, cargoCapacipy } = submitForm;
    const { loads, unloads } = submitForm;
    const data = {
      ...submitForm,
      ...moneyData,
      truckTypeList: submitForm.carType[0]?.id || null,
      truckLength: submitForm.carLength[0]?.name || null,
      truckWeight:
        submitForm.settlementUnit == 1 ? `${minTruckWeight || 0}-${maxTruckWeight || 0}` : `${truckWeight || 0}-${truckWeight || 0}`,
      cargoCapacipy:
        submitForm.settlementUnit == 1
          ? `${minCargoCapacity || 0}-${maxCargoCapacity || 0}`
          : `${cargoCapacipy || 0}-${cargoCapacipy || 0}`,
      minTruckWeight: submitForm.settlementUnit == 1 ? minTruckWeight : truckWeight,
      maxTruckWeight: submitForm.settlementUnit == 1 ? maxTruckWeight : truckWeight,
      minCargoCapacity: submitForm.settlementUnit == 1 ? minCargoCapacity : cargoCapacipy,
      maxCargoCapacity: submitForm.settlementUnit == 1 ? maxCargoCapacity : cargoCapacipy,
      feeItemNewList: invoiceFlagIsGeneralTicket ? serviceFeeData.feeItemNewList : null, // 普票字段，本次需求不涉及
      start: submitForm.start ? submitForm.start : loads?.cityCode || null, // 区县code,没有区号用市号
      end: submitForm.end ? submitForm.end : unloads?.cityCode || null, // 区县code,没有区号用市号
      hasLargeInsurance: null, // 是否勾选大额保价保障 0/null:未勾选 1：已勾选 // 修改时不用提交
      largeInsuranceCost: null, // 保价费用 单位:元 // 修改时不用提交
    };
    API.protocolSubmitSupplement(data).then((res: any) => {
      if (res.success) {
        this.props.navigation.replace('agreeToDeal'); // 关闭当前页打开新页面
      }
    });
  }
  public render() {
    return (
      <View style={styles.page}>
        <NavBar title="修改协议" leftClick={() => this.props.navigation?.goBack()} />
        <ContentAgreement type="edit" navigation={this.props.navigation} />
        {this.props.store.showFootBtn && (
          <View style={[styles.bottomBtn, styles.shadow, { flexDirection: 'column' }]}>
            <View style={[styles.bottomBtn, { paddingHorizontal: 0, paddingTop: 0 }]}>
              <Image style={{ height: autoFix(30), width: autoFix(30), marginRight: autoFix(10) }} source={images.icon_check_gray} />
              <Agreement {...this.props} />
            </View>
            <View style={{ height: autoFix(80) }}>
              <Button radius style={styles.btn} interval={500} onPress={this.submit} size="sm" type="primary">
                确定修改
              </Button>
            </View>
          </View>
        )}
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </View>
    );
  }
}
