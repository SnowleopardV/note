import * as React from 'react';
import RouterMap, { RouterPageName } from './register';
import { Provider } from 'mobx-react';
import Store from '../store';
import { LayProvider } from '@ymm/rn-elements';

const CustomerSelector: React.FunctionComponent<any> = (props) => {
  const store = new Store();
  console.log('------------------------props----------------------------');
  let urlData = null;
  try {
    urlData = JSON.parse(decodeURIComponent(props?.schemeurl));
  } catch (error) {
    urlData = props?.schemeurl;
  }
  const { showPage, ...arg } = urlData || {};
  store.setGetFrom(arg); // 将多余的参数存起来，留备后用
  /** 设置发票状态，在这里判断，可以收口，避免在内部去判断状态 0-不开票，1-满帮专票，2-满帮普票 */
  store.setInvoiceFlagStatus(arg.invoiceFlag == '2');
  const RootStack = new RouterMap().getRouterMap(showPage || 'agreeToDeal');
  return (
    <Provider store={store}>
      <LayProvider theme="skyblue">
        <RootStack screenProps={props} />
      </LayProvider>
    </Provider>
  );
};

export default CustomerSelector;
