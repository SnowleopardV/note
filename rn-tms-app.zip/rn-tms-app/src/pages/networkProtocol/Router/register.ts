import { createStackNavigatorCompat, createAppContainerCompat } from '@ymm/rn-lib';
import createAgreementPage from '../createAgreement/index'; // 创建协议
import editAgreementPage from '../editAgreement/index'; // 修改协议
import agreeToDealPage from '../agreeToDeal/index'; // 同意协议
import selectAddressPage from '../selectAddress'; // 城市选择

/**
 * RN页面
 */
export enum RouterPageName {
  createAgreement = 'createAgreement',
  editAgreement = 'editAgreement',
  agreeToDeal = 'agreeToDeal',
  selectAddress = 'selectAddress',
}
/**
 * 路由表
 */
export default class RouterMap {
  /**
   * 获取路由表
   * @param initialRouteName 初始路由
   */
  getRouterMapInner(initialRouteName: string) {
    return createStackNavigatorCompat(
      {
        createAgreement: { screen: createAgreementPage, navigationOptions: () => ({ header: null }) }, // 创建协议
        editAgreement: { screen: editAgreementPage, navigationOptions: () => ({ header: null }) }, // 修改协议
        agreeToDeal: { screen: agreeToDealPage, navigationOptions: () => ({ header: null }) }, // 同意协议
        selectAddress: { screen: selectAddressPage, navigationOptions: () => ({ header: null }) }, // 城市选择
      },
      {
        initialRouteName: initialRouteName,
      }
    );
  }

  getRouterMap(initialRouteName: RouterPageName) {
    return createAppContainerCompat(this.getRouterMapInner(initialRouteName));
  }
}
