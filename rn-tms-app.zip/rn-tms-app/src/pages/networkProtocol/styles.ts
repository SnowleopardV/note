import { StyleSheet } from 'react-native';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';

export default StyleSheet.create({
  page: {
    flex: 1,
    position: 'relative',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  freightFlexRow: {
    flexDirection: 'row',
  },
  flexColumn: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  bottomBtn: {
    backgroundColor: '#FFF',
    paddingHorizontal: autoFix(28),
    paddingVertical: autoFix(20),
    flexDirection: 'row',
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -5 },
    shadowRadius: 10,
    elevation: 20,
  },
  btn: {
    backgroundColor: '#4885FF',
    flex: 1,
  },
  cellGroupBox: {
    marginTop: autoFix(20),
    marginHorizontal: autoFix(17),
    padding: autoFix(28),
    borderRadius: 5,
    backgroundColor: '#FFFFFF',
  },
  points: {
    flexDirection: 'row',
    width: autoFix(80),
    justifyContent: 'space-between',
  },
  point: {
    width: autoFix(16),
    height: autoFix(16),
    backgroundColor: '#DFECFD',
    borderRadius: 1000,
  },
  stepLine: {
    position: 'absolute',
    top: autoFix(68),
    left: autoFix(50),
  },
  cardBox: {
    backgroundColor: '#FFFFFF',
    borderRadius: autoFix(10),
    padding: autoFix(28),
    marginTop: autoFix(20),
  },
  sortArrows: {
    width: autoFix(10),
    height: autoFix(20),
    marginLeft: autoFix(10),
    marginTop: autoFix(4),
  },
  circular: {
    height: autoFix(46),
    width: autoFix(46),
    backgroundColor: '#F0F0F0',
    borderRadius: 100,
  },
  timeLinePoint: {
    width: autoFix(14),
    height: autoFix(14),
    backgroundColor: '#CBCED6',
    borderRadius: 100,
  },
});
