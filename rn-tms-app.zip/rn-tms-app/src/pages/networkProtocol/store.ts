import { observable, action } from 'mobx';
import { MBLog, MBJournal, MBBridge } from '@ymm/rn-lib';
import { DetailProps, submitFormProps } from './propTypes';
import API from './api';
import xyMath from '~/extends/xyMath';
import { api_getTruckLengthPlateList, api_getTruckTypePlateList } from '../commonData';
import images from '~public/static/images';
import dayjs from 'dayjs';
import NativeBridge from '~/extends/NativeBridge';

let showFootBtnTimer: NodeJS.Timeout | null = null;
class Store {
  @observable serviceFeeDetailData = {
    serviceFee: null, //附加运费加，单位分
    companyServiceRate: null, // 服务费率数据
    feeItemNewList: [], // 费用项集合
  };
  @observable serviceFeeData = {
    serviceFee: null, //附加运费加，单位分
    companyServiceRate: null, // 服务费率数据
    feeItemNewList: [], // 费用项集合
  };
  @observable getFrom = {
    orderId: null, // 订单id
    userId: null, // 用户id
    companyId: null, // 公司id
  };
  @observable detailData: DetailProps = {}; // 协议详情
  @observable submitForm: submitFormProps = {
    start: null, // 	始发地id,三级地址
    startAddressLatitude: null, // 起始地纬度
    startAddressLongitude: null, // 起始地经度
    end: null, // 	目的地id,三级地址
    endAddressLatitude: null, // 目的地纬度
    endAddressLongitude: null, // 目的地经度
    loadAddress: null, // 装货地点详细地址
    unloadAddress: null, // 卸货地点详细地址
    orderId: null, // 订单编号
    companyId: null, // 公司ID
    loadTime: null, // 装货时间时间戳
    unloadTime: null, // 卸货截止时间时间戳
    truckTypeList: null, // 车型
    truckLength: null, // 车长，多个用英文逗号分隔，单位：米
    truckWeight: null, // 货物重量，单位：吨
    cargoCapacipy: null, // 货物体积，单位：方
    truckNumber: null, // 车牌号
    prepaidMoney: null, // 预付运费，单位分
    preCashMoney: null, // 预付现金，单位分
    preOilMoney: null, // 预付油卡，单位分
    receiptMoney: null, // 回单付，单位分
    arriveMoney: null, // 到付 单位分
    payMoney: null, // 总运费，单位分  小计
    totalMoney: null, // 总运费，单位分 包含服务费
    settlementUnit: 1, // 结算单位，  1：趟，2：吨 ； 3：方
    freightUnitPrice: null, // 运费单位，单位分
    payDelayDays: null, // 最晚付款延迟时间
    deposit: null, // 定金金额，单位：分
    note: null, // 补充约定
    cargoUserId: null, // 货主Id
    driverUserId: null, // 司机ID
    serviceChargeRate: null, // 附加服务费率
    serviceFeeRateFeatures: null, // 费率拓展字段
    minTruckWeight: 0, //  最小重量
    maxTruckWeight: 0, // 最大重量
    minCargoCapacity: 0, // 最小体积
    maxCargoCapacity: 0, // 最大体积
    carLength: [], // [{ id: '15', name: '13.7' }],
    carType: [], // [{ id: '3', name: '厢式' }],
    oilRestrictionRatio: 0, // 油卡比例配置， 小计的30%≥油卡金额≥100
    largeInsuranceInfo: null, // 大额保价信息
    hasLargeInsurance: 1, // 是否勾选大额保价保障 0/null:未勾选 1：已勾选
    largeInsuranceCost: null, // 保价费用 单位:元
  };
  @observable showFootBtn: boolean = true;
  @observable timeLineHeight: any = [];
  /** 是否普票 */
  @observable invoiceFlagIsGeneralTicket: boolean = false;
  @observable feeItemNewList: any = [];
  @action settimeLineHeight = (data: any) => {
    this.timeLineHeight = data;
  };
  @action setGetFrom = (data: any) => {
    this.getFrom = { ...this.getFrom, ...data };
  };
  @action setInvoiceFlagStatus = (blo: boolean) => {
    this.invoiceFlagIsGeneralTicket = blo;
  };
  @action setServiceFeeDetailData = (data: any) => {
    this.serviceFeeDetailData = data;
  };
  // 修改要提交的表单
  @action setSubmitForm = (data: submitFormProps) => {
    this.submitForm = { ...this.submitForm, ...data };
  };
  @action setDetailData = (data: DetailProps) => {
    let allSupplements: any = null;
    this.timeLineHeight = [];
    if (data.allSupplements && data.allSupplements?.length) {
      allSupplements = data.allSupplements.map((item: any) => {
        this.timeLineHeight.push(0);
        const {
          updateTime,
          status,
          proposerRole,
          loadAddress,
          unloadAddress,
          loadTime,
          unloadTime,
          additionalFreightDesc,
          truckTypeName,
          truckLengthDesc,
          totalMoneyDesc,
          payMoneyDesc,
          prepaidMoneyDesc,
          receiptMoneyDesc,
          weightVolumeDesc,
          unloads,
          loads,
          feeItemNewList,
        } = item;
        let img = null;
        let btnList: any = [];
        // 已确认 = 协议状态: 已签署
        if (status === 1) {
          img = images.sealConfirmed;
          btnList = [{ name: '修改', type: 'edit', color: '#4885FF', content: null }];
        } else if (status === 0 && proposerRole === 1) {
          // 待货主确认 = 协议状态: 待发起 + 货主
          img = images.sealOwner;
          btnList = [
            {
              name: '拒绝',
              type: 'refuse',
              color: '#9DA1B0',
              content: '确认拒绝协议？',
            },
            {
              name: '同意',
              type: 'confirm',
              color: '#4885FF',
              content: '确认协议内容？',
            },
          ];
        } else if (status === 0 && proposerRole === 2) {
          // 待司机确认 = 协议状态: 待发起 + 司机
          img = images.sealDriver;
          btnList = [{ name: '撤销协议', type: 'revoke', color: '#4885FF', content: '确认撤回修改？' }];
        } else if (status == 2 || status == 3) {
          img = status == 2 ? images.sealRejected : images.sealCancelled;
          btnList = [{ name: '修改', type: 'edit', color: '#4885FF', content: null }];
        }

        /** 普票和专票共同内容 */
        const commonContent = [
          {
            label: '装货地址：',
            key: '',
            value: `${loads.fullName || ''} ${loads.fullName && loadAddress ? '-' : ''} ${loadAddress || ''}`,
          },
          {
            label: '卸货地址：',
            key: '',
            value: `${unloads.fullName || ''} ${unloads.fullName && unloadAddress ? '-' : ''} ${unloadAddress || ''}`,
          },
          { label: '装货时间：', key: '', value: dayjs(loadTime).format('YYYY-MM-DD HH:mm') },
          { label: '卸货时间：', key: '', value: dayjs(unloadTime).format('YYYY-MM-DD HH:mm') },
          { label: '车型：', key: '', value: truckTypeName },
          { label: '车长：', key: '', value: truckLengthDesc },
          { label: '重量/体积：', key: '', value: weightVolumeDesc },
        ];

        /** 普票费用 */
        const feeItemNewListStr = (feeItemNewList ?? []).reduce((str: string, cur: any) => {
          return str + `${cur.feeName}: ${xyMath.accDiv(cur.amount, 100).toFixed(2)}   `;
        }, '');

        return {
          ...item,
          name: '修改运输协议',
          time: dayjs(updateTime).format('MM-DD HH:mm'),
          img,
          content: this.invoiceFlagIsGeneralTicket
            ? [{ label: '总费用：', key: '', value: `${totalMoneyDesc}； 小计：${payMoneyDesc}； ${feeItemNewListStr}` }, ...commonContent]
            : [
                { label: '预付：', key: '', value: prepaidMoneyDesc },
                { label: '回单：', key: '', value: receiptMoneyDesc },
                { label: '总运费：', key: '', value: `${totalMoneyDesc}； 小计：${payMoneyDesc}； 附加运费：${additionalFreightDesc}`},
                ...commonContent,
              ],
          btnList,
        };
      });
    }

    data.allSupplements = allSupplements;

    this.detailData = { ...this.detailData, ...data };
  };
  @action setTotalMoney = () => {
    /** 普票+司机端发起协议，总金额不对，需要重新计算一次 */
    if (this.invoiceFlagIsGeneralTicket && !this.detailData?.feeItemNewList && !this.detailData?.feeItemNewList?.length) {
      // @ts-ignore
      const totalItemFee = this.serviceFeeDetailData.feeItemNewList.reduce((num: any, cur: any) => {
        return xyMath.accAdd(num, cur.amount);
      }, 0);
      this.detailData.totalMoney = xyMath.accAdd(this.detailData.payMoney, totalItemFee) as any;
    }
  };
  @action setServiceFeeData = (data: any) => {
    console.log('------------------------------------', data);
    this.serviceFeeData = data;
  };
  /** 获取附加运费 */
  @action api_protocolGetServiceFee(val: string) {
    API.protocolGetServiceFee({ amount: val })
      .then((res: any) => {
        if (res.data) {
          res.data.serviceFee = xyMath.accDiv(res.data.serviceFee || 0, 100).toFixed(2);
          this.setServiceFeeData(res.data);
        } else {
          this.setServiceFeeData({ serviceFee: null, companyServiceRate: null, feeItemNewList: [] });
        }
      })
      .catch((err: any) => {
        this.setServiceFeeData({ serviceFee: null, companyServiceRate: null, feeItemNewList: [] });
      });
  }
  /** 计算小计 */
  @action computeSubtotal = () => {
    const { freightUnitPrice, truckWeight, cargoCapacipy, settlementUnit } = this.submitForm;
    let data = null;
    if (settlementUnit == 1) {
      data = Number(freightUnitPrice).toFixed(2);
    } else if (settlementUnit == 2) {
      data = xyMath.accMul(freightUnitPrice, truckWeight).toFixed(2);
    } else if (settlementUnit == 3) {
      data = xyMath.accMul(freightUnitPrice, cargoCapacipy).toFixed(2);
    }
    this.setSubmitForm({ payMoney: data || null });
    this.computeArriveMoney();
    this.computeServiceFee(); // 计算附加运费
  };

  /** 计算 预付运费 */
  @action computePrepaidMoney = () => {
    // 到付金额=小计-现金-油卡-回单
    const { preOilMoney, preCashMoney } = this.submitForm;
    const data = xyMath.accAdd(preOilMoney, preCashMoney);
    this.setSubmitForm({ prepaidMoney: data && Number(data) > 0 ? data : '0.00' });
  };

  /** 计算 到付 */
  @action computeArriveMoney = () => {
    // 到付金额=小计-现金-油卡-回单
    const { payMoney, preCashMoney, preOilMoney, receiptMoney } = this.submitForm;
    const data = xyMath.subtr(xyMath.subtr(payMoney, preCashMoney), xyMath.accAdd(preOilMoney, receiptMoney));
    this.setSubmitForm({ arriveMoney: data && Number(data) > 0 ? data : '0.00' });
  };

  /** 计算附加运费 */
  @action computeServiceFee = () => {
    const { payMoney } = this.submitForm;
    API.protocolGetServiceFee({ amount: xyMath.accMul(payMoney, 100).toFixed(0) })
      .then((res) => {
        if (res.data) {
          res.data.serviceFee = xyMath.accDiv(res.data.serviceFee || 0, 100).toFixed(2);
          this.setServiceFeeData(res.data);
          this.computeTotalMoney(); // 计算总运费
        } else {
          this.setServiceFeeData({ serviceFee: null, companyServiceRate: null, feeItemNewList: [...this.feeItemNewList] });
          this.computeTotalMoney(); // 计算总运费
        }
      })
      .catch((err: any) => {
        this.setServiceFeeData({ serviceFee: null, companyServiceRate: null, feeItemNewList: [...this.feeItemNewList] });
        this.computeTotalMoney(); // 计算总运费
      });
  };
  /** 计算总运费
   * 总运费= 小计 + 附加运费
   */
  @action computeTotalMoney = () => {
    const { payMoney } = this.submitForm;
    const { serviceFee, feeItemNewList } = this.serviceFeeData;
    /** 普票 */
    if (this.invoiceFlagIsGeneralTicket) {
      const feeItemNewListTotal = (feeItemNewList ?? []).reduce((sum: any, cur) => {
        return xyMath.accAdd(sum, (cur as any).amount);
      }, 0);
      this.setSubmitForm({
        payMoney: payMoney,
        totalMoney: xyMath.accAdd(payMoney, xyMath.accDiv(feeItemNewListTotal, 100).toFixed(2)),
      });
    } else {
      this.setSubmitForm({
        payMoney: payMoney,
        totalMoney: xyMath.accAdd(payMoney, serviceFee),
      });
    };
  };
  @action setShowFootBtn = (data: boolean) => {
    !!showFootBtnTimer && clearTimeout(showFootBtnTimer);
    showFootBtnTimer = setTimeout(() => {
      this.showFootBtn = data;
    }, 100);
  };
  // 获取平台车型 车长
  @action api_TypeLengthPlateList(): Promise<any> {
    MBBridge.ui.showLoading({});
    return Promise.all([api_getTruckLengthPlateList(), api_getTruckTypePlateList()]).finally(() => {
      MBBridge.ui.hideLoading({});
    });
  }
  @action goAgreement() {
    const url = 'https://static.ymm56.com/customer-service-mobile/service-home/#/service-home/question-detail?id=311&categoryId=123';
    NativeBridge.openWebViewPage(url);
  }
  @action initFeeItemNewList(feeItemNewList: any) {
    if (!this.invoiceFlagIsGeneralTicket) return;
    this.feeItemNewList = feeItemNewList ?? [];
  }
}
export default Store;
