import server from '~/server';
const API = {
  // 初始化协议(主协议)
  protocolInit(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/init',
      data,
    });
  },
  // 创建协议(主协议)
  protocolSubmit(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/submit',
      data,
    });
  },
  // 查看协议详情
  protocolDetail(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/detail',
      data,
    });
  },
  // 确认/拒绝协议(主协议)
  protocolAudit(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/audit',
      data,
    });
  },
  // 初始化增补协议
  protocolInitSupplement(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/initContractSupplement',
      data,
    });
  },
  // 提交增补协议
  protocolSubmitSupplement(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/submitContractSupplement',
      data,
    });
  },
  // 撤回主协议
  withdrawContract(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/withdrawContract',
      data,
    });
  },
  // 撤回增补协议
  protocolWithdrawSupplement(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/withdrawContractSupplement',
      data,
    });
  },
  // 确认/拒绝增补协议
  protocolAuditSupplement(data = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/auditContractSupplement',
      data,
    });
  },
  // 获取附加运费
  protocolGetServiceFee(data = {}) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/contract/getServiceFee',
        data,
      },
      { showLoading: false }
    );
  },
  // 查询货主相关
  queryContractUser(data: { mybOrderId?: string } = {}) {
    return server({
      url: '/saas-tms-trans/yzgApp/contract/queryContractUser',
      data,
    });
  },
  // 获取大额保价信息
  insuranceInfo(data = {}) {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/insurance/get/large/insurance/info',
        data,
      },
      { toastError: false }
    );
  },
  // 创建调度-获取车长接口 http://yapi.1111.com/#/project/2532/interface/api/195989
  getTruckLengthList(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/getTruckLengths',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
  // 创建调度-查询车型列表 http://yapi.1111.com/#/project/2532/interface/api/195997
  getTruckTypeList(params: any = {}): Promise<any> {
    return server(
      {
        url: '/saas-tms-trans/yzgApp/capacity/getTruckTypes',
        data: { ...params },
      },
      { showLoading: false }
    );
  },
};

export default API;
