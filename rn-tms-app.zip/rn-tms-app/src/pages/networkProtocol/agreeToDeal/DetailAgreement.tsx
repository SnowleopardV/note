import { MBText, Splitline } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import { inject, observer } from 'mobx-react';
import React from 'react';
import { Image, Platform, TouchableOpacity, View } from 'react-native';
import ImageView from '~/components/common/ImageView';
import xyMath from '~/extends/xyMath';
import images from '~public/static/images';
import DataTimeAddress from '../components/ContentAgreement/DataTimeAddress';
import { DetailProps, KeyUnitMap, pageProps, UnitMap } from '../propTypes';
import styles from '../styles';
import FeeItemNewList from '../components/ContentAgreement/FeeItemNewList';

@inject('store')
@observer
export default class DetailAgreement extends React.Component<any, any> {
  constructor(props: pageProps) {
    super(props);
    this.state = {
      visibleImageView: false,
      paymentList: [
        {
          label: '现金',
          value: (data: DetailProps) => {
            const prepaidMoney = data.prepaidMoney || 0;
            const preOilMoney = data.preOilMoney || 0;
            const preEtcMoney = data.preEtcMoney || 0;
            return Number(xyMath.accDiv(xyMath.subtr(prepaidMoney - preOilMoney, preEtcMoney), 100)).toFixed(2);
          },
        },
        {
          label: '油卡',
          value: (data: DetailProps) => {
            const prepaidMoney = data.preOilMoney || 0;
            return Number(xyMath.accDiv(prepaidMoney, 100)).toFixed(2);
          },
        },
        {
          label: '到付',
          value: (data: DetailProps) => {
            const payMoney = data.payMoney || 0;
            const prepaidMoney = data.prepaidMoney || 0;
            const receiptMoney = data.receiptMoney || 0;
            return Number(xyMath.accDiv(xyMath.subtr(payMoney - prepaidMoney, receiptMoney), 100)).toFixed(2);
          },
        },
        {
          label: '回单',
          value: (data: DetailProps) => {
            const receiptMoney = data.receiptMoney || 0;
            return Number(xyMath.accDiv(receiptMoney, 100)).toFixed(2);
          },
        },
        {
          label: 'ETC',
          value: (data: DetailProps) => {
            const preEtcMoney = data.preEtcMoney || 0;
            return Number(xyMath.accDiv(preEtcMoney, 100)).toFixed(2);
          },
        },
      ],
      carryInfoList: [
        { label: '货物名称', value: (data: DetailProps) => <MBText>{data.goodsName || '-'}</MBText> },
        {
          label: '车型/车长',
          value: (data: DetailProps) => {
            const truckTypeName = data.truckTypeName;
            const truckLengthDesc = data.truckLengthDesc;
            return <MBText>{(truckTypeName || '-') + ' / ' + (truckLengthDesc || '-')}</MBText>;
          },
        },
        { label: '承运车牌', value: (data: DetailProps) => <MBText>{data.truckNumber || '-'}</MBText> },
        {
          label: '承运司机',
          value: (data: DetailProps) => {
            return (
              <TouchableOpacity onPress={() => this.setState({ visibleImageView: true })}>
                <View style={styles.flexRow}>
                  {!!data.vehicleLicenseUrl && (
                    <Image
                      style={{ width: autoFix(40), height: autoFix(40), marginRight: autoFix(10) }}
                      source={images.iconDriverLicense}
                    />
                  )}
                  <MBText>{data.driverName || '-'}</MBText>
                </View>
              </TouchableOpacity>
            );
          },
        },
      ],
    };
  }

  /**
   * 专票
   */
  renderSpecialTicketEle = () => {
    const { paymentList } = this.state;
    const { detailData, serviceFeeDetailData } = this.props.store;
    return (
      <>
        <View style={{ height: autoFix(275) }}></View>
        <View style={[styles.circular, { position: 'absolute', zIndex: 200, top: autoFix(360), left: -autoFix(28) }]}></View>
        <View style={[styles.circular, { position: 'absolute', zIndex: 200, top: autoFix(360), right: -autoFix(28) }]}></View>
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: autoFix(10),
            padding: autoFix(28),
            position: 'absolute',
            top: autoFix(90),
            height: Platform.OS == 'ios' ? autoFix(292) : autoFix(297),
            width: autoFix(680),
            zIndex: 100,
          }}
        >
          <View style={{ padding: autoFix(20), backgroundColor: '#F9F9F9' }}>
            <View style={[styles.flexRow, { justifyContent: 'space-between' }]}>
              <MBText>运费单价</MBText>
              <MBText>
                ¥{xyMath.accDiv(detailData.freightUnitPrice || 0, 100)}
                {detailData.settlementUnit != 1 && KeyUnitMap[detailData.settlementUnit]
                  ? ' x ' +
                    (detailData.settlementUnit == 1
                      ? parseFloat(xyMath.accDiv(detailData[KeyUnitMap[1]], 100).toFixed(2))
                      : detailData[KeyUnitMap[detailData.settlementUnit]] || '0') +
                    ' '
                  : ''}
                {detailData.settlementUnit === 1 ? '/' : ''}
                {UnitMap[detailData.settlementUnit]}
              </MBText>
            </View>
            <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(20) }]}>
              <MBText bold>小计</MBText>
              <MBText color="#FF6969">¥{xyMath.accDiv(detailData.payMoney || 0, 100).toFixed(2)}</MBText>
            </View>
          </View>
          <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(20), paddingHorizontal: autoFix(20) }]}>
            <MBText>附加运费</MBText>
            <MBText>¥{serviceFeeDetailData.serviceFee || '0.00'}</MBText>
          </View>
          <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(20), paddingHorizontal: autoFix(20) }]}>
            <MBText>附加费率</MBText>
            <MBText>{serviceFeeDetailData.companyServiceRate || '0.00'}%</MBText>
          </View>
        </View>
        <View style={{ paddingTop: Platform.OS == 'ios' ? autoFix(1) : 0, backgroundColor: '#FFFFFF' }}>
          <Splitline color="#E8E8E8" dashWidth={8} type="dashed" vertical={10} />
        </View>
        <View style={[styles.cardBox, { marginTop: 0 }]}>
          <MBText color="#999999" style={{ marginBottom: autoFix(20) }}>
            付款方式
          </MBText>
          {paymentList.map((item: any) => {
            return (
              <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(24) }]}>
                <MBText>{item.label}</MBText>
                <MBText>¥{item.value(detailData)}</MBText>
              </View>
            );
          })}
        </View>
      </>
    );
  };

  /**
   * 普票
   */
  renderGeneralTicketEle = () => {
    const { detailData } = this.props.store;
    return (
      <>
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: autoFix(10),
            padding: autoFix(28),
            width: autoFix(680),
            marginTop: autoFix(-15),
            position: 'relative',
            zIndex: 100,
          }}
        >
          <View style={{ padding: autoFix(20), backgroundColor: '#F9F9F9' }}>
            <View style={[styles.flexRow, { justifyContent: 'space-between' }]}>
              <MBText>运费单价</MBText>
              <MBText>
                ¥{xyMath.accDiv(detailData.freightUnitPrice || 0, 100)}
                {detailData.settlementUnit != 1 && KeyUnitMap[detailData.settlementUnit]
                  ? ' x ' +
                    (detailData.settlementUnit == 1
                      ? parseFloat(xyMath.accDiv(detailData[KeyUnitMap[1]], 100).toFixed(2))
                      : detailData[KeyUnitMap[detailData.settlementUnit]] || '0') +
                    ' '
                  : ''}
                {detailData.settlementUnit === 1 ? '/' : ''}
                {UnitMap[detailData.settlementUnit]}
              </MBText>
            </View>
            <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(20) }]}>
              <MBText bold>小计</MBText>
              <MBText color="#FF6969">¥{xyMath.accDiv(detailData.payMoney || 0, 100).toFixed(2)}</MBText>
            </View>
          </View>
          <FeeItemNewList {...this.props} type="detail" />
        </View>
      </>
    );
  };

  render(): JSX.Element {
    const { carryInfoList, visibleImageView } = this.state;
    const { detailData } = this.props.store;
    const invoiceFlagIsGeneralTicket = this.props.store.invoiceFlagIsGeneralTicket;

    return (
      <View style={{ flex: 1, margin: autoFix(20), position: 'relative' }}>
        <View
          style={{
            position: 'absolute',
            width: autoFix(680),
            height: autoFix(100),
            borderTopLeftRadius: autoFix(20),
            borderTopRightRadius: autoFix(20),
            zIndex: 50,
            backgroundColor: '#4885FF',
          }}
        >
          {Platform.OS === 'ios' && (
            <Image
              resizeMode="stretch"
              fadeDuration={0}
              style={{
                width: autoFix(680),
                height: autoFix(100),
                borderTopLeftRadius: autoFix(20),
                borderTopRightRadius: autoFix(20),
              }}
              source={images.blueGradient}
            />
          )}
        </View>
        <View
          style={[
            styles.flexRow,
            {
              zIndex: 100,
              justifyContent: 'space-between',
              padding: autoFix(28),
              paddingBottom: autoFix(40),
            },
          ]}
        >
          <MBText size="md" color="#ffffff">
            总运费
          </MBText>
          <MBText color="#ffffff">¥{xyMath.accDiv(detailData.totalMoney || 0, 100).toFixed(2)}</MBText>
        </View>
        {invoiceFlagIsGeneralTicket ? this.renderGeneralTicketEle() : this.renderSpecialTicketEle()}
        <View style={{ backgroundColor: '#ffffff', borderRadius: autoFix(10), marginTop: autoFix(20), paddingBottom: autoFix(20) }}>
          <DataTimeAddress boxStyle={{ marginTop: 0 }} isDetail={true} />
        </View>
        <View style={styles.cardBox}>
          <MBText color="#999999" style={{ marginBottom: autoFix(20) }}>
            承运信息
          </MBText>
          {carryInfoList.map((item: any) => {
            return (
              <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(24) }]}>
                <MBText>{item.label}</MBText>
                {item.value(detailData)}
              </View>
            );
          })}
        </View>
        {invoiceFlagIsGeneralTicket ? (
          <View style={styles.cardBox}>
            <MBText color="#999999" style={{ marginBottom: autoFix(20) }}>
              付款时间
            </MBText>
            <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(24) }]}>
              <MBText>最晚卸货后</MBText>
              <MBText>{detailData.payDelayDays} 天</MBText>
            </View>
          </View>
        ) : null}
        <View style={styles.cardBox}>
          <MBText color="#999999" style={{ marginBottom: autoFix(20) }}>
            补充约定
          </MBText>
          <View style={[styles.flexRow, { justifyContent: 'space-between', marginTop: autoFix(24) }]}>
            <MBText>补充约定</MBText>
            <MBText>{detailData.note || '-'}</MBText>
          </View>
        </View>
        {/* 驾驶证预览 */}
        {!!detailData?.vehicleLicenseUrl && (
          <ImageView
            visible={visibleImageView}
            onCancel={() => this.setState({ visibleImageView: false })}
            imageUrls={[{ url: detailData?.vehicleLicenseUrl || null }]}
            index={0}
          />
        )}
      </View>
    );
  }
}
