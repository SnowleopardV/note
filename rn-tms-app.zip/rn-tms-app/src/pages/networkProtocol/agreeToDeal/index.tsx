import * as React from 'react';
import { View, SafeAreaView, RefreshControl, ScrollView, Image } from 'react-native';
import { Button, MBText, Modal } from '@ymm/rn-elements';
import { inject, observer } from 'mobx-react';
import NavBar from '~/components/common/NavBar';
import { pageProps } from '../propTypes';
import styles from '../styles';
import MBTabs from '~/components/common/MBTabs';
import DetailAgreement from './DetailAgreement';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import AugmentAgreement from './AugmentAgreement';
import API from '../api';
import EmptyPage from '~/components/common/EmptyPage';
import images from '~public/static/images';
import xyMath from '~/extends/xyMath';
import Agreement from '../components/ContentAgreement/Agreement';

@inject('store')
@observer
export default class AgreeToDeal extends React.Component<pageProps, any> {
  constructor(props: pageProps) {
    super(props);
    this.state = {
      currentIndex: 0,
      tabs: [
        {
          name: 0,
          title: '协议详情',
          content: () => {
            return <DetailAgreement />;
          },
        },
        {
          name: 1,
          title: '增补协议',
          content: (isHasData: any) => {
            return isHasData ? (
              <AugmentAgreement updateDetail={() => this.api_Detail(false)} navigation={this.props.navigation} />
            ) : (
              <EmptyPage style={{ backgroundColor: '#F0F0F0' }} errorData={{ msg: '暂无增补协议数据', image: images.icon_empty_data }} />
            );
          },
        },
      ],
    };
  }
  componentDidMount() {
    this.api_Detail(true);
  }
  changeTab = (index: number) => {
    this.setState({ currentIndex: index });
  };

  // 确认/拒绝协议(主协议)
  onAgreementConfirmRefuse = (auditType: number) => {
    const {
      getFrom: { userId },
      detailData: { orderId, contractID, payMoney, totalMoney },
      invoiceFlagIsGeneralTicket,
      serviceFeeDetailData,
    } = this.props.store;
    const text = auditType === 1 ? '确认协议内容？' : '确认拒绝协议？';

    Modal.Confirm({
      title: '提示',
      headerLine: false,
      content: (
        <View>
          <MBText>{text}</MBText>
        </View>
      ),
      cancelText: '取消',
      confirmText: '确定',
      onConfirm: () => {
        this.api_agreementConfirmRefuse({
          orderId,
          contractId: contractID,
          auditType,
          userId,
          feeItemNewList: invoiceFlagIsGeneralTicket ? serviceFeeDetailData.feeItemNewList : null,
          payMoney,
          totalMoney,
        });
      },
      onCancel: () => {},
    });
  };

  submitEdit() {
    console.log('修改');
    this.props.navigation.navigate('editAgreement');
  }
  goPage(name: string) {
    console.log('跳转name', name);
    this.props.navigation.navigate(name);
  }
  /** 获取附加运费 */
  api_protocolGetServiceFee(val: string) {
    return API.protocolGetServiceFee({ amount: val }).then((res: any) => {
      if (res.data) {
        res.data.serviceFee = xyMath.accDiv(res.data.serviceFee || 0, 100).toFixed(2);
        this.props.store.setServiceFeeDetailData(res.data);
      }
    });
  }
  /** 第一次进入页面 如果有增补协议 就先显示增补协议，其他刷新数据无需切换tab */
  api_Detail(isSupplements: boolean = false) {
    const { orderId, userId, companyId } = this.props.store.getFrom;
    API.protocolDetail({ orderId, companyId, userId })
      .then((res: any) => {
        console.log('----------api_Detail------------');
        if (res.data) {
          this.props.store.setDetailData(res.data);

          if (res.data?.allSupplements && res.data?.allSupplements?.length && isSupplements) {
            this.setState({ currentIndex: 1 });
          }
          this.api_protocolGetServiceFee(res.data.payMoney).then(_ => {
            this.props.store.setTotalMoney();
          });
        }
      })
      .catch((err: any) => {
        console.log('协议详情:', err);
      });
  }

  api_agreementConfirmRefuse = (params: any) => {
    API.protocolAudit(params).then((res: any) => {
      if (res.success) {
        // 更新协议详情
        this.api_Detail(false);
      }
    });
  };
  /** 撤回主协议 */
  revokeAgree = () => {
    Modal.Confirm({
      title: '撤回协议',
      headerLine: false,
      content: '是否确定撤回协议',
      cancelText: '取消',
      confirmText: '确定',
      onConfirm: () => {
        console.log('确定撤回协议');
        setTimeout(() => this.api_withdrawContract(), 650);
      },
    });
  };
  api_withdrawContract() {
    const { detailData, getFrom } = this.props.store;
    const data = {
      orderId: detailData.orderId, // 平台订单ID
      contractId: detailData.contractID, // 协议ID
      userId: getFrom.userId, // userId
    };
    API.withdrawContract(data).then((res: any) => {
      if (res.success) {
        this.api_Detail(false);
      }
    });
  }
  public render() {
    const { tabs, currentIndex } = this.state;
    const { allSupplements, status, proposerRole } = this.props.store?.detailData || {};
    const BottomBtnMap = {
      // 司机发起，货主确认或拒绝
      1: () => (
        <>
          <Button
            radius
            style={{ backgroundColor: '#FFFFFF', width: autoFix(228), marginRight: autoFix(20) }}
            type="primary"
            onPress={() => this.onAgreementConfirmRefuse(2)}
            size="sm"
            textStyle={{ color: '#4885FF' }}
          >
            拒绝
          </Button>
          <Button radius style={styles.btn} onPress={() => this.onAgreementConfirmRefuse(1)} size="sm" type="primary">
            同意
          </Button>
        </>
      ),
      // 货主发起协议，司机确认，
      2: () => (
        <>
          <Button
            radius
            style={[styles.btn, { backgroundColor: '#FEF5E2', borderColor: '#FEF5E2' }]}
            type="primary"
            size="sm"
            textStyle={{ color: '#FAAD14' }}
          >
            待对方确认
          </Button>
          <Button radius style={[styles.btn, { marginLeft: autoFix(20) }]} type="primary" size="sm" onPress={() => this.revokeAgree()}>
            撤回协议
          </Button>
        </>
      ),
      // /* 司机发起，货主拒绝，等待司机重新创建，或者货主自己重新创建
      3: () => (
        <>
          <Button radius style={[styles.btn]} type="primary" size="sm" onPress={() => this.goPage('createAgreement')}>
            重新发起协议
          </Button>
        </>
      ),
    };
    return (
      <View style={[styles.page, { backgroundColor: '#F0F0F0' }]}>
        <NavBar title="货物运输交易协议" />
        <MBTabs
          key="AgreeToDeal"
          tabs={[...tabs]}
          onTabChange={this.changeTab}
          defaultIndex={currentIndex}
          renderTitle={(isActive: boolean, name: string) => <MBText style={{ color: isActive ? '#4885FF' : '#000' }}>{name}</MBText>}
          renderList={(index: number) => {
            return (
              <ScrollView
                refreshControl={<RefreshControl refreshing={false} onRefresh={() => this.api_Detail(false)} />}
                style={{ flex: 1 }}
              >
                {tabs[index].content(allSupplements)}
              </ScrollView>
            );
          }}
        />
        {currentIndex === 0 || !allSupplements ? (
          <View style={[styles.shadow, { backgroundColor: '#fff' }]}>
            {currentIndex === 0 && (
              <View style={[styles.bottomBtn]}>
                <Image style={{ height: autoFix(30), width: autoFix(30), marginRight: autoFix(10) }} source={images.icon_check_gray} />
                <Agreement {...this.props} />
              </View>
            )}
            {!allSupplements && (
              <View style={styles.bottomBtn}>
                {status == 0 && proposerRole && BottomBtnMap[proposerRole]()}
                {/* 司机发起，货主拒绝，等待司机重新创建 */}
                {(status == 2 || status == 3) && BottomBtnMap[3]()}
                {status == 1 && (
                  <Button radius style={styles.btn} onPress={() => this.submitEdit()} size="sm" type="primary">
                    修改协议
                  </Button>
                )}
              </View>
            )}
          </View>
        ) : null}
        <SafeAreaView style={{ backgroundColor: '#FFFFFF' }}></SafeAreaView>
      </View>
    );
  }
}
