import { Button, MBText, Modal } from '@ymm/rn-elements';
import { autoFix } from '@ymm/rn-elements/lib/util/scale';
import React from 'react';
import { inject, observer } from 'mobx-react';
import { ScrollView, Image, View, Platform } from 'react-native';
import { pageProps } from '../propTypes';
import styles from '../styles';
import images from '~public/static/images';
import API from '../api';
import { platform } from 'os';

@inject('store')
@observer
export default class AugmentAgreement extends React.Component<any, any> {
  constructor(props: pageProps) {
    super(props);
  }

  onLayoutAddress(el: any, index: number) {
    const { timeLineHeight, settimeLineHeight } = this.props.store;
    if (timeLineHeight.length - 1 !== index) {
      const arr = [...timeLineHeight];
      arr[index] = el?.nativeEvent?.layout?.height ?? 0;
      settimeLineHeight(arr);
    }
  }

  // 确认/拒绝协议
  onAgreementConfirmRefuse = (row: any, item: any) => {
    const {
      getFrom: { userId },
      detailData: { contractID, payMoney, totalMoney },
      invoiceFlagIsGeneralTicket,
      serviceFeeDetailData,
    } = this.props.store;
    const { orderId, id } = item;
    const { content, type } = row;
    if (content) {
      Modal.Confirm({
        title: '提示',
        headerLine: false,
        content: (
          <View>
            <MBText>{content}</MBText>
          </View>
        ),
        cancelText: '取消',
        confirmText: '确定',
        onConfirm: () => {
          if (type === 'confirm' || type === 'refuse') {
            const auditType = type === 'confirm' ? 1 : 2;
            const params = {
              orderId,
              contractId: contractID,
              contractSupplementId: id,
              auditType,
              userId,
              feeItemNewList: invoiceFlagIsGeneralTicket ? serviceFeeDetailData.feeItemNewList : null,
              payMoney,
              totalMoney,
            };
            this.api_agreementConfirmRefuse(params);
          } else if (type === 'revoke') {
            const params = { orderId, contractId: contractID, contractSupplementId: id };
            this.api_agreementRevoke(params);
          }
        },
        onCancel: () => {},
      });
    } else {
      if (type === 'edit') {
        this.props.navigation.navigate('editAgreement'); // 去修改页面
      }
    }
  };

  api_agreementConfirmRefuse = (params: any) => {
    const { updateDetail } = this.props;
    API.protocolAuditSupplement(params)
      .then((res: any) => {
        if (res.success) {
          // 更新协议详情
          updateDetail();
        }
      })
      .catch((err: any) => {
        console.log('api_agreementConfirmRefuse', err);
      });
  };

  api_agreementRevoke = (params: any) => {
    const { updateDetail } = this.props;
    API.protocolWithdrawSupplement(params)
      .then((res: any) => {
        if (res.success) {
          // 更新协议详情
          updateDetail();
        }
      })
      .catch((err: any) => {
        console.log('api_agreementRevokeerr', err);
        updateDetail();
      });
  };

  render(): JSX.Element {
    const {
      timeLineHeight,
      detailData: { allSupplements },
    } = this.props.store;

    return (
      <View
        style={{
          flex: 1,
          marginVertical: autoFix(20),
          borderRadius: autoFix(10),
          backgroundColor: '#FFFFFF',
          paddingHorizontal: autoFix(50),
          paddingVertical: autoFix(30),
        }}
      >
        {allSupplements &&
          allSupplements.map((item: any, index: number) => {
            return (
              <View
                key={index}
                style={{ position: 'relative', paddingBottom: autoFix(36) }}
                onLayout={(el) => this.onLayoutAddress(el, index)}
              >
                <View style={[styles.stepLine, { top: autoFix(20), left: autoFix(6) }]}>
                  {index < allSupplements.length - 1 && !!timeLineHeight[index] && (
                    <View
                      style={{
                        height: timeLineHeight[index],
                        width: autoFix(1),
                        borderColor: '#eee',
                        borderWidth: autoFix(1),
                        borderStyle: 'dashed',
                      }}
                    ></View>
                  )}
                </View>
                <View style={[styles.flexRow, { justifyContent: 'space-between' }]}>
                  <View style={[styles.flexRow]}>
                    <View style={[styles.timeLinePoint, { backgroundColor: !index ? '#4885FF' : '#CBCED6' }]}></View>
                    <MBText style={{ marginLeft: autoFix(10) }} color={!index ? '#4885FF' : '#666666'}>
                      {item.name}
                    </MBText>
                  </View>
                  <MBText size="sm" style={{ marginLeft: autoFix(10) }} color={!index ? '#4885FF' : '#666666'}>
                    {item.time}
                  </MBText>
                </View>
                {!!item.content && (
                  <View
                    style={{
                      backgroundColor: '#F9F9F9',
                      paddingHorizontal: autoFix(16),
                      paddingVertical: autoFix(20),
                      marginTop: autoFix(16),
                      marginLeft: autoFix(50),
                    }}
                  >
                    {item.content.map((row: any) => {
                      return (
                        <View style={[styles.freightFlexColumn, { paddingBottom: autoFix(10) }]}>
                          <MBText color="#525866" size="xs">
                            {row.label}
                          </MBText>
                          <MBText color="#525866" size="xs" style={{ flex: 1 }}>
                            {row.value || '-'}
                          </MBText>
                        </View>
                      );
                    })}
                    <View style={[styles.flexRow, { justifyContent: 'flex-end', marginTop: autoFix(20) }]}>
                      {item.btnList &&
                        index == 0 &&
                        item.btnList.map((row: any) => {
                          return (
                            <Button
                              type="bordered"
                              style={{ borderRadius: autoFix(10), width: autoFix(148), marginLeft: autoFix(16), borderColor: row.color }}
                              textStyle={{ color: row.color }}
                              size="xs"
                              onPress={() => this.onAgreementConfirmRefuse(row, item)}
                            >
                              {row.name}
                            </Button>
                          );
                        })}
                    </View>
                    {!!item.img && (
                      <Image
                        style={{
                          height: autoFix(152),
                          width: autoFix(153),
                          position: 'absolute',
                          bottom: index == 0 && item.btnList.length ? autoFix(100) : autoFix(60),
                          right: autoFix(30),
                        }}
                        source={item.img}
                      />
                    )}
                  </View>
                )}
              </View>
            );
          })}
      </View>
    );
  }
}
