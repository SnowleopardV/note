// @ts-nocheck
/**
 * 正则表达式
 */
export const pattern = {
  phone: /^1[0-9]{10}$/,
  telphone: /^[(（）)\-02-9][(（）)\-0-9]{1,19}$/,
  fee: /^[0-9]{0,9}(?:\.\d{1,4})?$/,
  mileage: /^[0-9]{0,6}(?:\.\d{1})?$/,
  car: /(^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}(([0-9]{5}[A-Z]$)|([A-Z][A-HJ-NP-Z0-9][0-9]{4}$)))|(^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳]{1}$)/,
  guaCar: /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼]{1}[A-Z]{1}[0-9]{4}$/,
  specialSymbolReg: /[^\u4e00-\u9fa5\da-zA-Z\s]/,
};
const validator = {
  /**
   * 校验手机号
   * @param {string} value
   */
  phone(value) {
    return pattern.phone.test(value);
  },
  // 座机号码
  telphone(value) {
    // return /^([0-9]|[-()（）]){1,}$/.test(value) && /^0[0-9]{10,}$/.test(value.replace(/[-()（）]/g, '')) && value.length <= 20
    return pattern.telphone.test(value);
  },
  /**
   * 费用一律限制整数位9位，精确2位小数
   * @param {number} value
   */
  fee(value) {
    return pattern.fee.test(value);
  },
  /**
   * 公里数
   * @param {*} value
   */
  mileage(value) {
    return pattern.mileage.test(value);
  },
  /**
   * 校验密码
   */
  checkPwd(value) {},
  /**
   * 车牌号
   * @param {string} value
   */
  car(value) {
    return pattern.car.test(value);
  },
  /**
   * 挂车车牌号
   * @param {string} value
   */
  guaCar(value) {
    return pattern.guaCar.test(value);
  },
  /**
   * 表情
   * @param str
   */
  emoji: function (str) {
    const reg =
      /[^\u0020-\u007E\u00A0-\u00BE\u2E80-\uA4CF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\u0080-\u009F\u2000-\u201f\u2026\u2022\u20ac\r\n]/g;
    return reg.test(str);
  },

  /**
   * 金额
   * @param str
   */
  price: function (str) {
    const reg = /^(([0-9][0-9]{0,8})|(([0]\.\d{0,2}|[0-9][0-9]{0,8}\.\d{0,2})))$/;
    return reg.test(str);
  },

  /**
   * 可以负数的金额
   * @param str
   */
  negativePrice: function (str) {
    const reg = /^((-|-?[0-9][0-9]{0,8})|((-?[0]\.\d{0,2}|-?[0-9][0-9]{0,8}\.\d{0,2})))$/;
    return reg.test(str);
  },

  /**
   * 浮点型
   * @param str
   */
  float: function (str) {
    const reg = /^(([0-9][0-9]*)|(([0]\.\d{0,2}|[0-9][0-9]*\.\d{0,2})))$/;
    return reg.test(str);
  },

  /**
   * 整数
   * @param str
   */
  number: function (str) {
    const reg = /^(([1-9][0-9]*))$/;
    return reg.test(str);
  },

  /**
   * 纯数字
   * @param str
   */
  isDigit: function (str) {
    const reg = /^[0-9]*$/;
    return reg.test(str);
  },

  /**
   * 详细地址
   * @param str
   */
  address: function (str) {
    const reg = /^[a-zA-Z0-9_\u4e00-\u9fa5-]+$/;
    return reg.test(str);
  },

  // /**
  //  * 手机号
  //  * @param str
  //  */
  // phone: function (str) {
  //   const reg = /^1[3,4,5,6,7,8,9]\d{9}$/;
  //   return reg.test(str);
  // },

  /**
   * 货物名称校验，至少包含一个中文
   * 纯数字字母特殊符号都不允许
   * @param str 货物名称
   */
  cargoName: function (str) {
    const reg = /[\u4e00-\u9fa5]+?/;
    return reg.test(str);
  },

  /**
   * 过滤特殊字符
   * @param str
   */
  specialChar: function (str) {
    return pattern.specialSymbolReg.test(str);
  },

  /**
   * 只允许输入：中文、英文、数字
   * @param str
   */
  userName: function (str) {
    const reg = /^[a-zA-Z0-9\u4e00-\u9fa5]+$/;
    return reg.test(str);
  },

  /**
   * 过滤搜索货物名中的特殊字符
   * 废弃：包含：空格，中英文逗号、句号、分号、引号，小括号，中括号，大括号，斜杠
   * !只允许包含：中文，英文，数字，必须含有中文
   */
  filterSpecialSymbol: function (str) {
    // return str.replace(/[\s,，。;'"“”‘’()（）\[\]\/{}]/g,'')
    return str.replace(/[^\u4e00-\u9fa5\da-zA-Z]/g, '');
  },
};
/**
 * 验证手机和固话
 * 1. 输入开头如果是1，说明是手机，只可以输入11位，并格式化344
 * 2. 如果不是1，说明是固话或国外号码，可以输入-，（），等字符，包含支持中英符号, 长度最长20位
 */
export const validatePhone = (rule, value, callback) => {
  value = value.replace(/\s/g, '');
  if (validator.phone(value) || validator.telphone(value)) {
    callback();
  } else {
    callback(new Error('请输入正确的手机号或座机号'));
  }
};

/**
 * @description: 根据最大值和最小值校验费用
 * @param {number} min 最小值(含) 默认0
 * @param {number} max 最大值(含) 默认100，最大值不能超过10位整数。
 * @return 校验函数
 */
export const validateFeeByMinAndMax = (min = 0, max = 100) => {
  return (rule, value, callback) => {
    if (!value) {
      callback();
      return;
    }

    const res = pattern.fee.exec(value);
    if (res && res[0] >= min && res[0] <= max) {
      callback();
    } else {
      callback(new Error(`必须大于${min}，小于${max}`));
    }
  };
};

export default validator;
