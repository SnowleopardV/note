import { MBBridge, RNBridge } from '@ymm/rn-lib';

/**
 * 打开地址选择
 * @param value
 * @param callback
 */
export function selectPlace(value: any, callback: any) {
  const param: any = {
    type: value && value?.type ? value?.type : 0,
    code: value && value.code ? value.code : -1,
    traceId: value.traceId ? value.traceId : '',
    from: value?.from || 0,
    referName: value.referName ? value.referName : '',
    isEditableCargo: value.isEdit ? value.isEdit : '0',
    isSpecialLine: value.isSpecialLine,
    commonCity: value.commonCity ? value.commonCity : '',
    openCity: value.openCity ? value.openCity : '',
    commonEndCity: value.commonEndCity ? value.commonEndCity : '',
    country: value.country != undefined ? value.country : 1,
    fixspecial: 0, //短途“开通城市”固定在顶部
    defaultselectcommon: 0, // 默认选中常用开关 1 开 0 关(默认)
    primarycolor: '4885FF',
  };
  RNBridge.invoke(
    {
      module: 'rnruntime',
      // business: 'script',
      method: 'invokeUrl',
      params: { url: 'ymm://base/citypicker?theme=1', data: param },
    },
    (success: boolean, result: any) => {
      callback && callback(result?.data, result?.data?.source);
    }
  );

  // if (YMMPublishRNBridgeModule && typeof YMMPublishRNBridgeModule.rn_ios_PublishRegionView === 'function') {
  //   YMMPublishRNBridgeModule.rn_ios_PublishRegionView(param, (result: any) => {
  //     callback(result, result.source);
  //   });
  // }
}
/**
 * 根据名字获取区县Region信息
 * @param params
 * @param callback
 */
export function getCountyRegion(params, callback: Function) {
  callback = callback || function (callbackParams) {};

  MBBridge.app.city.getCountyRegion(params).then((res) => {
    if (res?.code == 0) {
      if (res && res?.data) {
        callback(res?.data);
      } else {
        callback();
      }
    } else {
      callback();
    }
  });
}
