import { NativeModules } from 'react-native';
import { MBLog, MBBridge, URLUtils } from '@ymm/rn-lib';
/**
 * 打开地址选择
 * @param value
 * @param callback
 */
export function selectPlace(value: any, callback: any) {
  const url = 'ymm://base/citypicker';
  const param = {
    theme: 1,
    type: value && value?.type ? value?.type : 0,
    code: value && value.code ? value.code : -1,
    from: value?.from || 0,
    country: value.country != undefined ? value.country : 1,
    traceid: value.traceId ? value.traceId : '',
    refername: value.referName ? value.referName : '',
    isedit: value.isEdit ? value.isEdit : '0',
    isspecialline: value.isSpecialLine,
    fixspecial: 0, //短途“开通城市”固定在顶部
    defaultselectcommon: 0, // 默认选中常用开关 1 开 0 关(默认)
    primarycolor: '#4885FF', // 主题颜色
  };
  NativeModules.activity.startActivity(
    {
      schema: URLUtils.appendParamsToUrl(url, param),
      slideAnim: 1,
    },
    (result: any) => {
      callback(result.place ? JSON.parse(result.place) : {}, result.source);
    }
  );
}
/**
 * 根据名字获取区县Region信息
 * @param params
 * @param callback
 */
export function getCountyRegion(params, callback: Function) {
  callback =
    callback ||
    function (callbackParams) {
      return;
    };
  // 行政区城市合并问题 - 新老bridge替换
  MBBridge.app.city.getCountyRegion(params).then((res) => {
    if (res?.code == 0) {
      if (res && res?.data) {
        callback(res.data);
      } else {
        callback();
      }
    } else {
      callback();
    }
  });
}
