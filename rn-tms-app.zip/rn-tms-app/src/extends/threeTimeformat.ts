import dayjs, { Dayjs } from 'dayjs';
/**
 * api:https://wiki.1111.com/pages/viewpage.action?pageId=103234587
 * 比较当前时间，如果小于当前时间 修改为：当天+当前时间+1小时
 * （如果分钟<=30,则加1个小时，>30则加2个小时。比如当前是5:19，那么修改为6点，如果是5:45，那么修改为7点）
 * {
	"loadTime": {
		"dateCode": "20210618",
		"displayValue": "06月18日 上午 8:00",
		"endTimestamp": 1623974400000,
		"hourPeriod": 8,
		"startTimestamp": 1623970800000,
		"timeInterval": 2
	}
}
 */
export default function (timeItem: any) {
  if (!timeItem || (timeItem && dayjs(timeItem.endTimestamp).valueOf() <= dayjs().valueOf())) {
    const nowMinute = dayjs().minute().valueOf();
    let endTimestamp = null;
    let startTimestamp = null;
    let dateCode = null;
    let displayValue = null;
    let hourPeriod = null;
    let timeInterval = null;
    if (nowMinute > 30) {
      endTimestamp = dayjs().add(2, 'hour').startOf('hour');
      startTimestamp = dayjs(endTimestamp).subtract(1, 'hour').startOf('hour');
    } else {
      endTimestamp = dayjs().add(1, 'hour').startOf('hour');
      startTimestamp = dayjs(endTimestamp).subtract(1, 'hour').startOf('hour');
    }
    dateCode = dayjs(endTimestamp).format('YYYYMMDD');
    hourPeriod = dayjs(endTimestamp).hour().valueOf();
    timeInterval = getTimeInterval(hourPeriod);
    let dateText = dayjs(endTimestamp).format('MM月DD日');
    let timeText = dayjs(endTimestamp).format('HH:mm');
    if (timeText === '00:00') {
      timeText = '24:00';
      dateText = dayjs(endTimestamp).subtract(1, 'day').format('MM月DD日');
      dateCode = dayjs(endTimestamp).subtract(1, 'day').format('YYYYMMDD');
      hourPeriod = 24;
      timeInterval = 4;
    }
    displayValue = dateText + ' ' + dateTimeMap(timeInterval) + ' ' + timeText;
    return {
      dateCode: dateCode,
      displayValue: displayValue,
      endTimestamp: endTimestamp.valueOf(),
      hourPeriod: hourPeriod,
      startTimestamp: startTimestamp.valueOf(),
      timeInterval: timeInterval,
    };
  } else {
    return timeItem;
  }
}

function getTimeInterval(hourPeriod: number) {
  if (hourPeriod > 0 && hourPeriod <= 6) {
    return 1;
  } else if (hourPeriod > 6 && hourPeriod <= 12) {
    return 2;
  } else if (hourPeriod > 12 && hourPeriod <= 18) {
    return 3;
  } else if (hourPeriod > 18 && hourPeriod <= 24) {
    return 4;
  }
}

function dateTimeMap(index: number | undefined) {
  switch (index) {
    case 1:
      return '凌晨';
    case 2:
      return '上午';
    case 3:
      return '下午';
    case 4:
      return '晚上';
    default:
      return '';
  }
}

/** 带中文的时间 */
export function stringTime(timeItem: number) {
  const timeText = dayjs(timeItem).format('HH:mm');
  const Y = dayjs(timeItem).year(),
    M = dayjs(timeItem).month(),
    D = dayjs(timeItem).date(),
    nowY = dayjs().year(),
    nowM = dayjs().month(),
    nowD = dayjs().date();
  let diffText = '';
  if (Y === nowY && M === nowM) {
    if (nowD - D === 2) {
      diffText = '前天';
    } else if (nowD - D === 1) {
      diffText = '昨天';
    } else if (nowD - D === 0) {
      diffText = '今天';
    } else if (nowD - D === -1) {
      diffText = '明天';
    }
  }
  return diffText + timeText;
}
