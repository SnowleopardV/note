/**
 * @description 金额转换 元 -> 分
 * @param {*} value 要转换的金额
 * @returns
 */
function moneyFormat(value) {
  if (value) {
    value = value * 100; // 转换为分
    return value.toFixed(0);
  } else {
    return '';
  }
}

/**
 *
 * @param {*} value 金额转换 分 -> 元
 * @returns
 */
function moneyDecFormat(value) {
  value = value / 100; // 转换为元
  if (!!parseFloat(value)) {
    var str = parseFloat(value).toFixed(2);
    return parseFloat(str);
  } else {
    return 0;
  }
}

export default { moneyFormat, moneyDecFormat };
