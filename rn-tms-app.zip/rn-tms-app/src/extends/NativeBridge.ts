import { URLUtils, MBBridge, App, MBLog, MBToast, RNBridge, ExtendUtils } from '@ymm/rn-lib';
import { NativeModules, Platform, NativeEventEmitter, Alert } from 'react-native';

type NormalCallBack = (d: any) => void;
type OpenUrlCallBack = (response: { success: boolean }) => void;
let userInfo = {}; // 用户信息
const Bridge = {
  getFileURL: async function (filePath: string, callback: (fileUrl: string) => void) {
    if (ExtendUtils.isURL(filePath)) {
      callback(filePath);
      return;
    }

    const result = await MBBridge.app.base.getConfigCenter({ defaultValue: '', key: 'fileUrl', group: 'server' });
    const fileUrl: string = result.data.value;
    if (ExtendUtils.stringIsEmpty(fileUrl)) {
      callback(filePath);
      return;
    }
    const fileUrlArray: string[] = fileUrl.split(',');
    if (fileUrlArray.length > 0) {
      callback(fileUrlArray[0] + filePath);
    } else {
      callback(filePath);
    }
  },

  /**
   * @methdd setOpenUrl
   * @param params Object
   * @param callback Function
   * @description 打开一个URL
   * @example
   */
  setOpenUrl: function (params: { url: string; isPresent?: boolean; delay?: number }, callback?: OpenUrlCallBack) {
    MBBridge.app.base.openSchema(params).then((res) => {
      if (res.code == 0) {
        callback && callback({ success: true });
      } else {
        callback && callback({ success: false });
      }
    });
  },

  /**
   * @methdd postNoti
   * @param params Object
   * @param callback Function
   * @description 通知
   * @example
   */
  postNoti: function (params: { data: any; name: string }) {
    App.sendEvent(params.name, params.data);
  },

  backToLastPage: function (callback?: NormalCallBack) {
    MBBridge.app.ui.closeWindow({});
  },

  /**
   *
   * @methdd toast
   * @param message string
   * @param callback Function
   * @description toast
   * @example
   * bridge.toast("abc")
   */
  toast: function (message: string) {
    MBToast.show(message, '2');
  },

  get: function (key: string, callback: (value: any) => void) {
    MBBridge.app.storage.getInMemory({ key: key }).then((res) => {
      if (res.code == 0) {
        callback && callback(res.data);
      }
    });
  },

  set: function (key: string, value: any, callback: () => void) {
    MBBridge.app.storage.saveInMemory({ key: key, text: value }).then((res) => {
      callback && callback();
    });
  },

  tmsUserGet: async function (key: string) {
    const userInfo = await this.getUserInfo();
    if (key) {
      return new Promise((resolve) => {
        this.storageRead(userInfo?.userId || '' + key, (text) => {
          resolve(text ? JSON.parse(text) : null);
        });
      });
    } else {
      return null;
    }
  },

  tmsUserSet: async function (key: string, value: any) {
    const userInfo = await this.getUserInfo();
    if (key) {
      return new Promise((resolve) => {
        this.storageSave(userInfo?.userId || '' + key, JSON.stringify(value), () => resolve());
      });
    } else {
      console.log('-------key 请输入字符串有值--------');
      return null;
    }
  },

  async getUserInfo() {
    if (Object.keys(userInfo)?.length) {
      return userInfo;
    } else {
      const res = await MBBridge.user.getUserInfo({});
      userInfo = res.data;
      return userInfo;
    }
  },

  resetAndPush: function (url: string, finishDelay: number, callback?: (d: any) => void) {
    const paramContent = {
      url,
      finishDelay,
    };
    MBBridge.app.page.closeAndJump(paramContent).then((res) => {
      if (res.code == 0) {
        callback && callback(res.data);
      }
    });
  },

  // 当前的tabItem名称
  isTabShow: function (params: any[], callback?: (d: any) => void) {
    MBBridge.app.ui.isTabShow({ tabInfoList: params }).then((res) => {
      MBLog.log('isTabShow + ' + JSON.stringify(res.data));
      if (res.code == 0) {
        callback && callback(res.data?.show);
      }
    });
  },
  //
  storageSave(key: string, value: any, callback?: (d: any) => void) {
    MBBridge.app.storage.setItem({ key: key, text: value }).then((res) => {
      if (res.code == 0) {
        callback && callback(res.data);
      }
    });
  },

  storageRead(key: string, callback?: (d: any) => void) {
    MBBridge.app.storage.getItem({ key: key }).then((res) => {
      if (res.code == 0) {
        callback && callback(res.data?.text);
      }
    });
  },
  /**
   * 打开日历
   */
  showCalendar: function (param: any, callback: (data: any) => void) {
    MBBridge.trade.ui.showCalendar(param).then((res) => {
      if (res.code == 0) {
        callback && callback(res.data);
      }
    });
  },

  // 拨打电话
  dial(params: any) {
    return MBBridge.app.phone.dial(params);
  },

  /** 打开app 内的 webView 容器页面 */
  openWebViewPage(url: string) {
    let webUrl = url;
    if (Platform.OS == 'ios') {
      webUrl = 'ymm://web/web?url=' + encodeURIComponent(url) + '&useMBWebView=1';
    }
    MBBridge.app.base.openSchema({ url: webUrl });
  },

  /** 得到跳转到tms-moblie项目的域名 */
  async getTmsMoblieUrl() {
    const res = await MBBridge.app.base.appInfo({});
    // http://yapi.1111.com/#/project/1649/interface/api/109538
    // serverType 0:dev 1:QA 3: release
    if (res.data.serverType === 0) return 'https://dev-yzg.tms8.com/tms-mobile/#/';
    else if (res.data.serverType === 1) return 'https://qa-yzg.tms8.com/tms-mobile/#/';
    else if (res.data.serverType === 3) return 'https://yzg.tms8.com/tms-mobile/#/';
    return '';
  },
};

export default Bridge;
