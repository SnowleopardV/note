import { observable, action } from 'mobx';
export interface ValidateMessage {
  message?: string;
  success: boolean;
}
export default abstract class BaseStore<P, S> {
  // 全局store
  @observable pageStore: any = null;
  // 状态数据
  @observable stateData: S;
  // 展示数据
  @observable moduleData: P;

  constructor(pageStore: any) {
    this.pageStore = pageStore;
    this.stateData = {} as any;
    this.moduleData = {} as any;
  }

  @action
  public saveModuleData = (moduleData: P): void => {
    this.moduleData = moduleData;
  };
  /**
   * 1. 当接口查询赋值操作
   * 2. 内部状态扭转，赋值操作
   * @param stateData
   */
  @action
  public saveStateData = (stateData: S): void => {
    this.stateData = stateData;
  };

  /**
   * 提交接口最终的方法
   */
  public getStateData = (): S => {
    return this.stateData;
  };

  validateRule = (): ValidateMessage => {
    return {
      success: true,
    };
  };
}
