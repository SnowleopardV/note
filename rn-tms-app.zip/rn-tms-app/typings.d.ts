declare interface TechLogParams {
  model: string; // 模块名
  scenario: string; // 场景名
  extraDic?: object; // 附带信息
  isBussinessLog?: boolean; // true 业务打点， false 技术打点
}

declare interface NormalLogParams {
  isBussinessLog?: boolean; // true 业务打点， false 技术打点
  pageName?: string; // 页面名
  referPageName?: string; // 上一页面名
  elementId: string; // 业务id
  eventType: 'tap' | 'view'; // 事件类型
  priority?: number; // 优先级 0 high 1 normal
  extraDic?: object; // 附带信息
}

declare interface AlertButton {
  text: string;
  color?: string;
  onClick?: (noLongerPopup?: number) => void;
}

declare interface ActionSheetButton {
  title: string;
  onClick?: () => void;
  color?: string;
}

declare interface AlertViewModel {
  title?: string;
  message?: string;
  messageArea?: string[];
  buttonList: AlertButton[];
  checkboxChecked?: number;
  checkBoxMessage?: string;
  closeImageClick?: () => void;
  hiddenHeadLine?: boolean;
}

declare interface ComponentFrame {
  x: number;
  y: number;
  width: number;
  height: number;
  pageX: number;
  pageY: number;
}

type NormalCallBack = () => void;

type AddressType = {
  province: number; // 省code
  provinceName: string; // 省名
  city: number; // 市code
  cityName: string; // 市名
  area: number; // 区code
  areaName: string; // 区名
  address: string;
  poiName?: string;
  latitude: string; // 纬度
  longitude: string; // 经度
};

declare interface ResponseData<T> {
  code: number;
  success: true;
  data: T;
}
