#!/usr/bin/env node

var sourceMap = require('source-map');
var path = require('path')
var fs = require('fs');

/**
 * 从sentry stack信息中提取line和column
 * e.g.
 *   at ? (app:///ymmcargo.jsbundle:23:1354)
 * 提取出 23 1354
 */
var linePattener = /\s*at\s.*\(.*jsbundle:(\d*):(\d*)\)/;

/**
 * 从bugly信息中提取line和column
 * e.g.
 *   onPress@ymmcargo.jsbundle:840:628 
 * 提取出 23 1354
 */
var buglyLinePattener = /(.*)@.*:(\d*):(\d*)/;

var sourcemapFile = process.argv[2]
var stackFile = process.argv[3]

stackFile = stackFile || './scripts/parse_error_stack/error.txt'

// console.log('===>开始解析JS异常Stack');
// console.log('===>sourceMap:' + sourcemapFile)
// console.log('===>堆栈信息:' + stackFile)

fs.exists(sourcemapFile, (exist) => {
   let stack = stackFile;
   console.log("\n错误堆栈>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> \n")
   if(exist){
      stack = fs.readFileSync(stackFile, 'utf8')
   }else{
     console.log('参数是源栈字串:')
   }
   let sourcemap = fs.readFileSync(sourcemapFile, 'utf8')
    stack=stack.replace(/\\n/g,'\n')
    parseStack(stack, sourcemap)

    console.log('\n')
})


function parseStack(stack, sourcemap){
  var smcPromise = new sourceMap.SourceMapConsumer(sourcemap);
  
  if(typeof(smcPromise.originalPositionFor) == 'function'){
    parseFile(smcPromise, stack);
  } else {
    smcPromise.then((smc)=>{
      parseFile(smc, stack)
    }, err=>{
      console.log('Oops')
      console.log(err)
    });
  }
}

function parseFile(smc, stack){
  var lines = stack.split('\n')

  lines.forEach((item,index,array)=>{
    var original = parseLine(item, smc)
    if(original){
      let {method, source, line, column, name} = original

      source = source.replace("/Users/tristan/code/cargo-rn/YMMCargoRNModule/ymmcargo", "");
      
      console.log(method + "@" + source + ":" + line + ":" + column);
    } else {
      console.log(item)
    }
  })
}

function parseLine(stackLine, smc){
  try{
    var matchResult = stackLine.match(buglyLinePattener)
    if(matchResult && matchResult.length == 4){
      var method = matchResult[1]
      var line = Number(matchResult[2])
      var column = Number(matchResult[3])
      // console.log(stackLine + "=>" + line + "  " + column)
      var origin = smc.originalPositionFor({
        line: line,
        column: column
      })
      origin.method=method;
      return origin
    } else {
      return null;
    }


    
  }catch(e){
    console.log(e)
  }
}



// export parseStack