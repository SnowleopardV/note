module.exports = {
  root: true,
  parser: '@typescript-eslint/parser',
  env: {
    browser: true,
    es6: true,
    node: true,
  },
  parserOptions: {
    sourceType: 'module',
    ecmaVersion: 6,
    ecmaFeatures: {
      jsx: true,
      experimentalObjectRestSpread: true,
    },
  },
  extends: [
    'plugin:mbrn/recommended',
    'plugin:@typescript-eslint/recommended',
    'prettier',
    'plugin:prettier/recommended',
    'prettier/react',
    'prettier/@typescript-eslint',
  ],
  plugins: ['@typescript-eslint', 'react', 'react-native', 'jsx-a11y', 'mbrn'],
  rules: {
    'no-console': 1,
    '@typescript-eslint/no-unused-expressions': 0,
    '@typescript-eslint/no-inferrable-types': 0,
    '@typescript-eslint/no-this-alias': 0, // 支持本地this 别名
    '@typescript-eslint/no-var-requires': 1,
    '@typescript-eslint/ban-ts-comment': 0,
    'react/forbid-elements': [
      'error',
      { forbid: [{ element: 'Text', message: "please use <MBText> from '@ymm/rn-elements' instead of it" }] },
    ],
    'prettier/prettier': [
      'error',
      {
        endOfLine: 'auto',
      },
    ],
    // 禁用debugger
    'no-debugger': 'warn',
    // 禁止出现空语句块
    'no-empty': 'warn',
    // 禁止使用多个空格
    'no-multi-spaces': 'warn',
    // 禁止多次声明同一变量
    'no-redeclare': 'warn',
    // 强制数组方括号中使用一致的空格
    'array-bracket-spacing': 'warn',
    // 强制在代码块中使用一致的大括号风格
    'brace-style': 'warn',
    // 强制使用一致的缩进
    indent: 'off',
    // 强制最大行数 1000
    'max-lines': ['warn', { max: 1000 }],
    // 禁止空格和 tab 的混合缩进
    'no-mixed-spaces-and-tabs': 'warn',
    // 禁止出现多行空行
    'no-multiple-empty-lines': 'warn',
    // 禁止出现多行空行
    'no-multiple-empty-lines': 'warn',
    // 要求操作符周围有空格
    'space-infix-ops': 'warn',
    // 强制在一元操作符前后使用一致的空格
    'space-unary-ops': 'warn',
  },
};
