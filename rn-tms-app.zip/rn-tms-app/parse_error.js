const sourceMap = require('source-map');
const fs = require('fs');
const readlineSync = require('readline-sync');

const line = readlineSync.question('请输入行号：');
const column = readlineSync.question('请输入列号：');

fs.readFile('./dist/ios/index.map', 'utf8', function (err, data) {
  if (err) {
    console.error(err)
    return
  }

  var smc = new sourceMap.SourceMapConsumer(data);
  smc.then(result => {
    let r = result.originalPositionFor({
      line: line,
      column: column
    })
    console.log(`source:${r.source}`)
    console.log(`line:${r.line}`)
    console.log(`column::${r.column}`)
  })
});