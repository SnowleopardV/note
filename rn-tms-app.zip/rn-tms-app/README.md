TMS-RN 版承运商 app

TMS 内置/动态包分支命名 ：

| 分支类型     |                     分支命名                     | 备注 |
| :----------- | :----------------------------------------------: | ---: |
| release 分支 |   v${appver}/release/${date}/${static/dynamic}   |      |
| feature 分支 | v${appver}/feature/${date}/${static/dynamic}-xxx |      |

RN 包版本号规范：
https://wiki.1111.com/pages/viewpage.action?pageId=237510303
