import './extra';
import { AppRegistry } from 'react-native';
import { CrashReporter } from '@ymm/rn-lib';
import dispatch from '~/pages/dispatch/dispatch-add/Router/index'; // 创建调度
import dispatchEdit from '~/pages/dispatch/dispatch-edit/Router/index'; // 修改调度
import dispatchStowage from '~/pages/dispatch/dispatch-stowage/Router/index'; //配载调度
import newCars from '~/pages/newCars'; // 新增车辆
import newDrivers from '~/pages/newDrivers'; // 新增承运司机
import newCarrier from '~/pages/newCarrier'; // 新增承运商
import WaybillCreate from '~/pages/waybill/Router/index'; // 创建运单
import CustomerChooseIndex from '~/pages/waybill/customer/Add';
import CustomerPage from '~/pages/waybill/customer/Router/index';
import GoodsInfo from '~/pages/waybill/goods-info';
import DetailAddress from '~/pages/detail-address';
import TaskManage from '~/pages/task-manage/routerList'; // 任务管理
import TaskDetail from '~/pages/task-manage/routerDetail'; // 任务详情
import WaybillList from '~/pages/waybill-manage/routerList'; // 运单管理
import WaybillDetail from '~/pages/waybill-manage/routerDetail';
import About from '~/pages/about/Router/index'; // 关于我们
import CargoAddress from '~/pages/waybill/cargo-address/Router/index'; // 收发货地址
import Home from '~/pages/home/index'; // 收发货地址
import WaybillEdit from '~/pages/waybill/Router/edit'; // 修改运单
import Approve from '~/pages/approve/Router/index'; // 审批列表
import networkProtocol from '~/pages/networkProtocol/Router/index'; // 创建协议
import CreateOrderSetting from '~/pages/createOrderSetting/index'; // 开单设置
import callRecords from '~/pages/callRecords/Router/index'; // 通话记录
import CustomerManagement from '~/pages/customer-management/Router/index'; // 客户管理

CrashReporter.register('rn-tms-app');

AppRegistry.registerComponent('home', () => Home);
AppRegistry.registerComponent('waybillcreate', () => WaybillCreate);
AppRegistry.registerComponent('dispatch', () => dispatch); // 创建调度
AppRegistry.registerComponent('dispatchedit', () => dispatchEdit); // 修改调度
AppRegistry.registerComponent('newcars', () => newCars); // 新增车辆
AppRegistry.registerComponent('newdrivers', () => newDrivers); // 新增承运司机
AppRegistry.registerComponent('newcarrier', () => newCarrier); // 新增承运商
AppRegistry.registerComponent('dispatchstowage', () => dispatchStowage); // 配载调度
AppRegistry.registerComponent('taskmanage', () => TaskManage);
AppRegistry.registerComponent('taskdetail', () => TaskDetail);
AppRegistry.registerComponent('waybillmanage', () => WaybillList);
AppRegistry.registerComponent('waybilldetail', () => WaybillDetail);
AppRegistry.registerComponent('customerchoose', () => CustomerChooseIndex);
AppRegistry.registerComponent('customer', () => CustomerPage);
AppRegistry.registerComponent('goodsinfo', () => GoodsInfo);
AppRegistry.registerComponent('detailaddress', () => DetailAddress);
AppRegistry.registerComponent('about', () => About);
AppRegistry.registerComponent('cargoaddress', () => CargoAddress);
AppRegistry.registerComponent('waybilledit', () => WaybillEdit);
AppRegistry.registerComponent('approve', () => Approve);
AppRegistry.registerComponent('networkprotocol', () => networkProtocol); // 网络协议 默认先打开创建协议
AppRegistry.registerComponent('createordersetting', () => CreateOrderSetting);
AppRegistry.registerComponent('callrecords', () => callRecords); // 通话记录
AppRegistry.registerComponent('customermanagement', () => CustomerManagement); // 客户管理
