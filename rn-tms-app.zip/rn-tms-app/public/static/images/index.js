/**
 * 图标上传地址：https://boss.1111.com/public-service-admin/#/fileCenter/upload
 * bizType: static-image  （公有桶）
 * 文件目录：ymmfile/static/image/tms
 */

const IMAGES = {
  icon_input_search: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_input_search.png',
  icon_input_edit_cancel: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_input_edit_cancel.png',
  icon_arrow_gray: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_arrow_gray.png',
  icon_close: 'https://image.ymm56.com/ymmfile/operation-biz/26b70797-6688-439e-a065-614eba670a9b.png',
  icon_startAudit: 'https://image.ymm56.com/ymmfile/operation-biz/953df857-d70e-4000-8ce8-eaea8a2e9b58.png', // 审批中
  icon_auditing: 'https://image.ymm56.com/ymmfile/operation-biz/953df857-d70e-4000-8ce8-eaea8a2e9b58.png', // 审批中
  icon_audit_catch: 'https://image.ymm56.com/ymmfile/operation-biz/4cdec71e-b78a-4bbc-835c-ce091442a95e.png', // 已撤销
  icon_audit_reject: 'https://image.ymm56.com/ymmfile/operation-biz/5156e73f-5568-4456-85ee-e9dd8f60edde.png', // 已驳回
  icon_audit_end: 'https://image.ymm56.com/ymmfile/operation-biz/e12e8685-0df5-45d6-88a2-fc8667ed5480.png', //已完成
  longArrows: 'https://image.ymm56.com/ymmfile/operation-biz/e0dffaf4-3bf6-4786-a6a4-a673e3dd5a52.png',
  icon_add_circle: 'https://image.ymm56.com/ymmfile/operation-biz/09af8e84-f952-4d70-91d9-2083f06e6443.png',
  icon_del_circle: 'https://image.ymm56.com/ymmfile/operation-biz/cf601e5e-a2fe-4fa3-94d9-65ed8aef917f.png',
  logo_mybqy: 'https://cdn.ymm56.com/files/mybqy_2tmlb.png', // 满运宝企业 发票专票 标识
  logo_task_mybqy: { uri: 'https://cdn.ymm56.com/files/mybqy_2tmlb.png' }, // 满运宝企业 发票专票 标识
  icon_myb: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_myb.png', // 满运宝 发票普票 标识
  icon_bg_map: 'https://image.ymm56.com/ymmfile/operation-biz/93bd4c0e-2e33-490e-8fa4-8e306bda2a57.png', // 地图背景
  icon_solid_check: 'https://image.ymm56.com/ymmfile/operation-biz/5893e222-5f48-4692-a4b5-b33ba48e28b7.png', // 地图背景
  icon_send: 'https://image.ymm56.com/ymmfile/operation-biz/7e81428b-8eb3-4a6a-8693-a2f9a527e8f5.png', // 发
  icon_receive: 'https://image.ymm56.com/ymmfile/operation-biz/33468761-e2af-4bdc-9cc2-c0981a920aec.png', // 收
  icon_time: 'https://image.ymm56.com/ymmfile/operation-biz/16c4045a-4f4e-4a85-baaf-904c729d557e.png', // 时间
  detail_bg: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/c65a82c3-d4d7-450c-9fdf-33fe07f251bd.png' },
  icon_success_small: 'https://image.ymm56.com/ymmfile/operation-biz/cc58ff63-becf-4d61-a227-eaaf895f84f4.png',
  sortArrows: 'https://image.ymm56.com/ymmfile/operation-biz/3b56c458-20be-4cdc-a30c-b53785f249bf.png',
  sortArrowsApplicetion: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/3b56c458-20be-4cdc-a30c-b53785f249bf.png' },
  icon_shipper: 'https://image.ymm56.com/ymmfile/operation-biz/15bc804d-66cc-429a-a172-52d24bf68ffb.png', // 装
  icon_consignee: 'https://image.ymm56.com/ymmfile/operation-biz/0385e9bb-e63e-4755-843c-a7638546990a.png', // 卸
  icon_peopleGary: 'https://image.ymm56.com/ymmfile/operation-biz/d25984b1-2331-4c09-9f33-f48d57ebc098.png', // 人头像
  line_vertical: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/785bfb3f-1a67-4bb9-959c-aaa15d5150e8.png' }, // 过渡线
  icon_dashLine: 'https://image.ymm56.com/ymmfile/operation-biz/217ae0af-f6bb-4ec8-b797-58410ea800e6.png', // 灰竖线框
  icon_timeOrange: 'https://image.ymm56.com/ymmfile/operation-biz/2297ea02-31ef-4b3b-99ff-bc1bfcba0db8.png', // 橙色时间
  icon_addressBlue: 'https://image.ymm56.com/ymmfile/operation-biz/7ed5ffd3-f079-43ae-b0e5-26e5cf698c1c.png', // 蓝色地址
  icon_weixin: 'https://image.ymm56.com/ymmfile/operation-biz/c484aca6-05ad-46ad-b53a-71036662a075.png',
  icon_no_data: 'https://image.ymm56.com/ymmfile/operation-biz/ee0cff21-8376-474c-bb40-7e74866ad636.png', // 暂无数据
  icon_customerService: 'https://image.ymm56.com/ymmfile/operation-biz/b08697c2-0895-48bd-9349-636bca741ddc.png', // 客服
  icon_question: 'https://image.ymm56.com/ymmfile/operation-biz/36b0f5b9-b73e-4c20-9dc9-9c2fdea0e3a0.png', // 问号
  bg_approve: 'https://image.ymm56.com/ymmfile/operation-biz/2e40f451-5deb-4718-8833-16d7ef5fe708.png', // 审批功能
  companyName_icon: 'https://image.ymm56.com/ymmfile/operation-biz/c1e21620-db50-403d-aeb4-8500b5bba83c.png', //收发货单位
  icon_plus_sign: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_plus_sign.png', // 灰色 加号
  icon_arrow_up: 'https://image.ymm56.com/ymmfile/operation-biz/b50be8ac-d006-4e8a-bca8-1b7193ab3a36.png', // 向上灰色箭头
  icon_car_orange: 'https://image.ymm56.com/ymmfile/operation-biz/1197c737-fdd9-4375-8d76-db74ae162de7.png', // 向上灰色箭头
  icon_empty_data: 'https://image.ymm56.com/ymmfile/operation-biz/43215d82-c71b-4e84-938d-7c9bb2cf5dca.png', // 向上灰色箭头
  icon_hook_mark: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/0dbf7e71-365c-4438-9a56-6c07d14dfe1e.png' }, // 对号
  icon_cross_mark: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/3eb7e3f3-3dba-4735-b9e6-2fba6172cd81.png' }, // 叉号
  // tms图标新上传路径
  icon_pull_down: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_pull_down.png' }, // 向下灰色小三角
  icon_oil_card: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_oil_card.png' }, // 蓝色的油卡（卡片）
  icon_check_mark: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_check_mark.png' }, // 蓝色的对号
  icon_down: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_down.png' }, // 向下箭头
  icon_tips: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_tips.png' }, // 帮助提示;
  top_shadow: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/top_shadow.png' }, // 上部阴影;
  icon_circleSelect: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_circleSelect.png' }, // 未选择 钩
  icon_circleSelectCheck: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_circleSelectCheck.png' }, // 已选择 钩
  icon_checklist: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_checkList.png' }, // 清单
  icon_warning: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_warning.png' }, // 警告
  icon_readjust: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_readjust.png' }, // 拖拽调整
  icon_help: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_help.png' }, // 帮助
  icon_setting: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_setting.png' }, // 设置
  icon_more: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_more.png' }, // 更多 点点点
  icon_left_bule: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_left_bule.png' }, // 向右 蓝色箭头
  icon_warning_yellow: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_warning_yellow.png' }, // 黄色警告
  icon_selected_circle: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_selected.png' }, // 已选择
  icon_price_chart: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon-price-chart.png' }, // 折线图
  icon_telephone: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/9c66dfe7-9797-49bd-bb04-bd7b4a9ab623.png' }, // 电话
  icon_copy: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/1a7f2689-947b-4b9b-a9f3-6967fd41cd3c.png' }, // 复制
  icon_position: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_position.png' }, // 定位
  icon_clear: { uri: 'https://image.ymm56.com/ymmfile/operation-biz/2efce668-ddc6-4cd2-ac05-cadd78107da9.png' }, // 灰底叉叉
  icon_goBack: 'https://image.ymm56.com/ymmfile/operation-biz/f6b9468b-5324-4eb6-a862-f3c7495c4792.png', // 向左箭头
  icon_combined_billing: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/image/tms/combined_billing.png' }, // 合并计费
  icon_grey_no_data: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/noDataImg.png' }, // 灰色暂无数据
  icon_long_gray_arrow: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/long-gray-arrow.png' }, // 灰色长箭头
  blueGradient: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/blueGradient.png' },
  sealDriver: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/seal_driver.png' }, // 待司机确认
  sealOwner: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/seal_owner.png' }, // 待货主确认
  sealConfirmed: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/seal_confirmed.png' }, // 已确认
  sealRejected: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/seal_rejected.png' }, // 已拒绝
  sealCancelled: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/seal_cancelled.png' }, // 已取消
  iconDriverLicense: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_driver_license.png' }, // 驾驶证
  icon_success: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_success.png' },
  icon_checkoub_disabled: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_checkbox_disabled.png' },
  icon_check_gray: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_check_gray.png' }, // 勾选 灰色
  default_avatar: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/default_avatar.png' }, // 默认头像
  icon_telephone2: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_telephone.png' }, // 电话
  icon_unselected: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/unselected.png' }, // 选择框未勾选
  icon_selected: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/selected.png' }, // 选择框勾选
  dealNumberHeaderbg: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/dealNumberHeaderbg.png' }, // 背景图片
  btn_buleBg: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/btn-buleBg.png' }, // 按钮背景
  icon_safe: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_safe.png' }, // 安全号图标
  connect_in: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/connect_in.png' }, //
  connect_out: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/connect_out.png' }, //
  not_connect_in: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/not_connect_in.png' }, //
  not_connect_out: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/not_connect_out.png' }, //
  icon_telephone_w: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_telephone_w.png' }, //
  icon_selected_point: { uri: 'https://imagecdn.ymm56.com/ymmfile/static/image/tms/icon_selected_point.png' }, //
};

module.exports = {
  ...IMAGES,
};
